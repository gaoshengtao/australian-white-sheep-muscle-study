#!/usr/bin/env python3
import argparse, pathlib
p = argparse.ArgumentParser(description='Configure project paths in copied analysis scripts.')
p.add_argument('--root', required=True, help='Australian White sheep project root')
p.add_argument('--hmdb-root', default='', help='Optional local HMDB database root')
a = p.parse_args()
base = pathlib.Path(__file__).resolve().parent
for f in base.rglob('*'):
    if f.suffix.lower() not in {'.r', '.py', '.sh'} or f.name == pathlib.Path(__file__).name: continue
    s = f.read_text(encoding='utf-8')
    s = s.replace('__PROJECT_ROOT__', a.root.rstrip('/'))
    if a.hmdb_root: s = s.replace('__HMDB_ROOT__', a.hmdb_root.rstrip('/'))
    f.write_text(s, encoding='utf-8')
print('Configured analysis scripts under', base)
