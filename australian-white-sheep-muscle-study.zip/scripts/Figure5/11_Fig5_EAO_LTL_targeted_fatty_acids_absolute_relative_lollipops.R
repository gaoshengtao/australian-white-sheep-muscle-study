#!/usr/bin/env Rscript

# Figure 5 targeted-fatty-acid differential analysis and lollipop plots.
# Two complementary scales are analysed using the same paired design:
#   1) absolute content (ug/mg);
#   2) relative percentage of total quantified fatty acids in each sample.
# Primary test: abundance ~ Animal + Site (randomized-block/repeated-measures
# ANOVA), equivalent to the paired t-test for two within-animal sites.
# Positive log2FC denotes LTL enrichment; negative denotes EAO enrichment.

rm(list = ls())

suppressPackageStartupMessages({
  library(openxlsx)
  library(ggplot2)
  library(svglite)
})

project_dir <- "__PROJECT_ROOT__"
work_dir <- file.path(project_dir, "11_Figure5_EAO_LTL_meat_color")
input_file <- file.path(project_dir, "02_fatty_acids", "fatty acids.xlsx")
table_dir <- file.path(work_dir, "Tables")
figure_dir <- file.path(work_dir, "Figures")
dir.create(table_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(figure_dir, recursive = TRUE, showWarnings = FALSE)

eao_samples <- paste0("AM_", 1:6)
ltl_samples <- paste0("LT_", 1:6)
sample_order <- c(eao_samples, ltl_samples)
site_order <- c("EAO", "LTL")

# Match Figure 4H/I: color encodes saturation; tone encodes FDR status.
deep_colors <- c(SFA = "#355C8A", MUFA = "#C28B48", PUFA = "#A65D68")

write_tsv <- function(x, filename) {
  write.table(
    x, file.path(table_dir, filename), sep = "\t", quote = FALSE,
    row.names = FALSE, na = "NA"
  )
}

significance_symbol <- function(q) {
  ifelse(
    is.na(q), "NA",
    ifelse(q < 0.001, "***", ifelse(q < 0.01, "**", ifelse(q < 0.05, "*", "n.s.")))
  )
}

safe_shapiro <- function(x) {
  if (length(x) < 3L || stats::sd(x) == 0) return(NA_real_)
  tryCatch(stats::shapiro.test(x)$p.value, error = function(e) NA_real_)
}

if (!file.exists(input_file)) stop("Input file not found: ", input_file)
measurement <- read.xlsx(
  input_file, sheet = "measurement.xls", check.names = FALSE,
  detectDates = FALSE, skipEmptyRows = FALSE
)
annotation <- read.xlsx(
  input_file, sheet = "其他信息", check.names = FALSE,
  detectDates = FALSE, skipEmptyRows = FALSE
)

required_columns <- c(
  "Metabolite", "CAS.id", "Formula", "KEGG.Compound.ID", "unit",
  "Retention.time", sample_order
)
missing_columns <- setdiff(required_columns, names(measurement))
if (length(missing_columns)) stop("Missing columns: ", paste(missing_columns, collapse = ", "))
if (nrow(measurement) != nrow(annotation)) {
  stop("Measurement and annotation sheets have different row counts")
}
if (max(abs(measurement$Retention.time - annotation[["RT/min"]])) > 1e-10) {
  stop("Measurement and annotation sheets are not aligned by retention time")
}
if (anyDuplicated(measurement$Metabolite) || anyDuplicated(annotation$Metabolite)) {
  stop("Duplicated metabolite or fatty-acid names")
}
if (length(unique(measurement$unit)) != 1L || unique(measurement$unit) != "ug/mg") {
  stop("Expected one absolute-content unit: ug/mg")
}

absolute_matrix <- as.matrix(measurement[, sample_order, drop = FALSE])
storage.mode(absolute_matrix) <- "double"
rownames(absolute_matrix) <- annotation$Metabolite
if (any(!is.finite(absolute_matrix)) || any(absolute_matrix < 0)) {
  stop("Absolute matrix contains missing, non-finite or negative values")
}

sample_totals <- colSums(absolute_matrix)
if (any(sample_totals <= 0)) stop("At least one sample has zero total fatty acids")
relative_matrix <- sweep(absolute_matrix, 2, sample_totals, "/") * 100
if (max(abs(colSums(relative_matrix) - 100)) > 1e-8) {
  stop("Relative percentages do not sum to 100")
}

parse_saturation <- function(fatty_acid) {
  unsaturation_text <- sub("^[^:]+:", "", fatty_acid)
  double_bonds <- suppressWarnings(as.integer(sub("^([0-9]+).*$", "\\1", unsaturation_text)))
  if (!is.finite(double_bonds)) stop("Cannot parse unsaturation: ", fatty_acid)
  list(
    double_bonds = double_bonds,
    saturation_class = if (double_bonds == 0L) "SFA" else if (double_bonds == 1L) "MUFA" else "PUFA"
  )
}

analyse_scale <- function(value_matrix, scale_name, value_column, unit_text) {
  result_rows <- vector("list", nrow(value_matrix))
  long_rows <- vector("list", nrow(value_matrix))

  for (i in seq_len(nrow(value_matrix))) {
    eao <- as.numeric(value_matrix[i, eao_samples])
    ltl <- as.numeric(value_matrix[i, ltl_samples])
    paired_difference <- ltl - eao
    testable <- length(unique(c(eao, ltl))) > 1L && stats::sd(paired_difference) > 0
    sat <- parse_saturation(annotation$Metabolite[i])

    long_data <- data.frame(
      Fatty_acid = annotation$Metabolite[i],
      Metabolite = measurement$Metabolite[i],
      Animal = factor(rep(seq_len(6L), times = 2L)),
      Site = factor(rep(site_order, each = 6L), levels = site_order),
      Value = c(eao, ltl),
      Scale = scale_name,
      stringsAsFactors = FALSE
    )
    names(long_data)[names(long_data) == "Value"] <- value_column
    long_rows[[i]] <- long_data

    anova_f <- anova_p <- paired_t <- paired_t_p <- wilcoxon_v <- wilcoxon_p <- NA_real_
    if (testable) {
      model_data <- long_data
      names(model_data)[names(model_data) == value_column] <- "Response"
      fit <- stats::lm(Response ~ Animal + Site, data = model_data)
      anova_table <- stats::anova(fit)
      anova_f <- unname(anova_table["Site", "F value"])
      anova_p <- unname(anova_table["Site", "Pr(>F)"])
      paired_t_result <- stats::t.test(ltl, eao, paired = TRUE, alternative = "two.sided")
      paired_t <- unname(paired_t_result$statistic)
      paired_t_p <- paired_t_result$p.value
      wilcoxon_result <- suppressWarnings(stats::wilcox.test(
        ltl, eao, paired = TRUE, alternative = "two.sided",
        exact = FALSE, correct = FALSE
      ))
      wilcoxon_v <- unname(wilcoxon_result$statistic)
      wilcoxon_p <- wilcoxon_result$p.value
    }

    mean_eao <- mean(eao)
    mean_ltl <- mean(ltl)
    log2fc <- if (mean_eao > 0 && mean_ltl > 0) log2(mean_ltl / mean_eao) else NA_real_
    ci_half <- if (stats::sd(paired_difference) > 0) {
      stats::qt(0.975, df = 5L) * stats::sd(paired_difference) / sqrt(6)
    } else {
      NA_real_
    }

    result_rows[[i]] <- data.frame(
      Original_order = i,
      Fatty_acid = annotation$Metabolite[i],
      Metabolite = measurement$Metabolite[i],
      Saturation_class = sat$saturation_class,
      Double_bonds = sat$double_bonds,
      CAS_ID = measurement$CAS.id[i],
      Formula = measurement$Formula[i],
      KEGG_Compound_ID = measurement$KEGG.Compound.ID[i],
      Unit = unit_text,
      Retention_time = measurement$Retention.time[i],
      N_pairs = 6L,
      Number_nonzero_EAO = sum(eao > 0),
      Number_nonzero_LTL = sum(ltl > 0),
      Mean_EAO = mean_eao,
      SD_EAO = stats::sd(eao),
      Mean_LTL = mean_ltl,
      SD_LTL = stats::sd(ltl),
      log2FC_LTL_vs_EAO = log2fc,
      Mean_paired_difference_LTL_minus_EAO = mean(paired_difference),
      Lower_95CI_paired_difference = mean(paired_difference) - ci_half,
      Upper_95CI_paired_difference = mean(paired_difference) + ci_half,
      Direction = ifelse(
        mean(paired_difference) > 0, "Higher in LTL",
        ifelse(mean(paired_difference) < 0, "Higher in EAO", "No difference")
      ),
      Testable = testable,
      Paired_ANOVA_F = anova_f,
      Paired_ANOVA_raw_P = anova_p,
      Paired_t = paired_t,
      Paired_t_raw_P = paired_t_p,
      Shapiro_P_paired_differences = safe_shapiro(paired_difference),
      Paired_Wilcoxon_V = wilcoxon_v,
      Paired_Wilcoxon_raw_P = wilcoxon_p,
      stringsAsFactors = FALSE
    )
  }

  results <- do.call(rbind, result_rows)
  long_data <- do.call(rbind, long_rows)
  testable_idx <- which(results$Testable & is.finite(results$Paired_ANOVA_raw_P))
  results$Paired_ANOVA_FDR_BH <- NA_real_
  results$Paired_ANOVA_FDR_BH[testable_idx] <- stats::p.adjust(
    results$Paired_ANOVA_raw_P[testable_idx], method = "BH"
  )
  results$Paired_ANOVA_significance <- significance_symbol(results$Paired_ANOVA_FDR_BH)
  results$Paired_ANOVA_FDR_lt_0.05 <-
    !is.na(results$Paired_ANOVA_FDR_BH) & results$Paired_ANOVA_FDR_BH < 0.05

  wilcoxon_idx <- which(results$Testable & is.finite(results$Paired_Wilcoxon_raw_P))
  results$Paired_Wilcoxon_FDR_BH <- NA_real_
  results$Paired_Wilcoxon_FDR_BH[wilcoxon_idx] <- stats::p.adjust(
    results$Paired_Wilcoxon_raw_P[wilcoxon_idx], method = "BH"
  )

  plot_data <- results[
    results$Testable & is.finite(results$log2FC_LTL_vs_EAO), , drop = FALSE
  ]
  plot_data <- plot_data[
    order(plot_data$log2FC_LTL_vs_EAO, plot_data$Original_order), , drop = FALSE
  ]
  plot_data$Fatty_acid <- factor(plot_data$Fatty_acid, levels = plot_data$Fatty_acid)
  plot_data$Saturation_class <- factor(
    plot_data$Saturation_class, levels = c("SFA", "MUFA", "PUFA")
  )
  plot_data$Significance <- factor(
    ifelse(plot_data$Paired_ANOVA_FDR_lt_0.05, "FDR < 0.05", "FDR >= 0.05"),
    levels = c("FDR < 0.05", "FDR >= 0.05")
  )

  list(results = results, plot_data = plot_data, long_data = long_data)
}

absolute <- analyse_scale(
  absolute_matrix, "Absolute content", "Absolute_content_ug_mg", "ug/mg"
)
relative <- analyse_scale(
  relative_matrix, "Relative percentage", "Relative_percentage",
  "% of total quantified fatty acids"
)

make_plot <- function(plot_data, y_label) {
  ggplot(plot_data, aes(x = Fatty_acid, y = log2FC_LTL_vs_EAO)) +
    geom_hline(yintercept = 0, color = "#44484C", linewidth = 0.45) +
    geom_segment(
      aes(
        xend = Fatty_acid, y = 0, yend = log2FC_LTL_vs_EAO,
        color = Saturation_class, alpha = Significance
      ),
      linewidth = 0.82, lineend = "round"
    ) +
    geom_point(
      aes(color = Saturation_class, alpha = Significance), size = 2.65
    ) +
    scale_color_manual(
      values = deep_colors, breaks = c("SFA", "MUFA", "PUFA"),
      name = "Saturation"
    ) +
    scale_alpha_manual(
      values = c("FDR < 0.05" = 1, "FDR >= 0.05" = 0.28),
      breaks = c("FDR < 0.05", "FDR >= 0.05"),
      labels = c("FDR < 0.05", "FDR >= 0.05"),
      name = "Paired ANOVA", drop = FALSE
    ) +
    scale_y_continuous(expand = expansion(mult = c(0.08, 0.10))) +
    labs(x = "Fatty acid", y = y_label) +
    theme_bw(base_size = 10.5, base_family = "Arial") +
    theme(
      panel.grid.minor = element_blank(),
      panel.grid.major.x = element_blank(),
      panel.grid.major.y = element_line(color = "#E3E5E7", linewidth = 0.30),
      panel.border = element_rect(color = "#303337", linewidth = 0.50),
      axis.text.x = element_text(
        angle = 90, hjust = 1, vjust = 0.5, color = "#30363D", size = 7.8
      ),
      axis.text.y = element_text(color = "#30363D", size = 8.5),
      axis.title = element_text(color = "#1F2328", size = 10.5),
      axis.title.x = element_text(margin = margin(t = 7)),
      axis.title.y = element_text(margin = margin(r = 7)),
      legend.position = "top",
      legend.direction = "horizontal",
      legend.box = "horizontal",
      legend.title = element_text(size = 8.8),
      legend.text = element_text(size = 8.5),
      legend.key = element_blank(),
      plot.margin = margin(5, 7, 5, 7)
    ) +
    guides(
      color = guide_legend(order = 1, override.aes = list(alpha = 1, size = 2.8)),
      alpha = guide_legend(order = 2, override.aes = list(color = "#4D5358", size = 2.8))
    )
}

p_absolute <- make_plot(
  absolute$plot_data,
  expression(log[2] * "FC of absolute content (LTL / EAO)")
)
p_relative <- make_plot(
  relative$plot_data,
  expression(log[2] * "FC of relative proportion (LTL / EAO)")
)

save_plot <- function(plot_object, base_name) {
  stub <- file.path(figure_dir, base_name)
  plot_width <- 10.5
  plot_height <- 4.8
  ggsave(
    paste0(stub, ".pdf"), plot_object, device = cairo_pdf,
    width = plot_width, height = plot_height, units = "in", family = "Arial"
  )
  ggsave(
    paste0(stub, ".png"), plot_object,
    width = plot_width, height = plot_height, units = "in", dpi = 600, bg = "white"
  )
  svglite::svglite(
    paste0(stub, ".svg"), width = plot_width, height = plot_height,
    system_fonts = list(sans = "Arial")
  )
  print(plot_object)
  dev.off()
}

absolute_base <- "Fig5_EAO_LTL_targeted_fatty_acids_absolute_saturation_log2FC_lollipop"
relative_base <- "Fig5_EAO_LTL_targeted_fatty_acids_relative_percentage_saturation_log2FC_lollipop"
save_plot(p_absolute, absolute_base)
save_plot(p_relative, relative_base)

make_summary <- function(results, scale_label) {
  data.frame(
    Scale = scale_label,
    Metric = c(
      "Fatty acids measured", "Fatty acids testable/plotted", "All-zero/not-testable",
      "Paired ANOVA raw P < 0.05", "Paired ANOVA BH-FDR < 0.05",
      "FDR < 0.05 higher in EAO", "FDR < 0.05 higher in LTL",
      "SFA plotted", "MUFA plotted", "PUFA plotted"
    ),
    Value = c(
      nrow(results), sum(results$Testable & is.finite(results$log2FC_LTL_vs_EAO)),
      sum(!results$Testable), sum(results$Paired_ANOVA_raw_P < 0.05, na.rm = TRUE),
      sum(results$Paired_ANOVA_FDR_lt_0.05),
      sum(results$Paired_ANOVA_FDR_lt_0.05 & results$Direction == "Higher in EAO"),
      sum(results$Paired_ANOVA_FDR_lt_0.05 & results$Direction == "Higher in LTL"),
      sum(results$Saturation_class == "SFA" & results$Testable),
      sum(results$Saturation_class == "MUFA" & results$Testable),
      sum(results$Saturation_class == "PUFA" & results$Testable)
    ),
    stringsAsFactors = FALSE
  )
}

summary_table <- rbind(
  make_summary(absolute$results, "Absolute content"),
  make_summary(relative$results, "Relative percentage")
)
sample_total_table <- data.frame(
  Sample = sample_order,
  Site = rep(site_order, each = 6L),
  Animal = rep(1:6, times = 2L),
  Total_fatty_acid_ug_mg = sample_totals,
  Sum_relative_percentage = colSums(relative_matrix),
  stringsAsFactors = FALSE
)
qa <- data.frame(
  Item = c(
    "Input", "Comparison", "Pairs", "Primary models", "Multiple testing",
    "Significance", "log2FC direction", "Saturation classification",
    "Fatty-acid order", "Absolute scale", "Relative scale caveat", "Font"
  ),
  Value = c(
    input_file, "EAO vs LTL paired within Animal", 6,
    "absolute or relative abundance ~ Animal + Site",
    "BH separately across all testable fatty acids within each scale",
    "paired ANOVA FDR < 0.05; nonsignificant points shown with lower alpha",
    "positive = higher in LTL; negative = higher in EAO",
    "0 double bonds=SFA; 1=MUFA; >=2=PUFA",
    "ascending log2FC(LTL/EAO)", "raw absolute content (ug/mg)",
    "percentages sum to 100; a relative increase can reflect decreases in other fatty acids",
    "Arial"
  ),
  stringsAsFactors = FALSE
)

export_plot_data <- function(x) {
  z <- x
  z$Fatty_acid <- as.character(z$Fatty_acid)
  z$Saturation_class <- as.character(z$Saturation_class)
  z$Significance <- as.character(z$Significance)
  z
}
absolute_plot_export <- export_plot_data(absolute$plot_data)
relative_plot_export <- export_plot_data(relative$plot_data)

write_tsv(absolute$results, "Fig5_EAO_LTL_targeted_fatty_acids_absolute_paired_ANOVA_all_results.tsv")
write_tsv(
  absolute$results[absolute$results$Paired_ANOVA_FDR_lt_0.05, , drop = FALSE],
  "Fig5_EAO_LTL_targeted_fatty_acids_absolute_paired_ANOVA_FDR_lt_0.05.tsv"
)
write_tsv(absolute_plot_export, paste0(absolute_base, "_plot_data.tsv"))
write_tsv(relative$results, "Fig5_EAO_LTL_targeted_fatty_acids_relative_paired_ANOVA_all_results.tsv")
write_tsv(
  relative$results[relative$results$Paired_ANOVA_FDR_lt_0.05, , drop = FALSE],
  "Fig5_EAO_LTL_targeted_fatty_acids_relative_paired_ANOVA_FDR_lt_0.05.tsv"
)
write_tsv(relative_plot_export, paste0(relative_base, "_plot_data.tsv"))
write_tsv(summary_table, "Fig5_EAO_LTL_targeted_fatty_acids_lollipop_summary.tsv")
write_tsv(sample_total_table, "Fig5_EAO_LTL_targeted_fatty_acids_relative_sample_totals.tsv")
write_tsv(qa, "Fig5_EAO_LTL_targeted_fatty_acids_lollipop_QA.tsv")

write.xlsx(
  list(
    Summary = summary_table,
    Absolute_FDR_significant = absolute$results[
      absolute$results$Paired_ANOVA_FDR_lt_0.05, , drop = FALSE
    ],
    Absolute_all_results = absolute$results,
    Absolute_plot_data = absolute_plot_export,
    Relative_FDR_significant = relative$results[
      relative$results$Paired_ANOVA_FDR_lt_0.05, , drop = FALSE
    ],
    Relative_all_results = relative$results,
    Relative_plot_data = relative_plot_export,
    Sample_totals = sample_total_table,
    QA = qa
  ),
  file.path(
    table_dir,
    "Fig5_EAO_LTL_targeted_fatty_acids_absolute_relative_lollipop_results.xlsx"
  ),
  overwrite = TRUE, asTable = TRUE
)

message(
  "Done. Absolute FDR < 0.05: ", sum(absolute$results$Paired_ANOVA_FDR_lt_0.05),
  " (EAO ", sum(absolute$results$Paired_ANOVA_FDR_lt_0.05 & absolute$results$Direction == "Higher in EAO"),
  "; LTL ", sum(absolute$results$Paired_ANOVA_FDR_lt_0.05 & absolute$results$Direction == "Higher in LTL"),
  "). Relative FDR < 0.05: ", sum(relative$results$Paired_ANOVA_FDR_lt_0.05),
  " (EAO ", sum(relative$results$Paired_ANOVA_FDR_lt_0.05 & relative$results$Direction == "Higher in EAO"),
  "; LTL ", sum(relative$results$Paired_ANOVA_FDR_lt_0.05 & relative$results$Direction == "Higher in LTL"), ")."
)
