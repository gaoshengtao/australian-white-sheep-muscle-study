#!/usr/bin/env Rscript

# Figure 5D/E: integrated RNA-protein preranked KEGG GSEA for EAO versus LTL
# meat-colour biology.
#
# Ranking construction follows Figure 3D/E exactly:
#   - use all RNA and protein features from the paired EAO/LTL contrasts;
#   - map sheep gene symbols to human Entrez IDs;
#   - average same-direction RNA/protein log2FC values;
#   - when RNA and protein directions conflict, retain the observation with
#     the smaller raw P value (largest absolute log2FC breaks exact ties);
#   - positive rank = LTL enriched; negative rank = EAO enriched.
#
# Candidate KEGG pathways/modules were prespecified around six meat-colour
# processes: postmortem glycolysis/pH, mitochondrial oxygen consumption,
# heme/pigment biology, reducing/antioxidant capacity, lipid oxidation, and
# structural light scattering. No differential-gene prefilter is applied.

rm(list = ls())

suppressPackageStartupMessages({
  library(AnnotationDbi)
  library(clusterProfiler)
  library(enrichplot)
  library(ggplot2)
  library(KEGGREST)
  library(openxlsx)
  library(org.Hs.eg.db)
  library(patchwork)
})

options(stringsAsFactors = FALSE, timeout = 900)
set.seed(20260909)

project_dir <- "__PROJECT_ROOT__"
work_dir <- file.path(project_dir, "11_Figure5_EAO_LTL_meat_color")
source_dir <- file.path(
  project_dir, "07_Figure2_muscle_functional_states",
  "03_One_vs_rest_specificity", "Tables"
)
table_dir <- file.path(work_dir, "Tables")
figure_dir <- file.path(
  work_dir, "Figures", "Fig5_EAO_LTL_meat_color_KEGG_GSEA"
)
dir.create(table_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(figure_dir, recursive = TRUE, showWarnings = FALSE)

rna_file <- file.path(
  source_dir,
  "Fig2_muscle_fiber_pairwise_transcriptome_DESeq2_all_gene_results.tsv.gz"
)
protein_file <- file.path(
  source_dir,
  "Fig2_muscle_fiber_pairwise_proteome_limma_all_gene_results.tsv.gz"
)
stopifnot(file.exists(rna_file), file.exists(protein_file))

comparison <- "LTL_vs_EAO"
# Use the site colours fixed throughout Figures 1-5.
site_colors <- c(LTL = "#355C8A", EAO = "#A65D68")
omics_order <- c("Transcriptome", "Proteome")

write_tsv <- function(x, filename) {
  write.table(
    x, file.path(table_dir, filename), sep = "\t", quote = FALSE,
    row.names = FALSE, na = "NA"
  )
}
write_gz_tsv <- function(x, filename) {
  con <- gzfile(file.path(table_dir, filename), open = "wt")
  on.exit(close(con), add = TRUE)
  write.table(x, con, sep = "\t", quote = FALSE, row.names = FALSE, na = "NA")
}
clean_text <- function(x) {
  x <- trimws(as.character(x)); x[is.na(x)] <- ""; x
}
safe_filename <- function(x, max_length = 130L) {
  x <- gsub("[^A-Za-z0-9._-]+", "_", x)
  x <- gsub("_+", "_", x)
  substr(gsub("^_|_$", "", x), 1L, max_length)
}
bind_nonempty <- function(x) {
  x <- x[vapply(x, nrow, integer(1)) > 0L]
  if (!length(x)) return(data.frame())
  out <- do.call(rbind, x); rownames(out) <- NULL; out
}

# -------------------------------------------------------------------------
# 1. Prespecified meat-colour-relevant KEGG sets
# -------------------------------------------------------------------------
pathway_manifest <- data.frame(
  Set_type = "PATHWAY",
  Set_ID = c(
    "hsa00500", "hsa00010", "hsa00620", "hsa04066", "hsa04152",
    "hsa00020", "hsa00190", "hsa04714", "hsa00130", "hsa00071",
    "hsa00860", "hsa00030", "hsa00480", "hsa00760", "hsa04146",
    "hsa04216", "hsa00230", "hsa04020", "hsa04512", "hsa04510",
    "hsa04820", "hsa04810"
  ),
  Mechanism_axis = c(
    rep("Postmortem glycolysis and pH", 5),
    rep("Mitochondrial oxygen consumption", 5),
    "Heme and pigment supply",
    rep("Reducing and antioxidant capacity", 5),
    "ATP and nucleotide turnover", "Calcium-dependent contraction",
    rep("Structural light scattering", 4)
  ),
  Mechanistic_order = c(
    1, 2, 3, 4, 4,
    5, 6, 6, 5, 5,
    3,
    2, 4, 4, 4, 5,
    1, 2,
    6, 6, 6, 6
  ),
  Interpretation_role = c(
    "Glycogen substrate availability",
    "Lactate-forming glycolytic potential",
    "Pyruvate-lactate/acetyl-CoA branch point",
    "Hypoxia-responsive glycolytic regulation",
    "Energy-sensing regulation of glycolysis and oxidation",
    "Reducing equivalents and respiratory substrate oxidation",
    "Mitochondrial oxygen consumption and ATP generation",
    "Mitochondrial respiration-related programme",
    "Electron transport cofactor supply",
    "Respiratory substrate supply and lipid oxidation pressure",
    "Heme synthesis and turnover; not myoglobin abundance alone",
    "NADPH supply for reducing systems",
    "Glutathione-dependent antioxidant capacity",
    "NAD/NADH redox cofactor metabolism",
    "Peroxide control and fatty-acid oxidation",
    "Lipid peroxidation/iron-dependent oxidative damage",
    "ATP degradation and postmortem nucleotide turnover",
    "Contraction, calcium handling and structural shrinkage",
    "Extracellular matrix contribution to optical scattering",
    "Cell-matrix force transmission and spacing",
    "Sarcomere/cytoskeleton architecture affecting scattering",
    "Actin architecture and structural spacing"
  ),
  stringsAsFactors = FALSE
)

module_manifest <- data.frame(
  Set_type = "MODULE",
  Set_ID = c(
    "M00854", "M00855", "M00001", "M00002", "M00307",
    "M00009", "M00128", "M00087", "M00142", "M00148", "M00151",
    "M00154", "M00158", "M00868", "M00004", "M00006", "M00118",
    "M00912"
  ),
  Mechanism_axis = c(
    rep("Postmortem glycolysis and pH", 5),
    rep("Mitochondrial oxygen consumption", 8),
    "Heme and pigment supply",
    rep("Reducing and antioxidant capacity", 4)
  ),
  Mechanistic_order = c(
    1, 1, 2, 2, 3,
    5, 5, 5, 6, 6, 6, 6, 6,
    3,
    2, 2, 4, 4
  ),
  Interpretation_role = c(
    "Glycogen storage potential",
    "Glycogen mobilisation into glycolysis",
    "Complete glucose-to-pyruvate glycolysis",
    "Core lower glycolysis",
    "Pyruvate entry into mitochondrial acetyl-CoA",
    "TCA-cycle reducing-equivalent supply",
    "Ubiquinone synthesis for electron transfer",
    "Fatty-acid beta-oxidation substrate supply",
    "Mitochondrial respiratory complex I",
    "Respiratory complex II",
    "Respiratory complex III",
    "Respiratory complex IV and oxygen reduction",
    "ATP synthase",
    "Animal heme biosynthesis",
    "Pentose phosphate NADPH/ribose production",
    "Oxidative pentose phosphate NADPH production",
    "Glutathione biosynthesis",
    "Tryptophan-derived NAD biosynthesis"
  ),
  stringsAsFactors = FALSE
)

# -------------------------------------------------------------------------
# 2. Build the all-gene integrated LTL-versus-EAO rank
# -------------------------------------------------------------------------
rna <- read.delim(gzfile(rna_file), check.names = FALSE, quote = "", comment.char = "")
protein <- read.delim(gzfile(protein_file), check.names = FALSE, quote = "", comment.char = "")
required <- c("Gene_symbol", "Comparison", "log2FoldChange", "P_value")
if (length(setdiff(required, names(rna))) || length(setdiff(required, names(protein)))) {
  stop("RNA or protein result table lacks required columns.")
}
rna <- rna[rna$Comparison == comparison, , drop = FALSE]
protein <- protein[protein$Comparison == comparison, , drop = FALSE]

make_source <- function(d, omics) {
  source_id <- if (omics == "Transcriptome" && "gene_id" %in% names(d)) {
    as.character(d$gene_id)
  } else if (omics == "Proteome" && "Protein_row" %in% names(d)) {
    as.character(d$Protein_row)
  } else if ("Human_Entrez_ID" %in% names(d)) {
    as.character(d$Human_Entrez_ID)
  } else {
    as.character(seq_len(nrow(d)))
  }
  data.frame(
    Omics = omics,
    Source_feature_ID = source_id,
    Input_Gene_symbol = clean_text(d$Gene_symbol),
    log2FC_LTL_vs_EAO = as.numeric(d$log2FoldChange),
    Raw_P = as.numeric(d$P_value),
    Source_FDR = as.numeric(d$P_FDR_BH),
    stringsAsFactors = FALSE
  )
}
source_all <- rbind(make_source(rna, "Transcriptome"), make_source(protein, "Proteome"))
source_all <- source_all[
  nzchar(source_all$Input_Gene_symbol) & is.finite(source_all$log2FC_LTL_vs_EAO) &
    is.finite(source_all$Raw_P), , drop = FALSE
]

symbol_map <- AnnotationDbi::select(
  org.Hs.eg.db, keys = sort(unique(source_all$Input_Gene_symbol)),
  keytype = "SYMBOL", columns = c("SYMBOL", "ENTREZID")
)
symbol_map <- unique(symbol_map[
  !is.na(symbol_map$ENTREZID) & nzchar(symbol_map$ENTREZID),
  c("SYMBOL", "ENTREZID"), drop = FALSE
])
names(symbol_map) <- c("Human_Gene_symbol", "Human_Entrez_ID")
ambiguous <- names(which(table(symbol_map$Human_Gene_symbol) > 1L))
symbol_map <- symbol_map[!symbol_map$Human_Gene_symbol %in% ambiguous, , drop = FALSE]

mapped <- merge(
  source_all, symbol_map, by.x = "Input_Gene_symbol",
  by.y = "Human_Gene_symbol", all = FALSE, sort = FALSE
)
mapped$Direction <- ifelse(
  mapped$log2FC_LTL_vs_EAO > 0, "LTL",
  ifelse(mapped$log2FC_LTL_vs_EAO < 0, "EAO", "Zero")
)

resolve_rows <- function(z, level) {
  dirs <- unique(z$Direction[z$Direction != "Zero"])
  conflict <- length(dirs) > 1L
  z <- z[order(z$Raw_P, -abs(z$log2FC_LTL_vs_EAO), z$Omics), ]
  if (conflict) {
    selected <- z[1, , drop = FALSE]
    effect <- selected$log2FC_LTL_vs_EAO
    rule <- "direction conflict: selected smallest raw P"
    sources <- paste(selected$Omics, selected$Source_feature_ID, sep = ":")
  } else {
    selected <- z[1, , drop = FALSE]
    effect <- mean(z$log2FC_LTL_vs_EAO)
    rule <- if (nrow(z) > 1L) "same direction: mean log2FC" else "single observation"
    sources <- paste(paste(z$Omics, z$Source_feature_ID, sep = ":"), collapse = ";")
  }
  data.frame(
    Human_Entrez_ID = selected$Human_Entrez_ID,
    Human_Gene_symbol = selected$Input_Gene_symbol,
    Integrated_log2FC_LTL_vs_EAO = effect,
    Minimum_raw_P = min(z$Raw_P),
    Direction_conflict = conflict,
    Resolution_rule = rule,
    Resolution_level = level,
    Observation_count = nrow(z),
    Omics_membership = paste(omics_order[omics_order %in% unique(z$Omics)], collapse = ";"),
    RNA_log2FC = if (any(z$Omics == "Transcriptome"))
      mean(z$log2FC_LTL_vs_EAO[z$Omics == "Transcriptome"]) else NA_real_,
    Protein_log2FC = if (any(z$Omics == "Proteome"))
      mean(z$log2FC_LTL_vs_EAO[z$Omics == "Proteome"]) else NA_real_,
    Selected_or_averaged_sources = sources,
    stringsAsFactors = FALSE
  )
}

within_keys <- interaction(mapped$Omics, mapped$Human_Entrez_ID, drop = TRUE, lex.order = TRUE)
within_resolved <- bind_nonempty(lapply(split(mapped, within_keys), resolve_rows, level = "within omics"))
within_for_integration <- data.frame(
  Omics = sub(";.*$", "", within_resolved$Omics_membership),
  Source_feature_ID = within_resolved$Selected_or_averaged_sources,
  Input_Gene_symbol = within_resolved$Human_Gene_symbol,
  Human_Entrez_ID = within_resolved$Human_Entrez_ID,
  log2FC_LTL_vs_EAO = within_resolved$Integrated_log2FC_LTL_vs_EAO,
  Raw_P = within_resolved$Minimum_raw_P,
  Direction = ifelse(within_resolved$Integrated_log2FC_LTL_vs_EAO > 0, "LTL",
                     ifelse(within_resolved$Integrated_log2FC_LTL_vs_EAO < 0, "EAO", "Zero")),
  stringsAsFactors = FALSE
)
integrated <- bind_nonempty(lapply(
  split(within_for_integration, within_for_integration$Human_Entrez_ID),
  resolve_rows, level = "between omics"
))
integrated <- integrated[is.finite(integrated$Integrated_log2FC_LTL_vs_EAO), , drop = FALSE]
integrated <- integrated[order(-integrated$Integrated_log2FC_LTL_vs_EAO,
                               integrated$Minimum_raw_P,
                               integrated$Human_Entrez_ID), , drop = FALSE]
rownames(integrated) <- NULL
if (anyDuplicated(integrated$Human_Entrez_ID)) stop("Integrated Entrez ranking is not unique.")
gene_list <- integrated$Integrated_log2FC_LTL_vs_EAO
names(gene_list) <- integrated$Human_Entrez_ID
gene_list <- sort(gene_list, decreasing = TRUE)
if (length(gene_list) < 5000L) stop("Too few genes in integrated ranking.")

write_gz_tsv(source_all, "Fig5_EAO_LTL_GSEA_all_source_RNA_protein_features.tsv.gz")
write_gz_tsv(mapped, "Fig5_EAO_LTL_GSEA_symbol_to_human_Entrez_mapped_features.tsv.gz")
write_gz_tsv(within_resolved, "Fig5_EAO_LTL_GSEA_within_omics_duplicate_resolution.tsv.gz")
write_gz_tsv(integrated, "Fig5_EAO_LTL_GSEA_integrated_RNA_protein_gene_ranking.tsv.gz")

# -------------------------------------------------------------------------
# 3. Official KEGG memberships
# -------------------------------------------------------------------------
download_time <- format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")
pathway_names_raw <- KEGGREST::keggList("pathway", "hsa"); Sys.sleep(0.4)
pathway_links_raw <- KEGGREST::keggLink("hsa", "pathway"); Sys.sleep(0.4)
module_names_raw <- KEGGREST::keggList("module"); Sys.sleep(0.4)
module_to_ko_raw <- KEGGREST::keggLink("ko", "module"); Sys.sleep(0.4)
ko_to_human_raw <- KEGGREST::keggLink("hsa", "ko")

pathway_names <- data.frame(
  Set_ID = sub("^path:", "", names(pathway_names_raw)),
  Official_name = sub(" - Homo sapiens \\(human\\)$", "", unname(pathway_names_raw)),
  stringsAsFactors = FALSE
)
pathway_membership <- unique(data.frame(
  Set_ID = sub("^path:", "", names(pathway_links_raw)),
  Human_Entrez_ID = sub("^hsa:", "", unname(pathway_links_raw)),
  stringsAsFactors = FALSE
))
module_names <- data.frame(
  Set_ID = sub("^md:", "", names(module_names_raw)),
  Official_name = unname(module_names_raw), stringsAsFactors = FALSE
)
module_to_ko <- data.frame(
  Set_ID = sub("^md:", "", names(module_to_ko_raw)),
  KO = sub("^ko:", "", unname(module_to_ko_raw)), stringsAsFactors = FALSE
)
ko_to_human <- data.frame(
  KO = sub("^ko:", "", names(ko_to_human_raw)),
  Human_Entrez_ID = sub("^hsa:", "", unname(ko_to_human_raw)),
  stringsAsFactors = FALSE
)
module_membership <- unique(merge(module_to_ko, ko_to_human, by = "KO", sort = FALSE)[
  , c("Set_ID", "Human_Entrez_ID")
])

join_names <- function(manifest, names_table) {
  ids <- manifest$Set_ID
  out <- merge(manifest, names_table, by = "Set_ID", all.x = TRUE, sort = FALSE)
  out <- out[match(ids, out$Set_ID), , drop = FALSE]
  if (anyNA(out$Official_name)) stop("A prespecified KEGG set is unavailable.")
  out
}
pathway_manifest <- join_names(pathway_manifest, pathway_names)
module_manifest <- join_names(module_manifest, module_names)
pathway_membership <- pathway_membership[pathway_membership$Set_ID %in% pathway_manifest$Set_ID, ]
module_membership <- module_membership[module_membership$Set_ID %in% module_manifest$Set_ID, ]

add_counts <- function(manifest, membership) {
  manifest$Official_human_gene_count <- vapply(manifest$Set_ID, function(id)
    length(unique(membership$Human_Entrez_ID[membership$Set_ID == id])), integer(1))
  manifest$Ranked_gene_overlap_count <- vapply(manifest$Set_ID, function(id)
    length(intersect(unique(membership$Human_Entrez_ID[membership$Set_ID == id]),
                     names(gene_list))), integer(1))
  manifest
}
pathway_manifest <- add_counts(pathway_manifest, pathway_membership)
module_manifest <- add_counts(module_manifest, module_membership)
write_tsv(pathway_manifest, "Fig5_EAO_LTL_meat_color_KEGG_PATHWAY_manifest.tsv")
write_tsv(module_manifest, "Fig5_EAO_LTL_meat_color_KEGG_MODULE_manifest.tsv")
write_tsv(pathway_membership, "Fig5_EAO_LTL_meat_color_KEGG_PATHWAY_membership.tsv")
write_tsv(module_membership, "Fig5_EAO_LTL_meat_color_KEGG_MODULE_membership.tsv")

# -------------------------------------------------------------------------
# 4. Separate GSEA tests, with all plots stored in one directory
# -------------------------------------------------------------------------
run_gsea <- function(membership, manifest, min_size) {
  clusterProfiler::GSEA(
    geneList = gene_list, exponent = 1, minGSSize = min_size,
    maxGSSize = 1000, eps = 0, pvalueCutoff = 1, pAdjustMethod = "BH",
    verbose = FALSE, seed = TRUE, by = "fgsea", nPermSimple = 10000,
    TERM2GENE = unique(data.frame(term = membership$Set_ID,
                                  gene = membership$Human_Entrez_ID)),
    TERM2NAME = unique(data.frame(term = manifest$Set_ID,
                                  name = manifest$Official_name))
  )
}
gsea_pathway <- run_gsea(pathway_membership, pathway_manifest, 10L)
gsea_module <- run_gsea(module_membership, module_manifest, 2L)
saveRDS(gsea_pathway, file.path(table_dir, "Fig5_EAO_LTL_meat_color_PATHWAY_GSEA_object.rds"))
saveRDS(gsea_module, file.path(table_dir, "Fig5_EAO_LTL_meat_color_MODULE_GSEA_object.rds"))

decorate <- function(gsea_object, manifest) {
  result <- as.data.frame(gsea_object)
  names(result)[names(result) == "ID"] <- "Set_ID"
  names(result)[names(result) == "Description"] <- "GSEA_description"
  out <- merge(manifest, result, by = "Set_ID", all.x = TRUE, sort = FALSE)
  out <- out[match(manifest$Set_ID, out$Set_ID), , drop = FALSE]
  out$Observed_enriched_site <- ifelse(out$NES > 0, "LTL",
                                       ifelse(out$NES < 0, "EAO", NA_character_))
  out$Nominal_P_lt_0.05 <- !is.na(out$pvalue) & out$pvalue < 0.05
  out$FDR_BH_lt_0.05 <- !is.na(out$p.adjust) & out$p.adjust < 0.05
  out$Q_value_lt_0.05 <- !is.na(out$qvalue) & out$qvalue < 0.05
  out$Core_enrichment_symbols <- vapply(out$core_enrichment, function(x) {
    if (is.na(x) || !nzchar(x)) return(NA_character_)
    ids <- strsplit(x, "/", fixed = TRUE)[[1]]
    syms <- integrated$Human_Gene_symbol[match(ids, integrated$Human_Entrez_ID)]
    syms[is.na(syms)] <- ids[is.na(syms)]
    paste(syms, collapse = "/")
  }, character(1))
  out
}
pathway_results <- decorate(gsea_pathway, pathway_manifest)
module_results <- decorate(gsea_module, module_manifest)

export_plot <- function(gsea_object, row, set_type) {
  if (!is.finite(row$NES)) return(NULL)
  id <- row$Set_ID
  site <- row$Observed_enriched_site
  qtxt <- if (is.finite(row$qvalue)) sprintf("%.3g", row$qvalue) else "NA"
  ttl <- sprintf("%s | %s\nNES = %.2f; q = %s; enriched in %s",
                 id, row$Official_name, row$NES, qtxt, site)
  p <- enrichplot::gseaplot2(
    gsea_object, geneSetID = id, title = ttl,
    color = unname(site_colors[site]), base_size = 10.5,
    rel_heights = c(1.5, 0.5, 1), subplots = 1:3,
    pvalue_table = FALSE, ES_geom = "line"
  )
  p[] <- lapply(p, function(z) z + theme(
    text = element_text(family = "Arial", color = "#25282C"),
    plot.title = element_text(family = "Arial", face = "bold", size = 10,
                              hjust = 0, margin = margin(b = 3)),
    panel.grid.minor = element_blank()
  ))
  p[[length(p)]] <- p[[length(p)]] +
    labs(x = "Rank in ordered genes (LTL-high to EAO-high)")
  stub <- file.path(figure_dir, safe_filename(paste(set_type, id, row$Official_name, sep = "_")))
  ggsave(paste0(stub, ".pdf"), p, device = cairo_pdf,
         width = 6.6, height = 5.0, units = "in", family = "Arial")
  ggsave(paste0(stub, ".png"), p, device = "png",
         width = 6.6, height = 5.0, units = "in", dpi = 600, bg = "white")
  svg(paste0(stub, ".svg"), width = 6.6, height = 5.0,
      family = "Arial", bg = "white", onefile = TRUE)
  print(p); dev.off()
  data.frame(Set_type = set_type, Set_ID = id, Official_name = row$Official_name,
             Mechanism_axis = row$Mechanism_axis,
             Observed_enriched_site = site, NES = row$NES,
             P_value = row$pvalue, FDR_BH = row$p.adjust, Q_value = row$qvalue,
             PDF = paste0(stub, ".pdf"), PNG = paste0(stub, ".png"),
             SVG = paste0(stub, ".svg"), stringsAsFactors = FALSE)
}
plot_rows <- list(); k <- 0L
for (i in seq_len(nrow(pathway_results))) {
  k <- k + 1L; plot_rows[[k]] <- export_plot(gsea_pathway, pathway_results[i, ], "PATHWAY")
}
for (i in seq_len(nrow(module_results))) {
  k <- k + 1L; plot_rows[[k]] <- export_plot(gsea_module, module_results[i, ], "MODULE")
}
plot_index <- bind_nonempty(plot_rows)

# A single significance table mixes pathways and modules as requested. The
# q-value is retained from the separate pathway/module GSEA families, exactly
# matching the Figure 3D/E analysis convention.
combined_results <- rbind(
  pathway_results,
  module_results
)
combined_results <- combined_results[order(combined_results$Mechanistic_order,
                                            combined_results$Set_type,
                                            -abs(combined_results$NES)), ]
significant_results <- combined_results[
  !is.na(combined_results$qvalue) & combined_results$qvalue < 0.05, , drop = FALSE
]

summary_table <- rbind(
  data.frame(Set_type = "PATHWAY", Sets_prespecified = nrow(pathway_results),
             Sets_tested = sum(is.finite(pathway_results$NES)),
             Nominal_P_lt_0.05 = sum(pathway_results$pvalue < 0.05, na.rm = TRUE),
             FDR_BH_lt_0.05 = sum(pathway_results$p.adjust < 0.05, na.rm = TRUE),
             Q_value_lt_0.05 = sum(pathway_results$qvalue < 0.05, na.rm = TRUE),
             Enriched_in_LTL = sum(pathway_results$NES > 0, na.rm = TRUE),
             Enriched_in_EAO = sum(pathway_results$NES < 0, na.rm = TRUE)),
  data.frame(Set_type = "MODULE", Sets_prespecified = nrow(module_results),
             Sets_tested = sum(is.finite(module_results$NES)),
             Nominal_P_lt_0.05 = sum(module_results$pvalue < 0.05, na.rm = TRUE),
             FDR_BH_lt_0.05 = sum(module_results$p.adjust < 0.05, na.rm = TRUE),
             Q_value_lt_0.05 = sum(module_results$qvalue < 0.05, na.rm = TRUE),
             Enriched_in_LTL = sum(module_results$NES > 0, na.rm = TRUE),
             Enriched_in_EAO = sum(module_results$NES < 0, na.rm = TRUE))
)

qa <- data.frame(
  Item = c(
    "Comparison", "Rank sign", "Rank metric", "RNA input features",
    "Protein input features", "Integrated ranked genes",
    "RNA-protein overlapping genes", "RNA-protein direction conflicts",
    "Conflict rule", "Same-direction rule", "Pathway multiplicity",
    "Module multiplicity", "Pathway minimum set size",
    "Module minimum set size", "Official KEGG download time",
    "Plot directory", "clusterProfiler version", "enrichplot version"
  ),
  Value = c(
    comparison, "positive = LTL; negative = EAO",
    "integrated RNA/protein log2FC", nrow(rna), nrow(protein), length(gene_list),
    sum(integrated$Omics_membership == "Transcriptome;Proteome"),
    sum(integrated$Direction_conflict),
    "smallest raw P; tie by largest absolute log2FC",
    "mean log2FC across available observations",
    "BH/q-value across selected PATHWAY sets",
    "BH/q-value across selected MODULE sets", 10, 2, download_time,
    figure_dir, as.character(packageVersion("clusterProfiler")),
    as.character(packageVersion("enrichplot"))
  ), stringsAsFactors = FALSE
)

write_tsv(pathway_results, "Fig5_EAO_LTL_meat_color_PATHWAY_GSEA_results.tsv")
write_tsv(module_results, "Fig5_EAO_LTL_meat_color_MODULE_GSEA_results.tsv")
write_tsv(combined_results, "Fig5_EAO_LTL_meat_color_PATHWAY_MODULE_GSEA_all_results.tsv")
write_tsv(significant_results, "Fig5_EAO_LTL_meat_color_PATHWAY_MODULE_GSEA_q_lt_0.05.tsv")
write_tsv(plot_index, "Fig5_EAO_LTL_meat_color_PATHWAY_MODULE_GSEA_plot_index.tsv")
write_tsv(summary_table, "Fig5_EAO_LTL_meat_color_KEGG_GSEA_summary.tsv")
write_tsv(qa, "Fig5_EAO_LTL_meat_color_KEGG_GSEA_QA.tsv")
write.xlsx(
  list(Summary = summary_table, Significant_q_lt_0.05 = significant_results,
       All_sets = combined_results, PATHWAY_GSEA = pathway_results,
       MODULE_GSEA = module_results, PATHWAY_manifest = pathway_manifest,
       MODULE_manifest = module_manifest, Plot_index = plot_index,
       Integrated_rank = integrated, QA = qa),
  file.path(table_dir, "Fig5_EAO_LTL_integrated_RNA_protein_meat_color_KEGG_GSEA_results.xlsx"),
  overwrite = TRUE, asTable = TRUE
)

cat("Figure 5 meat-colour KEGG GSEA completed.\n")
print(summary_table)
cat("\nSignificant pathways/modules (q < 0.05):\n")
print(significant_results[, c("Set_type", "Set_ID", "Official_name",
                              "Mechanism_axis", "NES", "pvalue", "p.adjust",
                              "qvalue", "Observed_enriched_site")], row.names = FALSE)
