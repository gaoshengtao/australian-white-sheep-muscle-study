#!/usr/bin/env Rscript

# Figure 5B: combined paired LTL-vs-EAO transcriptome/proteome volcano plot
# and FDR-significant feature counts.
#
# Source contrasts were generated previously using all features:
#   RNA: DESeq2 paired design (~ Animal + Site)
#   Protein: limma paired design (~ Animal + Site)
# The displayed threshold is BH-adjusted P < 0.05 with no fold-change cutoff.
# Positive log2FC indicates higher abundance in LTL; negative indicates EAO.

suppressPackageStartupMessages({
  library(cowplot)
  library(ggplot2)
  library(openxlsx)
})

project_dir <- "__PROJECT_ROOT__"
work_dir <- file.path(project_dir, "11_Figure5_EAO_LTL_meat_color")
source_dir <- file.path(
  project_dir, "07_Figure2_muscle_functional_states",
  "03_One_vs_rest_specificity", "Tables"
)
figure_dir <- file.path(work_dir, "Figures")
table_dir <- file.path(work_dir, "Tables")
dir.create(figure_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(table_dir, recursive = TRUE, showWarnings = FALSE)

rna_file <- file.path(
  source_dir,
  "Fig2_muscle_fiber_pairwise_transcriptome_DESeq2_all_gene_results.tsv.gz"
)
protein_file <- file.path(
  source_dir,
  "Fig2_muscle_fiber_pairwise_proteome_limma_all_gene_results.tsv.gz"
)
for (f in c(rna_file, protein_file)) {
  if (!file.exists(f)) stop("Input file not found: ", f)
}

figure_stub <- file.path(
  figure_dir, "Fig5B_EAO_LTL_combined_RNA_protein_volcano_with_counts"
)
count_figure_stub <- file.path(
  figure_dir, "Fig5B_EAO_LTL_FDR_counts_faceted_barplot"
)
plot_data_file <- file.path(
  table_dir, "Fig5B_EAO_LTL_combined_volcano_plot_data.tsv.gz"
)
count_file <- file.path(
  table_dir, "Fig5B_EAO_LTL_combined_volcano_counts.tsv"
)
count_plot_file <- file.path(
  table_dir, "Fig5B_EAO_LTL_FDR_counts_faceted_barplot.tsv"
)
workbook_file <- file.path(
  table_dir, "Fig5B_EAO_LTL_differential_RNA_protein_statistics.xlsx"
)

read_contrast <- function(path, omics) {
  d <- read.delim(gzfile(path), check.names = FALSE)
  required <- c(
    "Gene_symbol", "Comparison", "log2FoldChange", "P_value", "P_FDR_BH"
  )
  missing_columns <- setdiff(required, names(d))
  if (length(missing_columns)) {
    stop(
      "Missing columns in ", basename(path), ": ",
      paste(missing_columns, collapse = ", ")
    )
  }
  d <- d[
    d$Comparison == "LTL_vs_EAO" &
      is.finite(d$log2FoldChange) &
      !is.na(d$P_value) & d$P_value > 0 &
      !is.na(d$P_FDR_BH) & d$P_FDR_BH > 0,
    , drop = FALSE
  ]

  feature_id <- if (omics == "Transcriptome") {
    if ("gene_id" %in% names(d)) d$gene_id else seq_len(nrow(d))
  } else {
    if ("Human_Entrez_ID" %in% names(d)) d$Human_Entrez_ID else seq_len(nrow(d))
  }

  data.frame(
    Omics = omics,
    Feature_ID = as.character(feature_id),
    Gene_symbol = as.character(d$Gene_symbol),
    Comparison = d$Comparison,
    log2FoldChange_LTL_vs_EAO = d$log2FoldChange,
    P_value = d$P_value,
    P_FDR_BH = d$P_FDR_BH,
    stringsAsFactors = FALSE
  )
}

plot_df <- rbind(
  read_contrast(rna_file, "Transcriptome"),
  read_contrast(protein_file, "Proteome")
)
plot_df$Enriched_site <- ifelse(
  plot_df$log2FoldChange_LTL_vs_EAO > 0, "LTL", "EAO"
)
plot_df$Evidence <- ifelse(
  plot_df$P_FDR_BH < 0.05, "FDR < 0.05", "FDR >= 0.05"
)
plot_df$Minus_log10_FDR <- -log10(plot_df$P_FDR_BH)
plot_df$Omics <- factor(plot_df$Omics,
                         levels = c("Transcriptome", "Proteome"))
plot_df$Enriched_site <- factor(plot_df$Enriched_site,
                                levels = c("EAO", "LTL"))
plot_df$Evidence <- factor(plot_df$Evidence,
                           levels = c("FDR < 0.05", "FDR >= 0.05"))

count_summary <- do.call(
  rbind,
  lapply(levels(plot_df$Omics), function(omics_name) {
    z <- plot_df[plot_df$Omics == omics_name, , drop = FALSE]
    data.frame(
      Omics = omics_name,
      Tested_features = nrow(z),
      FDR_lt_0.05_total = sum(z$Evidence == "FDR < 0.05"),
      FDR_lt_0.05_EAO = sum(
        z$Evidence == "FDR < 0.05" & z$Enriched_site == "EAO"
      ),
      FDR_lt_0.05_LTL = sum(
        z$Evidence == "FDR < 0.05" & z$Enriched_site == "LTL"
      ),
      FDR_ge_0.05_total = sum(z$Evidence == "FDR >= 0.05"),
      stringsAsFactors = FALSE
    )
  })
)

count_df <- rbind(
  data.frame(
    Omics = count_summary$Omics,
    Enriched_site = "EAO",
    Count = count_summary$FDR_lt_0.05_EAO,
    Tested_features = count_summary$Tested_features,
    FDR_threshold = "FDR < 0.05"
  ),
  data.frame(
    Omics = count_summary$Omics,
    Enriched_site = "LTL",
    Count = count_summary$FDR_lt_0.05_LTL,
    Tested_features = count_summary$Tested_features,
    FDR_threshold = "FDR < 0.05"
  )
)
count_df$Omics <- factor(count_df$Omics,
                          levels = c("Transcriptome", "Proteome"))
count_df$Enriched_site <- factor(count_df$Enriched_site,
                                  levels = c("EAO", "LTL"))
count_df <- count_df[order(count_df$Omics, count_df$Enriched_site), ]

write.table(count_summary, count_file, sep = "\t", quote = FALSE,
            row.names = FALSE)
write.table(count_df, count_plot_file, sep = "\t", quote = FALSE,
            row.names = FALSE)
gz_connection <- gzfile(plot_data_file, open = "wt")
write.table(plot_df, gz_connection, sep = "\t", quote = FALSE,
            row.names = FALSE, na = "NA")
close(gz_connection)

highlight_df <- plot_df[plot_df$Evidence == "FDR < 0.05", , drop = FALSE]
methods_qa <- data.frame(
  Item = c(
    "Comparison", "RNA method", "Protein method", "Pairing design",
    "Positive log2FC", "Negative log2FC", "Colored symbols",
    "Neutral symbols", "Transcriptome symbol", "Proteome symbol",
    "Threshold", "Fold-change cutoff", "Y axis", "Panel aspect ratio",
    "Font", "LTL color", "EAO color", "RNA source", "Protein source",
    "Main figure dimensions", "Count figure dimensions"
  ),
  Value = c(
    "LTL_vs_EAO", "DESeq2", "limma", "~ Animal + Site",
    "Enriched in LTL", "Enriched in EAO",
    "BH-adjusted P < 0.05, site-colored",
    "BH-adjusted P >= 0.05, small neutral gray",
    "Circle", "Square", "BH-adjusted P < 0.05", "None",
    "-log10(BH-adjusted P)",
    "1:1, enforced for volcano panel with theme(aspect.ratio = 1)",
    "Arial", "#355C8A", "#A65D68", rna_file, protein_file,
    "6.20 x 4.65 inches", "4.20 x 2.75 inches"
  ),
  stringsAsFactors = FALSE
)
write.xlsx(
  list(
    Counts = count_summary,
    Count_plot_data = count_df,
    FDR_significant_features = highlight_df,
    Methods_and_QA = methods_qa
  ),
  workbook_file, overwrite = TRUE, asTable = TRUE
)

site_colors <- c(EAO = "#A65D68", LTL = "#355C8A")
omics_shapes <- c(Transcriptome = 21, Proteome = 22)
background_df <- plot_df[plot_df$Evidence == "FDR >= 0.05", , drop = FALSE]

x_abs <- ceiling(max(abs(plot_df$log2FoldChange_LTL_vs_EAO)) * 2) / 2
y_max <- ceiling(max(plot_df$Minus_log10_FDR) * 2) / 2
x_limits <- c(-x_abs, x_abs)
y_limits <- c(0, y_max)

volcano_p <- ggplot() +
  geom_hline(
    yintercept = -log10(0.05), color = "#A8ACB0",
    linewidth = 0.34, linetype = "22"
  ) +
  geom_vline(
    xintercept = 0, color = "#8D9297",
    linewidth = 0.42, linetype = "22"
  ) +
  geom_point(
    data = background_df,
    aes(x = log2FoldChange_LTL_vs_EAO, y = Minus_log10_FDR,
        shape = Omics),
    color = "#B7BABD", fill = "#B7BABD", alpha = 0.22,
    size = 0.34, stroke = 0, show.legend = FALSE
  ) +
  geom_point(
    data = highlight_df,
    aes(x = log2FoldChange_LTL_vs_EAO, y = Minus_log10_FDR,
        shape = Omics, color = Enriched_site, fill = Enriched_site),
    size = 0.84, stroke = 0.28, alpha = 0.72
  ) +
  scale_x_continuous(limits = x_limits,
                     expand = expansion(mult = c(0, 0))) +
  scale_y_continuous(limits = y_limits,
                     expand = expansion(mult = c(0, 0))) +
  scale_shape_manual(
    values = omics_shapes, breaks = c("Transcriptome", "Proteome"),
    labels = c("RNA", "Protein"), name = "Omics"
  ) +
  scale_color_manual(values = site_colors,
                     breaks = c("EAO", "LTL"), name = "Enriched site") +
  scale_fill_manual(values = site_colors, guide = "none") +
  labs(
    x = expression(log[2] * " fold change (LTL / EAO)"),
    y = expression(-log[10] * "(FDR)")
  ) +
  theme_bw(base_size = 10.5, base_family = "Arial") +
  theme(
    aspect.ratio = 1,
    plot.background = element_rect(fill = "white", color = NA),
    panel.background = element_rect(fill = "white", color = NA),
    panel.grid.major = element_line(color = "#E6E8EA", linewidth = 0.30),
    panel.grid.minor = element_blank(),
    panel.border = element_rect(color = "#303337", linewidth = 0.48),
    axis.title = element_text(size = 10.2, color = "#25282C"),
    axis.text = element_text(size = 9.0, color = "#25282C"),
    axis.ticks = element_line(color = "#303337", linewidth = 0.35),
    axis.ticks.length = unit(1.5, "mm"),
    legend.position = "right",
    legend.box = "vertical",
    legend.box.just = "left",
    legend.title = element_text(face = "bold", size = 9.0),
    legend.text = element_text(size = 8.5),
    legend.key.height = unit(4.2, "mm"),
    legend.key.width = unit(4.2, "mm"),
    legend.spacing.y = unit(1.8, "mm"),
    plot.margin = margin(5.0, 4.0, 4.5, 5.0)
  ) +
  guides(
    shape = guide_legend(
      order = 1,
      override.aes = list(size = 2.8, stroke = 0.65,
                          color = "#303337", fill = "white", alpha = 1)
    ),
    color = guide_legend(
      order = 2,
      override.aes = list(shape = 16, size = 2.8, fill = NA, alpha = 1)
    )
  )

# Free vertical scales make RNA and protein counts legible in their respective
# facets; exact counts are printed above each bar.
count_p <- ggplot(
  count_df, aes(x = Enriched_site, y = Count, fill = Enriched_site)
) +
  geom_col(width = 0.62, color = "#303337", linewidth = 0.38,
           show.legend = FALSE) +
  geom_text(
    aes(label = scales::comma(Count), color = Enriched_site),
    vjust = -0.42, size = 3.10, fontface = "bold", show.legend = FALSE
  ) +
  facet_wrap(~Omics, nrow = 1, scales = "free_y") +
  scale_fill_manual(values = site_colors) +
  scale_color_manual(values = site_colors) +
  scale_y_continuous(
    expand = expansion(mult = c(0, 0.18)),
    breaks = scales::pretty_breaks(n = 4), labels = scales::comma
  ) +
  labs(x = NULL, y = "FDR-significant features") +
  theme_bw(base_size = 10.5, base_family = "Arial") +
  theme(
    plot.background = element_rect(fill = "white", color = NA),
    panel.background = element_rect(fill = "white", color = NA),
    panel.grid.major.x = element_blank(),
    panel.grid.minor = element_blank(),
    panel.grid.major.y = element_line(color = "#E6E8EA", linewidth = 0.30),
    panel.border = element_rect(color = "#303337", linewidth = 0.45),
    strip.background = element_rect(fill = "#F1F1F1", color = "#B8BABD",
                                    linewidth = 0.36),
    strip.text = element_text(face = "bold", size = 9.2,
                              color = "#25282C"),
    axis.title.y = element_text(size = 9.2, color = "#25282C"),
    axis.text.x = element_text(size = 8.8, color = "#25282C"),
    axis.text.y = element_text(size = 8.0, color = "#25282C"),
    axis.ticks = element_line(color = "#303337", linewidth = 0.34),
    axis.ticks.length = unit(1.3, "mm"),
    panel.spacing.x = unit(4.0, "mm"),
    plot.margin = margin(4.0, 4.5, 4.0, 4.5)
  )

# Compact count inset matching the layout logic of the assembled Figure 3B.
inset_p <- count_p +
  labs(y = NULL) +
  theme(
    text = element_text(family = "Arial"),
    strip.text = element_text(size = 7.1, face = "bold"),
    axis.text.x = element_blank(),
    axis.text.y = element_blank(),
    axis.ticks = element_blank(),
    panel.grid = element_blank(),
    panel.spacing.x = unit(1.8, "mm"),
    plot.margin = margin(1.5, 1.5, 1.5, 1.5)
  )

combined_p <- ggdraw(volcano_p) +
  draw_plot(inset_p, x = 0.49, y = 0.68, width = 0.38, height = 0.25)

main_width <- 6.20
main_height <- 4.65
ggsave(paste0(figure_stub, ".pdf"), combined_p, device = cairo_pdf,
       width = main_width, height = main_height, units = "in", family = "Arial")
ggsave(paste0(figure_stub, ".png"), combined_p, device = "png",
       width = main_width, height = main_height, units = "in",
       dpi = 600, bg = "white")
svg(paste0(figure_stub, ".svg"), width = main_width, height = main_height,
    family = "Arial", bg = "white", onefile = TRUE)
print(combined_p)
dev.off()

count_width <- 4.20
count_height <- 2.75
ggsave(paste0(count_figure_stub, ".pdf"), count_p, device = cairo_pdf,
       width = count_width, height = count_height, units = "in", family = "Arial")
ggsave(paste0(count_figure_stub, ".png"), count_p, device = "png",
       width = count_width, height = count_height, units = "in",
       dpi = 600, bg = "white")
svg(paste0(count_figure_stub, ".svg"), width = count_width,
    height = count_height, family = "Arial", bg = "white", onefile = TRUE)
print(count_p)
dev.off()

message("Figure 5B written to: ", figure_dir)
message("Statistics written to: ", table_dir)
