#!/usr/bin/env Rscript

# Figure 5H: selected untargeted metabolites that provide molecule-level
# support for the RNA/protein results in EAO versus LTL.
#
# Selection is deliberately conservative and direction checked:
#   1) VIP > 1 and paired Wilcoxon raw P < 0.05 in the existing analysis;
#   2) endogenous, biologically interpretable HMDB annotation at Level Bi/Bii;
#   3) a pre-specified connection to an RNA/protein result already reported.
# The plot shows relative abundance (row Z-score), not pathway activation or
# metabolic flux. No feature is selected from the displayed sample pattern.

rm(list = ls())

suppressPackageStartupMessages({
  library(data.table)
  library(openxlsx)
  library(ComplexHeatmap)
  library(circlize)
  library(grid)
  library(svglite)
})

project_dir <- "__PROJECT_ROOT__"
work_dir <- file.path(project_dir, "11_Figure5_EAO_LTL_meat_color")
table_dir <- file.path(work_dir, "Tables")
figure_dir <- file.path(work_dir, "Figures")
dir.create(table_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(figure_dir, recursive = TRUE, showWarnings = FALSE)

normalized_file <- file.path(
  project_dir, "06_LCMS_untarget",
  "01_PM_SM_TIC_OPLSDA_VIP_paired_Wilcoxon",
  "pos_neg_named_HMDB_TIC_log10_normalized.tsv"
)
differential_file <- file.path(
  table_dir,
  "Fig5_EAO_LTL_untargeted_all_named_OPLSDA_VIP_paired_Wilcoxon_differential.tsv"
)
required <- c(normalized_file, differential_file)
if (any(!file.exists(required))) {
  stop("Missing required files: ", paste(required[!file.exists(required)], collapse = ", "))
}

normalized <- fread(normalized_file, na.strings = c("NA", ""), check.names = FALSE)
differential <- fread(differential_file, na.strings = c("NA", ""), check.names = FALSE)

# Explicit manifest: each row links a metabolite to an observed RNA/protein
# programme. Several related lipid mediators are retained because their
# within-class coherence is more informative than any single annotation.
manifest <- data.table(
  Metabolite = c(
    "L-Glutathione", "L-Glutamic Acid", "Homocysteine",
    "Lps(18:0)", "1-Myristoyl-sn-glycero-3-phosphocholine",
    "Glycerophosphocholine", "Palmitoyl sphingomyelin",
    "5-Hydroxy-6E,8Z,11Z,14Z-eicosatetraenoic acid",
    "Prostaglandin e2", "Prostaglandin F2alpha", "Thromboxane B2",
    "13,14-Dihydro-15-keto-PGE2",
    "Niacinamide", "Butyrylcarnitine", "Hexanoylcarnitine"
  ),
  Display_name = c(
    "Glutathione", "L-Glutamate", "Homocysteine",
    "LysoPS(18:0)", "LysoPC(14:0)",
    "Glycerophosphocholine", "SM(d18:1/16:0)",
    "5-HETE", "PGE2", "PGF2alpha", "Thromboxane B2",
    "13,14-Dihydro-15-keto-PGE2",
    "Niacinamide", "Butyrylcarnitine", "Hexanoylcarnitine"
  ),
  Expected_higher_in = c(rep("EAO", 12), rep("LTL", 3)),
  Mechanism_group = c(
    rep("EAO: glutathione / redox substrates", 3),
    rep("EAO: membrane lipids / eicosanoids", 9),
    rep("LTL: mitochondrial cofactors / substrates", 3)
  ),
  Cross_omics_anchor = c(
    rep("EAO proteomic glutathione metabolism and reductive programme", 3),
    rep("EAO transcriptomic phospholipase D / glycerolipid-lipid signalling", 9),
    rep("LTL RNA/protein TCA-respiratory-chain-oxidative phosphorylation programme", 3)
  ),
  Interpretation = c(
    "Reductant pool associated with pigment redox environment",
    "Glutathione precursor; supports the glutathione/redox context",
    "Sulfur-amino-acid/redox context; not a direct GSH synthesis readout",
    "Membrane phospholipid-remodelling pool",
    "Membrane phospholipid-remodelling pool",
    "Phospholipid head-group turnover",
    "Sphingomyelin-rich membrane-lipid pool",
    "Arachidonic-acid-derived lipid mediator",
    "Arachidonic-acid-derived lipid mediator",
    "Arachidonic-acid-derived lipid mediator",
    "Arachidonic-acid-derived lipid mediator/turnover product",
    "Prostaglandin turnover product",
    "NAD cofactor precursor associated with oxidative metabolism",
    "Short-chain acylcarnitine; mitochondrial substrate handling",
    "Medium-chain acylcarnitine; mitochondrial substrate handling"
  ),
  Interpretation_limit = c(
    "Association only; GSH abundance does not establish color stability",
    "Pool abundance does not measure glutathione synthesis flux",
    "Not specific to glutathione metabolism",
    rep("Lipid abundance does not establish phospholipase activity or flux", 4),
    rep("Putative LC-MS annotation; does not establish eicosanoid pathway flux", 5),
    "Pool abundance does not measure NAD redox ratio",
    rep("Acylcarnitine abundance can reflect substrate entry or incomplete oxidation", 2)
  )
)

if (anyDuplicated(manifest$Metabolite)) stop("Manifest contains duplicate metabolite names")
selected <- merge(manifest, differential, by = "Metabolite", all.x = TRUE, sort = FALSE)
if (anyNA(selected$Feature_key)) {
  stop("Manifest metabolites absent from differential table: ",
       paste(selected[is.na(Feature_key), Metabolite], collapse = ", "))
}
selected[, Direction_check := Higher_in == Expected_higher_in]
if (!all(selected$Direction_check)) stop("At least one selected metabolite has the wrong direction")
if (!all(selected$VIP > 1 & selected$paired_Wilcoxon_P < 0.05)) {
  stop("At least one selected metabolite fails VIP > 1 and raw paired P < 0.05")
}
if (!all(selected$Level %chin% c("LevelBi", "LevelBii"))) {
  stop("At least one selected metabolite is not Level Bi/Bii")
}

# Restore the manifest order after merge.
selected[, manifest_order := match(Metabolite, manifest$Metabolite)]
setorder(selected, manifest_order)

eao_cols <- paste0("AM_", 1:6)
ltl_cols <- paste0("LT_", 1:6)
sample_cols <- c(eao_cols, ltl_cols)
missing_samples <- setdiff(sample_cols, names(normalized))
if (length(missing_samples)) stop("Normalized input lacks samples: ", paste(missing_samples, collapse = ", "))

idx <- match(selected$Feature_key, normalized$Feature_key)
if (anyNA(idx)) stop("Selected Feature_key is absent from normalized abundance matrix")
mat_log10 <- as.matrix(normalized[idx, ..sample_cols])
storage.mode(mat_log10) <- "double"
rownames(mat_log10) <- selected$Display_name
colnames(mat_log10) <- c(paste0("EAO", 1:6), paste0("LTL", 1:6))

row_mean <- rowMeans(mat_log10, na.rm = TRUE)
row_sd <- apply(mat_log10, 1, sd, na.rm = TRUE)
if (any(!is.finite(row_sd) | row_sd == 0)) stop("Selected row has zero or invalid SD")
mat_z <- sweep(sweep(mat_log10, 1, row_mean, "-"), 1, row_sd, "/")
mat_display <- mat_z
mat_display[mat_display < -2] <- -2
mat_display[mat_display > 2] <- 2

group_levels <- unique(manifest$Mechanism_group)
row_split <- factor(selected$Mechanism_group, levels = group_levels)
column_split <- factor(rep(c("EAO", "LTL"), each = 6), levels = c("EAO", "LTL"))

site_colors <- c(EAO = "#A65D68", LTL = "#355C8A")
heat_colors <- colorRamp2(c(-2, 0, 2), c("#355C8A", "#F7F5F0", "#B65F6A"))

column_annotation <- HeatmapAnnotation(
  Site = factor(rep(c("EAO", "LTL"), each = 6), levels = c("EAO", "LTL")),
  col = list(Site = site_colors),
  simple_anno_size = unit(3.3, "mm"),
  show_annotation_name = FALSE,
  show_legend = FALSE
)

make_heatmap <- function() {
  Heatmap(
    mat_display,
    name = "Row Z-score",
    col = heat_colors,
    top_annotation = column_annotation,
    row_split = row_split,
    column_split = column_split,
    cluster_rows = TRUE,
    cluster_row_slices = FALSE,
    clustering_distance_rows = "euclidean",
    clustering_method_rows = "complete",
    cluster_columns = FALSE,
    cluster_column_slices = FALSE,
    show_row_dend = FALSE,
    show_column_dend = FALSE,
    border = TRUE,
    rect_gp = gpar(col = "white", lwd = 0.55),
    row_names_side = "left",
    row_names_gp = gpar(fontfamily = "Arial", fontsize = 8.5),
    row_names_max_width = unit(61, "mm"),
    show_column_names = FALSE,
    row_title = NULL,
    column_title_gp = gpar(fontfamily = "Arial", fontsize = 10, fontface = "bold"),
    row_gap = unit(2.2, "mm"),
    column_gap = unit(2.0, "mm"),
    heatmap_legend_param = list(
      at = c(-2, -1, 0, 1, 2),
      title_gp = gpar(fontfamily = "Arial", fontsize = 9, fontface = "bold"),
      labels_gp = gpar(fontfamily = "Arial", fontsize = 8.5),
      legend_height = unit(27, "mm")
    )
  )
}

base <- "Fig5H_EAO_LTL_hypothesis_aligned_untargeted_metabolite_heatmap"
pdf_file <- file.path(figure_dir, paste0(base, ".pdf"))
png_file <- file.path(figure_dir, paste0(base, ".png"))
svg_file <- file.path(figure_dir, paste0(base, ".svg"))

plot_width <- 5.4
plot_height <- 6.2

grDevices::cairo_pdf(pdf_file, width = plot_width, height = plot_height, family = "Arial")
ht_drawn <- suppressWarnings(draw(
  make_heatmap(), heatmap_legend_side = "right",
  padding = unit(c(4, 4, 4, 4), "mm")
))
dev.off()

png(png_file, width = plot_width, height = plot_height, units = "in", res = 500,
    type = "cairo", bg = "white")
suppressWarnings(draw(
  make_heatmap(), heatmap_legend_side = "right",
  padding = unit(c(4, 4, 4, 4), "mm")
))
dev.off()

svglite(svg_file, width = plot_width, height = plot_height)
suppressWarnings(draw(
  make_heatmap(), heatmap_legend_side = "right",
  padding = unit(c(4, 4, 4, 4), "mm")
))
dev.off()

row_order_list <- row_order(ht_drawn)
ordered_indices <- unlist(row_order_list, use.names = FALSE)
ordered_slices <- rep(names(row_order_list), lengths(row_order_list))
row_order_table <- data.table(
  Heatmap_row_order = seq_along(ordered_indices),
  Row_slice = ordered_slices,
  Display_name = rownames(mat_display)[ordered_indices],
  Metabolite = selected$Metabolite[ordered_indices],
  Feature_key = selected$Feature_key[ordered_indices],
  Higher_in = selected$Higher_in[ordered_indices]
)

z_table <- as.data.table(mat_z, keep.rownames = "Display_name")
metadata_cols <- c(
  "Display_name", "Metabolite", "Feature_key", "Mechanism_group",
  "Cross_omics_anchor", "Interpretation", "Interpretation_limit",
  "Higher_in", "Direction_check", "Level", "HMDB_ID", "HMDB_Name",
  "HMDB_KEGG_ID", "log2FC_EAO_vs_LTL", "VIP", "paired_Wilcoxon_P",
  "paired_Wilcoxon_FDR_BH"
)
metadata <- selected[, ..metadata_cols]
plot_data <- merge(metadata, z_table, by = "Display_name", all.x = TRUE, sort = FALSE)

qa <- data.table(
  Check = c(
    "Selected metabolites", "EAO-enriched", "LTL-enriched",
    "All pass VIP > 1", "All pass paired raw P < 0.05",
    "All annotation levels Bi/Bii", "Feature-level BH FDR < 0.05",
    "Normalization", "Display scale", "Interpretation boundary"
  ),
  Result = c(
    nrow(selected), sum(selected$Higher_in == "EAO"), sum(selected$Higher_in == "LTL"),
    all(selected$VIP > 1), all(selected$paired_Wilcoxon_P < 0.05),
    all(selected$Level %chin% c("LevelBi", "LevelBii")),
    sum(selected$paired_Wilcoxon_FDR_BH < 0.05, na.rm = TRUE),
    "TIC normalized and log10 transformed in the source matrix",
    "Per-metabolite row Z-score, clipped to [-2, 2] only for color display",
    "Selected pools support cross-omics context; they do not measure pathway flux or prove meat-color causality"
  )
)

fwrite(plot_data, file.path(table_dir, paste0(base, "_row_Z_scores.tsv")),
       sep = "\t", quote = FALSE, na = "NA")
fwrite(row_order_table, file.path(table_dir, paste0(base, "_row_order.tsv")),
       sep = "\t", quote = FALSE, na = "NA")
fwrite(qa, file.path(table_dir, paste0(base, "_QA.tsv")),
       sep = "\t", quote = FALSE, na = "NA")
write.xlsx(
  list(
    Selection_and_statistics = as.data.frame(metadata),
    Plot_Z_scores = as.data.frame(plot_data),
    Heatmap_row_order = as.data.frame(row_order_table),
    QA = as.data.frame(qa)
  ),
  file.path(table_dir, paste0(base, "_data.xlsx")),
  overwrite = TRUE, keepNA = TRUE
)

message(
  "Done. Plotted ", nrow(selected), " metabolites across 12 paired samples: EAO ",
  sum(selected$Higher_in == "EAO"), "; LTL ", sum(selected$Higher_in == "LTL"), "."
)
