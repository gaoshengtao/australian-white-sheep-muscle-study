#!/usr/bin/env Rscript

# Figure 5C: faceted KEGG bar plot for direction-specific EAO-LTL differential
# transcriptome genes and proteins.
# Rows are EAO- and LTL-enriched pathway unions; columns are Transcriptome and
# Proteome. Missing omics-pathway combinations remain blank.

rm(list = ls())

suppressPackageStartupMessages({
  library(ggplot2)
  library(openxlsx)
})

project_dir <- "__PROJECT_ROOT__"
work_dir <- file.path(project_dir, "11_Figure5_EAO_LTL_meat_color")
table_dir <- file.path(work_dir, "Tables")
figure_dir <- file.path(work_dir, "Figures")
input_file <- file.path(
  table_dir,
  "Fig5C_EAO_LTL_RNA_protein_separate_KEGG_pathways_FDR_lt_0.05.tsv"
)
output_stub <- file.path(
  figure_dir, "Fig5C_EAO_LTL_RNA_protein_KEGG_FDR_faceted_barplot"
)
output_tsv <- file.path(
  table_dir, "Fig5C_EAO_LTL_RNA_protein_KEGG_FDR_faceted_barplot_data.tsv"
)
output_xlsx <- file.path(
  table_dir, "Fig5C_EAO_LTL_RNA_protein_KEGG_FDR_faceted_barplot_data.xlsx"
)

if (!file.exists(input_file)) {
  stop(
    "Input file not found: ", input_file,
    "\nRun 03_Fig5C_EAO_LTL_RNA_protein_FDR005_separate_KEGG_ORA.R first."
  )
}
dir.create(figure_dir, recursive = TRUE, showWarnings = FALSE)

d <- read.delim(input_file, check.names = FALSE, stringsAsFactors = FALSE,
                quote = "", comment.char = "")
required <- c(
  "Omics", "Higher_in", "KEGG_level1", "KEGG_level2", "Pathway",
  "Pathway_ID", "FDR_BH_after_category_filter", "Count"
)
missing_columns <- setdiff(required, names(d))
if (length(missing_columns)) {
  stop("Missing columns: ", paste(missing_columns, collapse = ", "))
}
d <- d[
  d$Omics %in% c("Transcriptome", "Proteome") &
    d$Higher_in %in% c("EAO", "LTL") &
    is.finite(d$FDR_BH_after_category_filter) &
    d$FDR_BH_after_category_filter < 0.05,
  , drop = FALSE
]
if (!nrow(d)) stop("No FDR-significant pathways were found.")
if (anyDuplicated(d[, c("Omics", "Higher_in", "Pathway_ID")])) {
  stop("Duplicated omics-site-pathway rows detected.")
}

omics_order <- c("Transcriptome", "Proteome")
site_order <- c("EAO", "LTL")
site_colors <- c(EAO = "#A65D68", LTL = "#355C8A")

# Build the RNA/protein pathway union separately within each site. Ordering is
# based on the strongest FDR evidence across the two omics layers.
site_union_list <- lapply(site_order, function(site_name) {
  z <- d[d$Higher_in == site_name, , drop = FALSE]
  pathway_ids <- unique(z$Pathway_ID)
  rows <- lapply(pathway_ids, function(pathway_id) {
    q <- z[z$Pathway_ID == pathway_id, , drop = FALSE]
    data.frame(
      Higher_in = site_name,
      Pathway_ID = pathway_id,
      Pathway = q$Pathway[1],
      KEGG_level1 = q$KEGG_level1[1],
      KEGG_level2 = q$KEGG_level2[1],
      Maximum_minus_log10_FDR = max(
        -log10(q$FDR_BH_after_category_filter)
      ),
      Omics_detected = paste(
        omics_order[omics_order %in% q$Omics], collapse = "; "
      ),
      stringsAsFactors = FALSE
    )
  })
  if (!length(rows)) return(data.frame())
  union <- do.call(rbind, rows)
  union <- union[
    order(union$Maximum_minus_log10_FDR, union$Pathway),
    , drop = FALSE
  ]
  union$Pathway_order_within_site <- seq_len(nrow(union))
  union
})
site_union_list <- site_union_list[
  vapply(site_union_list, nrow, integer(1)) > 0L
]
site_union <- do.call(rbind, site_union_list)
rownames(site_union) <- NULL

# Cross each site-specific pathway union with both omics layers. Zero retains
# the row label but produces no visible bar when that omics result is absent.
expanded_list <- lapply(seq_len(nrow(site_union)), function(i) {
  u <- site_union[i, , drop = FALSE]
  do.call(rbind, lapply(omics_order, function(omics_name) {
    q <- d[
      d$Higher_in == u$Higher_in & d$Pathway_ID == u$Pathway_ID &
        d$Omics == omics_name,
      , drop = FALSE
    ]
    present <- nrow(q) == 1L
    data.frame(
      Higher_in = u$Higher_in,
      Omics = omics_name,
      KEGG_level1 = u$KEGG_level1,
      KEGG_level2 = u$KEGG_level2,
      Pathway = u$Pathway,
      Pathway_ID = u$Pathway_ID,
      Pathway_order_within_site = u$Pathway_order_within_site,
      Present_in_omics = present,
      FDR_BH_after_category_filter = if (present) {
        q$FDR_BH_after_category_filter
      } else {
        NA_real_
      },
      Minus_log10_FDR = if (present) {
        -log10(q$FDR_BH_after_category_filter)
      } else {
        NA_real_
      },
      Plot_value = if (present) {
        -log10(q$FDR_BH_after_category_filter)
      } else {
        0
      },
      Gene_or_protein_count = if (present) q$Count else NA_integer_,
      stringsAsFactors = FALSE
    )
  }))
})
plot_data <- do.call(rbind, expanded_list)
rownames(plot_data) <- NULL

plot_data$Omics <- factor(plot_data$Omics, levels = omics_order)
plot_data$Higher_in <- factor(plot_data$Higher_in, levels = site_order)
plot_data$Pathway_key <- paste(
  as.character(plot_data$Higher_in), plot_data$Pathway_ID,
  plot_data$Pathway, sep = "|||"
)

pathway_level_rows <- unique(plot_data[, c(
  "Higher_in", "Pathway_key", "Pathway_order_within_site"
)])
pathway_level_rows <- pathway_level_rows[
  order(match(pathway_level_rows$Higher_in, site_order),
        pathway_level_rows$Pathway_order_within_site),
  , drop = FALSE
]
plot_data$Pathway_key <- factor(
  plot_data$Pathway_key, levels = pathway_level_rows$Pathway_key
)
plot_data <- plot_data[
  order(plot_data$Higher_in, plot_data$Pathway_order_within_site,
        plot_data$Omics),
  , drop = FALSE
]

summary_table <- do.call(rbind, lapply(site_order, function(site_name) {
  z <- d[d$Higher_in == site_name, , drop = FALSE]
  rna_ids <- unique(z$Pathway_ID[z$Omics == "Transcriptome"])
  protein_ids <- unique(z$Pathway_ID[z$Omics == "Proteome"])
  data.frame(
    Higher_in = site_name,
    Transcriptome_significant_pathways = length(rna_ids),
    Proteome_significant_pathways = length(protein_ids),
    RNA_protein_shared_pathways = length(intersect(rna_ids, protein_ids)),
    RNA_protein_union_pathways = length(union(rna_ids, protein_ids)),
    Transcriptome_only_pathways = length(setdiff(rna_ids, protein_ids)),
    Proteome_only_pathways = length(setdiff(protein_ids, rna_ids)),
    stringsAsFactors = FALSE
  )
}))

write.table(plot_data, output_tsv, sep = "\t", quote = FALSE,
            row.names = FALSE, na = "NA")

plot_height <- max(5.0, 1.8 + 0.22 * nrow(site_union))
methods_qa <- data.frame(
  Item = c(
    "Input", "Pathway threshold", "X axis", "Pathway rows",
    "Missing omics result", "Pathway ordering", "Facet rows",
    "Facet columns", "X scale", "EAO color", "LTL color", "Font",
    "Figure dimensions"
  ),
  Value = c(
    input_file, "FDR_BH_after_category_filter < 0.05",
    "-log10(FDR_BH_after_category_filter)",
    "RNA/protein union separately within EAO and LTL",
    "blank retained row (Plot_value = 0; FDR = NA)",
    "ascending maximum -log10(FDR), giving strongest pathway at top",
    "EAO above LTL", "Transcriptome left; Proteome right",
    "common across all four panels", "#A65D68", "#355C8A", "Arial",
    paste0("8.8 x ", sprintf("%.2f", plot_height), " inches")
  ),
  stringsAsFactors = FALSE
)
write.xlsx(
  list(
    Plot_data = plot_data,
    Pathway_union = site_union,
    Summary = summary_table,
    Methods_and_QA = methods_qa
  ),
  output_xlsx, overwrite = TRUE, asTable = TRUE
)

clean_pathway_label <- function(x) {
  vapply(strsplit(x, "|||", fixed = TRUE), `[`, character(1), 3)
}

x_max <- max(plot_data$Minus_log10_FDR, na.rm = TRUE)
p <- ggplot(
  plot_data,
  aes(x = Plot_value, y = Pathway_key, fill = Higher_in)
) +
  geom_vline(
    xintercept = -log10(0.05), color = "#9A9EA2",
    linewidth = 0.34, linetype = "22"
  ) +
  geom_col(
    data = plot_data[plot_data$Present_in_omics, , drop = FALSE],
    width = 0.66, orientation = "y",
    color = "#303337", linewidth = 0.30, show.legend = FALSE
  ) +
  facet_grid(
    rows = vars(Higher_in), cols = vars(Omics),
    scales = "free_y", space = "free_y", drop = FALSE
  ) +
  scale_fill_manual(values = site_colors, drop = FALSE) +
  scale_x_continuous(
    limits = c(0, x_max * 1.03),
    expand = expansion(mult = c(0, 0)),
    breaks = scales::pretty_breaks(n = 6)
  ) +
  scale_y_discrete(labels = clean_pathway_label, drop = TRUE) +
  labs(x = expression(-log[10] * "(FDR)"), y = NULL) +
  theme_bw(base_size = 10.5, base_family = "Arial") +
  theme(
    plot.background = element_rect(fill = "white", color = NA),
    panel.background = element_rect(fill = "white", color = NA),
    panel.grid.major.y = element_blank(),
    panel.grid.minor = element_blank(),
    panel.grid.major.x = element_line(color = "#E4E6E8", linewidth = 0.30),
    panel.border = element_rect(color = "#303337", linewidth = 0.46),
    strip.background = element_rect(fill = "#F1F1F1", color = "#B8BABD",
                                    linewidth = 0.38),
    strip.text.x = element_text(face = "bold", size = 10.0,
                                color = "#25282C"),
    strip.text.y = element_text(face = "bold", size = 10.0,
                                color = "#25282C"),
    axis.title.x = element_text(size = 10.2, color = "#25282C",
                                margin = margin(t = 7)),
    axis.text.x = element_text(size = 8.7, color = "#25282C"),
    axis.text.y = element_text(size = 8.2, color = "#25282C"),
    axis.ticks = element_line(color = "#303337", linewidth = 0.34),
    axis.ticks.length = unit(1.3, "mm"),
    panel.spacing.x = unit(4.0, "mm"),
    panel.spacing.y = unit(3.2, "mm"),
    plot.margin = margin(5.0, 5.0, 4.5, 5.0)
  )

plot_width <- 8.8
ggsave(paste0(output_stub, ".pdf"), p, device = cairo_pdf,
       width = plot_width, height = plot_height, units = "in", family = "Arial")
ggsave(paste0(output_stub, ".png"), p, device = "png",
       width = plot_width, height = plot_height, units = "in",
       dpi = 600, bg = "white")
svg(paste0(output_stub, ".svg"), width = plot_width, height = plot_height,
    family = "Arial", bg = "white", onefile = TRUE)
print(p)
dev.off()

message("Figure 5C written to: ", figure_dir)
message("Plot data written to: ", table_dir)
print(summary_table)
