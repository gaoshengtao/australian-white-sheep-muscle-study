#!/usr/bin/env Rscript

# Figure 5: EAO-LTL untargeted-metabolome and targeted-fatty-acid PCoA.
# The analytical and visual conventions match Figure 3F/G.
#
# Untargeted metabolome:
#   all 1,611 named features, inverse log10(TIC + 1), square-root transform,
#   Bray-Curtis distance.
# Targeted fatty acids:
#   absolute contents (ug/mg) without normalization/transformation,
#   Bray-Curtis distance.
# Statistics for both datasets:
#   distance ~ Animal + Site with all within-animal EAO/LTL label swaps.

rm(list = ls())

suppressPackageStartupMessages({
  library(ggplot2)
  library(grid)
  library(openxlsx)
  library(vegan)
})

options(stringsAsFactors = FALSE)
set.seed(20260909)

project_dir <- "__PROJECT_ROOT__"
work_dir <- file.path(project_dir, "11_Figure5_EAO_LTL_meat_color")
figure_dir <- file.path(work_dir, "Figures")
table_dir <- file.path(work_dir, "Tables")
dir.create(figure_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(table_dir, recursive = TRUE, showWarnings = FALSE)

untargeted_file <- file.path(
  project_dir, "06_LCMS_untarget",
  "01_PM_SM_TIC_OPLSDA_VIP_paired_Wilcoxon",
  "pos_neg_named_HMDB_TIC_log10_normalized.tsv"
)
fatty_acid_file <- file.path(project_dir, "02_fatty_acids", "fatty acids.xlsx")
fatty_acid_sheet <- "measurement.xls"
stopifnot(file.exists(untargeted_file), file.exists(fatty_acid_file))

site_order <- c("EAO", "LTL")
site_colors <- c(EAO = "#A65D68", LTL = "#355C8A")
eao_samples <- paste0("AM_", 1:6)
ltl_samples <- paste0("LT_", 1:6)
sample_order <- as.vector(rbind(eao_samples, ltl_samples))
plot_width_in <- 5.2
plot_height_in <- 4.5

write_tsv <- function(x, filename) {
  write.table(
    x, file.path(table_dir, filename), sep = "\t", quote = FALSE,
    row.names = FALSE, na = "NA"
  )
}

format_p <- function(p) {
  if (!is.finite(p)) return("NA")
  if (p < 0.001) return(format(p, scientific = TRUE, digits = 1))
  formatC(p, format = "f", digits = 3)
}

adonis_to_table <- function(x) {
  data.frame(
    Term = rownames(x), as.data.frame(x, check.names = FALSE),
    row.names = NULL, check.names = FALSE
  )
}

# All 2^6 within-animal EAO/LTL label swaps except the identity ordering.
make_exact_paired_permutations <- function(n_animals = 6L) {
  n_samples <- 2L * n_animals
  permutations <- t(vapply(
    seq_len(2^n_animals - 1L),
    function(mask) {
      index <- seq_len(n_samples)
      bits <- as.integer(intToBits(mask))[seq_len(n_animals)]
      for (animal_i in seq_len(n_animals)) {
        if (bits[animal_i] == 1L) {
          pair_index <- c(2L * animal_i - 1L, 2L * animal_i)
          index[pair_index] <- rev(index[pair_index])
        }
      }
      index
    },
    integer(n_samples)
  ))
  stopifnot(nrow(unique(permutations)) == 2^n_animals - 1L)
  permutations
}

centroid_confidence_ellipse <- function(data, level = 0.95, n_points = 200L) {
  coordinates <- as.matrix(data[, c("PCoA1", "PCoA2"), drop = FALSE])
  n <- nrow(coordinates)
  p <- ncol(coordinates)
  if (n <= p) stop("Too few samples for a two-dimensional confidence ellipse.")
  covariance_matrix <- stats::cov(coordinates)
  eigen_decomposition <- eigen(covariance_matrix, symmetric = TRUE)
  if (any(eigen_decomposition$values <= 0)) {
    stop("Non-positive covariance eigenvalue in confidence ellipse.")
  }
  hotelling_factor <-
    p * (n - 1) / (n * (n - p)) * stats::qf(level, p, n - p)
  transform_matrix <- eigen_decomposition$vectors %*%
    diag(sqrt(eigen_decomposition$values * hotelling_factor), nrow = p)
  angles <- seq(0, 2 * pi, length.out = n_points)
  unit_circle <- cbind(cos(angles), sin(angles))
  ellipse_coordinates <- sweep(
    unit_circle %*% t(transform_matrix), 2, colMeans(coordinates), "+"
  )
  data.frame(PCoA1 = ellipse_coordinates[, 1], PCoA2 = ellipse_coordinates[, 2])
}

make_metadata <- function(matrix_for_distance, feature_label, total_label) {
  metadata <- data.frame(
    Sample = sample_order,
    Site = factor(rep(site_order, times = 6L), levels = site_order),
    Animal = factor(rep(1:6, each = 2L), levels = as.character(1:6)),
    Detected_features = colSums(matrix_for_distance > 0),
    Abundance_sum = colSums(matrix_for_distance),
    row.names = sample_order,
    stringsAsFactors = FALSE
  )
  names(metadata)[4:5] <- c(feature_label, total_label)
  pairing <- table(metadata$Animal, metadata$Site)
  if (!all(dim(pairing) == c(6L, 2L)) || !all(pairing == 1L)) {
    stop("Expected one EAO and one LTL sample from each of six animals.")
  }
  metadata
}

run_pcoa <- function(matrix_for_distance, metadata, analysis_label,
                     output_prefix, input_scale_note) {
  if (any(!is.finite(matrix_for_distance)) || any(matrix_for_distance < 0)) {
    stop(analysis_label, " matrix contains invalid values.")
  }
  detected <- rowSums(matrix_for_distance > 0) > 0
  matrix_for_distance <- matrix_for_distance[detected, , drop = FALSE]
  if (nrow(matrix_for_distance) < 2L) stop("Too few detected features.")

  bray_distance <- vegan::vegdist(t(matrix_for_distance), method = "bray")
  distance_matrix <- as.matrix(bray_distance)
  uncorrected_pcoa <- vegan::wcmdscale(bray_distance, k = 2, eig = TRUE, add = FALSE)
  pcoa_fit <- vegan::wcmdscale(
    bray_distance, k = 2, eig = TRUE, add = "lingoes", x.ret = TRUE
  )
  positive_eigenvalues <- as.numeric(pcoa_fit$eig[pcoa_fit$eig > 0])
  if (length(positive_eigenvalues) < 2L) stop("Fewer than two positive PCoA axes.")
  pcoa_variance <- 100 * positive_eigenvalues / sum(positive_eigenvalues)

  coordinates <- data.frame(
    Sample = rownames(pcoa_fit$points),
    PCoA1 = pcoa_fit$points[, 1],
    PCoA2 = pcoa_fit$points[, 2],
    Site = metadata[rownames(pcoa_fit$points), "Site"],
    Animal = metadata[rownames(pcoa_fit$points), "Animal"],
    stringsAsFactors = FALSE
  )
  coordinates$Site <- factor(coordinates$Site, levels = site_order)
  coordinates$Animal <- factor(coordinates$Animal, levels = as.character(1:6))

  variance_table <- data.frame(
    Axis = paste0("PCoA", seq_along(positive_eigenvalues)),
    Positive_eigenvalue = positive_eigenvalues,
    Variance_explained_percent = pcoa_variance,
    Cumulative_variance_percent = cumsum(pcoa_variance)
  )

  ellipses <- do.call(rbind, lapply(site_order, function(site_name) {
    z <- coordinates[coordinates$Site == site_name, , drop = FALSE]
    ellipse <- centroid_confidence_ellipse(z)
    ellipse$Site <- factor(site_name, levels = site_order)
    ellipse$Point_order <- seq_len(nrow(ellipse))
    ellipse
  }))
  centroids <- do.call(rbind, lapply(site_order, function(site_name) {
    z <- coordinates[coordinates$Site == site_name, , drop = FALSE]
    data.frame(
      Site = site_name, n = nrow(z),
      PCoA1_centroid = mean(z$PCoA1), PCoA2_centroid = mean(z$PCoA2)
    )
  }))

  permutation_matrix <- make_exact_paired_permutations(6L)
  adonis_fit <- vegan::adonis2(
    bray_distance ~ Animal + Site, data = metadata,
    permutations = permutation_matrix, by = "margin", parallel = 1
  )
  adonis_full <- adonis_to_table(adonis_fit)
  site_row <- adonis_full[adonis_full$Term == "Site", , drop = FALSE]
  residual_row <- adonis_full[adonis_full$Term == "Residual", , drop = FALSE]
  if (nrow(site_row) != 1L || nrow(residual_row) != 1L) {
    stop("Could not extract Site and Residual rows from adonis2.")
  }
  adonis_summary <- data.frame(
    Dataset = analysis_label,
    Test = "EAO vs LTL paired Site effect",
    Model = "Bray-Curtis distance ~ Animal + Site",
    Site_Df = site_row$Df,
    Site_SumOfSqs = site_row$SumOfSqs,
    Site_R2_total = site_row$R2,
    Site_partial_R2 = site_row$SumOfSqs /
      (site_row$SumOfSqs + residual_row$SumOfSqs),
    Pseudo_F = site_row$F,
    P_value = site_row[["Pr(>F)"]],
    Exact_nonidentity_permutations = nrow(permutation_matrix),
    Total_label_configurations_including_observed = nrow(permutation_matrix) + 1L,
    Minimum_attainable_P = 1 / (nrow(permutation_matrix) + 1L),
    Permutation_restriction = "EAO/LTL label swaps within Animal",
    Input_scale = input_scale_note,
    Features_used = nrow(matrix_for_distance),
    stringsAsFactors = FALSE
  )

  dispersion_fit <- vegan::betadisper(
    bray_distance, group = metadata$Site, type = "median", bias.adjust = TRUE
  )
  dispersion_test <- vegan::permutest(
    dispersion_fit, permutations = permutation_matrix, pairwise = FALSE
  )
  dispersion_overall <- data.frame(
    Term = rownames(dispersion_test$tab),
    as.data.frame(dispersion_test$tab, check.names = FALSE),
    row.names = NULL, check.names = FALSE
  )
  dispersion_distances <- data.frame(
    Sample = rownames(metadata), Site = metadata$Site, Animal = metadata$Animal,
    Distance_to_site_spatial_median = dispersion_fit$distances
  )
  correction <- data.frame(
    Method = "Lingoes", Additive_constant = pcoa_fit$ac,
    Negative_eigenvalues_before_correction = sum(uncorrected_pcoa$eig < -1e-10),
    Sum_positive_eigenvalues = sum(positive_eigenvalues)
  )

  annotation_label <- sprintf(
    "R²: %.2f\nP-value: %s",
    adonis_summary$Site_R2_total, format_p(adonis_summary$P_value)
  )
  p <- ggplot(coordinates, aes(PCoA1, PCoA2)) +
    geom_hline(yintercept = 0, color = "#D8DADD", linewidth = 0.32) +
    geom_vline(xintercept = 0, color = "#D8DADD", linewidth = 0.32) +
    geom_polygon(
      data = ellipses, aes(PCoA1, PCoA2, group = Site, fill = Site),
      inherit.aes = FALSE, alpha = 0.12, color = NA, show.legend = FALSE
    ) +
    geom_path(
      data = ellipses, aes(PCoA1, PCoA2, group = Site, color = Site),
      inherit.aes = FALSE, linewidth = 0.62, alpha = 0.88,
      show.legend = FALSE
    ) +
    geom_point(
      aes(fill = Site), shape = 21, size = 3.2, stroke = 0.45,
      alpha = 0.92, color = "#1F2328"
    ) +
    annotate(
      "text", x = -Inf, y = Inf, label = annotation_label,
      hjust = -0.10, vjust = 1.18, family = "Arial", size = 3.0,
      color = "#30363D", lineheight = 1.05
    ) +
    scale_fill_manual(values = site_colors, breaks = site_order, drop = FALSE) +
    scale_color_manual(values = site_colors, breaks = site_order, drop = FALSE) +
    scale_x_continuous(expand = expansion(mult = 0.12)) +
    scale_y_continuous(expand = expansion(mult = 0.12)) +
    labs(
      title = analysis_label,
      x = sprintf("PCoA1 (%.1f%%)", pcoa_variance[1]),
      y = sprintf("PCoA2 (%.1f%%)", pcoa_variance[2]),
      fill = NULL
    ) +
    theme_bw(base_size = 10.5, base_family = "Arial") +
    theme(
      aspect.ratio = 1,
      plot.title = element_text(
        hjust = 0.5, size = 11.2, face = "plain", color = "#1F2328",
        margin = margin(b = 4)
      ),
      panel.grid = element_blank(),
      panel.border = element_rect(color = "#1F1F1F", linewidth = 0.5),
      axis.text = element_text(color = "#30363D", size = 8.5),
      axis.title = element_text(color = "#1F2328", size = 10.5),
      axis.title.x = element_text(margin = margin(t = 7)),
      axis.title.y = element_text(margin = margin(r = 7)),
      axis.ticks = element_line(color = "#1F1F1F", linewidth = 0.4),
      axis.ticks.length = unit(2, "mm"),
      legend.position = "right",
      legend.text = element_text(size = 9, color = "#1F2328"),
      legend.key = element_blank(),
      plot.margin = margin(t = 5, r = 7, b = 5, l = 7)
    ) +
    guides(fill = guide_legend(override.aes = list(
      shape = 21, size = 3.2, stroke = 0.45, alpha = 0.92,
      color = "#1F2328"
    )))

  figure_stub <- file.path(figure_dir, output_prefix)
  ggsave(
    paste0(figure_stub, ".pdf"), p, device = cairo_pdf,
    width = plot_width_in, height = plot_height_in, units = "in",
    family = "Arial"
  )
  ggsave(
    paste0(figure_stub, ".png"), p, device = "png",
    width = plot_width_in, height = plot_height_in, units = "in",
    dpi = 600, bg = "white"
  )
  svg(
    paste0(figure_stub, ".svg"), width = plot_width_in,
    height = plot_height_in, family = "Arial", bg = "white", onefile = TRUE
  )
  print(p)
  dev.off()

  list(
    Plot = p, Metadata = data.frame(metadata, row.names = NULL,
                                    check.names = FALSE),
    PCoA_coordinates = coordinates, PCoA_variance = variance_table,
    Confidence_ellipses = ellipses, Site_centroids = centroids,
    Adonis_full = adonis_full, Adonis_summary = adonis_summary,
    PERMDISP_overall = dispersion_overall,
    PERMDISP_sample_distances = dispersion_distances,
    PCoA_correction = correction,
    Distance_matrix = data.frame(
      Sample = rownames(distance_matrix), distance_matrix,
      row.names = NULL, check.names = FALSE
    ),
    Input_matrix = data.frame(
      Feature = rownames(matrix_for_distance), matrix_for_distance,
      row.names = NULL, check.names = FALSE
    )
  )
}

# -------------------------------------------------------------------------
# Untargeted metabolome: all named features, Figure 3F transformation
# -------------------------------------------------------------------------
untargeted <- read.delim(
  untargeted_file, check.names = FALSE, quote = "", comment.char = ""
)
required_untargeted <- c("Feature_key", "Metabolite", sample_order)
missing_untargeted <- setdiff(required_untargeted, names(untargeted))
if (length(missing_untargeted)) {
  stop("Untargeted input lacks: ", paste(missing_untargeted, collapse = ", "))
}
if (anyDuplicated(untargeted$Feature_key)) stop("Feature_key is not unique.")
if (any(is.na(untargeted$Metabolite) | trimws(untargeted$Metabolite) == "")) {
  stop("Untargeted input contains unnamed features.")
}
log10_tic <- as.matrix(untargeted[, sample_order, drop = FALSE])
storage.mode(log10_tic) <- "double"
rownames(log10_tic) <- untargeted$Feature_key
if (any(!is.finite(log10_tic)) || any(log10_tic < 0)) {
  stop("Untargeted normalized matrix contains invalid values.")
}
tic_scaled <- 10^log10_tic - 1
tic_scaled[tic_scaled < 0 & tic_scaled > -1e-8] <- 0
if (any(tic_scaled < 0)) stop("Negative back-transformed untargeted abundance.")
sqrt_tic <- sqrt(tic_scaled)
untargeted_metadata <- make_metadata(
  sqrt_tic, "Named_features_detected", "TIC_scaled_sqrt_sum"
)
untargeted_result <- run_pcoa(
  sqrt_tic, untargeted_metadata,
  analysis_label = "Untargeted metabolism",
  output_prefix = "Fig5_EAO_LTL_untargeted_metabolome_BrayCurtis_PCoA_95CI",
  input_scale_note = "sqrt(back-transformed log10(TIC-scaled abundance + 1)); all named features"
)

# -------------------------------------------------------------------------
# Targeted fatty acids: direct absolute contents, Figure 3G convention
# -------------------------------------------------------------------------
fatty_acids <- read.xlsx(
  fatty_acid_file, sheet = fatty_acid_sheet, check.names = FALSE,
  detectDates = FALSE, skipEmptyRows = FALSE
)
required_fatty_acid <- c(
  "Metabolite", "CAS.id", "Formula", "KEGG.Compound.ID", "unit",
  "Retention.time", sample_order
)
missing_fatty_acid <- setdiff(required_fatty_acid, names(fatty_acids))
if (length(missing_fatty_acid)) {
  stop("Fatty-acid input lacks: ", paste(missing_fatty_acid, collapse = ", "))
}
if (anyDuplicated(fatty_acids$Metabolite)) stop("Fatty-acid names are not unique.")
if (length(unique(fatty_acids$unit)) != 1L || unique(fatty_acids$unit) != "ug/mg") {
  stop("Expected a single targeted-fatty-acid unit: ug/mg.")
}
absolute_fatty_acid <- as.matrix(fatty_acids[, sample_order, drop = FALSE])
storage.mode(absolute_fatty_acid) <- "double"
rownames(absolute_fatty_acid) <- fatty_acids$Metabolite
fatty_acid_metadata <- make_metadata(
  absolute_fatty_acid, "Fatty_acids_detected",
  "Total_fatty_acid_content_ug_mg"
)
fatty_acid_result <- run_pcoa(
  absolute_fatty_acid, fatty_acid_metadata,
  analysis_label = "Targeted fatty acids",
  output_prefix = "Fig5_EAO_LTL_targeted_fatty_acids_absolute_BrayCurtis_PCoA_95CI",
  input_scale_note = "absolute fatty-acid content (ug/mg); no normalization or transformation"
)

# -------------------------------------------------------------------------
# Auditable tables
# -------------------------------------------------------------------------
write_analysis_tables <- function(result, prefix) {
  write_tsv(result$Metadata, paste0(prefix, "_sample_metadata.tsv"))
  write_tsv(result$PCoA_coordinates, paste0(prefix, "_PCoA_coordinates.tsv"))
  write_tsv(result$PCoA_variance, paste0(prefix, "_PCoA_variance.tsv"))
  write_tsv(result$Confidence_ellipses, paste0(prefix, "_PCoA_centroid_95CI_coordinates.tsv"))
  write_tsv(result$Site_centroids, paste0(prefix, "_PCoA_site_centroids.tsv"))
  write_tsv(result$Adonis_full, paste0(prefix, "_paired_Adonis_full.tsv"))
  write_tsv(result$Adonis_summary, paste0(prefix, "_paired_Adonis_summary.tsv"))
  write_tsv(result$PERMDISP_overall, paste0(prefix, "_PERMDISP_overall.tsv"))
  write_tsv(result$PERMDISP_sample_distances, paste0(prefix, "_PERMDISP_sample_distances.tsv"))
  write_tsv(result$PCoA_correction, paste0(prefix, "_PCoA_correction.tsv"))
  write_tsv(result$Distance_matrix, paste0(prefix, "_BrayCurtis_distance_matrix.tsv"))
  write_tsv(result$Input_matrix, paste0(prefix, "_PCoA_input.tsv"))
}
write_analysis_tables(untargeted_result, "Fig5_EAO_LTL_untargeted_metabolome")
write_analysis_tables(fatty_acid_result, "Fig5_EAO_LTL_targeted_fatty_acids_absolute")

qa <- data.frame(
  Item = c(
    "Comparison", "Animals", "Samples per site", "Distance",
    "PCoA correction", "PERMANOVA model", "Permutation restriction",
    "Nonidentity permutations", "Untargeted feature policy",
    "Untargeted features used", "Untargeted abundance scale",
    "Targeted features used", "Targeted abundance scale", "Figure size",
    "Panel aspect ratio", "Font"
  ),
  Value = c(
    "EAO vs LTL", 6, 6, "Bray-Curtis", "Lingoes",
    "distance ~ Animal + Site", "EAO/LTL swaps within each animal", 63,
    "all named features; no QC-CV filtering",
    nrow(untargeted_result$Input_matrix),
    "sqrt(back-transformed log10(TIC-scaled abundance + 1))",
    nrow(fatty_acid_result$Input_matrix),
    "absolute ug/mg; no normalization/transformation",
    sprintf("%.1f x %.1f in", plot_width_in, plot_height_in), "1:1", "Arial"
  ),
  stringsAsFactors = FALSE
)
write_tsv(qa, "Fig5_EAO_LTL_metabolome_targeted_FA_PCoA_Adonis_QA.tsv")

write.xlsx(
  list(
    Summary = rbind(untargeted_result$Adonis_summary,
                    fatty_acid_result$Adonis_summary),
    Untargeted_coordinates = untargeted_result$PCoA_coordinates,
    Untargeted_variance = untargeted_result$PCoA_variance,
    Untargeted_Adonis = untargeted_result$Adonis_full,
    Untargeted_PERMDISP = untargeted_result$PERMDISP_overall,
    Fatty_acid_coordinates = fatty_acid_result$PCoA_coordinates,
    Fatty_acid_variance = fatty_acid_result$PCoA_variance,
    Fatty_acid_Adonis = fatty_acid_result$Adonis_full,
    Fatty_acid_PERMDISP = fatty_acid_result$PERMDISP_overall,
    QA = qa
  ),
  file.path(
    table_dir,
    "Fig5_EAO_LTL_untargeted_targeted_FA_PCoA_Adonis_results.xlsx"
  ),
  overwrite = TRUE, asTable = TRUE
)

cat("Figure 5 EAO-LTL metabolome PCoA completed.\n")
print(rbind(untargeted_result$Adonis_summary,
            fatty_acid_result$Adonis_summary)[,
  c("Dataset", "Site_R2_total", "Site_partial_R2", "Pseudo_F", "P_value",
    "Features_used")
])
