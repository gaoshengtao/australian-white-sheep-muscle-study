#!/usr/bin/env Rscript

# Turn significant Figure 5 KEGG GSEA results into an ordered, non-graphical
# biological clue. Pathway/module overlaps are explicitly labelled so they are
# not counted as independent evidence.

suppressPackageStartupMessages(library(openxlsx))

work_dir <- "__PROJECT_ROOT__/11_Figure5_EAO_LTL_meat_color"
table_dir <- file.path(work_dir, "Tables")
input_file <- file.path(
  table_dir,
  "Fig5_EAO_LTL_meat_color_PATHWAY_MODULE_GSEA_q_lt_0.05.tsv"
)
stopifnot(file.exists(input_file))

gsea <- read.delim(input_file, check.names = FALSE, quote = "", comment.char = "")

chain_manifest <- data.frame(
  Branch = c(
    rep("LTL mitochondrial oxygen-use axis", 7),
    rep("EAO structural light-scattering axis", 4)
  ),
  Step = c(1, 2, 2, 3, 4, 4, 4, 1, 2, 3, 4),
  Set_ID = c(
    "M00307", "M00009", "hsa00020", "M00142", "hsa00190", "M00158",
    "hsa04714", "hsa04512", "hsa04510", "hsa04810", "hsa04820"
  ),
  Position_in_chain = c(
    "Pyruvate entry into mitochondrial acetyl-CoA",
    "TCA-cycle production of reducing equivalents",
    "TCA-cycle production of reducing equivalents (pathway-level duplicate)",
    "NADH electron entry through respiratory complex I",
    "Integrated respiratory electron transfer and proton pumping",
    "ATP synthase use of the proton gradient (component of OXPHOS)",
    "Parallel respiration-associated mitochondrial signature; not a literal downstream step",
    "Extracellular ligands and matrix receptors",
    "Cell-matrix adhesion and force transmission",
    "Actin-cytoskeleton remodelling/regulation",
    "Muscle-cell structural architecture"
  ),
  Non_independence_note = c(
    "Distinct upstream module",
    "Same biological process as hsa00020",
    "Same biological process as M00009",
    "Component of hsa00190",
    "Umbrella pathway overlapping M00142 and M00158",
    "Component of hsa00190",
    "Strongly overlaps oxidative-phosphorylation genes",
    "Partly overlaps focal adhesion/cytoskeleton sets",
    "Connects ECM-receptor and cytoskeleton programmes",
    "Overlaps focal adhesion and muscle cytoskeleton",
    "Overlaps focal adhesion/actin-regulation genes"
  ),
  stringsAsFactors = FALSE
)

chain <- merge(chain_manifest, gsea, by = "Set_ID", all.x = TRUE, sort = FALSE)
chain <- chain[match(chain_manifest$Set_ID, chain$Set_ID), , drop = FALSE]
if (anyNA(chain$NES) || any(chain$qvalue >= 0.05)) {
  stop("Chain contains a missing or non-significant GSEA set.")
}

chain$Biological_interpretation <- ifelse(
  chain$Branch == "LTL mitochondrial oxygen-use axis",
  paste0(
    "Coordinated enrichment in LTL supports a stronger mitochondrial oxidative programme. ",
    "This can influence postmortem oxygen competition and pigment redox state, but is not a direct oxygen-consumption measurement."
  ),
  paste0(
    "Coordinated enrichment in EAO supports a distinct ECM-to-cytoskeleton structural state. ",
    "This may alter fibre packing and optical scattering, but microstructure was not directly measured."
  )
)

chain_text <- c(
  "Figure 5 significant KEGG GSEA mechanism clue (EAO versus LTL)",
  "",
  "LTL mitochondrial oxygen-use axis:",
  paste(
    "Pyruvate oxidation (M00307)",
    "Citrate cycle [M00009 + hsa00020; duplicate module/pathway views]",
    "NADH:ubiquinone oxidoreductase / complex I (M00142)",
    "Oxidative phosphorylation (hsa00190)",
    "F-type ATPase (M00158)",
    sep = " -> "
  ),
  "Thermogenesis (hsa04714) is a parallel overlapping mitochondrial signature, not a separate terminal reaction.",
  "Interpretation: stronger LTL mitochondrial respiration may change postmortem oxygen competition and myoglobin redox/oxygenation, potentially contributing to lower redness than EAO.",
  "",
  "EAO structural light-scattering axis:",
  paste(
    "ECM-receptor interaction (hsa04512)",
    "Focal adhesion (hsa04510)",
    "Regulation of actin cytoskeleton (hsa04810)",
    "Cytoskeleton in muscle cells (hsa04820)",
    "altered fibre/myofibril packing and optical scattering",
    sep = " -> "
  ),
  "Interpretation: this axis is most relevant to the lower L* of EAO; it is not evidence of greater pigment abundance.",
  "",
  "Boundary of evidence:",
  "Porphyrin metabolism, animal heme biosynthesis, glutathione metabolism/biosynthesis, pentose-phosphate pathways and glycolysis were not significant at q < 0.05.",
  "Therefore, this GSEA does not support claims that EAO-LTL colour differences are driven by altered heme supply, a globally activated glutathione programme, or a broad glycolytic programme.",
  "GSEA indicates coordinated association, not temporal causality; pathway/module overlaps must not be counted as independent replications."
)

write.table(
  chain,
  file.path(table_dir, "Fig5_EAO_LTL_significant_GSEA_mechanism_chain.tsv"),
  sep = "\t", quote = FALSE, row.names = FALSE, na = "NA"
)
writeLines(
  chain_text,
  file.path(table_dir, "Fig5_EAO_LTL_significant_GSEA_mechanism_chain.txt")
)
write.xlsx(
  list(Ordered_chain = chain, Significant_GSEA = gsea,
       Interpretation = data.frame(Text = chain_text)),
  file.path(table_dir, "Fig5_EAO_LTL_significant_GSEA_mechanism_chain.xlsx"),
  overwrite = TRUE, asTable = TRUE
)

cat(paste(chain_text, collapse = "\n"), "\n")
