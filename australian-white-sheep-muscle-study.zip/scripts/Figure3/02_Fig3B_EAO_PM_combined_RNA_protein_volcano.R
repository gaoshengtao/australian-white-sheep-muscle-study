#!/usr/bin/env Rscript

# Figure 3B: combined EAO-PM volcano plot for transcriptome and proteome.
# Comparison is PM_vs_EAO in both source result tables:
#   log2FC > 0: enriched in PM
#   log2FC < 0: enriched in EAO
# Encoding:
#   Transcriptome = circle; Proteome = square
#   FDR < 0.05 = solid site color; FDR >= 0.05 = neutral gray
#   EAO/PM colors follow the project-wide site palette.

suppressPackageStartupMessages({
  library(ggplot2)
  library(openxlsx)
})

project_dir <- "__PROJECT_ROOT__"
work_dir <- file.path(project_dir, "09_Figure3_EAO_PM_IMF_tenderness_decoupling")
source_dir <- file.path(
  project_dir, "07_Figure2_muscle_functional_states",
  "03_One_vs_rest_specificity", "Tables"
)
figure_dir <- file.path(work_dir, "Figures")
table_dir <- file.path(work_dir, "Tables")
dir.create(figure_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(table_dir, recursive = TRUE, showWarnings = FALSE)

rna_file <- file.path(
  source_dir,
  "Fig2_muscle_fiber_pairwise_transcriptome_DESeq2_all_gene_results.tsv.gz"
)
protein_file <- file.path(
  source_dir,
  "Fig2_muscle_fiber_pairwise_proteome_limma_all_gene_results.tsv.gz"
)
figure_stub <- file.path(
  figure_dir, "Fig3B_EAO_PM_combined_RNA_protein_volcano"
)
plot_data_file <- file.path(
  table_dir, "Fig3B_EAO_PM_combined_volcano_plot_data.tsv.gz"
)
summary_file <- file.path(
  table_dir, "Fig3B_EAO_PM_combined_volcano_counts.tsv"
)
highlight_file <- file.path(
  table_dir, "Fig3B_EAO_PM_highlighted_features.xlsx"
)

for (f in c(rna_file, protein_file)) {
  if (!file.exists(f)) stop("Input file not found: ", f)
}

read_eao_pm <- function(path, omics) {
  d <- read.delim(gzfile(path), check.names = FALSE)
  required <- c(
    "Gene_symbol", "Comparison", "log2FoldChange", "P_value", "P_FDR_BH"
  )
  missing_columns <- setdiff(required, names(d))
  if (length(missing_columns)) {
    stop(
      "Missing columns in ", basename(path), ": ",
      paste(missing_columns, collapse = ", ")
    )
  }

  d <- d[
    d$Comparison == "PM_vs_EAO" &
      is.finite(d$log2FoldChange) &
      !is.na(d$P_value) & d$P_value > 0 &
      !is.na(d$P_FDR_BH),
    , drop = FALSE
  ]

  feature_id <- if (omics == "Transcriptome") {
    if ("gene_id" %in% names(d)) d$gene_id else seq_len(nrow(d))
  } else {
    if ("Human_Entrez_ID" %in% names(d)) d$Human_Entrez_ID else seq_len(nrow(d))
  }

  data.frame(
    Omics = omics,
    Feature_ID = as.character(feature_id),
    Gene_symbol = as.character(d$Gene_symbol),
    Comparison = d$Comparison,
    log2FoldChange_PM_vs_EAO = d$log2FoldChange,
    P_value = d$P_value,
    P_FDR_BH = d$P_FDR_BH,
    stringsAsFactors = FALSE
  )
}

plot_df <- rbind(
  read_eao_pm(rna_file, "Transcriptome"),
  read_eao_pm(protein_file, "Proteome")
)

plot_df$Enriched_site <- ifelse(
  plot_df$log2FoldChange_PM_vs_EAO > 0, "PM", "EAO"
)
plot_df$Evidence <- ifelse(
  plot_df$P_FDR_BH < 0.05,
  "FDR < 0.05",
  "FDR >= 0.05"
)
plot_df$Minus_log10_FDR <- -log10(plot_df$P_FDR_BH)
plot_df$Omics <- factor(
  plot_df$Omics,
  levels = c("Transcriptome", "Proteome")
)
plot_df$Enriched_site <- factor(
  plot_df$Enriched_site,
  levels = c("EAO", "PM")
)
plot_df$Evidence <- factor(
  plot_df$Evidence,
  levels = c("FDR < 0.05", "FDR >= 0.05")
)

count_summary <- do.call(
  rbind,
  lapply(levels(plot_df$Omics), function(omics_name) {
    z <- plot_df[plot_df$Omics == omics_name, , drop = FALSE]
    data.frame(
      Omics = omics_name,
      Tested_features = nrow(z),
      FDR_lt_0.05_total = sum(z$Evidence == "FDR < 0.05"),
      FDR_lt_0.05_EAO = sum(
        z$Evidence == "FDR < 0.05" & z$Enriched_site == "EAO"
      ),
      FDR_lt_0.05_PM = sum(
        z$Evidence == "FDR < 0.05" & z$Enriched_site == "PM"
      ),
      FDR_ge_0.05_total = sum(z$Evidence == "FDR >= 0.05"),
      stringsAsFactors = FALSE
    )
  })
)

expected_fdr <- c(Transcriptome = 4160L, Proteome = 575L)
observed_fdr <- setNames(
  count_summary$FDR_lt_0.05_total,
  count_summary$Omics
)
if (!identical(as.integer(observed_fdr[names(expected_fdr)]),
               as.integer(expected_fdr))) {
  stop(
    "FDR count QA failed. Observed: ",
    paste(names(observed_fdr), observed_fdr, collapse = "; ")
  )
}

write.table(
  count_summary, summary_file, sep = "\t", quote = FALSE,
  row.names = FALSE
)
gz_connection <- gzfile(plot_data_file, open = "wt")
write.table(
  plot_df, gz_connection, sep = "\t", quote = FALSE,
  row.names = FALSE, na = "NA"
)
close(gz_connection)

highlight_df <- plot_df[plot_df$Evidence == "FDR < 0.05", , drop = FALSE]
methods_qa <- data.frame(
  Item = c(
    "Comparison", "Positive log2FC", "Negative log2FC",
    "Colored symbols", "Neutral symbols",
    "Transcriptome symbol", "Proteome symbol", "FDR threshold",
    "Y axis", "Panel aspect ratio", "Font",
    "PM color", "EAO color", "RNA source", "Protein source"
  ),
  Value = c(
    "PM_vs_EAO, paired by Animal in the source differential models",
    "Enriched in PM", "Enriched in EAO", "FDR < 0.05, site-colored",
    "FDR >= 0.05, neutral gray",
    "Circle", "Square", "BH-adjusted P < 0.05", "-log10(BH-adjusted P)",
    "1:1, enforced with theme(aspect.ratio = 1)", "Arial",
    "#C28B48", "#A65D68", rna_file, protein_file
  ),
  stringsAsFactors = FALSE
)
write.xlsx(
  list(
    Counts = count_summary,
    Highlighted_features = highlight_df,
    Methods_and_QA = methods_qa
  ),
  file = highlight_file,
  overwrite = TRUE,
  asTable = TRUE
)

site_colors <- c(EAO = "#A65D68", PM = "#C28B48")
omics_shapes <- c(Transcriptome = 21, Proteome = 22)
background_df <- plot_df[plot_df$Evidence == "FDR >= 0.05", , drop = FALSE]

x_abs <- ceiling(max(abs(plot_df$log2FoldChange_PM_vs_EAO)) * 2) / 2
y_max <- ceiling(max(plot_df$Minus_log10_FDR) * 2) / 2
x_limits <- c(-x_abs, x_abs)
y_limits <- c(0, y_max)

rna_counts <- count_summary[count_summary$Omics == "Transcriptome", ]
protein_counts <- count_summary[count_summary$Omics == "Proteome", ]
rna_label <- sprintf(
  "Transcriptome\nFDR < 0.05: %d\nEAO: %d | PM: %d",
  rna_counts$FDR_lt_0.05_total,
  rna_counts$FDR_lt_0.05_EAO,
  rna_counts$FDR_lt_0.05_PM
)
protein_label <- sprintf(
  "Proteome\nFDR < 0.05: %d\nEAO: %d | PM: %d",
  protein_counts$FDR_lt_0.05_total,
  protein_counts$FDR_lt_0.05_EAO,
  protein_counts$FDR_lt_0.05_PM
)

p <- ggplot() +
  geom_hline(
    yintercept = -log10(0.05), color = "#A8ACB0",
    linewidth = 0.34, linetype = "22"
  ) +
  geom_vline(
    xintercept = 0, color = "#8D9297",
    linewidth = 0.42, linetype = "22"
  ) +
  geom_point(
    data = background_df,
    aes(
      x = log2FoldChange_PM_vs_EAO,
      y = Minus_log10_FDR,
      shape = Omics
    ),
    color = "#B7BABD", fill = "#B7BABD", alpha = 0.25,
    size = 0.38, stroke = 0, show.legend = FALSE
  ) +
  geom_point(
    data = highlight_df,
    aes(
      x = log2FoldChange_PM_vs_EAO,
      y = Minus_log10_FDR,
      shape = Omics,
      color = Enriched_site,
      fill = Enriched_site
    ),
    size = 0.88, stroke = 0.30, alpha = 0.72
  ) +
  annotate(
    "label", x = x_limits[1] + 0.26, y = y_limits[2] - 0.20,
    label = rna_label, hjust = 0, vjust = 1,
    family = "Arial", fontface = "bold", size = 3.05,
    lineheight = 1.04, linewidth = 0, fill = scales::alpha("white", 0.86),
    label.padding = unit(0.18, "lines")
  ) +
  annotate(
    "label", x = x_limits[2] - 0.26, y = y_limits[2] - 0.20,
    label = protein_label, hjust = 1, vjust = 1,
    family = "Arial", fontface = "bold", size = 3.05,
    lineheight = 1.04, linewidth = 0, fill = scales::alpha("white", 0.86),
    label.padding = unit(0.18, "lines")
  ) +
  scale_x_continuous(
    limits = x_limits,
    expand = expansion(mult = c(0, 0))
  ) +
  scale_y_continuous(
    limits = y_limits,
    expand = expansion(mult = c(0, 0))
  ) +
  scale_shape_manual(
    values = omics_shapes,
    breaks = c("Transcriptome", "Proteome"),
    labels = c("RNA", "Protein"),
    name = "Omics"
  ) +
  scale_color_manual(
    values = site_colors,
    breaks = c("EAO", "PM"),
    name = "Enriched site"
  ) +
  scale_fill_manual(values = site_colors, guide = "none") +
  labs(
    x = expression(log[2] * " fold change (PM / EAO)"),
    y = expression(-log[10] * "(FDR)")
  ) +
  theme_bw(base_size = 10.5, base_family = "Arial") +
  theme(
    aspect.ratio = 1,
    plot.background = element_rect(fill = "white", color = NA),
    panel.background = element_rect(fill = "white", color = NA),
    panel.grid.major = element_line(color = "#E6E8EA", linewidth = 0.30),
    panel.grid.minor = element_blank(),
    panel.border = element_rect(color = "#303337", linewidth = 0.48),
    axis.title = element_text(size = 10.2, color = "#25282C"),
    axis.text = element_text(size = 9.0, color = "#25282C"),
    axis.ticks = element_line(color = "#303337", linewidth = 0.35),
    axis.ticks.length = unit(1.5, "mm"),
    legend.position = "right",
    legend.box = "vertical",
    legend.box.just = "left",
    legend.title = element_text(face = "bold", size = 9.0),
    legend.text = element_text(size = 8.5),
    legend.key.height = unit(4.2, "mm"),
    legend.key.width = unit(4.2, "mm"),
    legend.spacing.y = unit(1.8, "mm"),
    plot.margin = margin(5.0, 4.0, 4.5, 5.0)
  ) +
  guides(
    shape = guide_legend(
      order = 1,
      override.aes = list(
        size = 2.8, stroke = 0.65, color = "#303337", fill = "white",
        alpha = 1
      )
    ),
    color = guide_legend(
      order = 2,
      override.aes = list(shape = 16, size = 2.8, fill = NA, alpha = 1)
    )
  )

plot_width <- 6.20
plot_height <- 4.65

ggsave(
  paste0(figure_stub, ".pdf"), p, device = cairo_pdf,
  width = plot_width, height = plot_height, units = "in", family = "Arial"
)
ggsave(
  paste0(figure_stub, ".png"), p, device = "png",
  width = plot_width, height = plot_height, units = "in",
  dpi = 600, bg = "white"
)
svg(
  paste0(figure_stub, ".svg"), width = plot_width, height = plot_height,
  family = "Arial", bg = "white", onefile = TRUE
)
print(p)
dev.off()

message("Figure 3B written to: ", figure_dir)
message("Tables written to: ", table_dir)
