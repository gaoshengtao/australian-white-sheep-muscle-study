#!/usr/bin/env Rscript

# Integrated RNA-protein preranked GSEA for the hypothesis that EAO favors
# lipid synthesis/storage whereas PM favors lipid mobilization/oxidation.
#
# Rank construction (PM_vs_EAO):
#   1. All RNA and protein features are mapped from Gene_symbol to human Entrez.
#   2. Duplicate same-direction features are averaged on the log2FC scale.
#   3. Direction-conflicting observations retain the row with the smallest
#      raw P value (then largest |log2FC| as a deterministic tie-breaker).
#   4. Positive rank = PM enriched; negative rank = EAO enriched.
#
# KEGG PATHWAY and MODULE memberships are downloaded from the official KEGG
# REST API. Pathways and modules are analyzed separately with
# clusterProfiler::GSEA, and every tested set receives its own classic GSEA
# running-score plot.

rm(list = ls())

suppressPackageStartupMessages({
  library(AnnotationDbi)
  library(clusterProfiler)
  library(enrichplot)
  library(ggplot2)
  library(KEGGREST)
  library(openxlsx)
  library(org.Hs.eg.db)
  library(patchwork)
})

options(stringsAsFactors = FALSE, timeout = 900)
set.seed(20260903)

project_dir <- "__PROJECT_ROOT__"
work_dir <- file.path(
  project_dir, "09_Figure3_EAO_PM_IMF_tenderness_decoupling"
)
source_dir <- file.path(
  project_dir, "07_Figure2_muscle_functional_states",
  "03_One_vs_rest_specificity", "Tables"
)
table_dir <- file.path(work_dir, "Tables")
figure_root <- file.path(
  work_dir, "Figures", "Fig3_EAO_PM_lipid_KEGG_GSEA"
)
dir.create(table_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(figure_root, recursive = TRUE, showWarnings = FALSE)

rna_file <- file.path(
  source_dir,
  "Fig2_muscle_fiber_pairwise_transcriptome_DESeq2_all_gene_results.tsv.gz"
)
protein_file <- file.path(
  source_dir,
  "Fig2_muscle_fiber_pairwise_proteome_limma_all_gene_results.tsv.gz"
)
for (f in c(rna_file, protein_file)) {
  if (!file.exists(f)) stop("Input file not found: ", f)
}

comparison <- "PM_vs_EAO"
omics_order <- c("Transcriptome", "Proteome")
site_colors <- c(EAO = "#A65D68", PM = "#C28B48")

write_tsv <- function(x, filename) {
  write.table(
    x, file.path(table_dir, filename), sep = "\t", quote = FALSE,
    row.names = FALSE, na = "NA"
  )
}

write_gz_tsv <- function(x, filename) {
  connection <- gzfile(file.path(table_dir, filename), open = "wt")
  on.exit(close(connection), add = TRUE)
  write.table(
    x, connection, sep = "\t", quote = FALSE,
    row.names = FALSE, na = "NA"
  )
}

clean_text <- function(x) {
  x <- trimws(as.character(x))
  x[is.na(x)] <- ""
  x
}

safe_filename <- function(x, max_length = 110L) {
  x <- gsub("[^A-Za-z0-9._-]+", "_", x)
  x <- gsub("_+", "_", x)
  x <- gsub("^_|_$", "", x)
  substr(x, 1L, max_length)
}

bind_nonempty <- function(x) {
  x <- x[vapply(x, nrow, integer(1)) > 0L]
  if (!length(x)) return(data.frame())
  output <- do.call(rbind, x)
  rownames(output) <- NULL
  output
}

# ---------------------------------------------------------------------------
# 1. Prespecified KEGG sets and their biological roles
# ---------------------------------------------------------------------------
pathway_manifest <- data.frame(
  Set_type = "PATHWAY",
  Set_ID = c(
    # EAO lipid synthesis, uptake and storage
    "hsa00061", "hsa00062", "hsa01040", "hsa00561", "hsa00564",
    "hsa04975", "hsa04910",
    # PM lipid mobilization, oxidation and downstream energy utilization
    "hsa00071", "hsa01212", "hsa04923", "hsa04146", "hsa04152",
    "hsa04920", "hsa03320", "hsa00020", "hsa00190",
    "hsa04714"
  ),
  Hypothesis_axis = c(
    rep("Lipid synthesis/storage", 7),
    rep("Lipid consumption/oxidation", 10)
  ),
  Evidence_role = c(
    "Direct synthesis", "Direct synthesis", "Direct synthesis",
    "Storage-lipid metabolism", "Supporting lipid remodeling",
    "Lipid uptake", "Regulatory",
    "Direct beta-oxidation", "Mixed fatty-acid metabolism",
    "Lipolysis", "Peroxisomal oxidation", "Regulatory",
    "Regulatory", "Regulatory, branch-dependent",
    "Downstream acetyl-CoA oxidation", "Downstream ATP production",
    "Downstream mitochondrial oxidation"
  ),
  Expected_site = c(rep("EAO", 7), rep("PM", 10)),
  Selection_note = c(
    "de novo fatty-acid synthesis",
    "fatty-acid chain elongation",
    "unsaturated fatty-acid synthesis",
    "includes triacylglycerol synthesis and turnover",
    "membrane-lipid synthesis/remodeling; not IMF-specific",
    "supports uptake of dietary/circulating lipids; interpret cautiously in muscle",
    "broad insulin-linked lipogenic regulation",
    "fatty-acid beta-oxidation",
    "contains both synthesis and degradation branches; direction needs leading-edge inspection",
    "adipocyte lipolysis signaling",
    "very-long-chain and peroxisomal lipid oxidation",
    "broad energy-sensing regulation",
    "broad adipose-muscle metabolic regulation",
    "PPAR alpha/delta support oxidation whereas PPAR gamma supports adipogenesis",
    "downstream oxidation, not substrate-specific",
    "downstream respiration, not substrate-specific",
    "largely mitochondrial respiratory genes"
  ),
  stringsAsFactors = FALSE
)

module_manifest <- data.frame(
  Set_type = "MODULE",
  Set_ID = c(
    # EAO synthesis/storage modules
    "M00082", "M00083", "M00085", "M00415", "M00873", "M00089",
    # PM mobilization/oxidation and downstream energy modules
    "M00086", "M00087", "M00861", "M00098", "M00088",
    "M00009", "M00010", "M00011",
    "M00143", "M00146", "M00147", "M00148", "M00151", "M00154",
    "M00158"
  ),
  Hypothesis_axis = c(
    rep("Lipid synthesis/storage", 6),
    rep("Lipid consumption/oxidation", 15)
  ),
  Evidence_role = c(
    "Direct synthesis", "Direct synthesis", "Direct synthesis",
    "Direct synthesis", "Direct synthesis", "Storage synthesis",
    "Fatty-acid activation", "Direct beta-oxidation",
    "Peroxisomal beta-oxidation", "Triacylglycerol hydrolysis",
    "Fat-derived fuel", "Downstream TCA", "Downstream TCA",
    "Downstream TCA", "Respiratory complex I", "Respiratory complex I",
    "Respiratory complex I", "Respiratory complex II",
    "Respiratory complex III", "Respiratory complex IV",
    "ATP synthase"
  ),
  Expected_site = c(rep("EAO", 6), rep("PM", 15)),
  Selection_note = c(
    "fatty-acid biosynthesis initiation",
    "fatty-acid biosynthesis elongation",
    "mitochondrial fatty-acid elongation",
    "endoplasmic-reticulum fatty-acid elongation",
    "animal mitochondrial fatty-acid biosynthesis",
    "triacylglycerol biosynthesis",
    "acyl-CoA formation before beta-oxidation",
    "mitochondrial beta-oxidation",
    "peroxisomal very-long-chain fatty-acid beta-oxidation",
    "acylglycerol degradation",
    "ketone-body biosynthesis",
    "complete TCA cycle",
    "first TCA carbon-oxidation segment",
    "second TCA carbon-oxidation segment",
    "mitochondrial NADH dehydrogenase Fe-S/flavoprotein core",
    "NADH dehydrogenase alpha subcomplex",
    "NADH dehydrogenase beta subcomplex",
    "succinate dehydrogenase",
    "cytochrome bc1 respiratory unit",
    "cytochrome c oxidase",
    "eukaryotic F-type ATP synthase"
  ),
  stringsAsFactors = FALSE
)

# ---------------------------------------------------------------------------
# 2. Build the full-gene integrated RNA-protein PM/EAO ranking
# ---------------------------------------------------------------------------
rna <- read.delim(
  gzfile(rna_file), check.names = FALSE, quote = "", comment.char = ""
)
protein <- read.delim(
  gzfile(protein_file), check.names = FALSE, quote = "", comment.char = ""
)
required_columns <- c("Gene_symbol", "Comparison", "log2FoldChange", "P_value")
if (length(setdiff(required_columns, names(rna))) ||
    length(setdiff(required_columns, names(protein)))) {
  stop("RNA or protein result table lacks required columns.")
}
rna <- rna[rna$Comparison == comparison, , drop = FALSE]
protein <- protein[protein$Comparison == comparison, , drop = FALSE]

make_source_table <- function(d, omics_name) {
  data.frame(
    Omics = omics_name,
    Source_feature_ID = if (omics_name == "Transcriptome" &&
                            "gene_id" %in% names(d)) {
      as.character(d$gene_id)
    } else if (omics_name == "Proteome" && "Protein_row" %in% names(d)) {
      as.character(d$Protein_row)
    } else {
      as.character(seq_len(nrow(d)))
    },
    Input_Gene_symbol = clean_text(d$Gene_symbol),
    log2FC_PM_vs_EAO = as.numeric(d$log2FoldChange),
    Raw_P = as.numeric(d$P_value),
    Source_FDR = if ("P_FDR_BH" %in% names(d)) as.numeric(d$P_FDR_BH)
      else NA_real_,
    stringsAsFactors = FALSE
  )
}
source_all <- rbind(
  make_source_table(rna, "Transcriptome"),
  make_source_table(protein, "Proteome")
)
source_all <- source_all[
  nzchar(source_all$Input_Gene_symbol) &
    is.finite(source_all$log2FC_PM_vs_EAO) &
    is.finite(source_all$Raw_P),
  , drop = FALSE
]

human_symbol_map <- AnnotationDbi::select(
  org.Hs.eg.db,
  keys = sort(unique(source_all$Input_Gene_symbol)),
  keytype = "SYMBOL",
  columns = c("SYMBOL", "ENTREZID")
)
human_symbol_map <- unique(human_symbol_map[
  !is.na(human_symbol_map$ENTREZID) & nzchar(human_symbol_map$ENTREZID),
  c("SYMBOL", "ENTREZID"), drop = FALSE
])
names(human_symbol_map) <- c("Human_Gene_symbol", "Human_Entrez_ID")
map_multiplicity <- table(human_symbol_map$Human_Gene_symbol)
ambiguous_symbols <- names(map_multiplicity[map_multiplicity > 1L])
if (length(ambiguous_symbols)) {
  # Canonical human symbols should be one-to-one. Ambiguous mappings are
  # removed instead of duplicating a rank statistic across Entrez genes.
  human_symbol_map <- human_symbol_map[
    !human_symbol_map$Human_Gene_symbol %in% ambiguous_symbols,
    , drop = FALSE
  ]
}

mapped_source <- merge(
  source_all, human_symbol_map,
  by.x = "Input_Gene_symbol", by.y = "Human_Gene_symbol",
  all.x = FALSE, all.y = FALSE, sort = FALSE
)
mapped_source$Direction <- ifelse(
  mapped_source$log2FC_PM_vs_EAO > 0, "PM",
  ifelse(mapped_source$log2FC_PM_vs_EAO < 0, "EAO", "Zero")
)

resolve_rows <- function(z, resolution_level) {
  directions <- unique(z$Direction[z$Direction != "Zero"])
  conflict <- length(directions) > 1L
  z <- z[order(z$Raw_P, -abs(z$log2FC_PM_vs_EAO), z$Omics), ]
  if (conflict) {
    selected <- z[1, , drop = FALSE]
    resolved_log2fc <- selected$log2FC_PM_vs_EAO
    rule <- "direction conflict: selected smallest raw P"
    selected_source <- paste(selected$Omics, selected$Source_feature_ID, sep = ":")
  } else {
    selected <- z[1, , drop = FALSE]
    resolved_log2fc <- mean(z$log2FC_PM_vs_EAO)
    rule <- if (nrow(z) > 1L) {
      "same direction: mean log2FC"
    } else {
      "single observation"
    }
    selected_source <- paste(
      paste(z$Omics, z$Source_feature_ID, sep = ":"), collapse = ";"
    )
  }
  data.frame(
    Human_Entrez_ID = selected$Human_Entrez_ID,
    Human_Gene_symbol = selected$Input_Gene_symbol,
    Integrated_log2FC_PM_vs_EAO = resolved_log2fc,
    Minimum_raw_P = min(z$Raw_P),
    Direction_conflict = conflict,
    Resolution_rule = rule,
    Resolution_level = resolution_level,
    Observation_count = nrow(z),
    Omics_membership = paste(
      omics_order[omics_order %in% unique(z$Omics)], collapse = ";"
    ),
    RNA_log2FC = if (any(z$Omics == "Transcriptome")) {
      mean(z$log2FC_PM_vs_EAO[z$Omics == "Transcriptome"])
    } else NA_real_,
    Protein_log2FC = if (any(z$Omics == "Proteome")) {
      mean(z$log2FC_PM_vs_EAO[z$Omics == "Proteome"])
    } else NA_real_,
    Selected_or_averaged_sources = selected_source,
    stringsAsFactors = FALSE
  )
}

# First collapse duplicated sheep annotations within each omics-symbol pair.
within_keys <- interaction(
  mapped_source$Omics, mapped_source$Human_Entrez_ID,
  drop = TRUE, lex.order = TRUE
)
within_resolved <- bind_nonempty(lapply(
  split(mapped_source, within_keys),
  resolve_rows,
  resolution_level = "within omics"
))

# Recreate a source-like table, then integrate RNA and protein for each Entrez.
within_for_integration <- data.frame(
  Omics = sub(";.*$", "", within_resolved$Omics_membership),
  Source_feature_ID = within_resolved$Selected_or_averaged_sources,
  Input_Gene_symbol = within_resolved$Human_Gene_symbol,
  Human_Entrez_ID = within_resolved$Human_Entrez_ID,
  log2FC_PM_vs_EAO = within_resolved$Integrated_log2FC_PM_vs_EAO,
  Raw_P = within_resolved$Minimum_raw_P,
  Direction = ifelse(
    within_resolved$Integrated_log2FC_PM_vs_EAO > 0, "PM",
    ifelse(within_resolved$Integrated_log2FC_PM_vs_EAO < 0, "EAO", "Zero")
  ),
  stringsAsFactors = FALSE
)

entrez_groups <- split(
  within_for_integration, within_for_integration$Human_Entrez_ID
)
integrated_rank_table <- bind_nonempty(lapply(
  entrez_groups, resolve_rows, resolution_level = "between omics"
))
integrated_rank_table <- integrated_rank_table[
  is.finite(integrated_rank_table$Integrated_log2FC_PM_vs_EAO),
  , drop = FALSE
]
integrated_rank_table <- integrated_rank_table[
  order(
    -integrated_rank_table$Integrated_log2FC_PM_vs_EAO,
    integrated_rank_table$Minimum_raw_P,
    integrated_rank_table$Human_Entrez_ID
  ), , drop = FALSE
]
rownames(integrated_rank_table) <- NULL

if (anyDuplicated(integrated_rank_table$Human_Entrez_ID)) {
  stop("The integrated human Entrez ranking is not unique.")
}
gene_list <- integrated_rank_table$Integrated_log2FC_PM_vs_EAO
names(gene_list) <- integrated_rank_table$Human_Entrez_ID
gene_list <- sort(gene_list, decreasing = TRUE)
if (length(gene_list) < 5000L) stop("Too few genes in integrated ranking.")

write_gz_tsv(
  source_all,
  "Fig3_EAO_PM_GSEA_all_source_RNA_protein_features.tsv.gz"
)
write_gz_tsv(
  mapped_source,
  "Fig3_EAO_PM_GSEA_symbol_to_human_Entrez_mapped_features.tsv.gz"
)
write_gz_tsv(
  within_resolved,
  "Fig3_EAO_PM_GSEA_within_omics_duplicate_resolution.tsv.gz"
)
write_gz_tsv(
  integrated_rank_table,
  "Fig3_EAO_PM_GSEA_integrated_RNA_protein_gene_ranking.tsv.gz"
)

# ---------------------------------------------------------------------------
# 3. Download official KEGG PATHWAY and MODULE gene memberships
# ---------------------------------------------------------------------------
download_time <- format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")

pathway_names_raw <- KEGGREST::keggList("pathway", "hsa")
Sys.sleep(0.4)
pathway_links_raw <- KEGGREST::keggLink("hsa", "pathway")
Sys.sleep(0.4)
module_names_raw <- KEGGREST::keggList("module")
Sys.sleep(0.4)
module_to_ko_raw <- KEGGREST::keggLink("ko", "module")
Sys.sleep(0.4)
ko_to_human_raw <- KEGGREST::keggLink("hsa", "ko")

pathway_names <- data.frame(
  Set_ID = sub("^path:", "", names(pathway_names_raw)),
  Official_name = sub(" - Homo sapiens \\(human\\)$", "", unname(pathway_names_raw)),
  stringsAsFactors = FALSE
)
pathway_membership <- data.frame(
  Set_ID = sub("^path:", "", names(pathway_links_raw)),
  Human_Entrez_ID = sub("^hsa:", "", unname(pathway_links_raw)),
  stringsAsFactors = FALSE
)
pathway_membership <- unique(pathway_membership)

module_names <- data.frame(
  Set_ID = sub("^md:", "", names(module_names_raw)),
  Official_name = unname(module_names_raw),
  stringsAsFactors = FALSE
)
module_to_ko <- data.frame(
  Set_ID = sub("^md:", "", names(module_to_ko_raw)),
  KO = sub("^ko:", "", unname(module_to_ko_raw)),
  stringsAsFactors = FALSE
)
ko_to_human <- data.frame(
  KO = sub("^ko:", "", names(ko_to_human_raw)),
  Human_Entrez_ID = sub("^hsa:", "", unname(ko_to_human_raw)),
  stringsAsFactors = FALSE
)
module_membership <- unique(merge(
  module_to_ko, ko_to_human, by = "KO", all = FALSE, sort = FALSE
)[, c("Set_ID", "Human_Entrez_ID")])

pathway_manifest <- merge(
  pathway_manifest, pathway_names, by = "Set_ID", all.x = TRUE, sort = FALSE
)
module_manifest <- merge(
  module_manifest, module_names, by = "Set_ID", all.x = TRUE, sort = FALSE
)
pathway_manifest <- pathway_manifest[
  match(c(
    "hsa00061", "hsa00062", "hsa01040", "hsa00561", "hsa00564",
    "hsa04975", "hsa04910", "hsa00071", "hsa01212", "hsa04923",
    "hsa04146", "hsa04152", "hsa04920", "hsa03320",
    "hsa00020", "hsa00190", "hsa04714"
  ), pathway_manifest$Set_ID), , drop = FALSE
]
module_manifest <- module_manifest[
  match(c(
    "M00082", "M00083", "M00085", "M00415", "M00873", "M00089",
    "M00086", "M00087", "M00861", "M00098", "M00088", "M00009",
    "M00010", "M00011", "M00143", "M00146", "M00147", "M00148",
    "M00151", "M00154", "M00158"
  ), module_manifest$Set_ID), , drop = FALSE
]
if (anyNA(pathway_manifest$Official_name) || anyNA(module_manifest$Official_name)) {
  stop("At least one prespecified KEGG set was not found in the official database.")
}

pathway_membership_selected <- pathway_membership[
  pathway_membership$Set_ID %in% pathway_manifest$Set_ID, , drop = FALSE
]
module_membership_selected <- module_membership[
  module_membership$Set_ID %in% module_manifest$Set_ID, , drop = FALSE
]

add_set_counts <- function(manifest, membership) {
  manifest$Official_human_gene_count <- vapply(
    manifest$Set_ID,
    function(id) length(unique(membership$Human_Entrez_ID[
      membership$Set_ID == id
    ])),
    integer(1)
  )
  manifest$Ranked_gene_overlap_count <- vapply(
    manifest$Set_ID,
    function(id) length(intersect(
      unique(membership$Human_Entrez_ID[membership$Set_ID == id]),
      names(gene_list)
    )),
    integer(1)
  )
  manifest
}
pathway_manifest <- add_set_counts(pathway_manifest, pathway_membership_selected)
module_manifest <- add_set_counts(module_manifest, module_membership_selected)

write_tsv(
  pathway_membership_selected,
  "Fig3_EAO_PM_GSEA_selected_KEGG_PATHWAY_human_Entrez_membership.tsv"
)
write_tsv(
  module_membership_selected,
  "Fig3_EAO_PM_GSEA_selected_KEGG_MODULE_human_Entrez_membership.tsv"
)

# ---------------------------------------------------------------------------
# 4. Separate clusterProfiler GSEA for PATHWAY and MODULE sets
# ---------------------------------------------------------------------------
run_gsea <- function(membership, manifest, min_size) {
  term2gene <- unique(data.frame(
    term = membership$Set_ID,
    gene = membership$Human_Entrez_ID,
    stringsAsFactors = FALSE
  ))
  term2name <- unique(data.frame(
    term = manifest$Set_ID,
    name = manifest$Official_name,
    stringsAsFactors = FALSE
  ))
  clusterProfiler::GSEA(
    geneList = gene_list,
    exponent = 1,
    minGSSize = min_size,
    maxGSSize = 1000,
    eps = 0,
    pvalueCutoff = 1,
    pAdjustMethod = "BH",
    verbose = FALSE,
    seed = TRUE,
    by = "fgsea",
    nPermSimple = 10000,
    TERM2GENE = term2gene,
    TERM2NAME = term2name
  )
}

gsea_pathway <- run_gsea(
  pathway_membership_selected, pathway_manifest, min_size = 10L
)
gsea_module <- run_gsea(
  module_membership_selected, module_manifest, min_size = 2L
)

saveRDS(
  gsea_pathway,
  file.path(table_dir, "Fig3_EAO_PM_integrated_RNA_protein_KEGG_PATHWAY_GSEA_object.rds")
)
saveRDS(
  gsea_module,
  file.path(table_dir, "Fig3_EAO_PM_integrated_RNA_protein_KEGG_MODULE_GSEA_object.rds")
)

decorate_results <- function(gsea_object, manifest, set_type) {
  result <- as.data.frame(gsea_object)
  if (!nrow(result)) stop("No GSEA results returned for ", set_type)
  names(result)[names(result) == "ID"] <- "Set_ID"
  names(result)[names(result) == "Description"] <- "GSEA_Description"
  result <- merge(
    manifest, result, by = "Set_ID", all.x = TRUE, sort = FALSE
  )
  result <- result[match(manifest$Set_ID, result$Set_ID), , drop = FALSE]
  result$Observed_enriched_site <- ifelse(
    result$NES > 0, "PM", ifelse(result$NES < 0, "EAO", NA_character_)
  )
  result$Supports_prespecified_hypothesis <-
    result$Observed_enriched_site == result$Expected_site
  result$Nominal_P_lt_0.05 <- !is.na(result$pvalue) & result$pvalue < 0.05
  result$FDR_lt_0.05 <- !is.na(result$p.adjust) & result$p.adjust < 0.05
  result$Core_enrichment_symbols <- vapply(
    result$core_enrichment,
    function(x) {
      if (is.na(x) || !nzchar(x)) return(NA_character_)
      ids <- strsplit(x, "/", fixed = TRUE)[[1]]
      symbols <- integrated_rank_table$Human_Gene_symbol[
        match(ids, integrated_rank_table$Human_Entrez_ID)
      ]
      symbols[is.na(symbols) | !nzchar(symbols)] <- ids[
        is.na(symbols) | !nzchar(symbols)
      ]
      paste(symbols, collapse = "/")
    },
    character(1)
  )
  result
}

pathway_results <- decorate_results(
  gsea_pathway, pathway_manifest, "PATHWAY"
)
module_results <- decorate_results(
  gsea_module, module_manifest, "MODULE"
)

if (anyNA(pathway_results$NES) || anyNA(module_results$NES)) {
  stop("One or more selected KEGG sets were not testable by GSEA.")
}

# ---------------------------------------------------------------------------
# 5. One classic GSEA plot per pathway/module
# ---------------------------------------------------------------------------
export_one_gsea_plot <- function(gsea_object, result_row, set_type) {
  set_id <- result_row$Set_ID
  set_name <- result_row$Official_name
  observed_site <- result_row$Observed_enriched_site
  axis_directory <- safe_filename(result_row$Hypothesis_axis)
  type_directory <- file.path(figure_root, set_type, axis_directory)
  dir.create(type_directory, recursive = TRUE, showWarnings = FALSE)

  plot_title <- sprintf(
    "%s | %s\nNES = %.2f; FDR = %.3g; enriched in %s",
    set_id, set_name, result_row$NES, result_row$p.adjust, observed_site
  )
  plot_object <- enrichplot::gseaplot2(
    gsea_object,
    geneSetID = set_id,
    title = plot_title,
    color = unname(site_colors[observed_site]),
    base_size = 10.5,
    rel_heights = c(1.5, 0.5, 1),
    subplots = 1:3,
    pvalue_table = FALSE,
    ES_geom = "line"
  )
  # enrichplot 1.26 returns an aplot "gglist" rather than a patchwork object.
  # Apply the theme to each component while retaining the gglist attributes;
  # using the patchwork `&` operator would silently turn this object into NULL.
  plot_object[] <- lapply(plot_object, function(component_plot) {
    component_plot + theme(
      text = element_text(family = "Arial", color = "#25282C"),
      plot.title = element_text(
        family = "Arial", face = "bold", size = 10.0,
        hjust = 0, margin = margin(b = 3)
      ),
      panel.grid.minor = element_blank()
    )
  })
  plot_object[[length(plot_object)]] <- plot_object[[length(plot_object)]] +
    labs(x = "Rank in ordered genes (PM-high to EAO-high)")

  file_stub <- file.path(
    type_directory,
    safe_filename(paste(set_id, set_name, sep = "_"))
  )
  plot_width <- 6.6
  plot_height <- 5.0
  ggsave(
    paste0(file_stub, ".pdf"), plot_object, device = cairo_pdf,
    width = plot_width, height = plot_height, units = "in", family = "Arial"
  )
  ggsave(
    paste0(file_stub, ".png"), plot_object, device = "png",
    width = plot_width, height = plot_height, units = "in",
    dpi = 600, bg = "white"
  )
  svg(
    paste0(file_stub, ".svg"), width = plot_width, height = plot_height,
    family = "Arial", bg = "white", onefile = TRUE
  )
  print(plot_object)
  dev.off()

  data.frame(
    Set_type = set_type,
    Set_ID = set_id,
    Official_name = set_name,
    Hypothesis_axis = result_row$Hypothesis_axis,
    Expected_site = result_row$Expected_site,
    Observed_enriched_site = observed_site,
    NES = result_row$NES,
    P_value = result_row$pvalue,
    FDR = result_row$p.adjust,
    PDF = paste0(file_stub, ".pdf"),
    PNG = paste0(file_stub, ".png"),
    SVG = paste0(file_stub, ".svg"),
    stringsAsFactors = FALSE
  )
}

plot_index_rows <- list()
plot_index <- 0L
for (i in seq_len(nrow(pathway_results))) {
  plot_index <- plot_index + 1L
  plot_index_rows[[plot_index]] <- export_one_gsea_plot(
    gsea_pathway, pathway_results[i, , drop = FALSE], "PATHWAY"
  )
}
for (i in seq_len(nrow(module_results))) {
  plot_index <- plot_index + 1L
  plot_index_rows[[plot_index]] <- export_one_gsea_plot(
    gsea_module, module_results[i, , drop = FALSE], "MODULE"
  )
}
plot_index_table <- do.call(rbind, plot_index_rows)

# ---------------------------------------------------------------------------
# 6. Outputs and QA
# ---------------------------------------------------------------------------
write_tsv(
  pathway_manifest,
  "Fig3_EAO_PM_GSEA_selected_KEGG_PATHWAY_manifest.tsv"
)
write_tsv(
  module_manifest,
  "Fig3_EAO_PM_GSEA_selected_KEGG_MODULE_manifest.tsv"
)
write_tsv(
  pathway_results,
  "Fig3_EAO_PM_integrated_RNA_protein_KEGG_PATHWAY_GSEA_results.tsv"
)
write_tsv(
  module_results,
  "Fig3_EAO_PM_integrated_RNA_protein_KEGG_MODULE_GSEA_results.tsv"
)
write_tsv(
  plot_index_table,
  "Fig3_EAO_PM_integrated_RNA_protein_KEGG_GSEA_plot_index.tsv"
)

summary_table <- rbind(
  data.frame(
    Set_type = "PATHWAY",
    Sets_tested = nrow(pathway_results),
    Nominal_P_lt_0.05 = sum(pathway_results$pvalue < 0.05),
    FDR_lt_0.05 = sum(pathway_results$p.adjust < 0.05),
    Enriched_in_EAO = sum(pathway_results$NES < 0),
    Enriched_in_PM = sum(pathway_results$NES > 0),
    Direction_supports_hypothesis = sum(
      pathway_results$Supports_prespecified_hypothesis
    ),
    stringsAsFactors = FALSE
  ),
  data.frame(
    Set_type = "MODULE",
    Sets_tested = nrow(module_results),
    Nominal_P_lt_0.05 = sum(module_results$pvalue < 0.05),
    FDR_lt_0.05 = sum(module_results$p.adjust < 0.05),
    Enriched_in_EAO = sum(module_results$NES < 0),
    Enriched_in_PM = sum(module_results$NES > 0),
    Direction_supports_hypothesis = sum(
      module_results$Supports_prespecified_hypothesis
    ),
    stringsAsFactors = FALSE
  )
)

ranking_qa <- data.frame(
  Item = c(
    "Comparison", "Rank sign", "Rank metric", "RNA input features",
    "Protein input features", "Features with nonempty symbols",
    "Symbols mapped to unambiguous human Entrez", "Integrated ranked genes",
    "RNA-protein overlapping genes", "RNA-protein direction conflicts",
    "Conflict rule", "Same-direction rule", "Pathway GSEA multiplicity",
    "Module GSEA multiplicity", "Pathway minimum set size",
    "Module minimum set size", "Official KEGG download time",
    "KEGG pathway membership", "KEGG module membership",
    "clusterProfiler version", "enrichplot version", "org.Hs.eg.db version"
  ),
  Value = c(
    comparison, "positive = PM; negative = EAO",
    "integrated RNA/protein log2FC",
    nrow(rna), nrow(protein), nrow(source_all), nrow(mapped_source),
    length(gene_list),
    sum(integrated_rank_table$Omics_membership == "Transcriptome;Proteome"),
    sum(integrated_rank_table$Direction_conflict),
    "smallest raw P; tie broken by largest absolute log2FC",
    "mean log2FC across available observations",
    "BH across all selected PATHWAY sets",
    "BH across all selected MODULE sets", 10, 2, download_time,
    "official KEGG REST pathway-to-hsa links",
    "official reference MODULE-to-KO links joined to KO-to-hsa links",
    as.character(packageVersion("clusterProfiler")),
    as.character(packageVersion("enrichplot")),
    as.character(packageVersion("org.Hs.eg.db"))
  ),
  stringsAsFactors = FALSE
)

write_tsv(summary_table, "Fig3_EAO_PM_KEGG_GSEA_summary.tsv")
write_tsv(ranking_qa, "Fig3_EAO_PM_KEGG_GSEA_QA.tsv")

write.xlsx(
  list(
    Summary = summary_table,
    PATHWAY_GSEA = pathway_results,
    MODULE_GSEA = module_results,
    PATHWAY_manifest = pathway_manifest,
    MODULE_manifest = module_manifest,
    Plot_index = plot_index_table,
    Integrated_rank = integrated_rank_table,
    Ranking_QA = ranking_qa
  ),
  file.path(
    table_dir,
    "Fig3_EAO_PM_integrated_RNA_protein_lipid_KEGG_GSEA_results.xlsx"
  ),
  overwrite = TRUE, asTable = TRUE
)

cat("Integrated RNA-protein lipid KEGG GSEA completed.\n")
print(summary_table)
cat("\nPATHWAY results:\n")
print(pathway_results[, c(
  "Set_ID", "Official_name", "Hypothesis_axis", "Expected_site",
  "NES", "pvalue", "p.adjust", "Observed_enriched_site",
  "Supports_prespecified_hypothesis"
)])
cat("\nMODULE results:\n")
print(module_results[, c(
  "Set_ID", "Official_name", "Hypothesis_axis", "Expected_site",
  "NES", "pvalue", "p.adjust", "Observed_enriched_site",
  "Supports_prespecified_hypothesis"
)])
