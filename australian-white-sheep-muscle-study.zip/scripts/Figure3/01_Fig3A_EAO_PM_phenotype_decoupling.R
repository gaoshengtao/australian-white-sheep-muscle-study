#!/usr/bin/env Rscript

# Figure 3A: reproducibility of the paired EAO-PM phenotype contrast
# in the complete phenotype cohort (15 animals) and the omics subset
# (animals 1-6).
#
# Primary estimand: paired mean difference, EAO - PM, in the original unit.
# Confidence interval: two-sided 95% Student-t interval calculated from the
# animal-level paired differences.

suppressPackageStartupMessages({
  library(ggplot2)
  library(openxlsx)
})

project_dir <- "__PROJECT_ROOT__"
work_dir <- file.path(project_dir, "09_Figure3_EAO_PM_IMF_tenderness_decoupling")
input_file <- file.path(project_dir, "01_meat_quality", "meat quality.xlsx")
figure_dir <- file.path(work_dir, "Figures")
table_dir <- file.path(work_dir, "Tables")
dir.create(figure_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(table_dir, recursive = TRUE, showWarnings = FALSE)

figure_stub <- file.path(figure_dir, "Fig3A_EAO_PM_IMF_tenderness_decoupling")
summary_tsv <- file.path(table_dir, "Fig3A_EAO_PM_paired_effect_summary.tsv")
paired_tsv <- file.path(table_dir, "Fig3A_EAO_PM_animal_level_paired_differences.tsv")
workbook_file <- file.path(table_dir, "Fig3A_EAO_PM_phenotype_statistics.xlsx")

if (!file.exists(input_file)) {
  stop("Input file not found: ", input_file)
}

raw <- read.xlsx(input_file, sheet = "Sheet2", check.names = FALSE)
required_columns <- c(
  "Group", "SampleID", "IMF,%", "Shear.force,.N",
  "Cooking.loss,.%", "Drip.loss,.%"
)
missing_columns <- setdiff(required_columns, names(raw))
if (length(missing_columns)) {
  stop("Missing columns: ", paste(missing_columns, collapse = ", "))
}

raw$Animal <- suppressWarnings(as.integer(sub("^.*_", "", raw$SampleID)))
if (anyNA(raw$Animal)) {
  stop("Animal number could not be parsed from one or more SampleID values.")
}

trait_map <- data.frame(
  Source_column = c("IMF,%", "Shear.force,.N", "Cooking.loss,.%", "Drip.loss,.%"),
  Trait = c("IMF", "Shear force", "Cooking loss", "Drip loss"),
  Trait_label = c("IMF (%)", "Shear force (N)", "Cooking loss (%)", "Drip loss (%)"),
  Unit = c("%", "N", "%", "%"),
  Trait_order = seq_len(4),
  stringsAsFactors = FALSE
)

cohort_map <- data.frame(
  Cohort = c("Full cohort", "Omics subset"),
  Cohort_label = c("Full cohort (n = 15)", "Omics subset (n = 6)"),
  Max_animal = c(15L, 6L),
  Cohort_order = c(1L, 2L),
  stringsAsFactors = FALSE
)

calculate_paired_effect <- function(source_column, trait, trait_label, unit,
                                    trait_order, cohort, cohort_label,
                                    max_animal, cohort_order) {
  z <- raw[
    raw$Group %in% c("EAO", "PM") & raw$Animal <= max_animal,
    c("Animal", "Group", source_column),
    drop = FALSE
  ]
  names(z)[3] <- "Value"

  if (anyDuplicated(z[c("Animal", "Group")])) {
    stop("Duplicated Animal-Site rows detected for ", trait, " in ", cohort)
  }

  wide <- reshape(z, idvar = "Animal", timevar = "Group", direction = "wide")
  required_pair_columns <- c("Value.EAO", "Value.PM")
  if (!all(required_pair_columns %in% names(wide))) {
    stop("EAO/PM pairing failed for ", trait, " in ", cohort)
  }
  wide <- wide[complete.cases(wide[, required_pair_columns]), , drop = FALSE]
  wide <- wide[order(wide$Animal), , drop = FALSE]

  expected_n <- max_animal
  if (nrow(wide) != expected_n || !identical(wide$Animal, seq_len(expected_n))) {
    stop(
      "Incomplete paired data for ", trait, " in ", cohort,
      "; expected animals 1-", expected_n, "."
    )
  }

  wide$Difference_EAO_minus_PM <- wide$Value.EAO - wide$Value.PM
  n <- nrow(wide)
  estimate <- mean(wide$Difference_EAO_minus_PM)
  difference_sd <- sd(wide$Difference_EAO_minus_PM)
  se <- difference_sd / sqrt(n)
  critical_t <- qt(0.975, df = n - 1)
  ci_low <- estimate - critical_t * se
  ci_high <- estimate + critical_t * se
  t_result <- t.test(wide$Difference_EAO_minus_PM, mu = 0)

  summary_row <- data.frame(
    Cohort = cohort,
    Cohort_label = cohort_label,
    Cohort_order = cohort_order,
    Trait = trait,
    Trait_label = trait_label,
    Trait_order = trait_order,
    Unit = unit,
    Animals = n,
    EAO_mean = mean(wide$Value.EAO),
    EAO_SD = sd(wide$Value.EAO),
    PM_mean = mean(wide$Value.PM),
    PM_SD = sd(wide$Value.PM),
    Mean_difference_EAO_minus_PM = estimate,
    Difference_SD = difference_sd,
    SE = se,
    CI_95_low = ci_low,
    CI_95_high = ci_high,
    t_statistic = unname(t_result$statistic),
    df = unname(t_result$parameter),
    P_value = t_result$p.value,
    stringsAsFactors = FALSE
  )

  paired_rows <- data.frame(
    Cohort = cohort,
    Trait = trait,
    Unit = unit,
    Animal = wide$Animal,
    EAO = wide$Value.EAO,
    PM = wide$Value.PM,
    Difference_EAO_minus_PM = wide$Difference_EAO_minus_PM,
    stringsAsFactors = FALSE
  )

  list(summary = summary_row, paired = paired_rows)
}

results <- list()
result_index <- 1L
for (trait_index in seq_len(nrow(trait_map))) {
  for (cohort_index in seq_len(nrow(cohort_map))) {
    results[[result_index]] <- calculate_paired_effect(
      source_column = trait_map$Source_column[trait_index],
      trait = trait_map$Trait[trait_index],
      trait_label = trait_map$Trait_label[trait_index],
      unit = trait_map$Unit[trait_index],
      trait_order = trait_map$Trait_order[trait_index],
      cohort = cohort_map$Cohort[cohort_index],
      cohort_label = cohort_map$Cohort_label[cohort_index],
      max_animal = cohort_map$Max_animal[cohort_index],
      cohort_order = cohort_map$Cohort_order[cohort_index]
    )
    result_index <- result_index + 1L
  }
}

summary_df <- do.call(rbind, lapply(results, `[[`, "summary"))
paired_df <- do.call(rbind, lapply(results, `[[`, "paired"))

# BH adjustment is performed across the four traits separately within each
# cohort and supplies the significance labels in the figure.
summary_df$P_FDR_BH_within_cohort <- ave(
  summary_df$P_value,
  summary_df$Cohort,
  FUN = function(x) p.adjust(x, method = "BH")
)

# A shared x-axis requires a unitless effect. Each raw EAO-PM estimate and its
# confidence limits are divided by the trait-specific pooled EAO/PM SD from the
# complete 15-animal cohort. The same denominator is used for both cohorts.
full_standardizers <- summary_df[
  summary_df$Cohort == "Full cohort",
  c("Trait", "EAO_SD", "PM_SD")
]
full_standardizers$Standardizer_full_cohort_pooled_SD <- with(
  full_standardizers,
  sqrt((EAO_SD^2 + PM_SD^2) / 2)
)
full_standardizers <- full_standardizers[
  c("Trait", "Standardizer_full_cohort_pooled_SD")
]
summary_df <- merge(
  summary_df, full_standardizers,
  by = "Trait", all.x = TRUE, sort = FALSE
)
summary_df$Standardized_mean_difference <- with(
  summary_df,
  Mean_difference_EAO_minus_PM / Standardizer_full_cohort_pooled_SD
)
summary_df$Standardized_CI_95_low <- with(
  summary_df,
  CI_95_low / Standardizer_full_cohort_pooled_SD
)
summary_df$Standardized_CI_95_high <- with(
  summary_df,
  CI_95_high / Standardizer_full_cohort_pooled_SD
)
summary_df$Significance_FDR <- cut(
  summary_df$P_FDR_BH_within_cohort,
  breaks = c(-Inf, 0.001, 0.01, 0.05, Inf),
  labels = c("***", "**", "*", "n.s."),
  right = FALSE
)
summary_df$Direction <- ifelse(
  summary_df$Mean_difference_EAO_minus_PM < 0,
  "Lower in EAO", "Higher in EAO"
)
summary_df$CI_excludes_zero <- with(
  summary_df, CI_95_low > 0 | CI_95_high < 0
)

summary_df <- summary_df[
  order(summary_df$Trait_order, summary_df$Cohort_order),
]
paired_df$Trait_order <- match(paired_df$Trait, trait_map$Trait)
paired_df$Cohort_order <- match(paired_df$Cohort, cohort_map$Cohort)
paired_df <- paired_df[
  order(paired_df$Trait_order, paired_df$Cohort_order, paired_df$Animal),
]
paired_df$Trait_order <- NULL
paired_df$Cohort_order <- NULL

write.table(
  summary_df, summary_tsv, sep = "\t", quote = FALSE,
  row.names = FALSE, na = "NA"
)
write.table(
  paired_df, paired_tsv, sep = "\t", quote = FALSE,
  row.names = FALSE, na = "NA"
)

methods_qa <- data.frame(
  Item = c(
    "Source file", "Source sheet", "Contrast", "Primary estimand",
    "Figure x-axis", "Standardization denominator", "Confidence interval",
    "Significance labels", "Multiple-testing correction",
    "Full cohort", "Omics subset", "Pairing QA", "Figure dimensions",
    "Font", "Full cohort mark", "Omics subset mark"
  ),
  Value = c(
    input_file, "Sheet2", "EAO - PM",
    "Mean of animal-level paired differences in the original unit",
    "Standardized paired mean difference (EAO - PM)",
    paste(
      "Trait-specific pooled EAO/PM SD from the complete 15-animal cohort;",
      "identical denominator for both cohorts"
    ),
    "Two-sided 95% Student-t interval; df = animals - 1",
    "*** FDR < 0.001; ** FDR < 0.01; * FDR < 0.05; n.s. FDR >= 0.05",
    "BH correction across the four traits separately within each cohort",
    "Animals 1-15", "Animals 1-6",
    "One EAO and one PM measurement per animal and trait",
    "4.56 x 3.50 inches", "Arial",
    "Charcoal outline/CI with EAO-rose fill",
    "EAO-rose outline/CI with white fill"
  ),
  stringsAsFactors = FALSE
)

write.xlsx(
  list(
    Paired_effect_summary = summary_df,
    Animal_level_differences = paired_df,
    Methods_and_QA = methods_qa
  ),
  file = workbook_file,
  overwrite = TRUE,
  asTable = TRUE
)

plot_df <- summary_df
plot_df$Cohort <- factor(
  plot_df$Cohort,
  levels = c("Full cohort", "Omics subset")
)
plot_df$Trait_y <- 5 - plot_df$Trait_order
plot_df$Cohort_offset <- ifelse(
  plot_df$Cohort == "Full cohort", 0.13, -0.13
)
plot_df$Y_position <- plot_df$Trait_y + plot_df$Cohort_offset

x_span <- diff(range(c(
  plot_df$Standardized_CI_95_low,
  plot_df$Standardized_CI_95_high,
  0
)))
plot_df$Significance_x <-
  plot_df$Standardized_CI_95_high + 0.025 * x_span

cohort_colors <- c(
  "Full cohort" = "#25282C",
  "Omics subset" = "#A65D68"
)
cohort_fills <- c(
  "Full cohort" = "#A65D68",
  "Omics subset" = "white"
)
cohort_shapes <- c(
  "Full cohort" = 21,
  "Omics subset" = 22
)

p <- ggplot(
  plot_df,
  aes(
    x = Standardized_mean_difference,
    y = Y_position,
    color = Cohort,
    fill = Cohort,
    shape = Cohort
  )
) +
  geom_vline(
    xintercept = 0, color = "#8D9297", linewidth = 0.42,
    linetype = "22"
  ) +
  geom_segment(
    aes(
      x = Standardized_CI_95_low,
      xend = Standardized_CI_95_high,
      yend = Y_position
    ),
    linewidth = 0.72, lineend = "round", show.legend = FALSE
  ) +
  geom_segment(
    aes(
      x = Standardized_CI_95_low,
      xend = Standardized_CI_95_low,
      y = Y_position - 0.055,
      yend = Y_position + 0.055
    ),
    linewidth = 0.55, show.legend = FALSE
  ) +
  geom_segment(
    aes(
      x = Standardized_CI_95_high,
      xend = Standardized_CI_95_high,
      y = Y_position - 0.055,
      yend = Y_position + 0.055
    ),
    linewidth = 0.55, show.legend = FALSE
  ) +
  geom_point(size = 3.1, stroke = 0.75) +
  geom_text(
    aes(x = Significance_x, label = Significance_FDR),
    hjust = 0, vjust = 0.38, size = 3.15, fontface = "bold",
    show.legend = FALSE
  ) +
  scale_color_manual(
    values = cohort_colors,
    labels = c("Full cohort (n = 15)", "Omics subset (n = 6)"),
    name = NULL
  ) +
  scale_fill_manual(
    values = cohort_fills,
    labels = c("Full cohort (n = 15)", "Omics subset (n = 6)"),
    name = NULL
  ) +
  scale_shape_manual(
    values = cohort_shapes,
    labels = c("Full cohort (n = 15)", "Omics subset (n = 6)"),
    name = NULL
  ) +
  scale_x_continuous(expand = expansion(mult = c(0.08, 0.13))) +
  scale_y_continuous(
    breaks = c(4, 3, 2, 1),
    labels = trait_map$Trait_label,
    limits = c(0.55, 4.45),
    expand = expansion(mult = 0)
  ) +
  labs(
    x = "Standardized paired mean difference (EAO - PM)",
    y = NULL
  ) +
  theme_bw(base_size = 10.5, base_family = "Arial") +
  theme(
    plot.background = element_rect(fill = "white", color = NA),
    panel.background = element_rect(fill = "white", color = NA),
    panel.grid.major.x = element_line(color = "#E4E6E8", linewidth = 0.34),
    panel.grid.minor = element_blank(),
    panel.grid.major.y = element_line(color = "#EFF0F1", linewidth = 0.30),
    panel.border = element_rect(color = "#303337", linewidth = 0.45),
    axis.title.x = element_text(
      size = 10.3, color = "#25282C", margin = margin(t = 7)
    ),
    axis.text.x = element_text(size = 9.0, color = "#25282C"),
    axis.text.y = element_text(
      size = 9.5, color = "#25282C", margin = margin(r = 5)
    ),
    axis.ticks = element_line(color = "#303337", linewidth = 0.35),
    axis.ticks.length = unit(1.5, "mm"),
    legend.position = "top",
    legend.justification = "center",
    legend.direction = "horizontal",
    legend.text = element_text(size = 9.0, color = "#25282C"),
    legend.key.width = unit(5.0, "mm"),
    legend.key.height = unit(3.5, "mm"),
    legend.spacing.x = unit(1.8, "mm"),
    plot.margin = margin(4.5, 8.0, 4.5, 5.5)
  )

plot_width <- 4.56
plot_height <- 3.50

ggsave(
  paste0(figure_stub, ".pdf"), p, device = cairo_pdf,
  width = plot_width, height = plot_height, units = "in", family = "Arial"
)
ggsave(
  paste0(figure_stub, ".png"), p, device = "png",
  width = plot_width, height = plot_height, units = "in",
  dpi = 600, bg = "white"
)
svg(
  paste0(figure_stub, ".svg"), width = plot_width, height = plot_height,
  family = "Arial", bg = "white", onefile = TRUE
)
print(p)
dev.off()

message("Figure 3A written to: ", figure_dir)
message("Statistics written to: ", table_dir)
