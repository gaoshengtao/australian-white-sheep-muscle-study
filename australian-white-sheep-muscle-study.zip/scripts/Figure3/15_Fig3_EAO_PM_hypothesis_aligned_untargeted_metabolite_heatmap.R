#!/usr/bin/env Rscript

# Heatmap of all direction-checked, hypothesis-aligned untargeted metabolites.
# Rows are split by the site in which the metabolite is enriched and clustered
# only within that site. Columns remain EAO1-6 followed by PM1-6.

rm(list = ls())

suppressPackageStartupMessages({
  library(data.table)
  library(openxlsx)
  library(ComplexHeatmap)
  library(circlize)
  library(grid)
})

work_dir <- "__PROJECT_ROOT__/09_Figure3_EAO_PM_IMF_tenderness_decoupling"
table_dir <- file.path(work_dir, "Tables")
figure_dir <- file.path(work_dir, "Figures")
dir.create(table_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(figure_dir, recursive = TRUE, showWarnings = FALSE)

normalized_file <- file.path(
  "__PROJECT_ROOT__/06_LCMS_untarget",
  "01_PM_SM_TIC_OPLSDA_VIP_paired_Wilcoxon",
  "pos_neg_named_HMDB_TIC_log10_normalized.tsv"
)
curated_file <- file.path(
  table_dir, "Fig3_EAO_PM_hypothesis_aligned_untargeted_metabolites_all_curated.tsv"
)
required <- c(normalized_file, curated_file)
if (any(!file.exists(required))) {
  stop("Missing required files: ", paste(required[!file.exists(required)], collapse = ", "))
}

normalized <- fread(normalized_file, na.strings = c("NA", ""), check.names = FALSE)
curated <- fread(curated_file, na.strings = c("NA", ""), check.names = FALSE)

# The four explicitly rejected low-confidence/direction-exception entries are
# not visualized. Core, supportive, targeted-confirmed, and context-only rows
# are retained so the heatmap matches the complete discussed candidate set.
plot_meta <- curated[
  Evidence_tier != "Do not use as primary evidence" & Direction_check == TRUE
]
if (!nrow(plot_meta)) stop("No curated metabolites available for plotting")
if (anyDuplicated(plot_meta$Feature_key)) stop("Feature_key is duplicated in curated metadata")

eao_cols <- paste0("AM_", 1:6)
pm_cols <- paste0("PM_", 1:6)
sample_cols <- c(eao_cols, pm_cols)
if (length(setdiff(sample_cols, names(normalized)))) stop("Normalized input lacks samples")

idx <- match(plot_meta$Feature_key, normalized$Feature_key)
if (anyNA(idx)) stop("Some curated Feature_key values are absent from normalized data")
mat_log10 <- as.matrix(normalized[idx, ..sample_cols])
storage.mode(mat_log10) <- "double"
rownames(mat_log10) <- plot_meta$Metabolite
colnames(mat_log10) <- c(paste0("EAO", 1:6), paste0("PM", 1:6))

# Standardize each metabolite across the 12 samples so compounds with very
# different absolute ion intensities can be compared in one heatmap.
row_mean <- rowMeans(mat_log10, na.rm = TRUE)
row_sd <- apply(mat_log10, 1, sd, na.rm = TRUE)
if (any(!is.finite(row_sd) | row_sd == 0)) stop("A plotted metabolite has zero/invalid SD")
mat_z <- sweep(sweep(mat_log10, 1, row_mean, "-"), 1, row_sd, "/")
mat_z_display <- mat_z
mat_z_display[mat_z_display < -2] <- -2
mat_z_display[mat_z_display > 2] <- 2

row_split <- factor(
  paste0(plot_meta$Higher_in, " enriched"),
  levels = c("EAO enriched", "PM enriched")
)
column_split <- factor(rep(c("EAO", "PM"), each = 6), levels = c("EAO", "PM"))

site_colors <- c(EAO = "#A65D68", PM = "#C28B48")
evidence_colors <- c(
  "Core" = "#30343B",
  "Supportive" = "#8A8F98",
  "Targeted-confirmed overlap" = "#D1A65A",
  "Context only" = "#D8DADD"
)
qc_colors <- c(
  "QC CV <= 30%" = "#4F6D67",
  "QC CV > 30%; analytical caution" = "#C77B69",
  "QC CV unavailable" = "#E2E2E2"
)

column_annotation <- HeatmapAnnotation(
  Site = factor(rep(c("EAO", "PM"), each = 6), levels = c("EAO", "PM")),
  col = list(Site = site_colors),
  annotation_name_gp = gpar(fontfamily = "Arial", fontsize = 9),
  annotation_legend_param = list(
    Site = list(title_gp = gpar(fontfamily = "Arial", fontsize = 9, fontface = "bold"),
                labels_gp = gpar(fontfamily = "Arial", fontsize = 8.5))
  ),
  simple_anno_size = unit(3.2, "mm"),
  show_annotation_name = FALSE,
  show_legend = FALSE
)

row_annotation <- rowAnnotation(
  `Evidence level` = factor(
    plot_meta$Evidence_tier,
    levels = c("Core", "Supportive", "Targeted-confirmed overlap", "Context only")
  ),
  QC = factor(
    plot_meta$QC_interpretation,
    levels = c("QC CV <= 30%", "QC CV > 30%; analytical caution", "QC CV unavailable")
  ),
  col = list(`Evidence level` = evidence_colors, QC = qc_colors),
  annotation_name_gp = gpar(fontfamily = "Arial", fontsize = 8),
  annotation_legend_param = list(
    `Evidence level` = list(
      title_gp = gpar(fontfamily = "Arial", fontsize = 9, fontface = "bold"),
      labels_gp = gpar(fontfamily = "Arial", fontsize = 8.2)
    ),
    QC = list(
      title_gp = gpar(fontfamily = "Arial", fontsize = 9, fontface = "bold"),
      labels_gp = gpar(fontfamily = "Arial", fontsize = 8.2)
    )
  ),
  simple_anno_size = unit(3.2, "mm"),
  show_annotation_name = FALSE
)

heat_colors <- colorRamp2(
  c(-2, 0, 2), c("#355C8A", "#F7F5F0", "#B65F6A")
)

make_heatmap <- function() {
  Heatmap(
    mat_z_display,
    name = "Row Z-score",
    col = heat_colors,
    top_annotation = column_annotation,
    right_annotation = row_annotation,
    row_split = row_split,
    column_split = column_split,
    cluster_rows = TRUE,
    cluster_row_slices = FALSE,
    clustering_distance_rows = "euclidean",
    clustering_method_rows = "complete",
    cluster_columns = FALSE,
    cluster_column_slices = FALSE,
    show_row_dend = TRUE,
    row_dend_width = unit(8, "mm"),
    show_column_dend = FALSE,
    border = TRUE,
    rect_gp = gpar(col = "white", lwd = 0.55),
    row_names_side = "left",
    row_names_gp = gpar(fontfamily = "Arial", fontsize = 8.2),
    row_names_max_width = unit(68, "mm"),
    column_names_gp = gpar(fontfamily = "Arial", fontsize = 8.5),
    column_names_rot = 45,
    row_title_gp = gpar(fontfamily = "Arial", fontsize = 10, fontface = "bold"),
    column_title_gp = gpar(fontfamily = "Arial", fontsize = 10, fontface = "bold"),
    row_gap = unit(2.2, "mm"),
    column_gap = unit(2.0, "mm"),
    heatmap_legend_param = list(
      at = c(-2, -1, 0, 1, 2),
      title_gp = gpar(fontfamily = "Arial", fontsize = 9, fontface = "bold"),
      labels_gp = gpar(fontfamily = "Arial", fontsize = 8.5),
      legend_height = unit(28, "mm")
    )
  )
}

base <- "Fig3_EAO_PM_hypothesis_aligned_untargeted_metabolite_heatmap"
pdf_file <- file.path(figure_dir, paste0(base, ".pdf"))
png_file <- file.path(figure_dir, paste0(base, ".png"))
svg_file <- file.path(figure_dir, paste0(base, ".svg"))

grDevices::cairo_pdf(pdf_file, width = 7.8, height = 7.2, family = "Arial")
ht_drawn <- suppressWarnings(draw(
  make_heatmap(),
  heatmap_legend_side = "right", annotation_legend_side = "right",
  merge_legends = FALSE,
  padding = unit(c(4, 4, 4, 4), "mm")
))
dev.off()

png(png_file, width = 7.8, height = 7.2, units = "in", res = 500,
    type = "cairo", bg = "white")
suppressWarnings(draw(
  make_heatmap(),
  heatmap_legend_side = "right", annotation_legend_side = "right",
  merge_legends = FALSE,
  padding = unit(c(4, 4, 4, 4), "mm")
))
dev.off()

svglite::svglite(svg_file, width = 7.8, height = 7.2)
suppressWarnings(draw(
  make_heatmap(),
  heatmap_legend_side = "right", annotation_legend_side = "right",
  merge_legends = FALSE,
  padding = unit(c(4, 4, 4, 4), "mm")
))
dev.off()

row_order_list <- row_order(ht_drawn)
ordered_indices <- unlist(row_order_list, use.names = FALSE)
ordered_slices <- rep(names(row_order_list), lengths(row_order_list))
plot_order <- data.table(
  Heatmap_row_order = seq_along(ordered_indices),
  Row_slice = ordered_slices,
  Metabolite = rownames(mat_z_display)[ordered_indices],
  Feature_key = plot_meta$Feature_key[ordered_indices],
  Higher_in = plot_meta$Higher_in[ordered_indices],
  Evidence_tier = plot_meta$Evidence_tier[ordered_indices],
  QC_interpretation = plot_meta$QC_interpretation[ordered_indices]
)

plot_values <- as.data.table(mat_z, keep.rownames = "Metabolite")
plot_values <- merge(
  plot_meta[, .(
    Metabolite, Feature_key, Higher_in, Evidence_tier, QC_interpretation,
    log2FC_EAO_vs_PM, VIP, paired_Wilcoxon_P, paired_Wilcoxon_FDR_BH, Level
  )],
  plot_values, by = "Metabolite", all.x = TRUE, sort = FALSE
)

fwrite(plot_values, file.path(table_dir, paste0(base, "_row_Z_scores.tsv")),
       sep = "\t", quote = FALSE, na = "NA")
fwrite(plot_order, file.path(table_dir, paste0(base, "_row_order.tsv")),
       sep = "\t", quote = FALSE, na = "NA")
write.xlsx(
  list(
    Plot_metadata_and_Z = as.data.frame(plot_values),
    Heatmap_row_order = as.data.frame(plot_order)
  ),
  file.path(table_dir, paste0(base, "_data.xlsx")),
  overwrite = TRUE, keepNA = TRUE
)

message("Done. Plotted ", nrow(mat_z_display), " metabolites across ",
        ncol(mat_z_display), " samples (EAO = ", sum(plot_meta$Higher_in == "EAO"),
        "; PM = ", sum(plot_meta$Higher_in == "PM"), ").")
