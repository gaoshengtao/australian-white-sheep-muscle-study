#!/usr/bin/env Rscript

# EAO-PM direction-specific KEGG over-representation analysis performed
# separately for FDR-significant transcriptome genes and proteome proteins.
# Human Diseases and Drug Development pathways are removed before BH
# correction. Official pathway level-1/level-2 classes are refreshed from
# KEGG BRITE br08901 and placed before the pathway name in final tables.

rm(list = ls())

suppressPackageStartupMessages({
  library(clusterProfiler)
  library(KEGGREST)
  library(openxlsx)
})

options(stringsAsFactors = FALSE, timeout = 600)

project_dir <- "__PROJECT_ROOT__"
work_dir <- file.path(
  project_dir, "09_Figure3_EAO_PM_IMF_tenderness_decoupling"
)
table_dir <- file.path(work_dir, "Tables")
source_dir <- file.path(
  project_dir, "07_Figure2_muscle_functional_states",
  "03_One_vs_rest_specificity", "Tables"
)
dir.create(table_dir, recursive = TRUE, showWarnings = FALSE)

rna_file <- file.path(
  source_dir,
  "Fig2_muscle_fiber_pairwise_transcriptome_DESeq2_all_gene_results.tsv.gz"
)
protein_file <- file.path(
  source_dir,
  "Fig2_muscle_fiber_pairwise_proteome_limma_all_gene_results.tsv.gz"
)
ortholog_file <- file.path(
  source_dir, "Fig2_Ensembl115_sheep_to_human_ortholog_Entrez_mapping.tsv"
)
required_files <- c(rna_file, protein_file, ortholog_file)
missing_files <- required_files[!file.exists(required_files)]
if (length(missing_files)) {
  stop("Missing input files: ", paste(missing_files, collapse = ", "))
}

comparison <- "PM_vs_EAO"
feature_fdr_cutoff <- 0.05
pathway_fdr_cutoff <- 0.05
min_gene_set_size <- 10L
max_gene_set_size <- 500L
omics_order <- c("Transcriptome", "Proteome")
site_order <- c("EAO", "PM")
excluded_level1 <- c("Human Diseases", "Drug Development")

clean_id <- function(x) {
  x <- trimws(as.character(x))
  x[is.na(x)] <- ""
  x
}

write_tsv <- function(x, filename) {
  write.table(
    x, file.path(table_dir, filename), sep = "\t", quote = FALSE,
    row.names = FALSE, na = "NA"
  )
}

parse_ratio <- function(x) {
  pieces <- strsplit(as.character(x), "/", fixed = TRUE)
  vapply(
    pieces, function(z) as.numeric(z[1]) / as.numeric(z[2]), numeric(1)
  )
}

bind_nonempty <- function(x) {
  x <- x[vapply(x, nrow, integer(1)) > 0L]
  if (!length(x)) return(data.frame())
  out <- do.call(rbind, x)
  rownames(out) <- NULL
  out
}

make_symbol_list <- function(gene_string, symbol_lookup) {
  ids <- strsplit(gene_string, "/", fixed = TRUE)[[1]]
  symbols <- unname(symbol_lookup[ids])
  bad <- is.na(symbols) | !nzchar(symbols)
  symbols[bad] <- ids[bad]
  paste(symbols, collapse = "/")
}

# Refresh the KEGG pathway hierarchy directly from the official KEGG REST API.
brite_download_time <- format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")
brite_text <- KEGGREST::keggGet("br:br08901")
if (length(brite_text) != 1L || !nzchar(brite_text)) {
  stop("Official KEGG br08901 download returned no usable content.")
}
writeLines(
  brite_text,
  file.path(table_dir, "Fig3_KEGG_br08901_official_raw.txt"),
  useBytes = TRUE
)

brite_lines <- strsplit(brite_text, "\n", fixed = TRUE)[[1]]
level1 <- ""
level2 <- ""
category_records <- list()
record_index <- 0L
for (line in brite_lines) {
  if (grepl("^A", line)) {
    level1 <- trimws(sub("^A", "", line))
  } else if (grepl("^B +", line)) {
    level2 <- trimws(sub("^B +", "", line))
  } else if (grepl("^C +[0-9]{5} ", line)) {
    pathway_number <- sub("^C +([0-9]{5}).*$", "\\1", line)
    pathway_name <- sub("^C +[0-9]{5} +", "", line)
    pathway_name <- sub(
      " +\\[PATH:[A-Za-z0-9]+[0-9]{5}\\].*$", "", pathway_name
    )
    record_index <- record_index + 1L
    category_records[[record_index]] <- data.frame(
      Pathway_ID = paste0("hsa", pathway_number),
      KEGG_level1 = level1,
      KEGG_level2 = level2,
      KEGG_hierarchy_pathway = pathway_name,
      stringsAsFactors = FALSE
    )
  }
}
kegg_category_map <- unique(do.call(rbind, category_records))
if (!nrow(kegg_category_map) || anyDuplicated(kegg_category_map$Pathway_ID)) {
  stop("Official KEGG br08901 hierarchy parsing failed.")
}
if (!all(excluded_level1 %in% kegg_category_map$KEGG_level1)) {
  stop("KEGG hierarchy lacks required exclusion categories.")
}
write_tsv(
  kegg_category_map,
  "Fig3_KEGG_br08901_official_pathway_classification.tsv"
)

# Read the complete differential results and the validated sheep-human map.
rna <- read.delim(
  gzfile(rna_file), check.names = FALSE, quote = "", comment.char = ""
)
protein <- read.delim(
  gzfile(protein_file), check.names = FALSE, quote = "", comment.char = ""
)
ortholog <- read.delim(
  ortholog_file, check.names = FALSE, quote = "", comment.char = ""
)

required_rna <- c(
  "gene_id", "Gene_symbol", "Comparison", "log2FoldChange", "P_value",
  "P_FDR_BH"
)
required_protein <- c(
  "Human_Entrez_ID", "Gene_symbol", "Comparison", "log2FoldChange",
  "P_value", "P_FDR_BH"
)
required_map <- c(
  "Sheep_Ensembl_gene_id", "Human_Entrez_ID", "Human_Gene_symbol"
)
if (length(setdiff(required_rna, names(rna)))) {
  stop("RNA input lacks required columns.")
}
if (length(setdiff(required_protein, names(protein)))) {
  stop("Protein input lacks required columns.")
}
if (length(setdiff(required_map, names(ortholog)))) {
  stop("Ortholog map lacks required columns.")
}

rna <- rna[rna$Comparison == comparison, , drop = FALSE]
protein <- protein[protein$Comparison == comparison, , drop = FALSE]
if (!nrow(rna) || !nrow(protein)) stop("PM_vs_EAO results were not found.")

ortholog$Sheep_Ensembl_gene_id <- clean_id(ortholog$Sheep_Ensembl_gene_id)
ortholog$Human_Entrez_ID <- clean_id(ortholog$Human_Entrez_ID)
ortholog$Human_Gene_symbol <- clean_id(ortholog$Human_Gene_symbol)
ortholog <- unique(ortholog[
  nzchar(ortholog$Sheep_Ensembl_gene_id) & nzchar(ortholog$Human_Entrez_ID),
  required_map, drop = FALSE
])

# Map RNA sheep Ensembl genes to human Entrez orthologs.
rna_mapped <- merge(
  rna, ortholog,
  by.x = "gene_id", by.y = "Sheep_Ensembl_gene_id",
  all.x = FALSE, all.y = FALSE, sort = FALSE
)
rna_mapped$Omics <- "Transcriptome"
rna_mapped$Source_feature_ID <- clean_id(rna_mapped$gene_id)
rna_mapped$Source_Gene_symbol <- clean_id(rna_mapped$Gene_symbol)
rna_mapped$Human_Entrez_ID <- clean_id(rna_mapped$Human_Entrez_ID)
rna_mapped$Mapped_Gene_symbol <- clean_id(rna_mapped$Human_Gene_symbol)

# Protein results already carry the matched human Entrez IDs.
protein$Human_Entrez_ID <- clean_id(protein$Human_Entrez_ID)
protein_mapped <- protein[nzchar(protein$Human_Entrez_ID), , drop = FALSE]
protein_mapped$Omics <- "Proteome"
protein_mapped$Source_feature_ID <- if ("Protein_row" %in% names(protein_mapped)) {
  as.character(protein_mapped$Protein_row)
} else {
  as.character(seq_len(nrow(protein_mapped)))
}
protein_mapped$Source_Gene_symbol <- clean_id(protein_mapped$Gene_symbol)
protein_mapped$Mapped_Gene_symbol <- clean_id(protein_mapped$Gene_symbol)

common_columns <- c(
  "Omics", "Source_feature_ID", "Source_Gene_symbol", "Human_Entrez_ID",
  "Mapped_Gene_symbol", "log2FoldChange", "P_value", "P_FDR_BH"
)
mapped_all <- rbind(
  rna_mapped[, common_columns, drop = FALSE],
  protein_mapped[, common_columns, drop = FALSE]
)
mapped_all$Higher_in <- ifelse(mapped_all$log2FoldChange > 0, "PM", "EAO")
mapped_all <- mapped_all[
  is.finite(mapped_all$log2FoldChange) &
    !is.na(mapped_all$P_FDR_BH) & nzchar(mapped_all$Human_Entrez_ID),
  , drop = FALSE
]

# Resolve rare many-to-one mappings to one direction per human Entrez gene in
# each omics layer. The most significant feature is retained; ties use |FC|.
resolve_gene_level <- function(d, omics_name) {
  z <- d[d$Omics == omics_name, , drop = FALSE]
  ids <- sort(unique(z$Human_Entrez_ID))
  do.call(rbind, lapply(ids, function(id) {
    q <- z[z$Human_Entrez_ID == id, , drop = FALSE]
    q <- q[order(q$P_FDR_BH, q$P_value, -abs(q$log2FoldChange)), ]
    chosen <- q[1, , drop = FALSE]
    chosen$Mapped_feature_count <- nrow(q)
    chosen$Direction_conflict <- length(unique(q$Higher_in)) > 1L
    chosen$Resolution_rule <- if (nrow(q) > 1L) {
      "smallest FDR, then raw P, then largest absolute log2FC"
    } else {
      "single mapped feature"
    }
    chosen
  }))
}

gene_level <- rbind(
  resolve_gene_level(mapped_all, "Transcriptome"),
  resolve_gene_level(mapped_all, "Proteome")
)
gene_level$Omics <- factor(gene_level$Omics, levels = omics_order)
gene_level$Higher_in <- factor(gene_level$Higher_in, levels = site_order)
gene_level <- gene_level[
  order(gene_level$Omics, gene_level$Higher_in, gene_level$P_FDR_BH),
  , drop = FALSE
]
rownames(gene_level) <- NULL

significant_gene_level <- gene_level[
  gene_level$P_FDR_BH < feature_fdr_cutoff, , drop = FALSE
]
write_tsv(
  significant_gene_level,
  "Fig3_EAO_PM_FDR005_RNA_protein_KEGG_input_gene_membership.tsv"
)

symbol_lookup <- setNames(
  gene_level$Mapped_Gene_symbol, gene_level$Human_Entrez_ID
)
symbol_lookup <- symbol_lookup[!duplicated(names(symbol_lookup))]

# Run four primary analyses: RNA-EAO, RNA-PM, Protein-EAO and Protein-PM.
# Each omics layer uses its own mapped, testable universe.
enrichment_before <- list()
enrichment_retained <- list()
enrichment_excluded <- list()
set_summary <- list()
result_index <- 0L

for (omics_name in omics_order) {
  universe <- sort(unique(gene_level$Human_Entrez_ID[
    gene_level$Omics == omics_name
  ]))
  for (site_name in site_order) {
    target <- sort(unique(significant_gene_level$Human_Entrez_ID[
      significant_gene_level$Omics == omics_name &
        significant_gene_level$Higher_in == site_name
    ]))
    result_index <- result_index + 1L
    set_name <- paste(omics_name, site_name, sep = "_")
    message(
      set_name, ": ", length(target), " target genes; ",
      length(universe), " background genes"
    )
    if (length(target) < min_gene_set_size) {
      stop(set_name, " has fewer than ", min_gene_set_size, " target genes.")
    }
    enrichment <- clusterProfiler::enrichKEGG(
      gene = target,
      organism = "hsa",
      keyType = "ncbi-geneid",
      universe = universe,
      pvalueCutoff = 1,
      pAdjustMethod = "none",
      qvalueCutoff = 1,
      minGSSize = min_gene_set_size,
      maxGSSize = max_gene_set_size,
      use_internal_data = FALSE
    )
    result <- as.data.frame(enrichment)
    if (!nrow(result)) {
      stop("No KEGG pathways returned for ", set_name)
    }
    result$Omics <- omics_name
    result$Higher_in <- site_name
    result$Input_gene_count <- length(target)
    result$Universe_gene_count <- length(universe)
    result$RichFactor <- result$Count /
      as.numeric(sub("/.*$", "", result$BgRatio))
    result$FoldEnrichment <- parse_ratio(result$GeneRatio) /
      parse_ratio(result$BgRatio)
    result$Gene_symbols <- vapply(
      result$geneID,
      make_symbol_list,
      character(1),
      symbol_lookup = symbol_lookup
    )
    category_index <- match(result$ID, kegg_category_map$Pathway_ID)
    result$KEGG_level1 <- kegg_category_map$KEGG_level1[category_index]
    result$KEGG_level2 <- kegg_category_map$KEGG_level2[category_index]
    result$KEGG_hierarchy_pathway <-
      kegg_category_map$KEGG_hierarchy_pathway[category_index]
    if (anyNA(result$KEGG_level1)) {
      stop(
        "Unclassified KEGG IDs in ", set_name, ": ",
        paste(unique(result$ID[is.na(result$KEGG_level1)]), collapse = ", ")
      )
    }
    result$Excluded_before_BH <- result$KEGG_level1 %in% excluded_level1
    result$clusterProfiler_p_adjust_none <- result$p.adjust
    result$p.adjust <- NULL
    result$qvalue <- NULL

    excluded <- result[result$Excluded_before_BH, , drop = FALSE]
    retained <- result[!result$Excluded_before_BH, , drop = FALSE]
    retained$FDR_BH_after_category_filter <- p.adjust(
      retained$pvalue, method = "BH"
    )
    retained$FDR_lt_0.05 <-
      retained$FDR_BH_after_category_filter < pathway_fdr_cutoff

    # Put KEGG level 1/2 immediately before Pathway, as requested.
    make_final_table <- function(x) {
      if (!nrow(x)) return(x)
      x$Pathway <- x$Description
      x$Pathway_ID <- x$ID
      preferred <- c(
        "Omics", "Higher_in", "KEGG_level1", "KEGG_level2", "Pathway",
        "Pathway_ID", "GeneRatio", "BgRatio", "RichFactor",
        "FoldEnrichment", "pvalue", "FDR_BH_after_category_filter",
        "FDR_lt_0.05", "Count", "geneID", "Gene_symbols",
        "Input_gene_count", "Universe_gene_count",
        "KEGG_hierarchy_pathway", "Excluded_before_BH",
        "clusterProfiler_p_adjust_none"
      )
      x[, intersect(preferred, names(x)), drop = FALSE]
    }

    before_final <- make_final_table(result)
    retained_final <- make_final_table(retained)
    excluded_final <- make_final_table(excluded)
    enrichment_before[[set_name]] <- before_final
    enrichment_retained[[set_name]] <- retained_final[
      order(
        retained_final$FDR_BH_after_category_filter,
        retained_final$pvalue
      ), , drop = FALSE
    ]
    enrichment_excluded[[set_name]] <- excluded_final
    set_summary[[set_name]] <- data.frame(
      Omics = omics_name,
      Higher_in = site_name,
      Original_FDR_significant_features = if (omics_name == "Transcriptome") {
        sum(
          !is.na(rna$P_FDR_BH) & rna$P_FDR_BH < feature_fdr_cutoff &
            is.finite(rna$log2FoldChange) &
            if (site_name == "PM") rna$log2FoldChange > 0 else
              rna$log2FoldChange < 0
        )
      } else {
        sum(
          !is.na(protein$P_FDR_BH) &
            protein$P_FDR_BH < feature_fdr_cutoff &
            is.finite(protein$log2FoldChange) &
            if (site_name == "PM") protein$log2FoldChange > 0 else
              protein$log2FoldChange < 0
        )
      },
      Mapped_FDR_significant_feature_rows = sum(
        mapped_all$Omics == omics_name &
          mapped_all$Higher_in == site_name &
          mapped_all$P_FDR_BH < feature_fdr_cutoff
      ),
      Unique_human_Entrez_targets = length(target),
      Mapped_testable_background = length(universe),
      KEGG_pathways_before_category_filter = nrow(result),
      Excluded_Human_Diseases_or_Drug_Development = nrow(excluded),
      Retained_pathways_tested = nrow(retained),
      Retained_pathways_raw_P_lt_0.05 = sum(retained$pvalue < 0.05),
      Retained_pathways_FDR_lt_0.05 = sum(
        retained$FDR_BH_after_category_filter < pathway_fdr_cutoff
      ),
      stringsAsFactors = FALSE
    )
  }
}

all_before <- bind_nonempty(enrichment_before)
all_retained <- bind_nonempty(enrichment_retained)
all_excluded <- bind_nonempty(enrichment_excluded)
summary_table <- bind_nonempty(set_summary)
fdr_significant <- all_retained[
  all_retained$FDR_BH_after_category_filter < pathway_fdr_cutoff,
  , drop = FALSE
]
raw_p_significant <- all_retained[
  all_retained$pvalue < 0.05, , drop = FALSE
]

# QA: BH must be recomputed independently within each omics-direction set.
bh_qa <- do.call(rbind, lapply(names(enrichment_retained), function(set_name) {
  x <- enrichment_retained[[set_name]]
  data.frame(
    Analysis_set = set_name,
    BH_recalculation_matches = isTRUE(all.equal(
      x$FDR_BH_after_category_filter,
      p.adjust(x$pvalue, method = "BH"),
      tolerance = 1e-12
    )),
    Human_Diseases_retained = sum(x$KEGG_level1 == "Human Diseases"),
    Drug_Development_retained = sum(x$KEGG_level1 == "Drug Development"),
    stringsAsFactors = FALSE
  )
}))
if (!all(bh_qa$BH_recalculation_matches) ||
    any(bh_qa$Human_Diseases_retained > 0L) ||
    any(bh_qa$Drug_Development_retained > 0L)) {
  stop("Post-filter BH or category-exclusion QA failed.")
}

qa_manifest <- data.frame(
  Item = c(
    "Comparison", "RNA method", "Protein method", "Feature threshold",
    "Fold-change cutoff", "Enrichment method", "KEGG organism",
    "RNA background", "Protein background", "Direction handling",
    "Minimum gene-set size", "Maximum gene-set size",
    "Categories excluded before BH", "BH scope",
    "KEGG hierarchy source", "KEGG hierarchy download time",
    "clusterProfiler version", "KEGGREST version",
    "Direction conflicts in significant RNA", "Direction conflicts in significant protein"
  ),
  Value = c(
    comparison, "DESeq2 paired comparison", "limma paired comparison",
    "feature-level BH FDR < 0.05", "None",
    "clusterProfiler::enrichKEGG over-representation analysis",
    "hsa through Ensembl 115 sheep-human ortholog Entrez mapping",
    paste0("mapped testable transcriptome genes; n=",
           sum(gene_level$Omics == "Transcriptome")),
    paste0("mapped testable proteome genes; n=",
           sum(gene_level$Omics == "Proteome")),
    "EAO-enriched and PM-enriched genes tested separately",
    min_gene_set_size, max_gene_set_size,
    paste(excluded_level1, collapse = "; "),
    "independently within each omics-direction set after category exclusion",
    "official KEGG BRITE br08901 via KEGG REST API",
    brite_download_time,
    as.character(packageVersion("clusterProfiler")),
    as.character(packageVersion("KEGGREST")),
    sum(significant_gene_level$Omics == "Transcriptome" &
          significant_gene_level$Direction_conflict),
    sum(significant_gene_level$Omics == "Proteome" &
          significant_gene_level$Direction_conflict)
  ),
  stringsAsFactors = FALSE
)

write_tsv(summary_table, "Fig3_EAO_PM_RNA_protein_separate_KEGG_summary.tsv")
write_tsv(
  all_retained,
  "Fig3_EAO_PM_RNA_protein_separate_KEGG_all_retained_pathways.tsv"
)
write_tsv(
  fdr_significant,
  "Fig3_EAO_PM_RNA_protein_separate_KEGG_pathways_FDR_lt_0.05.tsv"
)
write_tsv(
  raw_p_significant,
  "Fig3_EAO_PM_RNA_protein_separate_KEGG_pathways_rawP_lt_0.05.tsv"
)
write_tsv(
  all_excluded,
  "Fig3_EAO_PM_RNA_protein_separate_KEGG_excluded_before_BH.tsv"
)
write_tsv(bh_qa, "Fig3_EAO_PM_RNA_protein_separate_KEGG_BH_QA.tsv")
write_tsv(qa_manifest, "Fig3_EAO_PM_RNA_protein_separate_KEGG_QA.tsv")

for (omics_name in omics_order) {
  omics_stub <- if (omics_name == "Transcriptome") "RNA" else "Protein"
  omics_all <- all_retained[all_retained$Omics == omics_name, , drop = FALSE]
  omics_sig <- omics_all[
    omics_all$FDR_BH_after_category_filter < pathway_fdr_cutoff,
    , drop = FALSE
  ]
  write_tsv(
    omics_all,
    paste0("Fig3_EAO_PM_", omics_stub, "_FDR005_KEGG_all_retained.tsv")
  )
  write_tsv(
    omics_sig,
    paste0("Fig3_EAO_PM_", omics_stub, "_FDR005_KEGG_significant.tsv")
  )
}

workbook_sheets <- list(
  Summary = summary_table,
  FDR_lt_0.05 = fdr_significant,
  Raw_P_lt_0.05 = raw_p_significant,
  All_retained = all_retained,
  Excluded_before_BH = all_excluded,
  Input_gene_membership = significant_gene_level,
  RNA_EAO = enrichment_retained[["Transcriptome_EAO"]],
  RNA_PM = enrichment_retained[["Transcriptome_PM"]],
  Protein_EAO = enrichment_retained[["Proteome_EAO"]],
  Protein_PM = enrichment_retained[["Proteome_PM"]],
  KEGG_classification = kegg_category_map,
  BH_QA = bh_qa,
  Methods_QA = qa_manifest
)
write.xlsx(
  workbook_sheets,
  file.path(
    table_dir,
    "Fig3_EAO_PM_RNA_protein_FDR005_separate_KEGG_enrichment.xlsx"
  ),
  overwrite = TRUE, asTable = TRUE
)

cat("EAO-PM separate RNA/protein KEGG enrichment completed.\n")
print(summary_table)
