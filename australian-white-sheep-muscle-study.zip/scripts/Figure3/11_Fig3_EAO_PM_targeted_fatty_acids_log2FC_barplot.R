#!/usr/bin/env Rscript

# Figure 3: targeted fatty acids significantly different between EAO and PM.
# Direction is aligned with the preceding omics analyses:
#   log2FC = log2(mean PM / mean EAO)
# Therefore, negative values are higher in EAO and positive values are higher
# in PM. Only paired-ANOVA BH-FDR < 0.05 fatty acids are plotted.

rm(list = ls())

suppressPackageStartupMessages({
  library(ggplot2)
  library(openxlsx)
})

project_dir <- "__PROJECT_ROOT__"
work_dir <- file.path(
  project_dir, "09_Figure3_EAO_PM_IMF_tenderness_decoupling"
)
table_dir <- file.path(work_dir, "Tables")
figure_dir <- file.path(work_dir, "Figures")
dir.create(figure_dir, recursive = TRUE, showWarnings = FALSE)

result_file <- file.path(
  table_dir,
  "Fig3_EAO_PM_targeted_fatty_acids_paired_ANOVA_FDR_results.xlsx"
)
fatty_acid_file <- file.path(
  project_dir, "02_fatty_acids", "fatty acids.xlsx"
)
figure_stub <- file.path(
  figure_dir,
  "Fig3_EAO_PM_targeted_fatty_acids_FDR005_log2FC_PM_vs_EAO_barplot"
)

site_colors <- c(EAO = "#A65D68", PM = "#C28B48")
plot_width_in <- 5.0
plot_height_in <- 7.4

stopifnot(file.exists(result_file), file.exists(fatty_acid_file))

results <- read.xlsx(
  result_file, sheet = "ANOVA_FDR_significant", check.names = FALSE
)
measurement <- read.xlsx(
  fatty_acid_file, sheet = "measurement.xls", check.names = FALSE
)
fatty_acid_names <- read.xlsx(
  fatty_acid_file, sheet = "其他信息", check.names = FALSE
)

if (nrow(measurement) != nrow(fatty_acid_names)) {
  stop("Fatty-acid annotation sheets have different row counts.")
}
if (max(abs(measurement$Retention.time - fatty_acid_names[["RT/min"]])) > 1e-10) {
  stop("Fatty-acid annotation sheets are not aligned by retention time.")
}

annotation <- data.frame(
  Metabolite = measurement$Metabolite,
  Fatty_acid = fatty_acid_names$Metabolite,
  Retention_time = measurement$Retention.time,
  stringsAsFactors = FALSE
)

plot_data <- merge(
  results, annotation,
  by = "Metabolite", all.x = TRUE, sort = FALSE
)
plot_data <- plot_data[
  match(results$Metabolite, plot_data$Metabolite), , drop = FALSE
]
if (anyNA(plot_data$Fatty_acid)) {
  stop("At least one significant fatty acid lacks a compact annotation.")
}
if (any(plot_data$Mean_EAO <= 0 | plot_data$Mean_PM <= 0)) {
  stop("A significant fatty acid has a non-positive group mean; log2FC undefined.")
}
if (!all(plot_data$Paired_ANOVA_FDR_BH < 0.05)) {
  stop("Input contains fatty acids outside paired-ANOVA BH-FDR < 0.05.")
}

plot_data$log2FC_PM_vs_EAO <- log2(plot_data$Mean_PM / plot_data$Mean_EAO)
plot_data$Enriched_site <- ifelse(
  plot_data$log2FC_PM_vs_EAO > 0, "PM",
  ifelse(plot_data$log2FC_PM_vs_EAO < 0, "EAO", "Neither")
)
if (any(plot_data$Enriched_site == "Neither")) {
  stop("A significant fatty acid has zero log2FC.")
}
plot_data$Enriched_site <- factor(
  plot_data$Enriched_site, levels = c("EAO", "PM")
)

# Place the largest absolute differences at the top of the horizontal chart.
plot_data <- plot_data[
  order(abs(plot_data$log2FC_PM_vs_EAO), decreasing = TRUE), , drop = FALSE
]
plot_data$Fatty_acid <- factor(
  plot_data$Fatty_acid,
  levels = rev(plot_data$Fatty_acid)
)

p <- ggplot(plot_data, aes(log2FC_PM_vs_EAO, Fatty_acid, fill = Enriched_site)) +
  geom_vline(xintercept = 0, color = "#4A4D52", linewidth = 0.45) +
  geom_col(
    width = 0.70, color = "#3B3D42", linewidth = 0.22,
    alpha = 0.94
  ) +
  scale_fill_manual(
    values = site_colors, breaks = c("EAO", "PM"), drop = TRUE,
    name = "Higher in"
  ) +
  scale_x_continuous(
    expand = expansion(mult = c(0.04, 0.08))
  ) +
  labs(
    title = "Targeted fatty acids",
    x = "log2FC (PM / EAO)",
    y = "Fatty acid"
  ) +
  theme_bw(base_size = 10.5, base_family = "Arial") +
  theme(
    plot.title = element_text(
      hjust = 0.5, size = 11.2, face = "plain", color = "#1F2328",
      margin = margin(b = 5)
    ),
    panel.grid.major.y = element_blank(),
    panel.grid.minor = element_blank(),
    panel.grid.major.x = element_line(color = "#E2E4E7", linewidth = 0.32),
    panel.border = element_rect(color = "#1F1F1F", linewidth = 0.5),
    axis.text.x = element_text(color = "#30363D", size = 8.5),
    axis.text.y = element_text(color = "#30363D", size = 8.2),
    axis.title = element_text(color = "#1F2328", size = 10.5),
    axis.title.x = element_text(margin = margin(t = 7)),
    axis.title.y = element_text(margin = margin(r = 7)),
    axis.ticks = element_line(color = "#1F1F1F", linewidth = 0.4),
    axis.ticks.length = grid::unit(1.6, "mm"),
    legend.position = "top",
    legend.direction = "horizontal",
    legend.justification = "center",
    legend.title = element_text(size = 9.0, color = "#1F2328"),
    legend.text = element_text(size = 9.0, color = "#1F2328"),
    legend.key = element_blank(),
    plot.margin = margin(t = 5, r = 7, b = 5, l = 7)
  ) +
  guides(
    fill = guide_legend(
      override.aes = list(color = "#3B3D42", linewidth = 0.22, alpha = 0.94)
    )
  )

ggsave(
  paste0(figure_stub, ".pdf"), p, device = cairo_pdf,
  width = plot_width_in, height = plot_height_in, units = "in",
  family = "Arial"
)
ggsave(
  paste0(figure_stub, ".png"), p, device = "png",
  width = plot_width_in, height = plot_height_in, units = "in",
  dpi = 600, bg = "white"
)
svg(
  paste0(figure_stub, ".svg"),
  width = plot_width_in, height = plot_height_in,
  family = "Arial", bg = "white", onefile = TRUE
)
print(p)
dev.off()

plot_data_export <- plot_data[, c(
  "Fatty_acid", "Metabolite", "Mean_EAO", "Mean_PM",
  "log2FC_PM_vs_EAO", "Enriched_site",
  "Paired_ANOVA_raw_P", "Paired_ANOVA_FDR_BH"
)]
plot_data_export$Fatty_acid <- as.character(plot_data_export$Fatty_acid)
plot_data_export$Enriched_site <- as.character(plot_data_export$Enriched_site)
write.table(
  plot_data_export,
  file.path(
    table_dir,
    "Fig3_EAO_PM_targeted_fatty_acids_FDR005_log2FC_PM_vs_EAO_barplot_data.tsv"
  ),
  sep = "\t", quote = FALSE, row.names = FALSE, na = "NA"
)

cat("Targeted fatty-acid log2FC bar plot completed.\n")
cat("Direction: log2FC = log2(mean PM / mean EAO).\n")
cat("Fatty acids plotted:", nrow(plot_data), "\n")
cat("Higher in EAO:", sum(plot_data$Enriched_site == "EAO"), "\n")
cat("Higher in PM:", sum(plot_data$Enriched_site == "PM"), "\n")
cat("log2FC range:", paste(range(plot_data$log2FC_PM_vs_EAO), collapse = " to "), "\n")
cat("Figure stub:", figure_stub, "\n")
