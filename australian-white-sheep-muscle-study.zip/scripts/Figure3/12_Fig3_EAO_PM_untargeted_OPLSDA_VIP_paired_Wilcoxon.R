#!/usr/bin/env Rscript

# EAO-PM untargeted LC-MS differential analysis used for integrated
# metabolite KEGG enrichment. The analysis intentionally retains every
# named feature (no QC-CV filter), following the previously agreed rule:
# paired multilevel OPLS-DA VIP > 1 and paired Wilcoxon raw P < 0.05.

rm(list = ls())

suppressPackageStartupMessages({
  library(data.table)
  library(openxlsx)
  library(ropls)
})

set.seed(20260903)

project_dir <- "__PROJECT_ROOT__"
input_file <- file.path(
  project_dir, "06_LCMS_untarget",
  "01_PM_SM_TIC_OPLSDA_VIP_paired_Wilcoxon",
  "pos_neg_named_HMDB_TIC_log10_normalized.tsv"
)
work_dir <- file.path(project_dir, "09_Figure3_EAO_PM_IMF_tenderness_decoupling")
table_dir <- file.path(work_dir, "Tables")
dir.create(table_dir, recursive = TRUE, showWarnings = FALSE)

if (!file.exists(input_file)) stop("Missing normalized LC-MS input: ", input_file)

dat <- fread(input_file, na.strings = c("NA", ""), check.names = FALSE)
eao_cols <- paste0("AM_", 1:6)
pm_cols <- paste0("PM_", 1:6)
paired_cols <- as.vector(rbind(eao_cols, pm_cols))
missing_cols <- setdiff(paired_cols, names(dat))
if (length(missing_cols)) stop("Missing sample columns: ", paste(missing_cols, collapse = ", "))

for (nm in paired_cols) set(dat, j = nm, value = as.numeric(dat[[nm]]))
x <- t(as.matrix(dat[, ..paired_cols]))
rownames(x) <- paired_cols
colnames(x) <- dat$Feature_key

# Within-animal centering removes the Animal main effect before OPLS-DA.
animal <- rep(1:6, each = 2)
site <- factor(rep(c("EAO", "PM"), 6), levels = c("EAO", "PM"))
for (a in 1:6) {
  idx <- animal == a
  x[idx, ] <- sweep(x[idx, , drop = FALSE], 2, colMeans(x[idx, , drop = FALSE]), "-")
}

feature_sd <- apply(x, 2, sd)
model_keep <- is.finite(feature_sd) & feature_sd > 0
x_model <- x[, model_keep, drop = FALSE]
if (ncol(x_model) < 2L) stop("Too few nonconstant features for OPLS-DA")

message("Fitting paired multilevel OPLS-DA for EAO versus PM...")
fit <- opls(
  x_model, site,
  predI = 1, orthoI = 1, scaleC = "standard", crossvalI = 6,
  permI = 0, fig.pdfC = "none", info.txtC = "none"
)

vip_model <- as.numeric(getVipVn(fit))
if (length(vip_model) != ncol(x_model)) stop("VIP length mismatch")
vip <- rep(NA_real_, nrow(dat))
vip[model_keep] <- vip_model

safe_paired_wilcox <- function(eao, pm) {
  d <- eao - pm
  if (all(!is.finite(d)) || all(d[is.finite(d)] == 0)) return(c(V = 0, P = 1))
  wt <- suppressWarnings(wilcox.test(
    eao, pm, paired = TRUE, exact = FALSE, correct = TRUE
  ))
  c(V = unname(wt$statistic), P = wt$p.value)
}

message("Running feature-wise paired Wilcoxon tests...")
stats <- rbindlist(lapply(seq_len(nrow(dat)), function(i) {
  eao <- as.numeric(dat[i, ..eao_cols])
  pm <- as.numeric(dat[i, ..pm_cols])
  d <- eao - pm
  wt <- safe_paired_wilcox(eao, pm)
  data.table(
    mean_log10_EAO = mean(eao),
    mean_log10_PM = mean(pm),
    mean_paired_difference_log10 = mean(d),
    log2FC_EAO_vs_PM = mean(d) * log2(10),
    n_EAO_gt_PM = sum(d > 0),
    n_EAO_lt_PM = sum(d < 0),
    n_equal = sum(d == 0),
    paired_Wilcoxon_V = wt[["V"]],
    paired_Wilcoxon_P = wt[["P"]]
  )
}))

annotation_cols <- intersect(c(
  "Feature_key", "Feature_ID", "ID", "Metabolite", "Metabolite_mode",
  "Source_mode", "Mode", "m/z", "Retention.time", "Adducts", "Formula",
  "KEGG.Compound.ID", "CAS.ID", "InChIKey", "Level", "HMDB_Match_Method",
  "HMDB_ID", "HMDB_Name", "HMDB_KEGG_ID", "HMDB_InChIKey",
  "HMDB_Taxonomy_superclass", "HMDB_Taxonomy_class",
  "HMDB_Taxonomy_subclass"
), names(dat))

results <- cbind(
  dat[, ..annotation_cols],
  data.table(VIP = vip, Entered_OPLSDA = model_keep),
  stats
)
results[, paired_Wilcoxon_FDR_BH := p.adjust(paired_Wilcoxon_P, method = "BH")]
results[, Differential := !is.na(VIP) & VIP > 1 & paired_Wilcoxon_P < 0.05]
results[, Higher_in := fifelse(
  Differential & log2FC_EAO_vs_PM > 0, "EAO",
  fifelse(Differential & log2FC_EAO_vs_PM < 0, "PM", "Not differential")
)]
setorder(results, -Differential, paired_Wilcoxon_P, -VIP)
significant <- results[Differential == TRUE]

prefix <- "Fig3_EAO_PM_untargeted_all_named_OPLSDA_VIP_paired_Wilcoxon"
fwrite(results, file.path(table_dir, paste0(prefix, "_all_results.tsv")),
       sep = "\t", quote = FALSE, na = "NA")
fwrite(significant, file.path(table_dir, paste0(prefix, "_differential.tsv")),
       sep = "\t", quote = FALSE, na = "NA")

model_summary <- as.data.table(getSummaryDF(fit), keep.rownames = "Model")
model_summary[, `:=`(
  Contrast = "EAO versus PM",
  Design = "paired multilevel OPLS-DA after within-Animal centering",
  Animals = 6L,
  Named_features = nrow(dat),
  Features_entered = sum(model_keep),
  Selection_rule = "VIP > 1 and paired Wilcoxon raw P < 0.05; no QC-CV filter"
)]
summary <- data.table(
  Item = c(
    "Named features", "Features entered in OPLS-DA", "Differential features",
    "EAO-enriched differential features", "PM-enriched differential features",
    "Differential features with Wilcoxon BH FDR < 0.05",
    "Selection rule", "TIC normalization source"
  ),
  Value = c(
    nrow(dat), sum(model_keep), nrow(significant),
    sum(significant$Higher_in == "EAO"), sum(significant$Higher_in == "PM"),
    sum(significant$paired_Wilcoxon_FDR_BH < 0.05, na.rm = TRUE),
    "OPLS-DA VIP > 1 plus paired Wilcoxon raw P < 0.05; all named features retained",
    "log10(raw intensity / sample TIC * median sample TIC + 1)"
  )
)
fwrite(summary, file.path(table_dir, paste0(prefix, "_summary.tsv")),
       sep = "\t", quote = FALSE, na = "NA")
fwrite(model_summary, file.path(table_dir, paste0(prefix, "_model_summary.tsv")),
       sep = "\t", quote = FALSE, na = "NA")
write.xlsx(
  list(
    Summary = as.data.frame(summary),
    Model_summary = as.data.frame(model_summary),
    Differential = as.data.frame(significant),
    All_results = as.data.frame(results)
  ),
  file.path(table_dir, paste0(prefix, "_results.xlsx")),
  overwrite = TRUE, keepNA = TRUE
)

message("Done. Differential features: ", nrow(significant),
        " (EAO ", sum(significant$Higher_in == "EAO"),
        "; PM ", sum(significant$Higher_in == "PM"), ")")
