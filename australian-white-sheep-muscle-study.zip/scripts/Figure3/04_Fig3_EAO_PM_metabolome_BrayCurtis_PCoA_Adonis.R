#!/usr/bin/env Rscript

# Figure 3: EAO-PM metabolome Bray-Curtis PCoA and paired PERMANOVA.
# All 1,611 named LC-MS features are retained without QC-CV filtering.
# The saved log10(TIC-scaled abundance + 1) values are back-transformed,
# square-root transformed, and used to calculate Bray-Curtis distances.

rm(list = ls())

suppressPackageStartupMessages({
  library(ggplot2)
  library(grid)
  library(openxlsx)
  library(vegan)
})

project_dir <- "__PROJECT_ROOT__"
work_dir <- file.path(
  project_dir, "09_Figure3_EAO_PM_IMF_tenderness_decoupling"
)
input_file <- file.path(
  project_dir, "06_LCMS_untarget",
  "01_PM_SM_TIC_OPLSDA_VIP_paired_Wilcoxon",
  "pos_neg_named_HMDB_TIC_log10_normalized.tsv"
)
figure_dir <- file.path(work_dir, "Figures")
table_dir <- file.path(work_dir, "Tables")
dir.create(figure_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(table_dir, recursive = TRUE, showWarnings = FALSE)

figure_stub <- file.path(
  figure_dir, "Fig3_EAO_PM_metabolome_BrayCurtis_PCoA_95CI"
)
site_order <- c("EAO", "PM")
site_colors <- c(EAO = "#A65D68", PM = "#C28B48")
eao_samples <- paste0("AM_", 1:6)
pm_samples <- paste0("PM_", 1:6)
sample_order <- as.vector(rbind(eao_samples, pm_samples))
plot_width_in <- 5.2
plot_height_in <- 4.5

write_tsv <- function(x, filename) {
  write.table(
    x, file.path(table_dir, filename), sep = "\t", quote = FALSE,
    row.names = FALSE, na = "NA"
  )
}

adonis_to_table <- function(x) {
  data.frame(
    Term = rownames(x), as.data.frame(x, check.names = FALSE),
    row.names = NULL, check.names = FALSE
  )
}

format_p <- function(p) {
  if (!is.finite(p)) return("NA")
  if (p < 0.001) return(format(p, scientific = TRUE, digits = 1))
  formatC(p, format = "f", digits = 3)
}

# All 2^6 paired EAO/PM label swaps, excluding the identity permutation.
make_exact_paired_permutations <- function(n_animals = 6L) {
  n_samples <- 2L * n_animals
  permutations <- t(vapply(
    seq_len(2^n_animals - 1L),
    function(mask) {
      index <- seq_len(n_samples)
      bits <- as.integer(intToBits(mask))[seq_len(n_animals)]
      for (animal_i in seq_len(n_animals)) {
        if (bits[animal_i] == 1L) {
          pair_index <- c(2L * animal_i - 1L, 2L * animal_i)
          index[pair_index] <- rev(index[pair_index])
        }
      }
      index
    },
    integer(n_samples)
  ))
  if (nrow(unique(permutations)) != 2^n_animals - 1L) {
    stop("Paired permutation matrix is not unique.")
  }
  permutations
}

centroid_confidence_ellipse <- function(data, level = 0.95, n_points = 200L) {
  coordinates <- as.matrix(data[, c("PCoA1", "PCoA2"), drop = FALSE])
  n <- nrow(coordinates)
  p <- ncol(coordinates)
  if (n <= p) stop("Too few samples for a two-dimensional confidence ellipse.")
  covariance_matrix <- stats::cov(coordinates)
  eigen_decomposition <- eigen(covariance_matrix, symmetric = TRUE)
  if (any(eigen_decomposition$values <= 0)) {
    stop("Non-positive covariance eigenvalue in confidence ellipse.")
  }
  hotelling_factor <-
    p * (n - 1) / (n * (n - p)) * stats::qf(level, p, n - p)
  transform_matrix <- eigen_decomposition$vectors %*%
    diag(sqrt(eigen_decomposition$values * hotelling_factor), nrow = p)
  angles <- seq(0, 2 * pi, length.out = n_points)
  unit_circle <- cbind(cos(angles), sin(angles))
  ellipse_coordinates <- sweep(
    unit_circle %*% t(transform_matrix), 2, colMeans(coordinates), "+"
  )
  data.frame(
    PCoA1 = ellipse_coordinates[, 1],
    PCoA2 = ellipse_coordinates[, 2]
  )
}

if (!file.exists(input_file)) stop("Input file not found: ", input_file)
metabolites <- read.delim(
  input_file, check.names = FALSE, stringsAsFactors = FALSE,
  quote = "", comment.char = ""
)
required <- c("Feature_key", "Metabolite", sample_order)
missing_columns <- setdiff(required, names(metabolites))
if (length(missing_columns)) {
  stop("Missing columns: ", paste(missing_columns, collapse = ", "))
}
if (anyDuplicated(metabolites$Feature_key)) stop("Feature_key is not unique.")
if (any(is.na(metabolites$Metabolite) | trimws(metabolites$Metabolite) == "")) {
  stop("Input contains unnamed metabolite features.")
}

log10_tic_matrix <- as.matrix(
  metabolites[, sample_order, drop = FALSE]
)
suppressWarnings(storage.mode(log10_tic_matrix) <- "double")
rownames(log10_tic_matrix) <- metabolites$Feature_key
if (any(!is.finite(log10_tic_matrix)) || any(log10_tic_matrix < 0)) {
  stop("Normalized metabolite matrix contains invalid values.")
}

# Exact inverse of log10(TIC-scaled abundance + 1), followed by the same
# square-root abundance compression used for the Figure 2 proteome PCoA.
tic_scaled_matrix <- 10^log10_tic_matrix - 1
tic_scaled_matrix[tic_scaled_matrix < 0 & tic_scaled_matrix > -1e-8] <- 0
if (any(tic_scaled_matrix < 0)) stop("Negative back-transformed abundance.")
sqrt_tic_matrix <- sqrt(tic_scaled_matrix)
feature_nonzero <- rowSums(sqrt_tic_matrix > 0) > 0
if (!all(feature_nonzero)) {
  sqrt_tic_matrix <- sqrt_tic_matrix[feature_nonzero, , drop = FALSE]
}

metadata <- data.frame(
  Sample = sample_order,
  Site = factor(rep(site_order, times = 6L), levels = site_order),
  Animal = factor(rep(1:6, each = 2L), levels = as.character(1:6)),
  Named_features_detected = colSums(sqrt_tic_matrix > 0),
  TIC_scaled_sum = colSums(tic_scaled_matrix[feature_nonzero, , drop = FALSE]),
  row.names = sample_order,
  stringsAsFactors = FALSE
)
pairing_table <- table(metadata$Animal, metadata$Site)
if (!all(dim(pairing_table) == c(6L, 2L)) || !all(pairing_table == 1L)) {
  stop("Expected one EAO and one PM sample from each of six animals.")
}

bray_distance <- vegan::vegdist(t(sqrt_tic_matrix), method = "bray")
distance_matrix <- as.matrix(bray_distance)

uncorrected_pcoa <- vegan::wcmdscale(
  bray_distance, k = 2, eig = TRUE, add = FALSE
)
pcoa_fit <- vegan::wcmdscale(
  bray_distance, k = 2, eig = TRUE, add = "lingoes", x.ret = TRUE
)
positive_eigenvalues <- as.numeric(pcoa_fit$eig[pcoa_fit$eig > 0])
if (length(positive_eigenvalues) < 2L) stop("Fewer than two positive PCoA axes.")
pcoa_variance <- 100 * positive_eigenvalues / sum(positive_eigenvalues)

pcoa_coordinates <- data.frame(
  Sample = rownames(pcoa_fit$points),
  PCoA1 = pcoa_fit$points[, 1],
  PCoA2 = pcoa_fit$points[, 2],
  Site = metadata[rownames(pcoa_fit$points), "Site"],
  Animal = metadata[rownames(pcoa_fit$points), "Animal"],
  stringsAsFactors = FALSE
)
pcoa_coordinates$Site <- factor(pcoa_coordinates$Site, levels = site_order)
pcoa_coordinates$Animal <- factor(
  pcoa_coordinates$Animal, levels = as.character(1:6)
)

pcoa_variance_table <- data.frame(
  Axis = paste0("PCoA", seq_along(positive_eigenvalues)),
  Positive_eigenvalue = positive_eigenvalues,
  Variance_explained_percent = pcoa_variance,
  Cumulative_variance_percent = cumsum(pcoa_variance)
)

confidence_ellipses <- do.call(rbind, lapply(site_order, function(site_name) {
  z <- pcoa_coordinates[pcoa_coordinates$Site == site_name, , drop = FALSE]
  ellipse <- centroid_confidence_ellipse(z)
  ellipse$Site <- factor(site_name, levels = site_order)
  ellipse$Point_order <- seq_len(nrow(ellipse))
  ellipse
}))

site_centroids <- do.call(rbind, lapply(site_order, function(site_name) {
  z <- pcoa_coordinates[pcoa_coordinates$Site == site_name, , drop = FALSE]
  data.frame(
    Site = site_name, n = nrow(z),
    PCoA1_centroid = mean(z$PCoA1),
    PCoA2_centroid = mean(z$PCoA2)
  )
}))

permutation_matrix <- make_exact_paired_permutations(6L)
adonis_fit <- vegan::adonis2(
  bray_distance ~ Animal + Site,
  data = metadata,
  permutations = permutation_matrix,
  by = "margin",
  parallel = 1
)
adonis_full <- adonis_to_table(adonis_fit)
site_row <- adonis_full[adonis_full$Term == "Site", , drop = FALSE]
residual_row <- adonis_full[adonis_full$Term == "Residual", , drop = FALSE]
if (nrow(site_row) != 1L || nrow(residual_row) != 1L) {
  stop("Could not extract Site and Residual rows from adonis2.")
}
adonis_summary <- data.frame(
  Test = "EAO vs PM paired Site effect",
  Model = "Bray-Curtis distance ~ Animal + Site",
  Site_Df = site_row$Df,
  Site_SumOfSqs = site_row$SumOfSqs,
  Site_R2_total = site_row$R2,
  Site_partial_R2 = site_row$SumOfSqs /
    (site_row$SumOfSqs + residual_row$SumOfSqs),
  Pseudo_F = site_row$F,
  P_value = site_row[["Pr(>F)"]],
  Exact_nonidentity_permutations = nrow(permutation_matrix),
  Total_label_configurations_including_observed = nrow(permutation_matrix) + 1L,
  Minimum_attainable_P = 1 / (nrow(permutation_matrix) + 1L),
  Permutation_restriction = "EAO/PM label swaps within Animal"
)

# Homogeneity-of-dispersion diagnostic, using the same paired permutation set.
dispersion_fit <- vegan::betadisper(
  bray_distance, group = metadata$Site,
  type = "median", bias.adjust = TRUE
)
dispersion_test <- vegan::permutest(
  dispersion_fit, permutations = permutation_matrix, pairwise = FALSE
)
dispersion_overall <- data.frame(
  Term = rownames(dispersion_test$tab),
  as.data.frame(dispersion_test$tab, check.names = FALSE),
  row.names = NULL, check.names = FALSE
)
dispersion_distances <- data.frame(
  Sample = rownames(metadata),
  Site = metadata$Site,
  Animal = metadata$Animal,
  Distance_to_site_spatial_median = dispersion_fit$distances
)

pcoa_correction <- data.frame(
  Method = "Lingoes",
  Additive_constant = pcoa_fit$ac,
  Negative_eigenvalues_before_correction = sum(uncorrected_pcoa$eig < -1e-10),
  Sum_positive_eigenvalues = sum(positive_eigenvalues)
)

annotation_label <- sprintf(
  "R²: %.2f\nP-value: %s",
  adonis_summary$Site_R2_total,
  format_p(adonis_summary$P_value)
)

p <- ggplot(pcoa_coordinates, aes(PCoA1, PCoA2)) +
  geom_hline(yintercept = 0, color = "#D8DADD", linewidth = 0.32) +
  geom_vline(xintercept = 0, color = "#D8DADD", linewidth = 0.32) +
  geom_polygon(
    data = confidence_ellipses,
    aes(PCoA1, PCoA2, group = Site, fill = Site),
    inherit.aes = FALSE, alpha = 0.12, color = NA, show.legend = FALSE
  ) +
  geom_path(
    data = confidence_ellipses,
    aes(PCoA1, PCoA2, group = Site, color = Site),
    inherit.aes = FALSE, linewidth = 0.62, alpha = 0.88,
    show.legend = FALSE
  ) +
  geom_point(
    aes(fill = Site), shape = 21, size = 3.2, stroke = 0.45,
    alpha = 0.92, color = "#1F2328"
  ) +
  annotate(
    "text", x = -Inf, y = Inf, label = annotation_label,
    hjust = -0.10, vjust = 1.18, family = "Arial", size = 3.0,
    color = "#30363D", lineheight = 1.05
  ) +
  scale_fill_manual(values = site_colors, breaks = site_order, drop = FALSE) +
  scale_color_manual(values = site_colors, breaks = site_order, drop = FALSE) +
  scale_x_continuous(expand = expansion(mult = 0.12)) +
  scale_y_continuous(expand = expansion(mult = 0.12)) +
  labs(
    title = "Metabolome",
    x = sprintf("PCoA1 (%.1f%%)", pcoa_variance[1]),
    y = sprintf("PCoA2 (%.1f%%)", pcoa_variance[2]),
    fill = NULL
  ) +
  theme_bw(base_size = 10.5, base_family = "Arial") +
  theme(
    aspect.ratio = 1,
    plot.title = element_text(
      hjust = 0.5, size = 11.2, face = "plain", color = "#1F2328",
      margin = margin(b = 4)
    ),
    panel.grid = element_blank(),
    panel.border = element_rect(color = "#1F1F1F", linewidth = 0.5),
    axis.text = element_text(color = "#30363D", size = 8.5),
    axis.title = element_text(color = "#1F2328", size = 10.5),
    axis.title.x = element_text(margin = margin(t = 7)),
    axis.title.y = element_text(margin = margin(r = 7)),
    axis.ticks = element_line(color = "#1F1F1F", linewidth = 0.4),
    axis.ticks.length = unit(2, "mm"),
    legend.position = "right",
    legend.text = element_text(size = 9, color = "#1F2328"),
    legend.key = element_blank(),
    plot.margin = margin(t = 5, r = 7, b = 5, l = 7)
  ) +
  guides(
    fill = guide_legend(
      override.aes = list(
        shape = 21, size = 3.2, stroke = 0.45,
        alpha = 0.92, color = "#1F2328"
      )
    )
  )

ggsave(
  paste0(figure_stub, ".pdf"), p, device = cairo_pdf,
  width = plot_width_in, height = plot_height_in, units = "in",
  family = "Arial"
)
ggsave(
  paste0(figure_stub, ".png"), p, device = "png",
  width = plot_width_in, height = plot_height_in, units = "in",
  dpi = 600, bg = "white"
)
svg(
  paste0(figure_stub, ".svg"), width = plot_width_in,
  height = plot_height_in, family = "Arial", bg = "white", onefile = TRUE
)
print(p)
dev.off()

write_tsv(metadata, "Fig3_EAO_PM_metabolome_sample_metadata.tsv")
write_tsv(
  pcoa_coordinates,
  "Fig3_EAO_PM_metabolome_BrayCurtis_PCoA_coordinates.tsv"
)
write_tsv(
  pcoa_variance_table,
  "Fig3_EAO_PM_metabolome_BrayCurtis_PCoA_variance.tsv"
)
write_tsv(
  confidence_ellipses,
  "Fig3_EAO_PM_metabolome_PCoA_centroid_95CI_coordinates.tsv"
)
write_tsv(site_centroids, "Fig3_EAO_PM_metabolome_PCoA_site_centroids.tsv")
write_tsv(adonis_full, "Fig3_EAO_PM_metabolome_paired_Adonis_full.tsv")
write_tsv(adonis_summary, "Fig3_EAO_PM_metabolome_paired_Adonis_summary.tsv")
write_tsv(
  dispersion_overall,
  "Fig3_EAO_PM_metabolome_PERMDISP_overall.tsv"
)
write_tsv(
  dispersion_distances,
  "Fig3_EAO_PM_metabolome_PERMDISP_sample_distances.tsv"
)
write_tsv(pcoa_correction, "Fig3_EAO_PM_metabolome_PCoA_correction.tsv")

distance_export <- data.frame(
  Sample = rownames(distance_matrix), distance_matrix,
  check.names = FALSE, row.names = NULL
)
write_tsv(distance_export, "Fig3_EAO_PM_metabolome_BrayCurtis_distance_matrix.tsv")

used_matrix_export <- data.frame(
  Feature_key = rownames(sqrt_tic_matrix),
  sqrt_tic_matrix,
  check.names = FALSE, row.names = NULL
)
used_connection <- gzfile(
  file.path(
    table_dir,
    "Fig3_EAO_PM_metabolome_sqrt_TIC_abundance_PCoA_input.tsv.gz"
  ),
  open = "wt"
)
write.table(
  used_matrix_export, used_connection, sep = "\t", quote = FALSE,
  row.names = FALSE, na = "NA"
)
close(used_connection)

qa_manifest <- data.frame(
  Item = c(
    "Input", "Samples", "Animals", "Sites", "Named features input",
    "Features retained", "QC-CV filter", "Normalization source",
    "Distance input", "Distance", "PCoA correction", "Adonis model",
    "Permutation scheme", "Nonidentity permutations", "Minimum P",
    "Site R2 total", "Site partial R2", "Adonis P", "Panel aspect", "Font"
  ),
  Value = c(
    input_file, nrow(metadata), nlevels(metadata$Animal),
    paste(site_order, collapse = ", "), nrow(metabolites),
    nrow(sqrt_tic_matrix), "None",
    "log10(raw intensity / sample TIC * median sample TIC + 1)",
    "sqrt(back-transformed TIC-scaled abundance)", "Bray-Curtis",
    "Lingoes", "distance ~ Animal + Site",
    "all paired EAO/PM swaps within Animal, excluding identity",
    nrow(permutation_matrix), 1 / (nrow(permutation_matrix) + 1L),
    adonis_summary$Site_R2_total, adonis_summary$Site_partial_R2,
    adonis_summary$P_value, "1:1", "Arial"
  ),
  stringsAsFactors = FALSE
)
write_tsv(qa_manifest, "Fig3_EAO_PM_metabolome_PCoA_Adonis_QA.tsv")

write.xlsx(
  list(
    Adonis_summary = adonis_summary,
    Adonis_full = adonis_full,
    PCoA_coordinates = pcoa_coordinates,
    PCoA_variance = pcoa_variance_table,
    Sample_metadata = metadata,
    PERMDISP = dispersion_overall,
    QA = qa_manifest
  ),
  file.path(table_dir, "Fig3_EAO_PM_metabolome_PCoA_Adonis_results.xlsx"),
  overwrite = TRUE, asTable = TRUE
)

message("Figure written to: ", figure_dir)
message("Tables written to: ", table_dir)
message(
  sprintf(
    "Paired Adonis Site effect: R2 = %.4f; partial R2 = %.4f; P = %.6f",
    adonis_summary$Site_R2_total,
    adonis_summary$Site_partial_R2,
    adonis_summary$P_value
  )
)
