#!/usr/bin/env Rscript

# Hypothesis-guided, direction-checked curation of EAO-PM differential
# untargeted metabolites. This does not introduce a new statistical test.
# It separates direct/supportive evidence from context-only and unsuitable
# annotations, preserving the original VIP and paired Wilcoxon statistics.

rm(list = ls())

suppressPackageStartupMessages({
  library(data.table)
  library(openxlsx)
})

work_dir <- "__PROJECT_ROOT__/09_Figure3_EAO_PM_IMF_tenderness_decoupling"
table_dir <- file.path(work_dir, "Tables")
input_file <- file.path(
  table_dir,
  "Fig3_EAO_PM_untargeted_all_named_OPLSDA_VIP_paired_Wilcoxon_differential.tsv"
)
override_file <- file.path(
  table_dir,
  "Fig3_EAO_PM_integrated_untargeted_targeted_metabolite_KEGG_untargeted_mapping_and_override.tsv"
)
qc_file <- file.path(
  "__PROJECT_ROOT__/06_LCMS_untarget",
  "01_PM_SM_TIC_OPLSDA_VIP_paired_Wilcoxon", "Tables",
  "LCMS_named_feature_QC_CV.tsv"
)
if (!file.exists(input_file)) stop("Missing input: ", input_file)

d <- fread(input_file, na.strings = c("NA", ""), check.names = FALSE)

# Each entry was reviewed for direction, biochemical specificity, annotation
# plausibility in sheep muscle, and whether it duplicates the targeted assay.
manifest <- data.table::data.table(
  Metabolite = c(
    # PM: coherent fatty-acid transport / mitochondrial substrate handling
    "Carnitine", "Hexanoylcarnitine", "Butyrylcarnitine",
    "Octanoyl L-Carnitine", "(5R)-5-Hydroxyhexanoylcarnitine",
    # PM: oxidative/energy-turnover context
    "NADH", "Hypoxanthine", "Inosine", "Phosphocreatine", "Taurine",
    # PM: phospholipid-remodelling context
    "Lpc(16:0-sn2)", "Lpc(18:2-sn2)", "Lpe(18:0)", "Lpe(18:1)",
    "1-Stearoyl-2-hydroxy-sn-glycero-3-phosphoethanolamine",
    # EAO: lipid accumulation/remodelling context
    "Palmitoyl sphingomyelin", "Cholesterol 3-sulfate", "Adrenic acid",
    "Pantetheine 4'-phosphate", "Thromboxane B2",
    "13,14-Dihydro-15-keto-PGE2",
    # Directional exceptions / low-confidence records not for primary claims
    "Decanoyl-l-carnitine", "3-Hydroxyheptadecanoylcarnitine",
    "Dg(13d5/11d5/0:0)", "Dg(9m5/9d3/0:0)"
  ),
  Expected_higher_in = c(
    rep("PM", 5), rep("PM", 5), rep("PM", 5),
    rep("EAO", 6), rep("EAO", 4)
  ),
  Evidence_tier = c(
    "Core", "Core", "Core", "Core", "Core",
    "Supportive", "Supportive", "Supportive", "Context only", "Context only",
    rep("Supportive", 4), "Do not use as primary evidence",
    "Context only", "Supportive", "Targeted-confirmed overlap", "Context only",
    "Context only", "Context only",
    rep("Do not use as primary evidence", 4)
  ),
  Mechanistic_axis = c(
    "Carnitine shuttle / fatty-acid transport",
    "Short/medium-chain acylcarnitine; mitochondrial substrate handling",
    "Short-chain acylcarnitine; mitochondrial substrate handling",
    "Medium-chain acylcarnitine; mitochondrial substrate handling",
    "Hydroxy-acylcarnitine; mitochondrial substrate handling",
    "Cellular redox/oxidative energy metabolism",
    "Purine degradation and energetic turnover",
    "Purine degradation and energetic turnover",
    "Phosphagen energy buffer",
    "Osmoregulation/redox-associated muscle metabolite",
    rep("Membrane phospholipid turnover/remodelling", 5),
    "Complex membrane-lipid pool",
    "Sterol-derived lipid pool",
    "Long-chain polyunsaturated fatty acid pool",
    "CoA biosynthesis precursor; not specific to synthesis versus oxidation",
    "Eicosanoid formation/turnover",
    "Eicosanoid degradation/turnover",
    "Acylcarnitine directional exception",
    "Acylcarnitine directional exception with negligible effect",
    "Putative diacylglycerol",
    "Putative diacylglycerol"
  ),
  Claim_supported = c(
    rep("PM has stronger fatty-acid transport/mitochondrial substrate handling", 5),
    "PM has a more oxidative/redox-active energetic state",
    "PM has greater energetic/purine turnover",
    "PM has greater energetic/purine turnover",
    "Exploratory evidence for higher energetic demand in PM",
    "General PM muscle-state context; not lipid-specific",
    rep("PM shows enhanced membrane-lipid remodelling; not direct beta-oxidation evidence", 4),
    "Duplicate annotation of LysoPE(18:0/0:0); not counted as a separate metabolite",
    "EAO contains a larger/remodelled structural lipid pool",
    "EAO contains a larger/remodelled sterol lipid pool",
    "EAO contains more long-chain fatty acid; direction agrees with targeted assay",
    "Possible greater acyl-group handling in EAO, but direction of flux is unresolved",
    "EAO shows altered lipid-derived signalling/turnover, not storage itself",
    "EAO shows altered lipid-derived signalling/turnover, not storage itself",
    "Does not support the overall PM acylcarnitine pattern",
    "Does not support the overall PM acylcarnitine pattern",
    "Potentially supports EAO neutral-lipid accumulation, but annotation is unreliable",
    "Potentially supports EAO neutral-lipid accumulation, but annotation is unreliable"
  ),
  Interpretation_limit = c(
    "Pool abundance supports transport capacity but does not measure beta-oxidation flux",
    "Acylcarnitine accumulation can reflect increased substrate entry or incomplete oxidation",
    "Acylcarnitine accumulation can reflect increased substrate entry or incomplete oxidation",
    "No HMDB match in the merged table; retain as class-coherence evidence",
    "Acylcarnitine accumulation can reflect increased substrate entry or incomplete oxidation",
    "NADH abundance is not a direct measurement of respiratory flux",
    "Not lipid-specific", "Not lipid-specific",
    "Level D annotation; confirmation required", "Not lipid-specific",
    rep("Supports lipid remodelling rather than oxidation rate", 4),
    "Same chemical interpretation as Lpe(18:0); retain only the higher-VIP feature",
    "Structural lipid abundance does not demonstrate de novo lipogenesis",
    "Small effect; structural/sterol pool evidence only",
    "Not independent: the same KEGG compound is covered by targeted fatty-acid analysis",
    "CoA is required by both synthesis and oxidation; cannot assign flux direction",
    "Eicosanoids are signalling/turnover products rather than storage lipids",
    "Eicosanoids are signalling/turnover products rather than storage lipids",
    "Level D annotation; conflicts with the dominant PM acylcarnitine direction",
    "Very small effect despite consistent paired direction",
    "Level D and chemically implausible shorthand; do not interpret",
    "Level D and chemically implausible shorthand; do not interpret"
  )
)

curated <- merge(manifest, d, by = "Metabolite", all.x = TRUE, sort = FALSE)
if (anyNA(curated$Feature_key)) {
  stop("Curated metabolites missing from differential table: ",
       paste(curated[is.na(Feature_key), Metabolite], collapse = ", "))
}
curated[, Direction_check := Higher_in == Expected_higher_in]
if (!all(curated$Direction_check)) stop("At least one curated metabolite has the wrong direction")

curated[, Paired_direction := sprintf(
  "%d/6 EAO>PM; %d/6 PM>EAO", n_EAO_gt_PM, n_EAO_lt_PM
)]
curated[, Targeted_override := FALSE]
curated[, Targeted_override_match := NA_character_]
if (file.exists(override_file)) {
  ov <- fread(override_file, na.strings = c("NA", ""), check.names = FALSE)
  ov <- unique(ov[, .(
    Feature_key = Source_feature_ID,
    Targeted_override = as.logical(Overridden_by_targeted),
    Targeted_override_match = Override_match
  )], by = "Feature_key")
  curated[, c("Targeted_override", "Targeted_override_match") := NULL]
  curated <- merge(curated, ov, by = "Feature_key", all.x = TRUE, sort = FALSE)
  curated[is.na(Targeted_override), Targeted_override := FALSE]
}
if (file.exists(qc_file)) {
  qc <- fread(qc_file, na.strings = c("NA", ""), check.names = FALSE)
  qc <- unique(qc[, .(
    Feature_key, QC_CV_percent,
    QC_CV_le_30_percent = as.logical(QC_CV_le_30_percent)
  )], by = "Feature_key")
  curated <- merge(curated, qc, by = "Feature_key", all.x = TRUE, sort = FALSE)
  curated[, QC_interpretation := fifelse(
    QC_CV_le_30_percent == TRUE, "QC CV <= 30%",
    fifelse(QC_CV_le_30_percent == FALSE, "QC CV > 30%; analytical caution",
            "QC CV unavailable")
  )]
}

preferred <- c(
  "Evidence_tier", "Mechanistic_axis", "Metabolite", "Higher_in",
  "Direction_check", "Paired_direction", "log2FC_EAO_vs_PM", "VIP",
  "paired_Wilcoxon_P", "paired_Wilcoxon_FDR_BH", "Level", "HMDB_ID",
  "HMDB_Name", "KEGG.Compound.ID", "HMDB_KEGG_ID", "InChIKey", "Formula",
  "Adducts", "QC_CV_percent", "QC_CV_le_30_percent", "QC_interpretation",
  "Targeted_override", "Targeted_override_match",
  "Claim_supported", "Interpretation_limit", "Feature_key"
)
curated <- curated[, intersect(preferred, names(curated)), with = FALSE]
curated[, Evidence_tier := factor(Evidence_tier, levels = c(
  "Core", "Supportive", "Targeted-confirmed overlap", "Context only",
  "Do not use as primary evidence"
))]
setorder(curated, Evidence_tier, Higher_in, -VIP)
curated[, Evidence_tier := as.character(Evidence_tier)]

core <- curated[Evidence_tier == "Core"]
supportive <- curated[Evidence_tier %chin% c("Supportive", "Targeted-confirmed overlap")]
context <- curated[Evidence_tier == "Context only"]
not_primary <- curated[Evidence_tier == "Do not use as primary evidence"]

summary <- data.table(
  Item = c(
    "Differential untargeted features screened",
    "EAO-enriched differential features",
    "PM-enriched differential features",
    "Core hypothesis-aligned metabolites",
    "Supportive or targeted-confirmed metabolites",
    "Context-only metabolites",
    "Explicitly excluded from primary evidence",
    "Feature-level FDR status",
    "Direction convention"
  ),
  Value = c(
    nrow(d), sum(d$Higher_in == "EAO"), sum(d$Higher_in == "PM"),
    nrow(core), nrow(supportive), nrow(context), nrow(not_primary),
    paste0(sum(d$paired_Wilcoxon_FDR_BH < 0.05, na.rm = TRUE),
           " of ", nrow(d), " pass BH FDR < 0.05"),
    "positive log2FC = EAO higher; negative log2FC = PM higher"
  )
)

base <- "Fig3_EAO_PM_hypothesis_aligned_untargeted_metabolites"
fwrite(curated, file.path(table_dir, paste0(base, "_all_curated.tsv")),
       sep = "\t", quote = FALSE, na = "NA")
fwrite(core, file.path(table_dir, paste0(base, "_core.tsv")),
       sep = "\t", quote = FALSE, na = "NA")
fwrite(summary, file.path(table_dir, paste0(base, "_summary.tsv")),
       sep = "\t", quote = FALSE, na = "NA")
write.xlsx(
  list(
    Summary = as.data.frame(summary),
    Recommended_core = as.data.frame(core),
    Supportive = as.data.frame(supportive),
    Context_only = as.data.frame(context),
    Do_not_use_primary = as.data.frame(not_primary),
    All_curated = as.data.frame(curated)
  ),
  file.path(table_dir, paste0(base, ".xlsx")),
  overwrite = TRUE, keepNA = TRUE
)

message("Done. Core = ", nrow(core), "; supportive/targeted overlap = ",
        nrow(supportive), "; context = ", nrow(context),
        "; not primary = ", nrow(not_primary))
