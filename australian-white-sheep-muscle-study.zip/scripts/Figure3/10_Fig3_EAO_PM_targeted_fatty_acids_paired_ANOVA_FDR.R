#!/usr/bin/env Rscript

# Figure 3: paired EAO-PM differential analysis of targeted fatty acids.
# Primary analysis: randomized-block / repeated-measures ANOVA
#   absolute content ~ Animal + Site
# With two within-animal Site levels, the Site F test is equivalent to a
# two-sided paired t test. BH correction is applied across testable fatty acids.
# Paired Wilcoxon tests are exported as a small-sample/nonparametric sensitivity
# analysis but do not define the primary significance calls.

rm(list = ls())

suppressPackageStartupMessages({
  library(openxlsx)
})

project_dir <- "__PROJECT_ROOT__"
work_dir <- file.path(
  project_dir, "09_Figure3_EAO_PM_IMF_tenderness_decoupling"
)
input_file <- file.path(project_dir, "02_fatty_acids", "fatty acids.xlsx")
input_sheet <- "measurement.xls"
table_dir <- file.path(work_dir, "Tables")
dir.create(table_dir, recursive = TRUE, showWarnings = FALSE)

site_order <- c("EAO", "PM")
eao_samples <- paste0("AM_", 1:6)
pm_samples <- paste0("PM_", 1:6)

write_tsv <- function(x, filename) {
  write.table(
    x, file.path(table_dir, filename), sep = "\t", quote = FALSE,
    row.names = FALSE, na = "NA"
  )
}

significance_symbol <- function(q) {
  ifelse(
    is.na(q), "NA",
    ifelse(q < 0.001, "***", ifelse(q < 0.01, "**", ifelse(q < 0.05, "*", "n.s.")))
  )
}

safe_shapiro <- function(x) {
  if (length(x) < 3L || length(x) > 5000L || stats::sd(x) == 0) return(NA_real_)
  tryCatch(stats::shapiro.test(x)$p.value, error = function(e) NA_real_)
}

if (!file.exists(input_file)) stop("Input file not found: ", input_file)
fatty_acids <- read.xlsx(
  input_file, sheet = input_sheet, check.names = FALSE,
  detectDates = FALSE, skipEmptyRows = FALSE
)

required_columns <- c(
  "Metabolite", "CAS.id", "Formula", "KEGG.Compound.ID", "unit",
  "Retention.time", eao_samples, pm_samples
)
missing_columns <- setdiff(required_columns, names(fatty_acids))
if (length(missing_columns)) {
  stop("Missing columns: ", paste(missing_columns, collapse = ", "))
}
if (anyDuplicated(fatty_acids$Metabolite)) stop("Metabolite names are not unique.")
if (length(unique(fatty_acids$unit)) != 1L || unique(fatty_acids$unit) != "ug/mg") {
  stop("Expected a single absolute-content unit: ug/mg.")
}

all_samples <- c(eao_samples, pm_samples)
absolute_matrix <- as.matrix(fatty_acids[, all_samples, drop = FALSE])
suppressWarnings(storage.mode(absolute_matrix) <- "double")
rownames(absolute_matrix) <- fatty_acids$Metabolite
if (any(!is.finite(absolute_matrix))) {
  stop("Absolute fatty-acid matrix contains missing or non-finite values.")
}
if (any(absolute_matrix < 0)) stop("Absolute fatty-acid matrix contains negative values.")

result_rows <- vector("list", nrow(fatty_acids))
long_rows <- vector("list", nrow(fatty_acids))

for (i in seq_len(nrow(fatty_acids))) {
  eao <- as.numeric(fatty_acids[i, eao_samples, drop = TRUE])
  pm <- as.numeric(fatty_acids[i, pm_samples, drop = TRUE])
  paired_difference <- eao - pm

  long_data <- data.frame(
    Metabolite = fatty_acids$Metabolite[i],
    Animal = factor(rep(seq_len(6L), times = 2L)),
    Site = factor(rep(site_order, each = 6L), levels = site_order),
    Absolute_content_ug_mg = c(eao, pm),
    stringsAsFactors = FALSE
  )
  long_rows[[i]] <- long_data

  testable <- length(unique(c(eao, pm))) > 1L && stats::sd(paired_difference) > 0
  anova_f <- anova_p <- paired_t <- paired_t_p <- wilcoxon_v <- wilcoxon_p <- NA_real_

  if (testable) {
    fit <- stats::lm(Absolute_content_ug_mg ~ Animal + Site, data = long_data)
    anova_table <- stats::anova(fit)
    anova_f <- unname(anova_table["Site", "F value"])
    anova_p <- unname(anova_table["Site", "Pr(>F)"])

    paired_t_result <- stats::t.test(eao, pm, paired = TRUE, alternative = "two.sided")
    paired_t <- unname(paired_t_result$statistic)
    paired_t_p <- paired_t_result$p.value

    wilcoxon_result <- suppressWarnings(stats::wilcox.test(
      eao, pm, paired = TRUE, alternative = "two.sided",
      exact = FALSE, correct = FALSE
    ))
    wilcoxon_v <- unname(wilcoxon_result$statistic)
    wilcoxon_p <- wilcoxon_result$p.value
  }

  result_rows[[i]] <- data.frame(
    Metabolite = fatty_acids$Metabolite[i],
    CAS_ID = fatty_acids$CAS.id[i],
    Formula = fatty_acids$Formula[i],
    KEGG_Compound_ID = fatty_acids$KEGG.Compound.ID[i],
    Unit = fatty_acids$unit[i],
    Retention_time = fatty_acids$Retention.time[i],
    N_pairs = 6L,
    Number_nonzero_EAO = sum(eao > 0),
    Number_nonzero_PM = sum(pm > 0),
    Mean_EAO = mean(eao),
    SD_EAO = stats::sd(eao),
    Mean_PM = mean(pm),
    SD_PM = stats::sd(pm),
    Mean_paired_difference_EAO_minus_PM = mean(paired_difference),
    Lower_95CI_paired_difference = mean(paired_difference) -
      stats::qt(0.975, df = 5L) * stats::sd(paired_difference) / sqrt(6),
    Upper_95CI_paired_difference = mean(paired_difference) +
      stats::qt(0.975, df = 5L) * stats::sd(paired_difference) / sqrt(6),
    Mean_ratio_EAO_to_PM = ifelse(mean(pm) > 0, mean(eao) / mean(pm), NA_real_),
    Direction = ifelse(
      mean(paired_difference) > 0, "Higher in EAO",
      ifelse(mean(paired_difference) < 0, "Higher in PM", "No difference")
    ),
    Testable = testable,
    Paired_ANOVA_F = anova_f,
    Paired_ANOVA_raw_P = anova_p,
    Paired_t = paired_t,
    Paired_t_raw_P = paired_t_p,
    Shapiro_P_paired_differences = safe_shapiro(paired_difference),
    Paired_Wilcoxon_V = wilcoxon_v,
    Paired_Wilcoxon_raw_P = wilcoxon_p,
    stringsAsFactors = FALSE
  )
}

results <- do.call(rbind, result_rows)
long_data_all <- do.call(rbind, long_rows)

testable_index <- which(results$Testable & is.finite(results$Paired_ANOVA_raw_P))
results$Paired_ANOVA_FDR_BH <- NA_real_
results$Paired_ANOVA_FDR_BH[testable_index] <- stats::p.adjust(
  results$Paired_ANOVA_raw_P[testable_index], method = "BH"
)
results$Paired_ANOVA_significance <- significance_symbol(results$Paired_ANOVA_FDR_BH)
results$Paired_ANOVA_FDR_lt_0.05 <-
  !is.na(results$Paired_ANOVA_FDR_BH) & results$Paired_ANOVA_FDR_BH < 0.05

wilcoxon_index <- which(results$Testable & is.finite(results$Paired_Wilcoxon_raw_P))
results$Paired_Wilcoxon_FDR_BH <- NA_real_
results$Paired_Wilcoxon_FDR_BH[wilcoxon_index] <- stats::p.adjust(
  results$Paired_Wilcoxon_raw_P[wilcoxon_index], method = "BH"
)
results$Paired_Wilcoxon_FDR_lt_0.05 <-
  !is.na(results$Paired_Wilcoxon_FDR_BH) & results$Paired_Wilcoxon_FDR_BH < 0.05

results$Direction_concordant_ANOVA_Wilcoxon <- ifelse(
  results$Paired_ANOVA_FDR_lt_0.05 & results$Paired_Wilcoxon_FDR_lt_0.05,
  TRUE, FALSE
)

results <- results[order(
  !results$Testable,
  results$Paired_ANOVA_FDR_BH,
  results$Paired_ANOVA_raw_P,
  -abs(results$Mean_paired_difference_EAO_minus_PM),
  na.last = TRUE
), , drop = FALSE]
rownames(results) <- NULL

significant_results <- results[
  results$Paired_ANOVA_FDR_lt_0.05, , drop = FALSE
]
higher_eao <- significant_results[
  significant_results$Direction == "Higher in EAO", , drop = FALSE
]
higher_pm <- significant_results[
  significant_results$Direction == "Higher in PM", , drop = FALSE
]

summary_table <- data.frame(
  Metric = c(
    "Fatty acids measured", "Fatty acids testable", "All-zero/not-testable",
    "ANOVA raw P < 0.05", "ANOVA BH-FDR < 0.05",
    "ANOVA BH-FDR < 0.05: higher in EAO",
    "ANOVA BH-FDR < 0.05: higher in PM",
    "Paired Wilcoxon raw P < 0.05", "Paired Wilcoxon BH-FDR < 0.05",
    "Significant by both ANOVA-FDR and Wilcoxon-FDR"
  ),
  Value = c(
    nrow(results), length(testable_index), sum(!results$Testable),
    sum(results$Paired_ANOVA_raw_P < 0.05, na.rm = TRUE),
    nrow(significant_results), nrow(higher_eao), nrow(higher_pm),
    sum(results$Paired_Wilcoxon_raw_P < 0.05, na.rm = TRUE),
    sum(results$Paired_Wilcoxon_FDR_lt_0.05, na.rm = TRUE),
    sum(results$Direction_concordant_ANOVA_Wilcoxon, na.rm = TRUE)
  ),
  stringsAsFactors = FALSE
)

qa_table <- data.frame(
  Item = c(
    "Input", "Input sheet", "Comparison", "Design", "Primary model",
    "Primary test", "Primary scale", "Pairs", "Multiple testing",
    "FDR family", "Primary significance threshold", "Sensitivity analysis",
    "Handling all-zero fatty acids", "Ordinary independent ANOVA used"
  ),
  Value = c(
    input_file, input_sheet, "EAO vs PM", "paired within Animal",
    "Absolute_content_ug_mg ~ Animal + Site",
    "Site F test from randomized-block/repeated-measures ANOVA",
    "raw absolute content (ug/mg); no normalization or transformation", 6,
    "Benjamini-Hochberg", paste0(length(testable_index), " testable fatty acids"),
    "Paired_ANOVA_FDR_BH < 0.05",
    "two-sided paired Wilcoxon with separate BH correction",
    "retained in All_results but excluded from testing", "No"
  ),
  stringsAsFactors = FALSE
)

write_tsv(
  results,
  "Fig3_EAO_PM_targeted_fatty_acids_paired_ANOVA_FDR_all_results.tsv"
)
write_tsv(
  significant_results,
  "Fig3_EAO_PM_targeted_fatty_acids_paired_ANOVA_FDR_significant.tsv"
)
write_tsv(
  summary_table,
  "Fig3_EAO_PM_targeted_fatty_acids_paired_ANOVA_FDR_summary.tsv"
)

write.xlsx(
  list(
    Summary = summary_table,
    ANOVA_FDR_significant = significant_results,
    Higher_in_EAO = higher_eao,
    Higher_in_PM = higher_pm,
    All_results = results,
    Long_absolute_data = long_data_all,
    QA = qa_table
  ),
  file.path(
    table_dir,
    "Fig3_EAO_PM_targeted_fatty_acids_paired_ANOVA_FDR_results.xlsx"
  ),
  overwrite = TRUE,
  asTable = TRUE
)

cat("Paired targeted fatty-acid differential analysis completed.\n")
print(summary_table, row.names = FALSE)
cat("\nANOVA BH-FDR < 0.05 results:\n")
print(
  significant_results[, c(
    "Metabolite", "Mean_EAO", "Mean_PM",
    "Mean_paired_difference_EAO_minus_PM", "Direction",
    "Paired_ANOVA_raw_P", "Paired_ANOVA_FDR_BH",
    "Paired_Wilcoxon_raw_P", "Paired_Wilcoxon_FDR_BH"
  )],
  row.names = FALSE
)
