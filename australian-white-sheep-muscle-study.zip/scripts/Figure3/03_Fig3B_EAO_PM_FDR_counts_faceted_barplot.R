#!/usr/bin/env Rscript

# Companion panel for Figure 3B: numbers of EAO- and PM-enriched RNA genes
# and proteins at BH-adjusted P (FDR) < 0.05.

suppressPackageStartupMessages({
  library(ggplot2)
  library(openxlsx)
})

project_dir <- "__PROJECT_ROOT__"
work_dir <- file.path(
  project_dir, "09_Figure3_EAO_PM_IMF_tenderness_decoupling"
)
table_dir <- file.path(work_dir, "Tables")
figure_dir <- file.path(work_dir, "Figures")
input_file <- file.path(
  table_dir, "Fig3B_EAO_PM_combined_volcano_counts.tsv"
)
output_stub <- file.path(
  figure_dir, "Fig3B_EAO_PM_FDR_counts_faceted_barplot"
)
output_tsv <- file.path(
  table_dir, "Fig3B_EAO_PM_FDR_counts_faceted_barplot.tsv"
)
output_xlsx <- file.path(
  table_dir, "Fig3B_EAO_PM_FDR_counts_faceted_barplot.xlsx"
)

if (!file.exists(input_file)) {
  stop(
    "Input file not found: ", input_file,
    "\nRun 02_Fig3B_EAO_PM_combined_RNA_protein_volcano.R first."
  )
}

d <- read.delim(input_file, check.names = FALSE)
required <- c(
  "Omics", "Tested_features", "FDR_lt_0.05_total",
  "FDR_lt_0.05_EAO", "FDR_lt_0.05_PM"
)
missing_columns <- setdiff(required, names(d))
if (length(missing_columns)) {
  stop("Missing columns: ", paste(missing_columns, collapse = ", "))
}

count_df <- rbind(
  data.frame(
    Omics = d$Omics,
    Enriched_site = "EAO",
    Count = d$FDR_lt_0.05_EAO,
    Tested_features = d$Tested_features,
    FDR_threshold = "FDR < 0.05"
  ),
  data.frame(
    Omics = d$Omics,
    Enriched_site = "PM",
    Count = d$FDR_lt_0.05_PM,
    Tested_features = d$Tested_features,
    FDR_threshold = "FDR < 0.05"
  )
)

omics_order <- c("Transcriptome", "Proteome")
site_order <- c("EAO", "PM")
count_df$Omics <- factor(count_df$Omics, levels = omics_order)
count_df$Enriched_site <- factor(
  count_df$Enriched_site, levels = site_order
)
count_df <- count_df[
  order(count_df$Omics, count_df$Enriched_site), , drop = FALSE
]

expected_counts <- c(
  "Transcriptome.EAO" = 2402L,
  "Transcriptome.PM" = 1758L,
  "Proteome.EAO" = 271L,
  "Proteome.PM" = 304L
)
observed_counts <- setNames(
  count_df$Count,
  paste(count_df$Omics, count_df$Enriched_site, sep = ".")
)
if (!identical(
  as.integer(observed_counts[names(expected_counts)]),
  as.integer(expected_counts)
)) {
  stop("FDR count QA failed.")
}

write.table(
  count_df, output_tsv, sep = "\t", quote = FALSE, row.names = FALSE
)
methods_qa <- data.frame(
  Item = c(
    "Contrast", "Threshold", "Direction", "Facet scales", "Font",
    "Figure dimensions", "EAO color", "PM color", "Source"
  ),
  Value = c(
    "PM_vs_EAO, paired by Animal in the source differential models",
    "BH-adjusted P < 0.05; no fold-change cutoff",
    "Positive log2FC = PM; negative log2FC = EAO",
    "Common y-axis across transcriptome and proteome facets",
    "Arial", "4.20 x 2.75 inches", "#A65D68", "#C28B48", input_file
  ),
  stringsAsFactors = FALSE
)
write.xlsx(
  list(FDR_counts = count_df, Methods_and_QA = methods_qa),
  file = output_xlsx, overwrite = TRUE, asTable = TRUE
)

site_colors <- c(EAO = "#A65D68", PM = "#C28B48")
facet_labels <- c(
  Transcriptome = "Transcriptome (genes)",
  Proteome = "Proteome (proteins)"
)

p <- ggplot(
  count_df,
  aes(x = Enriched_site, y = Count, fill = Enriched_site)
) +
  geom_col(
    width = 0.62, color = "#303337", linewidth = 0.38,
    show.legend = FALSE
  ) +
  geom_text(
    aes(label = scales::comma(Count), color = Enriched_site),
    vjust = -0.45, size = 3.25, fontface = "bold", show.legend = FALSE
  ) +
  facet_wrap(
    ~Omics, nrow = 1, scales = "fixed",
    labeller = as_labeller(facet_labels)
  ) +
  scale_fill_manual(values = site_colors) +
  scale_color_manual(values = site_colors) +
  scale_y_continuous(
    limits = c(0, max(count_df$Count) * 1.15),
    expand = expansion(mult = c(0, 0)),
    breaks = scales::pretty_breaks(n = 5),
    labels = scales::comma
  ) +
  labs(x = NULL, y = "Number of FDR-significant features") +
  theme_bw(base_size = 10.5, base_family = "Arial") +
  theme(
    plot.background = element_rect(fill = "white", color = NA),
    panel.background = element_rect(fill = "white", color = NA),
    panel.grid.major.x = element_blank(),
    panel.grid.minor = element_blank(),
    panel.grid.major.y = element_line(color = "#E6E8EA", linewidth = 0.30),
    panel.border = element_rect(color = "#303337", linewidth = 0.45),
    strip.background = element_rect(
      fill = "#F1F1F1", color = "#B8BABD", linewidth = 0.36
    ),
    strip.text = element_text(face = "bold", size = 9.4, color = "#25282C"),
    axis.title.y = element_text(size = 9.7, color = "#25282C"),
    axis.text.x = element_text(size = 9.0, color = "#25282C"),
    axis.text.y = element_text(size = 8.5, color = "#25282C"),
    axis.ticks = element_line(color = "#303337", linewidth = 0.34),
    axis.ticks.length = unit(1.3, "mm"),
    panel.spacing.x = unit(4.5, "mm"),
    plot.margin = margin(4.0, 4.5, 4.0, 4.5)
  )

plot_width <- 4.20
plot_height <- 2.75

ggsave(
  paste0(output_stub, ".pdf"), p, device = cairo_pdf,
  width = plot_width, height = plot_height, units = "in", family = "Arial"
)
ggsave(
  paste0(output_stub, ".png"), p, device = "png",
  width = plot_width, height = plot_height, units = "in",
  dpi = 600, bg = "white"
)
svg(
  paste0(output_stub, ".svg"), width = plot_width, height = plot_height,
  family = "Arial", bg = "white", onefile = TRUE
)
print(p)
dev.off()

message("FDR-count bar plot written to: ", figure_dir)
message("FDR-count tables written to: ", table_dir)
