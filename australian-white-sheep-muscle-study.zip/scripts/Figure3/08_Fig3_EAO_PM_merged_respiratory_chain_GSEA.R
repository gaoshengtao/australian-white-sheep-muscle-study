rm(list = ls())

suppressPackageStartupMessages({
  library(BiocParallel)
  library(clusterProfiler)
  library(enrichplot)
  library(ggplot2)
})

BiocParallel::register(BiocParallel::SerialParam())

options(stringsAsFactors = FALSE)
set.seed(20260903)

work_dir <- "__PROJECT_ROOT__/09_Figure3_EAO_PM_IMF_tenderness_decoupling"
table_dir <- file.path(work_dir, "Tables")
figure_dir <- file.path(
  work_dir, "Figures", "Fig3_EAO_PM_lipid_KEGG_GSEA", "MERGED"
)
dir.create(figure_dir, recursive = TRUE, showWarnings = FALSE)

rank_file <- file.path(
  table_dir, "Fig3_EAO_PM_GSEA_integrated_RNA_protein_gene_ranking.tsv.gz"
)
membership_file <- file.path(
  table_dir,
  "Fig3_EAO_PM_GSEA_selected_KEGG_MODULE_human_Entrez_membership.tsv"
)
module_result_file <- file.path(
  table_dir, "Fig3_EAO_PM_integrated_RNA_protein_KEGG_MODULE_GSEA_results.tsv"
)

stopifnot(
  file.exists(rank_file),
  file.exists(membership_file),
  file.exists(module_result_file)
)

rank_table <- read.delim(gzfile(rank_file), check.names = FALSE)
module_membership <- read.delim(membership_file, check.names = FALSE)
module_results <- read.delim(module_result_file, check.names = FALSE)

gene_list <- rank_table$Integrated_log2FC_PM_vs_EAO
names(gene_list) <- as.character(rank_table$Human_Entrez_ID)
gene_list <- gene_list[is.finite(gene_list) & nzchar(names(gene_list))]
gene_list <- sort(gene_list, decreasing = TRUE)

# Positive rank = higher in PM; negative rank = higher in EAO.
respiratory_modules <- c(
  "M00143", # Complex I core
  "M00146", # Complex I alpha subcomplex
  "M00147", # Complex I beta subcomplex
  "M00148", # Complex II
  "M00151", # Complex III
  "M00154", # Complex IV
  "M00158"  # Complex V / ATP synthase
)

missing_modules <- setdiff(respiratory_modules, unique(module_membership$Set_ID))
if (length(missing_modules)) {
  stop("Missing respiratory-chain modules: ", paste(missing_modules, collapse = ", "))
}

custom_set_id <- "MERGED_RESPIRATORY_CHAIN_I_V"
custom_set_name <- "Respiratory chain complexes I-V"

respiratory_union <- unique(module_membership$Human_Entrez_ID[
  module_membership$Set_ID %in% respiratory_modules
])
respiratory_union <- as.character(respiratory_union)

# Include the original 21 KEGG modules in the same GSEA run so the displayed
# FDR is adjusted across the complete module panel plus this merged set. The
# existing result workbook is deliberately not modified.
term2gene <- unique(data.frame(
  term = c(
    as.character(module_membership$Set_ID),
    rep(custom_set_id, length(respiratory_union))
  ),
  gene = c(
    as.character(module_membership$Human_Entrez_ID),
    respiratory_union
  ),
  stringsAsFactors = FALSE
))

module_names <- unique(module_results[, c("Set_ID", "Official_name")])
term2name <- rbind(
  data.frame(
    term = as.character(module_names$Set_ID),
    name = as.character(module_names$Official_name),
    stringsAsFactors = FALSE
  ),
  data.frame(
    term = custom_set_id,
    name = custom_set_name,
    stringsAsFactors = FALSE
  )
)

gsea_result <- clusterProfiler::GSEA(
  geneList = gene_list,
  exponent = 1,
  minGSSize = 2,
  maxGSSize = 1000,
  eps = 0,
  pvalueCutoff = 1,
  pAdjustMethod = "BH",
  verbose = FALSE,
  seed = TRUE,
  by = "fgsea",
  nPermSimple = 10000,
  TERM2GENE = term2gene,
  TERM2NAME = term2name
)

result_table <- as.data.frame(gsea_result)
custom_result <- result_table[result_table$ID == custom_set_id, , drop = FALSE]
if (nrow(custom_result) != 1L || !is.finite(custom_result$NES)) {
  stop("Merged respiratory-chain gene set was not testable by GSEA.")
}

enriched_site <- ifelse(custom_result$NES > 0, "PM", "EAO")
site_colors <- c(EAO = "#A65D68", PM = "#C28B48")
plot_title <- sprintf(
  "%s\nNES = %.2f; FDR = %.3g; enriched in %s",
  custom_set_name,
  custom_result$NES,
  custom_result$p.adjust,
  enriched_site
)

plot_object <- enrichplot::gseaplot2(
  gsea_result,
  geneSetID = custom_set_id,
  title = plot_title,
  color = unname(site_colors[enriched_site]),
  base_size = 10.5,
  rel_heights = c(1.5, 0.5, 1),
  subplots = 1:3,
  pvalue_table = FALSE,
  ES_geom = "line"
)

# enrichplot 1.26 returns an aplot gglist. Theme each component while
# preserving that class; applying patchwork's `&` would return NULL.
plot_object[] <- lapply(plot_object, function(component_plot) {
  component_plot +
    theme(
      text = element_text(family = "Arial", color = "#25282C"),
      plot.title = element_text(
        family = "Arial", face = "bold", size = 10,
        hjust = 0, margin = margin(b = 3)
      ),
      panel.grid.minor = element_blank()
    )
})
plot_object[[length(plot_object)]] <- plot_object[[length(plot_object)]] +
  labs(x = "Rank in ordered genes (PM-high to EAO-high)")

file_stub <- file.path(
  figure_dir, "Fig3_EAO_PM_merged_respiratory_chain_complexes_I_V_GSEA"
)
plot_width <- 6.6
plot_height <- 5.0

ggsave(
  paste0(file_stub, ".pdf"), plot_object,
  device = cairo_pdf, width = plot_width, height = plot_height,
  units = "in", family = "Arial"
)
ggsave(
  paste0(file_stub, ".png"), plot_object,
  device = "png", width = plot_width, height = plot_height,
  units = "in", dpi = 600, bg = "white"
)
svg(
  paste0(file_stub, ".svg"),
  width = plot_width, height = plot_height,
  family = "Arial", bg = "white", onefile = TRUE
)
print(plot_object)
dev.off()

cat("Merged respiratory-chain GSEA completed.\n")
cat("Modules:", paste(respiratory_modules, collapse = ", "), "\n")
cat("Unique human genes:", length(respiratory_union), "\n")
cat("Genes present in ranking:", custom_result$setSize, "\n")
cat("NES:", custom_result$NES, "\n")
cat("P value:", custom_result$pvalue, "\n")
cat("FDR across 21 original modules plus merged set:", custom_result$p.adjust, "\n")
cat("Enriched site:", enriched_site, "\n")
cat("Figure stub:", file_stub, "\n")
