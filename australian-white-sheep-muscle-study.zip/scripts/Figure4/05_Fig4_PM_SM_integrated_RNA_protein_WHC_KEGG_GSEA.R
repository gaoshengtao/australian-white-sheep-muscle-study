#!/usr/bin/env Rscript

# Figure 4: integrated RNA-protein preranked GSEA for molecular programs
# plausibly related to meat water-holding capacity (WHC).
#
# Ranking follows Figure 3D-E exactly:
#   1) all PM-SM RNA and protein results, without significance prefiltering;
#   2) map gene symbols to human Entrez IDs;
#   3) average same-direction duplicate log2FC values;
#   4) for direction conflicts, retain the observation with the smallest raw P;
#   5) positive rank = SM enriched; negative rank = PM enriched.
#
# Official KEGG PATHWAY and MODULE memberships are downloaded from KEGG REST.
# PATHWAY and MODULE collections are tested separately with BH correction.

rm(list = ls())
suppressPackageStartupMessages({
  library(AnnotationDbi)
  library(clusterProfiler)
  library(enrichplot)
  library(ggplot2)
  library(KEGGREST)
  library(openxlsx)
  library(org.Hs.eg.db)
})

options(stringsAsFactors = FALSE, timeout = 900)
set.seed(20260907)

project_dir <- "__PROJECT_ROOT__"
work_dir <- file.path(project_dir, "10_Figure4_PM_SM_water_holding_capacity")
source_dir <- file.path(project_dir, "07_Figure2_muscle_functional_states",
                        "03_One_vs_rest_specificity", "Tables")
table_dir <- file.path(work_dir, "Tables")
figure_root <- file.path(work_dir, "Figures",
                         "Fig4_PM_SM_WHC_KEGG_GSEA")
dir.create(table_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(figure_root, recursive = TRUE, showWarnings = FALSE)

rna_file <- file.path(source_dir,
  "Fig2_muscle_fiber_pairwise_transcriptome_DESeq2_all_gene_results.tsv.gz")
protein_file <- file.path(source_dir,
  "Fig2_muscle_fiber_pairwise_proteome_limma_all_gene_results.tsv.gz")
for (f in c(rna_file, protein_file)) if (!file.exists(f)) stop("Missing: ", f)

site_colors <- c(PM = "#C28B48", SM = "#5B837B")
omics_order <- c("Transcriptome", "Proteome")

write_tsv <- function(x, name) write.table(
  x, file.path(table_dir, name), sep = "\t", quote = FALSE,
  row.names = FALSE, na = "NA"
)
write_gz_tsv <- function(x, name) {
  con <- gzfile(file.path(table_dir, name), "wt")
  on.exit(close(con), add = TRUE)
  write.table(x, con, sep = "\t", quote = FALSE, row.names = FALSE, na = "NA")
}
clean_text <- function(x) {
  x <- trimws(as.character(x)); x[is.na(x)] <- ""; x
}
safe_filename <- function(x, n = 110L) {
  x <- gsub("[^A-Za-z0-9._-]+", "_", x)
  x <- gsub("_+", "_", x)
  substr(gsub("^_|_$", "", x), 1L, n)
}
bind_nonempty <- function(x) {
  x <- x[vapply(x, nrow, integer(1)) > 0L]
  if (!length(x)) return(data.frame())
  y <- do.call(rbind, x); rownames(y) <- NULL; y
}

# Prespecified WHC-related gene sets ----------------------------------------
pathway_manifest <- data.frame(
  Set_type = "PATHWAY",
  Set_ID = c(
    "hsa00010", "hsa00500", "hsa00620", "hsa04066", "hsa04152",
    "hsa00020", "hsa00190", "hsa04714",
    "hsa04020", "hsa04260", "hsa04820",
    "hsa04810", "hsa04510", "hsa04512",
    "hsa03050", "hsa04120", "hsa04142", "hsa04140",
    "hsa00564", "hsa00600", "hsa00480", "hsa00030", "hsa04146",
    "hsa00430"
  ),
  WHC_axis = c(
    rep("Glycolysis / postmortem acidification", 5),
    rep("Mitochondrial oxidative metabolism", 3),
    rep("Calcium handling / contraction", 3),
    rep("Cytoskeleton / cell-matrix structure", 3),
    rep("Proteolysis / proteostasis", 4),
    rep("Membrane / redox / osmotic homeostasis", 6)
  ),
  Evidence_role = c(
    "Glycolytic flux", "Glycogen turnover", "Pyruvate/lactate context",
    "Hypoxia-linked glycolytic regulation", "Energy sensing",
    "Oxidative carbon metabolism", "Respiratory ATP production",
    "Mitochondrial respiratory program",
    "Calcium signaling", "Contraction machinery",
    "Muscle structural organization",
    "Actin remodeling", "Cell-matrix force transmission",
    "Extracellular matrix interaction",
    "Proteasome", "Ubiquitin-dependent proteolysis", "Lysosomal proteolysis",
    "Autophagy",
    "Membrane phospholipid remodeling", "Sphingolipid membrane signaling",
    "Glutathione redox buffering", "NADPH/redox support", "Peroxisomal redox",
    "Osmolyte-related metabolism"
  ),
  Interpretation_boundary = c(
    rep("Relevant to WHC through postmortem pH kinetics; steady-state omics do not measure flux", 5),
    rep("Oxidative muscle-state evidence; not a direct postmortem respiration measurement", 3),
    rep("Direction requires leading-edge inspection; expression is not calcium flux", 3),
    rep("Structural potential only; no histology or shrinkage measurement", 3),
    rep("Proteolytic potential only; no enzyme-activity measurement", 4),
    rep("Indirect WHC support; no direct membrane-damage or osmolarity measurement", 6)
  ),
  stringsAsFactors = FALSE
)

module_manifest <- data.frame(
  Set_type = "MODULE",
  Set_ID = c(
    "M00854", "M00855", "M00001", "M00002", "M00003", "M00307",
    "M00004", "M00006", "M00009", "M00010", "M00011",
    "M00143", "M00146", "M00147", "M00148", "M00151", "M00154",
    "M00158"
  ),
  WHC_axis = c(
    "Glycogen turnover", "Glycogen turnover",
    rep("Glycolysis / postmortem acidification", 4),
    rep("Redox support", 2),
    rep("TCA cycle", 3),
    rep("Respiratory chain / ATP synthesis", 7)
  ),
  Evidence_role = c(
    "Glycogen biosynthesis", "Glycogen degradation", "Complete glycolysis",
    "Core three-carbon glycolysis", "Gluconeogenesis",
    "Pyruvate to acetyl-CoA", "Pentose phosphate pathway",
    "Oxidative pentose phosphate phase", "Complete TCA cycle",
    "First TCA oxidation segment", "Second TCA oxidation segment",
    "Respiratory complex I core", "Complex I alpha subcomplex",
    "Complex I beta subcomplex", "Respiratory complex II",
    "Respiratory complex III", "Respiratory complex IV", "ATP synthase"
  ),
  Interpretation_boundary = c(
    rep("Metabolic capacity, not postmortem pathway flux", 11),
    rep("Respiratory machinery abundance, not direct ATP-production rate", 7)
  ),
  stringsAsFactors = FALSE
)

# Integrated full-gene RNA-protein ranking ---------------------------------
rna <- read.delim(gzfile(rna_file), check.names = FALSE,
                  quote = "", comment.char = "")
protein <- read.delim(gzfile(protein_file), check.names = FALSE,
                      quote = "", comment.char = "")
rna <- rna[rna$Comparison == "SM_vs_PM", ]
protein <- protein[protein$Comparison == "SM_vs_PM", ]

make_source <- function(d, omics) data.frame(
  Omics = omics,
  Source_feature_ID = if (omics == "Transcriptome" && "gene_id" %in% names(d)) {
    as.character(d$gene_id)
  } else if (omics == "Proteome" && "Protein_row" %in% names(d)) {
    as.character(d$Protein_row)
  } else as.character(seq_len(nrow(d))),
  Input_Gene_symbol = clean_text(d$Gene_symbol),
  log2FC_SM_vs_PM = as.numeric(d$log2FoldChange),
  Raw_P = as.numeric(d$P_value),
  Source_FDR = as.numeric(d$P_FDR_BH),
  stringsAsFactors = FALSE
)
source_all <- rbind(make_source(rna, "Transcriptome"),
                    make_source(protein, "Proteome"))
source_all <- source_all[nzchar(source_all$Input_Gene_symbol) &
  is.finite(source_all$log2FC_SM_vs_PM) & is.finite(source_all$Raw_P), ]

symbol_map <- AnnotationDbi::select(
  org.Hs.eg.db, keys = sort(unique(source_all$Input_Gene_symbol)),
  keytype = "SYMBOL", columns = c("SYMBOL", "ENTREZID")
)
symbol_map <- unique(symbol_map[!is.na(symbol_map$ENTREZID),
                                c("SYMBOL", "ENTREZID")])
names(symbol_map) <- c("Human_Gene_symbol", "Human_Entrez_ID")
mult <- table(symbol_map$Human_Gene_symbol)
symbol_map <- symbol_map[!symbol_map$Human_Gene_symbol %in%
                           names(mult[mult > 1]), ]
mapped <- merge(source_all, symbol_map,
  by.x = "Input_Gene_symbol", by.y = "Human_Gene_symbol", sort = FALSE)
mapped$Direction <- ifelse(mapped$log2FC_SM_vs_PM > 0, "SM",
                           ifelse(mapped$log2FC_SM_vs_PM < 0, "PM", "Zero"))

resolve_group <- function(z, level) {
  dirs <- unique(z$Direction[z$Direction != "Zero"])
  conflict <- length(dirs) > 1L
  z <- z[order(z$Raw_P, -abs(z$log2FC_SM_vs_PM), z$Omics), ]
  chosen <- z[1, ]
  resolved <- if (conflict) chosen$log2FC_SM_vs_PM else mean(z$log2FC_SM_vs_PM)
  data.frame(
    Human_Entrez_ID = chosen$Human_Entrez_ID,
    Human_Gene_symbol = chosen$Input_Gene_symbol,
    Integrated_log2FC_SM_vs_PM = resolved,
    Minimum_raw_P = min(z$Raw_P),
    Direction_conflict = conflict,
    Resolution_rule = if (conflict) "direction conflict: smallest raw P"
      else if (nrow(z) > 1) "same direction: mean log2FC"
      else "single observation",
    Resolution_level = level,
    Observation_count = nrow(z),
    Omics_membership = paste(omics_order[omics_order %in% unique(z$Omics)],
                             collapse = ";"),
    RNA_log2FC = if (any(z$Omics == "Transcriptome"))
      mean(z$log2FC_SM_vs_PM[z$Omics == "Transcriptome"]) else NA_real_,
    Protein_log2FC = if (any(z$Omics == "Proteome"))
      mean(z$log2FC_SM_vs_PM[z$Omics == "Proteome"]) else NA_real_,
    Selected_sources = paste(paste(z$Omics, z$Source_feature_ID, sep = ":"),
                             collapse = ";"),
    stringsAsFactors = FALSE
  )
}

within_keys <- interaction(mapped$Omics, mapped$Human_Entrez_ID,
                           drop = TRUE, lex.order = TRUE)
within <- bind_nonempty(lapply(split(mapped, within_keys), resolve_group,
                               level = "within omics"))
within_for_integration <- data.frame(
  Omics = sub(";.*$", "", within$Omics_membership),
  Source_feature_ID = within$Selected_sources,
  Input_Gene_symbol = within$Human_Gene_symbol,
  Human_Entrez_ID = within$Human_Entrez_ID,
  log2FC_SM_vs_PM = within$Integrated_log2FC_SM_vs_PM,
  Raw_P = within$Minimum_raw_P,
  Direction = ifelse(within$Integrated_log2FC_SM_vs_PM > 0, "SM",
                     ifelse(within$Integrated_log2FC_SM_vs_PM < 0, "PM", "Zero")),
  stringsAsFactors = FALSE
)
integrated <- bind_nonempty(lapply(
  split(within_for_integration, within_for_integration$Human_Entrez_ID),
  resolve_group, level = "between omics"
))
integrated <- integrated[is.finite(integrated$Integrated_log2FC_SM_vs_PM), ]
integrated <- integrated[order(-integrated$Integrated_log2FC_SM_vs_PM,
                               integrated$Minimum_raw_P,
                               integrated$Human_Entrez_ID), ]
if (anyDuplicated(integrated$Human_Entrez_ID)) stop("Non-unique ranking.")
gene_list <- integrated$Integrated_log2FC_SM_vs_PM
names(gene_list) <- integrated$Human_Entrez_ID
gene_list <- sort(gene_list, decreasing = TRUE)
if (length(gene_list) < 5000) stop("Too few ranked genes.")

write_gz_tsv(source_all,
  "Fig4_PM_SM_WHC_GSEA_all_source_RNA_protein_features.tsv.gz")
write_gz_tsv(mapped,
  "Fig4_PM_SM_WHC_GSEA_symbol_to_human_Entrez_mapped_features.tsv.gz")
write_gz_tsv(integrated,
  "Fig4_PM_SM_WHC_GSEA_integrated_RNA_protein_gene_ranking.tsv.gz")

# Official KEGG memberships -------------------------------------------------
download_time <- format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")
pathway_names_raw <- KEGGREST::keggList("pathway", "hsa")
Sys.sleep(0.4)
pathway_links_raw <- KEGGREST::keggLink("hsa", "pathway")
Sys.sleep(0.4)
module_names_raw <- KEGGREST::keggList("module")
Sys.sleep(0.4)
module_to_ko_raw <- KEGGREST::keggLink("ko", "module")
Sys.sleep(0.4)
ko_to_human_raw <- KEGGREST::keggLink("hsa", "ko")

pathway_names <- data.frame(
  Set_ID = sub("^path:", "", names(pathway_names_raw)),
  Official_name = sub(" - Homo sapiens \\(human\\)$", "",
                      unname(pathway_names_raw)))
path_members <- unique(data.frame(
  Set_ID = sub("^path:", "", names(pathway_links_raw)),
  Human_Entrez_ID = sub("^hsa:", "", unname(pathway_links_raw))))
module_names <- data.frame(
  Set_ID = sub("^md:", "", names(module_names_raw)),
  Official_name = unname(module_names_raw))
module_to_ko <- data.frame(
  Set_ID = sub("^md:", "", names(module_to_ko_raw)),
  KO = sub("^ko:", "", unname(module_to_ko_raw)))
ko_to_human <- data.frame(
  KO = sub("^ko:", "", names(ko_to_human_raw)),
  Human_Entrez_ID = sub("^hsa:", "", unname(ko_to_human_raw)))
module_members <- unique(merge(module_to_ko, ko_to_human, by = "KO",
                               sort = FALSE)[, c("Set_ID", "Human_Entrez_ID")])

pathway_manifest <- merge(pathway_manifest, pathway_names,
                          by = "Set_ID", all.x = TRUE, sort = FALSE)
module_manifest <- merge(module_manifest, module_names,
                         by = "Set_ID", all.x = TRUE, sort = FALSE)
if (anyNA(pathway_manifest$Official_name) || anyNA(module_manifest$Official_name)) {
  stop("A prespecified KEGG set was not found.")
}
path_members <- path_members[path_members$Set_ID %in% pathway_manifest$Set_ID, ]
module_members <- module_members[module_members$Set_ID %in% module_manifest$Set_ID, ]

add_counts <- function(manifest, membership) {
  manifest$Official_human_gene_count <- vapply(manifest$Set_ID, function(id)
    length(unique(membership$Human_Entrez_ID[membership$Set_ID == id])), integer(1))
  manifest$Ranked_gene_overlap_count <- vapply(manifest$Set_ID, function(id)
    length(intersect(membership$Human_Entrez_ID[membership$Set_ID == id],
                     names(gene_list))), integer(1))
  manifest
}
pathway_manifest <- add_counts(pathway_manifest, path_members)
module_manifest <- add_counts(module_manifest, module_members)
write_tsv(path_members,
  "Fig4_PM_SM_WHC_GSEA_selected_KEGG_PATHWAY_membership.tsv")
write_tsv(module_members,
  "Fig4_PM_SM_WHC_GSEA_selected_KEGG_MODULE_membership.tsv")

# GSEA ----------------------------------------------------------------------
run_gsea <- function(membership, manifest, min_size) {
  GSEA(geneList = gene_list, exponent = 1, minGSSize = min_size,
       maxGSSize = 1000, eps = 0, pvalueCutoff = 1,
       pAdjustMethod = "BH", verbose = FALSE, seed = TRUE, by = "fgsea",
       nPermSimple = 10000,
       TERM2GENE = unique(data.frame(term = membership$Set_ID,
                                     gene = membership$Human_Entrez_ID)),
       TERM2NAME = unique(data.frame(term = manifest$Set_ID,
                                     name = manifest$Official_name)))
}
gsea_pathway <- run_gsea(path_members, pathway_manifest, 10L)
gsea_module <- run_gsea(module_members, module_manifest, 2L)
saveRDS(gsea_pathway, file.path(table_dir,
  "Fig4_PM_SM_WHC_integrated_RNA_protein_KEGG_PATHWAY_GSEA.rds"))
saveRDS(gsea_module, file.path(table_dir,
  "Fig4_PM_SM_WHC_integrated_RNA_protein_KEGG_MODULE_GSEA.rds"))

decorate <- function(obj, manifest) {
  z <- as.data.frame(obj)
  names(z)[names(z) == "ID"] <- "Set_ID"
  names(z)[names(z) == "Description"] <- "GSEA_Description"
  z <- merge(manifest, z, by = "Set_ID", all.x = TRUE, sort = FALSE)
  z <- z[match(manifest$Set_ID, z$Set_ID), ]
  z$Tested_by_GSEA <- !is.na(z$NES)
  z$Observed_enriched_site <- ifelse(z$NES > 0, "SM",
                                     ifelse(z$NES < 0, "PM", NA))
  z$Nominal_P_lt_0.05 <- !is.na(z$pvalue) & z$pvalue < 0.05
  z$FDR_lt_0.05 <- !is.na(z$p.adjust) & z$p.adjust < 0.05
  z$Core_enrichment_symbols <- vapply(z$core_enrichment, function(x) {
    if (is.na(x) || !nzchar(x)) return(NA_character_)
    ids <- strsplit(x, "/", fixed = TRUE)[[1]]
    syms <- integrated$Human_Gene_symbol[match(ids, integrated$Human_Entrez_ID)]
    syms[is.na(syms) | !nzchar(syms)] <- ids[is.na(syms) | !nzchar(syms)]
    paste(syms, collapse = "/")
  }, character(1))
  z
}
pathway_results <- decorate(gsea_pathway, pathway_manifest)
module_results <- decorate(gsea_module, module_manifest)

# Classic plot for every testable pathway/module ---------------------------
export_one <- function(obj, row, type) {
  site <- row$Observed_enriched_site
  out_dir <- file.path(figure_root, type, safe_filename(row$WHC_axis))
  dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)
  title <- sprintf("%s | %s\nNES = %.2f; FDR = %.3g; enriched in %s",
                   row$Set_ID, row$Official_name, row$NES, row$p.adjust, site)
  gp <- gseaplot2(obj, geneSetID = row$Set_ID, title = title,
                  color = unname(site_colors[site]), base_size = 10.5,
                  rel_heights = c(1.5, 0.5, 1), subplots = 1:3,
                  pvalue_table = FALSE, ES_geom = "line")
  gp[] <- lapply(gp, function(g) g + theme(
    text = element_text(family = "Arial", color = "#25282C"),
    plot.title = element_text(family = "Arial", face = "bold", size = 10,
                              hjust = 0, margin = margin(b = 3)),
    panel.grid.minor = element_blank()))
  gp[[length(gp)]] <- gp[[length(gp)]] +
    labs(x = "Rank in ordered genes (SM-high to PM-high)")
  stub <- file.path(out_dir, safe_filename(paste(row$Set_ID,
                                                 row$Official_name, sep = "_")))
  ggsave(paste0(stub, ".pdf"), gp, device = cairo_pdf,
         width = 6.6, height = 5.0, units = "in", family = "Arial")
  ggsave(paste0(stub, ".png"), gp, width = 6.6, height = 5.0,
         units = "in", dpi = 600, bg = "white")
  data.frame(Set_type = type, Set_ID = row$Set_ID,
             Official_name = row$Official_name, WHC_axis = row$WHC_axis,
             Observed_enriched_site = site, NES = row$NES,
             P_value = row$pvalue, FDR = row$p.adjust,
             PDF = paste0(stub, ".pdf"), PNG = paste0(stub, ".png"))
}
plot_index <- list(); k <- 0L
for (i in which(pathway_results$Tested_by_GSEA)) {
  k <- k + 1L; plot_index[[k]] <- export_one(
    gsea_pathway, pathway_results[i, , drop = FALSE], "PATHWAY")
}
for (i in which(module_results$Tested_by_GSEA)) {
  k <- k + 1L; plot_index[[k]] <- export_one(
    gsea_module, module_results[i, , drop = FALSE], "MODULE")
}
plot_index <- do.call(rbind, plot_index)

# Compact all-set screening summary; classic plots remain the primary output.
summary_plot_data <- rbind(
  data.frame(Set_type = "PATHWAY", Set_ID = pathway_results$Set_ID,
    Label = pathway_results$Official_name, WHC_axis = pathway_results$WHC_axis,
    NES = pathway_results$NES, FDR = pathway_results$p.adjust,
    Site = pathway_results$Observed_enriched_site,
    Tested = pathway_results$Tested_by_GSEA),
  data.frame(Set_type = "MODULE", Set_ID = module_results$Set_ID,
    Label = module_results$Official_name, WHC_axis = module_results$WHC_axis,
    NES = module_results$NES, FDR = module_results$p.adjust,
    Site = module_results$Observed_enriched_site,
    Tested = module_results$Tested_by_GSEA)
)
summary_plot_data <- summary_plot_data[summary_plot_data$Tested, ]
summary_plot_data$Display <- paste(summary_plot_data$Set_ID,
                                   summary_plot_data$Label, sep = " | ")
summary_plot_data$Display <- factor(summary_plot_data$Display,
  levels = rev(summary_plot_data$Display[order(summary_plot_data$Set_type,
                                                summary_plot_data$WHC_axis,
                                                summary_plot_data$NES)]))
summary_plot_data$FDR_state <- ifelse(summary_plot_data$FDR < 0.05,
                                      "FDR < 0.05", "FDR >= 0.05")
p_summary <- ggplot(summary_plot_data,
  aes(NES, Display, color = Site, fill = Site, shape = FDR_state)) +
  geom_vline(xintercept = 0, color = "#8D9297", linewidth = 0.42,
             linetype = "22") +
  geom_point(size = 2.8, stroke = 0.65) +
  facet_grid(rows = vars(WHC_axis), cols = vars(Set_type),
             scales = "free_y", space = "free_y") +
  scale_color_manual(values = site_colors) +
  scale_fill_manual(values = site_colors) +
  scale_shape_manual(values = c("FDR < 0.05" = 16, "FDR >= 0.05" = 1)) +
  labs(x = "Normalized enrichment score (SM - PM)", y = NULL,
       color = "Enriched site", fill = "Enriched site", shape = NULL) +
  theme_bw(base_size = 10.5, base_family = "Arial") +
  theme(panel.grid.major.y = element_blank(), panel.grid.minor = element_blank(),
        panel.border = element_rect(color = "#303337", linewidth = 0.45),
        strip.background = element_rect(fill = "#F1F1F1", color = "#B8BABD"),
        strip.text = element_text(face = "bold"),
        axis.text.y = element_text(size = 7.2), legend.position = "top",
        plot.background = element_rect(fill = "white", color = NA))
ggsave(file.path(figure_root, "Fig4_PM_SM_WHC_KEGG_GSEA_all_set_summary.pdf"),
       p_summary, device = cairo_pdf, width = 12, height = 12,
       units = "in", family = "Arial")
ggsave(file.path(figure_root, "Fig4_PM_SM_WHC_KEGG_GSEA_all_set_summary.png"),
       p_summary, width = 12, height = 12, units = "in", dpi = 500,
       bg = "white")

# Outputs and QA ------------------------------------------------------------
summary_table <- rbind(
  data.frame(Set_type = "PATHWAY",
    Sets_prespecified = nrow(pathway_results),
    Sets_tested = sum(pathway_results$Tested_by_GSEA),
    Nominal_P_lt_0.05 = sum(pathway_results$Nominal_P_lt_0.05),
    FDR_lt_0.05 = sum(pathway_results$FDR_lt_0.05),
    Enriched_in_PM = sum(pathway_results$Observed_enriched_site == "PM", na.rm = TRUE),
    Enriched_in_SM = sum(pathway_results$Observed_enriched_site == "SM", na.rm = TRUE)),
  data.frame(Set_type = "MODULE",
    Sets_prespecified = nrow(module_results),
    Sets_tested = sum(module_results$Tested_by_GSEA),
    Nominal_P_lt_0.05 = sum(module_results$Nominal_P_lt_0.05),
    FDR_lt_0.05 = sum(module_results$FDR_lt_0.05),
    Enriched_in_PM = sum(module_results$Observed_enriched_site == "PM", na.rm = TRUE),
    Enriched_in_SM = sum(module_results$Observed_enriched_site == "SM", na.rm = TRUE))
)
qa <- data.frame(
  Item = c("Comparison", "Rank sign", "RNA input", "Protein input",
           "Integrated ranked genes", "RNA-protein overlap",
           "Direction conflicts", "Conflict rule", "Same-direction rule",
           "Pathway GSEA correction", "Module GSEA correction",
           "Pathway min size", "Module min size", "KEGG download time"),
  Value = c("SM_vs_PM", "positive=SM; negative=PM", nrow(rna), nrow(protein),
            length(gene_list),
            sum(integrated$Omics_membership == "Transcriptome;Proteome"),
            sum(integrated$Direction_conflict),
            "smallest raw P; tie by largest absolute log2FC",
            "mean log2FC", "BH across selected PATHWAY sets",
            "BH across selected MODULE sets", 10, 2, download_time)
)
write_tsv(pathway_manifest,
  "Fig4_PM_SM_WHC_GSEA_selected_KEGG_PATHWAY_manifest.tsv")
write_tsv(module_manifest,
  "Fig4_PM_SM_WHC_GSEA_selected_KEGG_MODULE_manifest.tsv")
write_tsv(pathway_results,
  "Fig4_PM_SM_WHC_integrated_RNA_protein_KEGG_PATHWAY_GSEA_results.tsv")
write_tsv(module_results,
  "Fig4_PM_SM_WHC_integrated_RNA_protein_KEGG_MODULE_GSEA_results.tsv")
write_tsv(plot_index, "Fig4_PM_SM_WHC_KEGG_GSEA_plot_index.tsv")
write_tsv(summary_table, "Fig4_PM_SM_WHC_KEGG_GSEA_summary.tsv")
write_tsv(qa, "Fig4_PM_SM_WHC_KEGG_GSEA_QA.tsv")
write.xlsx(list(Summary = summary_table, PATHWAY_GSEA = pathway_results,
                MODULE_GSEA = module_results,
                PATHWAY_manifest = pathway_manifest,
                MODULE_manifest = module_manifest,
                Plot_index = plot_index, Integrated_rank = integrated,
                Ranking_QA = qa),
  file.path(table_dir,
    "Fig4_PM_SM_integrated_RNA_protein_WHC_KEGG_GSEA_results.xlsx"),
  overwrite = TRUE, asTable = TRUE)

cat("PM-SM WHC-targeted integrated RNA-protein KEGG GSEA completed.\n")
print(summary_table)
cat("\nFDR-significant PATHWAY results:\n")
print(pathway_results[pathway_results$FDR_lt_0.05,
  c("Set_ID", "Official_name", "WHC_axis", "NES", "pvalue", "p.adjust",
    "Observed_enriched_site")])
cat("\nFDR-significant MODULE results:\n")
print(module_results[module_results$FDR_lt_0.05,
  c("Set_ID", "Official_name", "WHC_axis", "NES", "pvalue", "p.adjust",
    "Observed_enriched_site")])
