#!/usr/bin/env Rscript

# PM-SM paired differential analysis and lollipop visualization of targeted
# fatty acids. Primary test: randomized-block/repeated-measures ANOVA
# (absolute content ~ Animal + Site), equivalent to a paired t test for two
# within-animal sites. BH-FDR is applied across testable fatty acids.

rm(list = ls())

suppressPackageStartupMessages({
  library(openxlsx)
  library(ggplot2)
  library(svglite)
})

project_dir <- "__PROJECT_ROOT__"
work_dir <- file.path(project_dir, "10_Figure4_PM_SM_water_holding_capacity")
input_file <- file.path(project_dir, "02_fatty_acids", "fatty acids.xlsx")
input_sheet <- "measurement.xls"
annotation_sheet <- "其他信息"
table_dir <- file.path(work_dir, "Tables")
figure_dir <- file.path(work_dir, "Figures")
dir.create(table_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(figure_dir, recursive = TRUE, showWarnings = FALSE)

pm_samples <- paste0("PM_", 1:6)
sm_samples <- paste0("SM_", 1:6)
site_order <- c("PM", "SM")
deep_colors <- c(SFA = "#355C8A", MUFA = "#C28B48", PUFA = "#A65D68")

write_tsv <- function(x, filename) {
  write.table(
    x, file.path(table_dir, filename), sep = "\t", quote = FALSE,
    row.names = FALSE, na = "NA"
  )
}

significance_symbol <- function(q) {
  ifelse(
    is.na(q), "NA",
    ifelse(q < 0.001, "***", ifelse(q < 0.01, "**", ifelse(q < 0.05, "*", "n.s.")))
  )
}

safe_shapiro <- function(x) {
  if (length(x) < 3L || stats::sd(x) == 0) return(NA_real_)
  tryCatch(stats::shapiro.test(x)$p.value, error = function(e) NA_real_)
}

if (!file.exists(input_file)) stop("Input file not found: ", input_file)
fatty_acids <- read.xlsx(
  input_file, sheet = input_sheet, check.names = FALSE,
  detectDates = FALSE, skipEmptyRows = FALSE
)
fatty_names <- read.xlsx(
  input_file, sheet = annotation_sheet, check.names = FALSE,
  detectDates = FALSE, skipEmptyRows = FALSE
)

required_columns <- c(
  "Metabolite", "CAS.id", "Formula", "KEGG.Compound.ID", "unit",
  "Retention.time", pm_samples, sm_samples
)
missing_columns <- setdiff(required_columns, names(fatty_acids))
if (length(missing_columns)) {
  stop("Missing columns: ", paste(missing_columns, collapse = ", "))
}
if (nrow(fatty_acids) != nrow(fatty_names)) {
  stop("Measurement and annotation sheets have different row counts.")
}
if (max(abs(fatty_acids$Retention.time - fatty_names[["RT/min"]])) > 1e-10) {
  stop("Measurement and annotation sheets are not aligned by retention time.")
}
if (anyDuplicated(fatty_acids$Metabolite)) stop("Metabolite names are duplicated.")
if (anyDuplicated(fatty_names$Metabolite)) stop("Fatty-acid abbreviations are duplicated.")
if (length(unique(fatty_acids$unit)) != 1L || unique(fatty_acids$unit) != "ug/mg") {
  stop("Expected a single absolute-content unit: ug/mg.")
}

result_rows <- vector("list", nrow(fatty_acids))
long_rows <- vector("list", nrow(fatty_acids))

for (i in seq_len(nrow(fatty_acids))) {
  pm <- as.numeric(fatty_acids[i, pm_samples, drop = TRUE])
  sm <- as.numeric(fatty_acids[i, sm_samples, drop = TRUE])
  paired_difference <- sm - pm

  if (any(!is.finite(c(pm, sm))) || any(c(pm, sm) < 0)) {
    stop("Missing, non-finite or negative abundance for ", fatty_acids$Metabolite[i])
  }

  long_data <- data.frame(
    Metabolite = fatty_acids$Metabolite[i],
    Fatty_acid = fatty_names$Metabolite[i],
    Animal = factor(rep(seq_len(6L), times = 2L)),
    Site = factor(rep(site_order, each = 6L), levels = site_order),
    Absolute_content_ug_mg = c(pm, sm),
    stringsAsFactors = FALSE
  )
  long_rows[[i]] <- long_data

  testable <- length(unique(c(pm, sm))) > 1L && stats::sd(paired_difference) > 0
  anova_f <- anova_p <- paired_t <- paired_t_p <- wilcoxon_v <- wilcoxon_p <- NA_real_
  if (testable) {
    fit <- stats::lm(Absolute_content_ug_mg ~ Animal + Site, data = long_data)
    anova_table <- stats::anova(fit)
    anova_f <- unname(anova_table["Site", "F value"])
    anova_p <- unname(anova_table["Site", "Pr(>F)"])
    paired_t_result <- stats::t.test(sm, pm, paired = TRUE, alternative = "two.sided")
    paired_t <- unname(paired_t_result$statistic)
    paired_t_p <- paired_t_result$p.value
    wilcoxon_result <- suppressWarnings(stats::wilcox.test(
      sm, pm, paired = TRUE, alternative = "two.sided",
      exact = FALSE, correct = FALSE
    ))
    wilcoxon_v <- unname(wilcoxon_result$statistic)
    wilcoxon_p <- wilcoxon_result$p.value
  }

  mean_pm <- mean(pm)
  mean_sm <- mean(sm)
  log2fc <- if (mean_pm > 0 && mean_sm > 0) log2(mean_sm / mean_pm) else NA_real_
  unsaturation_text <- sub("^[^:]+:", "", fatty_names$Metabolite[i])
  double_bonds <- suppressWarnings(as.integer(sub("^([0-9]+).*$", "\\1", unsaturation_text)))
  if (!is.finite(double_bonds)) stop("Cannot parse unsaturation: ", fatty_names$Metabolite[i])
  saturation_class <- if (double_bonds == 0L) "SFA" else if (double_bonds == 1L) "MUFA" else "PUFA"

  result_rows[[i]] <- data.frame(
    Display_order = i,
    Fatty_acid = fatty_names$Metabolite[i],
    Metabolite = fatty_acids$Metabolite[i],
    Saturation_class = saturation_class,
    Double_bonds = double_bonds,
    CAS_ID = fatty_acids$CAS.id[i],
    Formula = fatty_acids$Formula[i],
    KEGG_Compound_ID = fatty_acids$KEGG.Compound.ID[i],
    Unit = fatty_acids$unit[i],
    Retention_time = fatty_acids$Retention.time[i],
    N_pairs = 6L,
    Number_nonzero_PM = sum(pm > 0),
    Number_nonzero_SM = sum(sm > 0),
    Mean_PM = mean_pm,
    SD_PM = stats::sd(pm),
    Mean_SM = mean_sm,
    SD_SM = stats::sd(sm),
    log2FC_SM_vs_PM = log2fc,
    Mean_paired_difference_SM_minus_PM = mean(paired_difference),
    Lower_95CI_paired_difference = mean(paired_difference) -
      stats::qt(0.975, df = 5L) * stats::sd(paired_difference) / sqrt(6),
    Upper_95CI_paired_difference = mean(paired_difference) +
      stats::qt(0.975, df = 5L) * stats::sd(paired_difference) / sqrt(6),
    Direction = ifelse(
      mean(paired_difference) > 0, "Higher in SM",
      ifelse(mean(paired_difference) < 0, "Higher in PM", "No difference")
    ),
    Testable = testable,
    Paired_ANOVA_F = anova_f,
    Paired_ANOVA_raw_P = anova_p,
    Paired_t = paired_t,
    Paired_t_raw_P = paired_t_p,
    Shapiro_P_paired_differences = safe_shapiro(paired_difference),
    Paired_Wilcoxon_V = wilcoxon_v,
    Paired_Wilcoxon_raw_P = wilcoxon_p,
    stringsAsFactors = FALSE
  )
}

results <- do.call(rbind, result_rows)
long_data_all <- do.call(rbind, long_rows)
testable_index <- which(results$Testable & is.finite(results$Paired_ANOVA_raw_P))
results$Paired_ANOVA_FDR_BH <- NA_real_
results$Paired_ANOVA_FDR_BH[testable_index] <- stats::p.adjust(
  results$Paired_ANOVA_raw_P[testable_index], method = "BH"
)
results$Paired_ANOVA_significance <- significance_symbol(results$Paired_ANOVA_FDR_BH)
results$Paired_ANOVA_FDR_lt_0.05 <-
  !is.na(results$Paired_ANOVA_FDR_BH) & results$Paired_ANOVA_FDR_BH < 0.05

wilcoxon_index <- which(results$Testable & is.finite(results$Paired_Wilcoxon_raw_P))
results$Paired_Wilcoxon_FDR_BH <- NA_real_
results$Paired_Wilcoxon_FDR_BH[wilcoxon_index] <- stats::p.adjust(
  results$Paired_Wilcoxon_raw_P[wilcoxon_index], method = "BH"
)

plot_data <- results[results$Testable & is.finite(results$log2FC_SM_vs_PM), , drop = FALSE]
plot_data <- plot_data[
  order(plot_data$log2FC_SM_vs_PM, plot_data$Display_order), , drop = FALSE
]
plot_data$log2FC_order <- seq_len(nrow(plot_data))
plot_data$Fatty_acid <- factor(plot_data$Fatty_acid, levels = plot_data$Fatty_acid)
plot_data$Saturation_class <- factor(
  plot_data$Saturation_class, levels = c("SFA", "MUFA", "PUFA")
)
plot_data$Significance <- factor(
  ifelse(plot_data$Paired_ANOVA_FDR_lt_0.05, "FDR < 0.05", "FDR ≥ 0.05"),
  levels = c("FDR < 0.05", "FDR ≥ 0.05")
)

p <- ggplot(plot_data, aes(x = Fatty_acid, y = log2FC_SM_vs_PM)) +
  geom_hline(yintercept = 0, color = "#44484C", linewidth = 0.45) +
  geom_segment(
    aes(xend = Fatty_acid, y = 0, yend = log2FC_SM_vs_PM,
        color = Saturation_class, alpha = Significance),
    linewidth = 0.82, lineend = "round"
  ) +
  geom_point(
    aes(color = Saturation_class, alpha = Significance),
    size = 2.65
  ) +
  scale_color_manual(
    values = deep_colors, breaks = c("SFA", "MUFA", "PUFA"),
    name = "Saturation"
  ) +
  scale_alpha_manual(
    values = c("FDR < 0.05" = 1, "FDR ≥ 0.05" = 0.28),
    breaks = c("FDR < 0.05", "FDR ≥ 0.05"),
    name = "Paired ANOVA", drop = FALSE
  ) +
  scale_y_continuous(expand = expansion(mult = c(0.08, 0.10))) +
  labs(
    x = "Fatty acid",
    y = expression(log[2] * "FC (SM / PM)")
  ) +
  theme_bw(base_size = 10.5, base_family = "Arial") +
  theme(
    panel.grid.minor = element_blank(),
    panel.grid.major.x = element_blank(),
    panel.grid.major.y = element_line(color = "#E3E5E7", linewidth = 0.30),
    panel.border = element_rect(color = "#303337", linewidth = 0.50),
    axis.text.x = element_text(
      angle = 90, hjust = 1, vjust = 0.5, color = "#30363D", size = 7.8
    ),
    axis.text.y = element_text(color = "#30363D", size = 8.5),
    axis.title = element_text(color = "#1F2328", size = 10.5),
    axis.title.x = element_text(margin = margin(t = 7)),
    axis.title.y = element_text(margin = margin(r = 7)),
    legend.position = "top",
    legend.direction = "horizontal",
    legend.box = "horizontal",
    legend.title = element_text(size = 8.8),
    legend.text = element_text(size = 8.5),
    legend.key = element_blank(),
    plot.margin = margin(5, 7, 5, 7)
  ) +
  guides(
    color = guide_legend(order = 1, override.aes = list(alpha = 1, size = 2.8)),
    alpha = guide_legend(order = 2, override.aes = list(color = "#4D5358", size = 2.8))
  )

figure_stub <- file.path(
  figure_dir,
  "Fig4_PM_SM_targeted_fatty_acids_saturation_log2FC_lollipop"
)
plot_width <- 10.5
plot_height <- 4.8
ggsave(
  paste0(figure_stub, ".pdf"), p, device = cairo_pdf,
  width = plot_width, height = plot_height, units = "in", family = "Arial"
)
ggsave(
  paste0(figure_stub, ".png"), p,
  width = plot_width, height = plot_height, units = "in", dpi = 600, bg = "white"
)
svglite::svglite(
  paste0(figure_stub, ".svg"), width = plot_width, height = plot_height,
  system_fonts = list(sans = "Arial")
)
print(p)
dev.off()

summary_table <- data.frame(
  Metric = c(
    "Fatty acids measured", "Fatty acids testable/plotted", "All-zero/not-testable",
    "Paired ANOVA raw P < 0.05", "Paired ANOVA BH-FDR < 0.05",
    "FDR < 0.05 higher in PM", "FDR < 0.05 higher in SM",
    "SFA plotted", "MUFA plotted", "PUFA plotted"
  ),
  Value = c(
    nrow(results), nrow(plot_data), sum(!results$Testable),
    sum(results$Paired_ANOVA_raw_P < 0.05, na.rm = TRUE),
    sum(results$Paired_ANOVA_FDR_lt_0.05),
    sum(results$Paired_ANOVA_FDR_lt_0.05 & results$Direction == "Higher in PM"),
    sum(results$Paired_ANOVA_FDR_lt_0.05 & results$Direction == "Higher in SM"),
    sum(plot_data$Saturation_class == "SFA"),
    sum(plot_data$Saturation_class == "MUFA"),
    sum(plot_data$Saturation_class == "PUFA")
  )
)

qa <- data.frame(
  Item = c(
    "Input", "Comparison", "Primary model", "Primary scale", "Pairs",
    "Multiple testing", "Significance", "log2FC direction",
    "Saturation classification", "Fatty-acid order", "All-zero handling", "Font"
  ),
  Value = c(
    input_file, "PM vs SM paired within Animal",
    "Absolute_content_ug_mg ~ Animal + Site",
    "raw absolute content (ug/mg); no normalization or transformation", 6,
    "BH across testable fatty acids", "Paired ANOVA FDR < 0.05",
    "positive = higher in SM; negative = higher in PM",
    "0 double bonds=SFA; 1=MUFA; >=2=PUFA",
    "ascending log2FC(SM/PM), from PM-enriched to SM-enriched",
    "retained in all-results table but excluded from testing and plotting", "Arial"
  )
)

write_tsv(results, "Fig4_PM_SM_targeted_fatty_acids_paired_ANOVA_all_results.tsv")
write_tsv(
  results[results$Paired_ANOVA_FDR_lt_0.05, , drop = FALSE],
  "Fig4_PM_SM_targeted_fatty_acids_paired_ANOVA_FDR_lt_0.05.tsv"
)
plot_export <- plot_data
plot_export$Fatty_acid <- as.character(plot_export$Fatty_acid)
plot_export$Saturation_class <- as.character(plot_export$Saturation_class)
plot_export$Significance <- as.character(plot_export$Significance)
write_tsv(plot_export, "Fig4_PM_SM_targeted_fatty_acids_saturation_lollipop_plot_data.tsv")
write_tsv(summary_table, "Fig4_PM_SM_targeted_fatty_acids_paired_ANOVA_summary.tsv")
write_tsv(qa, "Fig4_PM_SM_targeted_fatty_acids_paired_ANOVA_QA.tsv")

write.xlsx(
  list(
    Summary = summary_table,
    FDR_significant = results[results$Paired_ANOVA_FDR_lt_0.05, , drop = FALSE],
    All_results = results,
    Plot_data = plot_export,
    Long_absolute_data = long_data_all,
    QA = qa
  ),
  file.path(
    table_dir,
    "Fig4_PM_SM_targeted_fatty_acids_paired_ANOVA_lollipop_results.xlsx"
  ),
  overwrite = TRUE, asTable = TRUE
)

message("Done. Testable/plotted fatty acids: ", nrow(plot_data),
        "; FDR < 0.05: ", sum(plot_data$Paired_ANOVA_FDR_lt_0.05),
        " (PM ", sum(plot_data$Paired_ANOVA_FDR_lt_0.05 & plot_data$Direction == "Higher in PM"),
        "; SM ", sum(plot_data$Paired_ANOVA_FDR_lt_0.05 & plot_data$Direction == "Higher in SM"), ").")
