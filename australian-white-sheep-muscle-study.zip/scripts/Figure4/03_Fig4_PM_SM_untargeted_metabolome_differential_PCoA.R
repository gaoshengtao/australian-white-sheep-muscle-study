#!/usr/bin/env Rscript

# Figure 4 PM-SM untargeted metabolomics analysis.
# Matches final Figure 3 rules:
#   - all named LC-MS features retained; no QC-CV exclusion
#   - paired multilevel OPLS-DA after within-Animal centering
#   - differential: VIP > 1 and paired Wilcoxon raw P < 0.05
#   - Bray-Curtis PCoA on sqrt(back-transformed TIC-scaled abundance)
#   - paired PERMANOVA: distance ~ Animal + Site

rm(list = ls())
suppressPackageStartupMessages({
  library(data.table)
  library(ggplot2)
  library(openxlsx)
  library(ropls)
  library(vegan)
})

set.seed(20260907)
project_dir <- "__PROJECT_ROOT__"
work_dir <- file.path(project_dir, "10_Figure4_PM_SM_water_holding_capacity")
input_file <- file.path(project_dir, "06_LCMS_untarget",
  "01_PM_SM_TIC_OPLSDA_VIP_paired_Wilcoxon",
  "pos_neg_named_HMDB_TIC_log10_normalized.tsv")
figure_dir <- file.path(work_dir, "Figures")
table_dir <- file.path(work_dir, "Tables")
dir.create(figure_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(table_dir, recursive = TRUE, showWarnings = FALSE)
if (!file.exists(input_file)) stop("Missing input: ", input_file)

dat <- fread(input_file, na.strings = c("NA", ""), check.names = FALSE)
pm_cols <- paste0("PM_", 1:6)
sm_cols <- paste0("SM_", 1:6)
paired_cols <- as.vector(rbind(pm_cols, sm_cols))
missing_cols <- setdiff(c("Feature_key", "Metabolite", paired_cols), names(dat))
if (length(missing_cols)) stop("Missing columns: ", paste(missing_cols, collapse = ", "))
if (anyDuplicated(dat$Feature_key)) stop("Feature_key is not unique.")
if (any(is.na(dat$Metabolite) | !nzchar(trimws(dat$Metabolite)))) {
  stop("Unnamed features found in named-feature input.")
}
for (nm in paired_cols) set(dat, j = nm, value = as.numeric(dat[[nm]]))

# Paired multilevel OPLS-DA -------------------------------------------------
x <- t(as.matrix(dat[, ..paired_cols]))
rownames(x) <- paired_cols
colnames(x) <- dat$Feature_key
animal <- rep(1:6, each = 2)
site <- factor(rep(c("PM", "SM"), 6), levels = c("PM", "SM"))
for (a in 1:6) {
  idx <- animal == a
  x[idx, ] <- sweep(x[idx, , drop = FALSE], 2,
                    colMeans(x[idx, , drop = FALSE]), "-")
}
feature_sd <- apply(x, 2, sd)
model_keep <- is.finite(feature_sd) & feature_sd > 0
x_model <- x[, model_keep, drop = FALSE]
fit <- opls(x_model, site, predI = 1, orthoI = 1, scaleC = "standard",
            crossvalI = 6, permI = 0, fig.pdfC = "none", info.txtC = "none")
vip_model <- as.numeric(getVipVn(fit))
if (length(vip_model) != ncol(x_model)) stop("VIP length mismatch.")
vip <- rep(NA_real_, nrow(dat))
vip[model_keep] <- vip_model

safe_wilcox <- function(sm, pm) {
  delta <- sm - pm
  if (all(!is.finite(delta)) || all(delta[is.finite(delta)] == 0)) {
    return(c(V = 0, P = 1))
  }
  w <- suppressWarnings(wilcox.test(sm, pm, paired = TRUE,
                                    exact = FALSE, correct = TRUE))
  c(V = unname(w$statistic), P = w$p.value)
}

stats <- rbindlist(lapply(seq_len(nrow(dat)), function(i) {
  sm <- as.numeric(dat[i, ..sm_cols])
  pm <- as.numeric(dat[i, ..pm_cols])
  delta <- sm - pm
  w <- safe_wilcox(sm, pm)
  data.table(
    mean_log10_SM = mean(sm), mean_log10_PM = mean(pm),
    mean_paired_difference_log10 = mean(delta),
    log2FC_SM_vs_PM = mean(delta) * log2(10),
    n_SM_gt_PM = sum(delta > 0), n_SM_lt_PM = sum(delta < 0),
    n_equal = sum(delta == 0), paired_Wilcoxon_V = w[["V"]],
    paired_Wilcoxon_P = w[["P"]]
  )
}))

annotation_cols <- intersect(c(
  "Feature_key", "Feature_ID", "ID", "Metabolite", "Metabolite_mode",
  "Source_mode", "Mode", "m/z", "Retention.time", "Adducts", "Formula",
  "KEGG.Compound.ID", "CAS.ID", "InChIKey", "Level", "QC_CV_percent",
  "HMDB_Match_Method", "HMDB_ID", "HMDB_Name", "HMDB_KEGG_ID",
  "HMDB_InChIKey", "HMDB_Taxonomy_superclass", "HMDB_Taxonomy_class",
  "HMDB_Taxonomy_subclass"
), names(dat))
results <- cbind(dat[, ..annotation_cols],
                 data.table(VIP = vip, Entered_OPLSDA = model_keep), stats)
results[, paired_Wilcoxon_FDR_BH := p.adjust(paired_Wilcoxon_P, "BH")]
results[, Differential := !is.na(VIP) & VIP > 1 & paired_Wilcoxon_P < 0.05]
results[, Higher_in := fifelse(Differential & log2FC_SM_vs_PM > 0, "SM",
  fifelse(Differential & log2FC_SM_vs_PM < 0, "PM", "Not differential"))]
setorder(results, -Differential, paired_Wilcoxon_P, -VIP)
significant <- results[Differential == TRUE]

prefix <- "Fig4_PM_SM_untargeted_all_named_OPLSDA_VIP_paired_Wilcoxon"
fwrite(results, file.path(table_dir, paste0(prefix, "_all_results.tsv.gz")),
       sep = "\t", quote = FALSE, na = "NA")
fwrite(significant, file.path(table_dir, paste0(prefix, "_differential.tsv")),
       sep = "\t", quote = FALSE, na = "NA")
model_summary <- as.data.table(getSummaryDF(fit), keep.rownames = "Model")
summary_dt <- data.table(
  Item = c("Named features", "Features entered in OPLS-DA",
           "Differential features", "PM-enriched differential features",
           "SM-enriched differential features",
           "Differential features with Wilcoxon BH FDR < 0.05",
           "Selection rule", "QC-CV inclusion filter"),
  Value = c(nrow(dat), sum(model_keep), nrow(significant),
            sum(significant$Higher_in == "PM"),
            sum(significant$Higher_in == "SM"),
            sum(significant$paired_Wilcoxon_FDR_BH < 0.05, na.rm = TRUE),
            "VIP > 1 plus paired Wilcoxon raw P < 0.05", "None")
)
fwrite(summary_dt, file.path(table_dir, paste0(prefix, "_summary.tsv")),
       sep = "\t", quote = FALSE)
write.xlsx(list(Summary = summary_dt, Model_summary = model_summary,
                Differential = significant, All_results = results),
  file.path(table_dir, paste0(prefix, "_results.xlsx")),
  overwrite = TRUE, keepNA = TRUE)

# Bray-Curtis PCoA and paired PERMANOVA ------------------------------------
log10_tic <- as.matrix(dat[, ..paired_cols])
rownames(log10_tic) <- dat$Feature_key
tic_scaled <- 10^log10_tic - 1
tic_scaled[tic_scaled < 0 & tic_scaled > -1e-8] <- 0
if (any(tic_scaled < 0)) stop("Negative back-transformed abundance.")
sqrt_tic <- sqrt(tic_scaled)
sqrt_tic <- sqrt_tic[rowSums(sqrt_tic > 0) > 0, , drop = FALSE]

metadata <- data.frame(
  Sample = paired_cols,
  Site = factor(rep(c("PM", "SM"), 6), levels = c("PM", "SM")),
  Animal = factor(rep(1:6, each = 2)), row.names = paired_cols
)
bray <- vegdist(t(sqrt_tic), method = "bray")
pcoa <- wcmdscale(bray, k = 2, eig = TRUE, add = "lingoes")
positive_eig <- pcoa$eig[pcoa$eig > 0]
variance <- 100 * positive_eig / sum(positive_eig)
coords <- data.frame(
  Sample = rownames(pcoa$points), PCoA1 = pcoa$points[, 1],
  PCoA2 = pcoa$points[, 2],
  Site = metadata[rownames(pcoa$points), "Site"],
  Animal = metadata[rownames(pcoa$points), "Animal"],
  row.names = NULL
)

make_permutations <- function(n = 6L) {
  t(vapply(seq_len(2^n - 1L), function(mask) {
    idx <- seq_len(2L * n)
    bits <- as.integer(intToBits(mask))[seq_len(n)]
    for (a in seq_len(n)) if (bits[a] == 1L) {
      pair <- c(2L * a - 1L, 2L * a)
      idx[pair] <- rev(idx[pair])
    }
    idx
  }, integer(2L * n)))
}
perm <- make_permutations(6L)
adonis_fit <- adonis2(bray ~ Animal + Site, data = metadata,
                      permutations = perm, by = "margin")
adonis_table <- data.frame(Term = rownames(adonis_fit),
                           as.data.frame(adonis_fit, check.names = FALSE),
                           row.names = NULL, check.names = FALSE)
site_row <- adonis_table[adonis_table$Term == "Site", ]
residual_row <- adonis_table[adonis_table$Term == "Residual", ]
adonis_summary <- data.frame(
  Test = "PM versus SM paired Site effect",
  Model = "Bray-Curtis distance ~ Animal + Site",
  Site_R2_total = site_row$R2,
  Site_partial_R2 = site_row$SumOfSqs /
    (site_row$SumOfSqs + residual_row$SumOfSqs),
  Pseudo_F = site_row$F, P_value = site_row[["Pr(>F)"]],
  Exact_nonidentity_permutations = nrow(perm)
)

ellipse_df <- do.call(rbind, lapply(c("PM", "SM"), function(s) {
  z <- coords[coords$Site == s, c("PCoA1", "PCoA2")]
  center <- colMeans(z)
  covmat <- cov(z)
  eig <- eigen(covmat, symmetric = TRUE)
  factor95 <- 2 * (nrow(z) - 1) /
    (nrow(z) * (nrow(z) - 2)) * qf(0.95, 2, nrow(z) - 2)
  transform <- eig$vectors %*% diag(sqrt(eig$values * factor95), 2)
  theta <- seq(0, 2 * pi, length.out = 200)
  xy <- cbind(cos(theta), sin(theta)) %*% t(transform)
  xy <- sweep(xy, 2, center, "+")
  data.frame(PCoA1 = xy[, 1], PCoA2 = xy[, 2], Site = s)
}))

fwrite(coords, file.path(table_dir,
  "Fig4_PM_SM_untargeted_BrayCurtis_PCoA_coordinates.tsv"), sep = "\t")
fwrite(adonis_table, file.path(table_dir,
  "Fig4_PM_SM_untargeted_paired_Adonis_full.tsv"), sep = "\t")
fwrite(adonis_summary, file.path(table_dir,
  "Fig4_PM_SM_untargeted_paired_Adonis_summary.tsv"), sep = "\t")

site_colors <- c(PM = "#C28B48", SM = "#5B837B")
p_pcoa <- ggplot(coords, aes(PCoA1, PCoA2, color = Site, fill = Site)) +
  geom_path(data = ellipse_df, aes(group = Site), linewidth = 0.68,
            alpha = 0.85) +
  geom_point(shape = 21, size = 2.8, stroke = 0.55) +
  annotate("text", x = -Inf, y = Inf,
    label = sprintf("R²: %.2f\nP-value: %.3f",
                    adonis_summary$Site_R2_total, adonis_summary$P_value),
    hjust = -0.08, vjust = 1.15, family = "Arial", size = 3.15) +
  scale_color_manual(values = site_colors) +
  scale_fill_manual(values = scales::alpha(site_colors, 0.20)) +
  labs(title = "Untargeted metabolism",
       x = sprintf("PCoA1 (%.1f%%)", variance[1]),
       y = sprintf("PCoA2 (%.1f%%)", variance[2])) +
  theme_bw(base_size = 10.5, base_family = "Arial") +
  theme(aspect.ratio = 1, plot.title = element_text(hjust = 0.5),
        panel.grid = element_line(color = "#E6E8EA", linewidth = 0.28),
        panel.border = element_rect(color = "#303337", linewidth = 0.48),
        legend.position = "right",
        plot.background = element_rect(fill = "white", color = NA))

# Differential overview: y is VIP, matching the selection rule.
plot_met <- copy(results)
plot_met[, Plot_group := fifelse(Differential, Higher_in, "Not differential")]
p_diff <- ggplot(plot_met, aes(log2FC_SM_vs_PM, VIP)) +
  geom_vline(xintercept = 0, color = "#8D9297", linewidth = 0.40,
             linetype = "22") +
  geom_hline(yintercept = 1, color = "#A8ACB0", linewidth = 0.34,
             linetype = "22") +
  geom_point(data = plot_met[Differential == FALSE], color = "#B7BABD",
             alpha = 0.25, size = 0.55) +
  geom_point(data = plot_met[Differential == TRUE], aes(color = Higher_in,
             fill = Higher_in), shape = 21, alpha = 0.78,
             size = 1.15, stroke = 0.30) +
  scale_color_manual(values = site_colors, breaks = c("PM", "SM"),
                     name = "Enriched site") +
  scale_fill_manual(values = site_colors, guide = "none") +
  labs(x = expression(log[2] * " fold change (SM / PM)"),
       y = "OPLS-DA VIP") +
  theme_bw(base_size = 10.5, base_family = "Arial") +
  theme(aspect.ratio = 1,
        panel.grid = element_line(color = "#E6E8EA", linewidth = 0.28),
        panel.border = element_rect(color = "#303337", linewidth = 0.48),
        plot.background = element_rect(fill = "white", color = NA))

ggsave(file.path(figure_dir,
  "Fig4_PM_SM_untargeted_metabolome_BrayCurtis_PCoA.pdf"),
  p_pcoa, device = cairo_pdf, width = 5.2, height = 4.5,
  units = "in", family = "Arial")
ggsave(file.path(figure_dir,
  "Fig4_PM_SM_untargeted_metabolome_BrayCurtis_PCoA.png"),
  p_pcoa, width = 5.2, height = 4.5, units = "in", dpi = 600, bg = "white")
ggsave(file.path(figure_dir,
  "Fig4_PM_SM_untargeted_metabolite_VIP_differential.pdf"),
  p_diff, device = cairo_pdf, width = 5.2, height = 4.5,
  units = "in", family = "Arial")
ggsave(file.path(figure_dir,
  "Fig4_PM_SM_untargeted_metabolite_VIP_differential.png"),
  p_diff, width = 5.2, height = 4.5, units = "in", dpi = 600, bg = "white")

message("Differential metabolites: ", nrow(significant),
        " (PM ", sum(significant$Higher_in == "PM"),
        "; SM ", sum(significant$Higher_in == "SM"), ")")
message("Paired PERMANOVA: R2 = ", signif(adonis_summary$Site_R2_total, 4),
        ", P = ", signif(adonis_summary$P_value, 4))
