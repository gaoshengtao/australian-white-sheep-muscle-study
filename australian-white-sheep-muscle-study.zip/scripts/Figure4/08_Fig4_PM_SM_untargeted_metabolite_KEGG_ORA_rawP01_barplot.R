#!/usr/bin/env Rscript

# Direction-specific KEGG compound ORA for PM-SM differential untargeted
# metabolites. Differential metabolites retain the established threshold:
# multilevel OPLS-DA VIP > 1 and paired Wilcoxon raw P < 0.05.
# Human Diseases and Drug Development pathways are removed before BH.
# Pathways with ORA raw P < 0.10 are displayed as horizontal bars.

rm(list = ls())

suppressPackageStartupMessages({
  library(data.table)
  library(openxlsx)
  library(clusterProfiler)
  library(ggplot2)
  library(svglite)
})

project_dir <- "__PROJECT_ROOT__"
work_dir <- file.path(project_dir, "10_Figure4_PM_SM_water_holding_capacity")
table_dir <- file.path(work_dir, "Tables")
figure_dir <- file.path(work_dir, "Figures")
hmdb_dir <- "__HMDB_ROOT__"
dir.create(table_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(figure_dir, recursive = TRUE, showWarnings = FALSE)

untarget_file <- file.path(
  table_dir,
  "Fig4_PM_SM_untargeted_all_named_OPLSDA_VIP_paired_Wilcoxon_all_results.tsv.gz"
)
classification_file <- file.path(
  project_dir,
  "09_Figure3_EAO_PM_IMF_tenderness_decoupling",
  "Tables", "Fig3_KEGG_br08901_official_pathway_classification.tsv"
)
local_script <- file.path(hmdb_dir, "local_kegg_enrichment.R")
required <- c(
  untarget_file, classification_file, local_script,
  file.path(hmdb_dir, "compound_pathway.txt"),
  file.path(hmdb_dir, "pathway names.txt")
)
if (any(!file.exists(required))) {
  stop("Missing required files: ", paste(required[!file.exists(required)], collapse = ", "))
}
source(local_script)

sites <- c("PM", "SM")
site_colors <- c(PM = "#C28B48", SM = "#5B837B")
excluded_level1 <- c("Human Diseases", "Drug Development")
pathway_display_raw_p <- 0.10

clean_text <- function(x) {
  x <- trimws(as.character(x))
  x[is.na(x) | x %in% c("", "NA", "-")] <- NA_character_
  x
}

explode_direct_kegg <- function(d) {
  d <- copy(d)
  d[, KEGG_ID := clean_text(KEGG_ID)]
  d[, KEGG_token := strsplit(
    fifelse(is.na(KEGG_ID), "", KEGG_ID), "[;,|]", perl = TRUE
  )]
  d <- d[, {
    toks <- clean_text(unlist(KEGG_token))
    if (!length(toks) || all(is.na(toks))) toks <- NA_character_
    .(KEGG_ID = unique(toks))
  }, by = setdiff(names(d), c("KEGG_ID", "KEGG_token"))]
  d
}

map_metabolites <- function(d, hmdb_index) {
  d <- explode_direct_kegg(d)
  mapped <- map_input_to_kegg(d, hmdb_db = hmdb_index)
  mapped[, KEGG_ID_final := clean_kegg_id(KEGG_ID_final)]
  mapped
}

untarget <- fread(untarget_file, na.strings = c("NA", ""), check.names = FALSE)
needed <- c(
  "Feature_key", "Metabolite", "KEGG.Compound.ID", "HMDB_ID", "InChIKey",
  "Differential", "Higher_in", "VIP", "paired_Wilcoxon_P",
  "paired_Wilcoxon_FDR_BH", "log2FC_SM_vs_PM"
)
missing_needed <- setdiff(needed, names(untarget))
if (length(missing_needed)) {
  stop("Untargeted table lacks columns: ", paste(missing_needed, collapse = ", "))
}

input <- untarget[, .(
  Input_ID = paste0("Untargeted::", Feature_key),
  Source_feature_ID = Feature_key,
  Metabolite,
  KEGG_ID = KEGG.Compound.ID,
  HMDB_ID,
  InChIKey,
  Differential = as.logical(Differential),
  Higher_in,
  Selection_P = paired_Wilcoxon_P,
  Selection_FDR = paired_Wilcoxon_FDR_BH,
  VIP,
  Directional_effect = log2FC_SM_vs_PM,
  Selection_rule = "multilevel OPLS-DA VIP > 1 and paired Wilcoxon raw P < 0.05"
)]

message("Loading local HMDB indexes and mapping untargeted metabolites...")
hmdb_index <- read_hmdb_db(file.path(hmdb_dir, "local_hmdb_annotation"))
mapped <- map_metabolites(input, hmdb_index)

# The measured background is all named LC-MS features that map to a KEGG
# compound. Each compound is counted once.
background_ids_all <- unique(mapped[!is.na(KEGG_ID_final), KEGG_ID_final])

# Resolve duplicate features mapping to the same KEGG compound. If directions
# conflict, retain the feature with the smallest paired P, then highest VIP and
# largest absolute effect.
diff_mapped <- mapped[
  Differential == TRUE & Higher_in %chin% sites & !is.na(KEGG_ID_final)
]
diff_mapped[, Absolute_effect := abs(Directional_effect)]
setorder(diff_mapped, KEGG_ID_final, Selection_P, -VIP, -Absolute_effect)
diff_resolved <- diff_mapped[, {
  group_n <- .N
  direction_conflict <- uniqueN(Higher_in) > 1L
  z <- .SD[1]
  z[, `:=`(
    Same_compound_feature_count = group_n,
    Direction_conflict = direction_conflict,
    Duplicate_resolution = fifelse(
      group_n > 1L,
      "smallest paired Wilcoxon P, then highest VIP, then largest absolute effect",
      "single mapped feature"
    )
  )]
  z
}, by = KEGG_ID_final]

# Build the retained KEGG compound-to-pathway universe. Category exclusion is
# applied before clusterProfiler calculates BH-adjusted P values.
cpd_path <- read_kegg_compound_pathway(file.path(hmdb_dir, "compound_pathway.txt"))
path_names <- read_kegg_pathway_names(file.path(hmdb_dir, "pathway names.txt"))
classes <- fread(classification_file, check.names = FALSE)
classes[, KEGG_Pathway := sub("^hsa", "map", Pathway_ID)]

cpd_path <- merge(cpd_path, path_names, by = "KEGG_Pathway", all.x = TRUE)
cpd_path <- merge(
  cpd_path,
  classes[, .(
    KEGG_Pathway, KEGG_level1, KEGG_level2, KEGG_hierarchy_pathway
  )],
  by = "KEGG_Pathway", all.x = TRUE
)
cpd_path[, Classified := !is.na(KEGG_level1)]
cpd_path[, Excluded_before_BH := KEGG_level1 %chin% excluded_level1]
cpd_path_retained <- unique(cpd_path[
  Classified == TRUE & Excluded_before_BH == FALSE,
  .(
    KEGG_Pathway, KEGG_Compound, Pathway_name,
    KEGG_level1, KEGG_level2, KEGG_hierarchy_pathway
  )
])

pathway_background <- intersect(
  background_ids_all, unique(cpd_path_retained$KEGG_Compound)
)
term2gene <- unique(cpd_path_retained[
  KEGG_Compound %chin% pathway_background,
  .(term = KEGG_Pathway, gene = KEGG_Compound)
])
term2name <- unique(cpd_path_retained[, .(term = KEGG_Pathway, name = Pathway_name)])
path_meta <- unique(cpd_path_retained[, .(
  KEGG_Pathway, KEGG_level1, KEGG_level2, KEGG_hierarchy_pathway
)], by = "KEGG_Pathway")

compound_name_lookup <- mapped[!is.na(KEGG_ID_final), .(
  KEGG_ID_final,
  Metabolite = Metabolite_input,
  Mapping_method,
  Selection_P,
  VIP,
  Directional_effect
)]
setorder(compound_name_lookup, KEGG_ID_final, Selection_P, -VIP)
compound_name_lookup <- compound_name_lookup[, .SD[1], by = KEGG_ID_final]

run_ora <- function(site_name) {
  input_ids <- unique(diff_resolved[
    Higher_in == site_name & KEGG_ID_final %chin% pathway_background,
    KEGG_ID_final
  ])
  if (!length(input_ids)) return(data.table())
  fit <- clusterProfiler::enricher(
    gene = input_ids,
    universe = pathway_background,
    TERM2GENE = as.data.frame(term2gene),
    TERM2NAME = as.data.frame(term2name),
    pAdjustMethod = "BH",
    pvalueCutoff = 1,
    qvalueCutoff = 1,
    minGSSize = 1,
    maxGSSize = 5000
  )
  if (is.null(fit) || !nrow(as.data.frame(fit))) return(data.table())
  out <- as.data.table(as.data.frame(fit))
  setnames(
    out,
    c("ID", "Description", "GeneRatio", "BgRatio", "pvalue", "p.adjust", "qvalue", "geneID", "Count"),
    c("KEGG_Pathway", "Pathway_name", "GeneRatio", "BackgroundRatio", "P_value",
      "FDR_BH_after_category_filter", "Q_value", "Input_KEGG_compounds", "Overlap")
  )
  out[, Higher_in := site_name]
  out[, `:=`(
    Input_size = length(input_ids),
    Background_size = length(pathway_background),
    Pathway_size = as.integer(sub(".*/", "", BackgroundRatio)),
    Rich_factor = Overlap / as.integer(sub(".*/", "", BackgroundRatio)),
    Fold_enrichment =
      (Overlap / as.integer(sub("/.*", "", GeneRatio))) /
      (as.integer(sub(".*/", "", BackgroundRatio)) /
         as.integer(sub("/.*", "", BackgroundRatio))),
    FDR_lt_0.05 = FDR_BH_after_category_filter < 0.05,
    Display_rawP_lt_0.10 = P_value < pathway_display_raw_p
  )]
  out <- merge(out, path_meta, by = "KEGG_Pathway", all.x = TRUE, sort = FALSE)
  out[, Input_metabolites := vapply(strsplit(Input_KEGG_compounds, "/"), function(ids) {
    nm <- compound_name_lookup$Metabolite[
      match(ids, compound_name_lookup$KEGG_ID_final)
    ]
    paste(sprintf("%s (%s)", nm, ids), collapse = "; ")
  }, character(1))]
  setorder(out, FDR_BH_after_category_filter, P_value, -Overlap)
  out[]
}

enrichment <- rbindlist(lapply(sites, run_ora), use.names = TRUE, fill = TRUE)
display_pathways <- enrichment[Display_rawP_lt_0.10 == TRUE]
fdr_pathways <- enrichment[FDR_lt_0.05 == TRUE]

# Audit excluded categories separately; they are not assigned adjusted P values.
excluded_rel <- unique(cpd_path[
  Classified == TRUE & Excluded_before_BH == TRUE,
  .(KEGG_Compound, KEGG_Pathway, Pathway_name, KEGG_level1, KEGG_level2)
])
excluded_hits <- rbindlist(lapply(sites, function(site_name) {
  ids <- unique(diff_resolved[Higher_in == site_name, KEGG_ID_final])
  excluded_rel[KEGG_Compound %chin% ids, .(
    Higher_in = site_name,
    Overlap = uniqueN(KEGG_Compound),
    Input_KEGG_compounds = paste(sort(unique(KEGG_Compound)), collapse = ";")
  ), by = .(KEGG_Pathway, Pathway_name, KEGG_level1, KEGG_level2)]
}), use.names = TRUE, fill = TRUE)

summary_table <- rbindlist(lapply(sites, function(site_name) {
  data.table(
    Higher_in = site_name,
    Differential_features = nrow(untarget[
      Differential == TRUE & Higher_in == site_name
    ]),
    Differential_features_mapped_to_KEGG = nrow(diff_mapped[
      Higher_in == site_name
    ]),
    Differential_unique_KEGG_after_resolution = uniqueN(diff_resolved[
      Higher_in == site_name, KEGG_ID_final
    ]),
    ORA_input_compounds_in_pathway_universe = uniqueN(diff_resolved[
      Higher_in == site_name & KEGG_ID_final %chin% pathway_background,
      KEGG_ID_final
    ]),
    Tested_pathways_with_overlap = nrow(enrichment[Higher_in == site_name]),
    ORA_rawP_lt_0.10_pathways = nrow(display_pathways[Higher_in == site_name]),
    ORA_rawP_lt_0.05_pathways = nrow(enrichment[
      Higher_in == site_name & P_value < 0.05
    ]),
    ORA_FDR_lt_0.05_pathways = nrow(fdr_pathways[Higher_in == site_name])
  )
}))

qa <- data.table(
  Item = c(
    "Named untargeted features", "Differential features", "Differential threshold",
    "Mapped detected KEGG background", "Background compounds in retained pathways",
    "Excluded KEGG level-1 categories", "Multiple-testing order",
    "ORA implementation", "Displayed pathway threshold", "Plot x-axis"
  ),
  Value = c(
    nrow(untarget), sum(untarget$Differential),
    "multilevel OPLS-DA VIP > 1 and paired Wilcoxon raw P < 0.05",
    length(background_ids_all), length(pathway_background),
    paste(excluded_level1, collapse = "; "),
    "remove excluded categories, then BH separately within PM and SM",
    "clusterProfiler::enricher with measured KEGG-mapped background",
    "ORA raw P < 0.10", "-log10(ORA raw P)"
  )
)

prefix <- "Fig4_PM_SM_untargeted_metabolite_KEGG_ORA"
fwrite(mapped, file.path(table_dir, paste0(prefix, "_mapping.tsv.gz")),
       sep = "\t", quote = FALSE, na = "NA")
fwrite(diff_resolved, file.path(table_dir, paste0(prefix, "_differential_compounds.tsv")),
       sep = "\t", quote = FALSE, na = "NA")
fwrite(enrichment, file.path(table_dir, paste0(prefix, "_all_retained_pathways.tsv")),
       sep = "\t", quote = FALSE, na = "NA")
fwrite(display_pathways, file.path(table_dir, paste0(prefix, "_pathways_rawP_lt_0.10.tsv")),
       sep = "\t", quote = FALSE, na = "NA")
fwrite(fdr_pathways, file.path(table_dir, paste0(prefix, "_pathways_FDR_lt_0.05.tsv")),
       sep = "\t", quote = FALSE, na = "NA")
fwrite(excluded_hits, file.path(table_dir, paste0(prefix, "_excluded_before_BH.tsv")),
       sep = "\t", quote = FALSE, na = "NA")
fwrite(summary_table, file.path(table_dir, paste0(prefix, "_summary.tsv")),
       sep = "\t", quote = FALSE, na = "NA")
fwrite(qa, file.path(table_dir, paste0(prefix, "_QA.tsv")),
       sep = "\t", quote = FALSE, na = "NA")

write.xlsx(
  list(
    Summary = as.data.frame(summary_table),
    QA = as.data.frame(qa),
    Pathways_rawP_lt_0.10 = as.data.frame(display_pathways),
    Pathways_FDR_lt_0.05 = as.data.frame(fdr_pathways),
    All_retained_pathways = as.data.frame(enrichment),
    Differential_compounds = as.data.frame(diff_resolved),
    Excluded_before_BH = as.data.frame(excluded_hits)
  ),
  file.path(table_dir, paste0(prefix, "_results.xlsx")),
  overwrite = TRUE, keepNA = TRUE
)

if (nrow(display_pathways)) {
  plot_dt <- copy(display_pathways)
  plot_dt[, minus_log10_rawP := -log10(pmax(P_value, .Machine$double.xmin))]
  plot_dt[, Higher_in := factor(Higher_in, levels = sites)]
  plot_dt[, FDR_marker := fifelse(FDR_lt_0.05, "*", "")]
  plot_dt[, Pathway_plot := factor(
    paste(Higher_in, Pathway_name, sep = "___"),
    levels = rev(paste(Higher_in, Pathway_name, sep = "___")[
      order(Higher_in, P_value, FDR_BH_after_category_filter)
    ])
  )]
  p <- ggplot(plot_dt, aes(x = minus_log10_rawP, y = Pathway_plot)) +
    geom_vline(
      xintercept = -log10(pathway_display_raw_p),
      color = "#8E9398", linetype = "22", linewidth = 0.40
    ) +
    geom_col(aes(fill = Higher_in), width = 0.72, show.legend = FALSE) +
    geom_text(
      aes(label = FDR_marker), hjust = -0.15,
      family = "Arial", fontface = "bold", size = 3.4, color = "#26292D"
    ) +
    facet_grid(
      rows = vars(Higher_in), scales = "free_y", space = "free_y", switch = "y"
    ) +
    scale_y_discrete(labels = function(x) sub("^[^_]+___", "", x)) +
    scale_fill_manual(values = site_colors, drop = FALSE) +
    scale_x_continuous(expand = expansion(mult = c(0, 0.08))) +
    labs(x = expression(-log[10] * "(ORA raw P)"), y = NULL) +
    theme_bw(base_size = 10.5, base_family = "Arial") +
    theme(
      panel.grid.minor = element_blank(),
      panel.grid.major.y = element_blank(),
      panel.grid.major.x = element_line(color = "#E5E7E9", linewidth = 0.28),
      panel.border = element_rect(color = "#303337", linewidth = 0.48),
      strip.background = element_blank(),
      strip.placement = "outside",
      strip.text.y.left = element_text(angle = 90, face = "bold", size = 10.5),
      axis.text.y = element_text(color = "#1F2328", size = 8.7),
      axis.text.x = element_text(color = "#1F2328"),
      axis.title.x = element_text(color = "#1F2328"),
      plot.margin = margin(6, 9, 6, 7)
    )

  fig_height <- max(4.8, 1.8 + 0.30 * nrow(plot_dt))
  fig_width <- 8.0
  stub <- file.path(figure_dir, paste0(prefix, "_rawP_lt_0.10_barplot"))
  ggsave(
    paste0(stub, ".pdf"), p, device = cairo_pdf,
    width = fig_width, height = fig_height, units = "in", family = "Arial"
  )
  ggsave(
    paste0(stub, ".png"), p,
    width = fig_width, height = fig_height, units = "in", dpi = 600, bg = "white"
  )
  svglite::svglite(
    paste0(stub, ".svg"), width = fig_width, height = fig_height,
    system_fonts = list(sans = "Arial")
  )
  print(p)
  dev.off()
} else {
  warning("No retained KEGG pathways passed ORA raw P < 0.10; no plot generated.")
}

message("Done. Raw P < 0.10 pathways: PM = ",
        nrow(display_pathways[Higher_in == "PM"]),
        "; SM = ", nrow(display_pathways[Higher_in == "SM"]),
        ". FDR < 0.05 pathways: PM = ",
        nrow(fdr_pathways[Higher_in == "PM"]),
        "; SM = ", nrow(fdr_pathways[Higher_in == "SM"]), ".")
