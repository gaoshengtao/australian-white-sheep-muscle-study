#!/usr/bin/env Rscript

# Figure 4C: direction-specific KEGG ORA for PM-SM FDR-significant RNA genes.
# The analysis matches Figure 3C:
#   DESeq2 paired result; feature BH FDR < 0.05; no log2FC cutoff;
#   sheep genes mapped to human Entrez orthologs;
#   PM- and SM-enriched genes tested separately with their common mapped,
#   testable transcriptome background;
#   Human Diseases and Drug Development removed before within-direction BH;
#   x = -log10(FDR), with PM and SM as vertical facet rows.

rm(list = ls())
suppressPackageStartupMessages({
  library(clusterProfiler)
  library(ggplot2)
  library(openxlsx)
})

options(stringsAsFactors = FALSE, timeout = 600)
project_dir <- "__PROJECT_ROOT__"
work_dir <- file.path(project_dir, "10_Figure4_PM_SM_water_holding_capacity")
source_dir <- file.path(project_dir, "07_Figure2_muscle_functional_states",
                        "03_One_vs_rest_specificity", "Tables")
figure_dir <- file.path(work_dir, "Figures")
table_dir <- file.path(work_dir, "Tables")
dir.create(figure_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(table_dir, recursive = TRUE, showWarnings = FALSE)

rna_file <- file.path(source_dir,
  "Fig2_muscle_fiber_pairwise_transcriptome_DESeq2_all_gene_results.tsv.gz")
ortholog_file <- file.path(source_dir,
  "Fig2_Ensembl115_sheep_to_human_ortholog_Entrez_mapping.tsv")
classification_file <- file.path(
  project_dir, "09_Figure3_EAO_PM_IMF_tenderness_decoupling", "Tables",
  "Fig3_KEGG_br08901_official_pathway_classification.tsv")
for (f in c(rna_file, ortholog_file, classification_file)) {
  if (!file.exists(f)) stop("Missing input: ", f)
}

clean_id <- function(x) {
  x <- trimws(as.character(x)); x[is.na(x)] <- ""; x
}
parse_ratio <- function(x) {
  p <- strsplit(as.character(x), "/", fixed = TRUE)
  vapply(p, function(z) as.numeric(z[1]) / as.numeric(z[2]), numeric(1))
}
write_tsv <- function(x, name) write.table(
  x, file.path(table_dir, name), sep = "\t", quote = FALSE,
  row.names = FALSE, na = "NA"
)

rna <- read.delim(gzfile(rna_file), check.names = FALSE,
                  quote = "", comment.char = "")
orth <- read.delim(ortholog_file, check.names = FALSE,
                   quote = "", comment.char = "")
class_map <- read.delim(classification_file, check.names = FALSE,
                        quote = "", comment.char = "")
rna <- rna[rna$Comparison == "SM_vs_PM" & is.finite(rna$log2FoldChange) &
             !is.na(rna$P_FDR_BH), ]
if (!nrow(rna)) stop("SM_vs_PM RNA result not found.")

orth$Sheep_Ensembl_gene_id <- clean_id(orth$Sheep_Ensembl_gene_id)
orth$Human_Entrez_ID <- clean_id(orth$Human_Entrez_ID)
orth$Human_Gene_symbol <- clean_id(orth$Human_Gene_symbol)
orth <- unique(orth[nzchar(orth$Sheep_Ensembl_gene_id) &
                      nzchar(orth$Human_Entrez_ID),
                    c("Sheep_Ensembl_gene_id", "Human_Entrez_ID",
                      "Human_Gene_symbol")])

mapped <- merge(rna, orth, by.x = "gene_id",
                by.y = "Sheep_Ensembl_gene_id", all = FALSE, sort = FALSE)
mapped$Human_Entrez_ID <- clean_id(mapped$Human_Entrez_ID)
mapped$Higher_in <- ifelse(mapped$log2FoldChange > 0, "SM", "PM")

# Resolve many-to-one ortholog mappings by the strongest statistical evidence.
mapped <- mapped[order(mapped$Human_Entrez_ID, mapped$P_FDR_BH,
                       mapped$P_value, -abs(mapped$log2FoldChange)), ]
gene_level <- mapped[!duplicated(mapped$Human_Entrez_ID), ]
gene_level$Mapped_feature_count <- as.integer(table(mapped$Human_Entrez_ID)[
  gene_level$Human_Entrez_ID])
universe <- sort(unique(gene_level$Human_Entrez_ID))
sig <- gene_level[gene_level$P_FDR_BH < 0.05, ]

write_tsv(sig,
  "Fig4C_PM_SM_RNA_FDR005_KEGG_input_gene_membership.tsv")

symbol_lookup <- setNames(gene_level$Human_Gene_symbol,
                          gene_level$Human_Entrez_ID)
symbol_lookup <- symbol_lookup[!duplicated(names(symbol_lookup))]
make_symbols <- function(gene_string) {
  ids <- strsplit(gene_string, "/", fixed = TRUE)[[1]]
  symbols <- unname(symbol_lookup[ids])
  symbols[is.na(symbols) | !nzchar(symbols)] <-
    ids[is.na(symbols) | !nzchar(symbols)]
  paste(symbols, collapse = "/")
}

site_order <- c("PM", "SM")
retained_list <- list()
excluded_list <- list()
summary_list <- list()
for (site_name in site_order) {
  target <- sort(unique(sig$Human_Entrez_ID[sig$Higher_in == site_name]))
  message(site_name, ": ", length(target), " mapped target genes; ",
          length(universe), " background genes")
  ek <- enrichKEGG(
    gene = target, organism = "hsa", keyType = "ncbi-geneid",
    universe = universe, pvalueCutoff = 1, pAdjustMethod = "none",
    qvalueCutoff = 1, minGSSize = 10, maxGSSize = 500,
    use_internal_data = FALSE
  )
  z <- as.data.frame(ek)
  if (!nrow(z)) stop("No KEGG pathways returned for ", site_name)
  z$Higher_in <- site_name
  z$Input_gene_count <- length(target)
  z$Universe_gene_count <- length(universe)
  z$RichFactor <- z$Count / as.numeric(sub("/.*$", "", z$BgRatio))
  z$FoldEnrichment <- parse_ratio(z$GeneRatio) / parse_ratio(z$BgRatio)
  z$Gene_symbols <- vapply(z$geneID, make_symbols, character(1))
  idx <- match(z$ID, class_map$Pathway_ID)
  z$KEGG_level1 <- class_map$KEGG_level1[idx]
  z$KEGG_level2 <- class_map$KEGG_level2[idx]
  z$KEGG_hierarchy_pathway <- class_map$KEGG_hierarchy_pathway[idx]
  if (anyNA(z$KEGG_level1)) stop("Unclassified KEGG pathway returned.")
  z$Excluded_before_BH <- z$KEGG_level1 %in%
    c("Human Diseases", "Drug Development")
  excluded <- z[z$Excluded_before_BH, ]
  retained <- z[!z$Excluded_before_BH, ]
  retained$FDR_BH_after_category_filter <- p.adjust(retained$pvalue, "BH")
  retained$FDR_lt_0.05 <- retained$FDR_BH_after_category_filter < 0.05
  retained$Pathway <- retained$Description
  retained$Pathway_ID <- retained$ID
  retained <- retained[order(retained$FDR_BH_after_category_filter,
                             retained$pvalue), ]
  retained_list[[site_name]] <- retained
  excluded_list[[site_name]] <- excluded
  summary_list[[site_name]] <- data.frame(
    Higher_in = site_name,
    Original_FDR_significant_genes = sum(
      rna$P_FDR_BH < 0.05 &
        if (site_name == "SM") rna$log2FoldChange > 0 else
          rna$log2FoldChange < 0),
    Unique_human_Entrez_targets = length(target),
    Mapped_testable_background = length(universe),
    KEGG_pathways_before_category_filter = nrow(z),
    Excluded_Human_Diseases_or_Drug_Development = nrow(excluded),
    Retained_pathways_tested = nrow(retained),
    Retained_pathways_raw_P_lt_0.05 = sum(retained$pvalue < 0.05),
    Retained_pathways_FDR_lt_0.05 = sum(
      retained$FDR_BH_after_category_filter < 0.05)
  )
}

all_retained <- do.call(rbind, retained_list)
all_excluded <- do.call(rbind, excluded_list)
summary_df <- do.call(rbind, summary_list)
rownames(all_retained) <- rownames(all_excluded) <- rownames(summary_df) <- NULL
significant <- all_retained[all_retained$FDR_BH_after_category_filter < 0.05, ]
raw_sig <- all_retained[all_retained$pvalue < 0.05, ]

preferred <- c(
  "Higher_in", "KEGG_level1", "KEGG_level2", "Pathway", "Pathway_ID",
  "GeneRatio", "BgRatio", "RichFactor", "FoldEnrichment", "pvalue",
  "FDR_BH_after_category_filter", "FDR_lt_0.05", "Count", "geneID",
  "Gene_symbols", "Input_gene_count", "Universe_gene_count",
  "KEGG_hierarchy_pathway"
)
significant <- significant[, intersect(preferred, names(significant))]
raw_sig <- raw_sig[, intersect(preferred, names(raw_sig))]
all_retained_out <- all_retained[, intersect(preferred, names(all_retained))]

write_tsv(summary_df, "Fig4C_PM_SM_RNA_FDR005_KEGG_summary.tsv")
write_tsv(all_retained_out,
  "Fig4C_PM_SM_RNA_FDR005_KEGG_all_retained_pathways.tsv")
write_tsv(significant,
  "Fig4C_PM_SM_RNA_FDR005_KEGG_pathways_FDR_lt_0.05.tsv")
write_tsv(raw_sig,
  "Fig4C_PM_SM_RNA_FDR005_KEGG_pathways_rawP_lt_0.05.tsv")
write_tsv(all_excluded,
  "Fig4C_PM_SM_RNA_FDR005_KEGG_excluded_before_BH.tsv")

methods <- data.frame(
  Item = c("Comparison", "Feature method", "Feature threshold",
           "Fold-change cutoff", "Enrichment", "Organism/mapping",
           "Background", "Direction", "Excluded before BH", "BH scope",
           "Pathway display threshold", "X-axis", "Facet order", "Font"),
  Value = c("SM_vs_PM", "DESeq2 paired: ~ Animal + Site",
            "gene-level BH FDR < 0.05", "None",
            "clusterProfiler::enrichKEGG ORA",
            "hsa; sheep Ensembl to human Entrez ortholog mapping",
            paste0("all mapped, testable RNA genes; n=", length(universe)),
            "PM- and SM-enriched genes analyzed separately",
            "Human Diseases; Drug Development",
            "independently within PM and SM after category exclusion",
            "pathway FDR < 0.05", "-log10(pathway FDR)",
            "PM above SM", "Arial")
)
write.xlsx(list(Summary = summary_df, FDR_lt_0.05 = significant,
                Raw_P_lt_0.05 = raw_sig, All_retained = all_retained_out,
                Excluded_before_BH = all_excluded,
                Input_gene_membership = sig, Methods_and_QA = methods),
  file.path(table_dir,
    "Fig4C_PM_SM_RNA_FDR005_separate_KEGG_enrichment.xlsx"),
  overwrite = TRUE, asTable = TRUE)

if (!nrow(significant)) stop("No pathway passed FDR < 0.05.")
significant$Higher_in <- factor(significant$Higher_in, levels = site_order)
significant$Minus_log10_FDR <- -log10(
  significant$FDR_BH_after_category_filter)

# Within each facet, the strongest pathway is placed at the top.
ord_list <- lapply(site_order, function(s) {
  z <- significant[significant$Higher_in == s, ]
  if (!nrow(z)) {
    return(data.frame(
      Higher_in = s,
      Pathway = "No pathway passed FDR < 0.05",
      Pathway_ID = paste0("placeholder_", s),
      Minus_log10_FDR = 0,
      Present = FALSE,
      stringsAsFactors = FALSE
    ))
  }
  z <- z[order(z$Minus_log10_FDR, z$Pathway), ]
  data.frame(
    Higher_in = s,
    Pathway = z$Pathway,
    Pathway_ID = z$Pathway_ID,
    Minus_log10_FDR = z$Minus_log10_FDR,
    Present = TRUE,
    stringsAsFactors = FALSE
  )
})
ord <- do.call(rbind, ord_list)
ord$Higher_in <- factor(ord$Higher_in, levels = site_order)
ord$Omics <- factor("Transcriptome", levels = "Transcriptome")
ord$Pathway_key <- paste(ord$Higher_in, ord$Pathway_ID, ord$Pathway,
                         sep = "|||")
ord$Pathway_key <- factor(ord$Pathway_key, levels = ord$Pathway_key)
clean_label <- function(x) vapply(strsplit(x, "|||", fixed = TRUE),
                                  `[`, character(1), 3)
site_colors <- c(PM = "#C28B48", SM = "#5B837B")

p <- ggplot(ord, aes(Minus_log10_FDR, Pathway_key, fill = Higher_in)) +
  geom_blank() +
  geom_vline(xintercept = -log10(0.05), color = "#9A9EA2",
             linewidth = 0.34, linetype = "22") +
  geom_col(data = ord[ord$Present, , drop = FALSE], width = 0.66,
           color = "#303337", linewidth = 0.30, show.legend = FALSE) +
  facet_grid(rows = vars(Higher_in), cols = vars(Omics),
             scales = "free_y", space = "free_y", drop = FALSE) +
  scale_fill_manual(values = site_colors) +
  scale_x_continuous(limits = c(0, max(ord$Minus_log10_FDR) * 1.03),
    expand = expansion(mult = 0), breaks = scales::pretty_breaks(n = 6)) +
  scale_y_discrete(labels = clean_label) +
  labs(x = expression(-log[10] * "(FDR)"), y = NULL) +
  theme_bw(base_size = 10.5, base_family = "Arial") +
  theme(
    plot.background = element_rect(fill = "white", color = NA),
    panel.background = element_rect(fill = "white", color = NA),
    panel.grid.major.y = element_blank(), panel.grid.minor = element_blank(),
    panel.grid.major.x = element_line(color = "#E4E6E8", linewidth = 0.30),
    panel.border = element_rect(color = "#303337", linewidth = 0.46),
    strip.background = element_rect(fill = "#F1F1F1", color = "#B8BABD",
                                    linewidth = 0.38),
    strip.text.x = element_text(face = "bold", size = 10, color = "#25282C"),
    strip.text.y = element_text(face = "bold", size = 10, color = "#25282C"),
    axis.title.x = element_text(size = 10.2, color = "#25282C",
                               margin = margin(t = 7)),
    axis.text.x = element_text(size = 8.7, color = "#25282C"),
    axis.text.y = element_text(size = 8.2, color = "#25282C"),
    axis.ticks = element_line(color = "#303337", linewidth = 0.34),
    panel.spacing.y = unit(3.2, "mm"),
    plot.margin = margin(5, 5, 4.5, 5)
  )

n_pm <- sum(significant$Higher_in == "PM")
n_sm <- sum(significant$Higher_in == "SM")
plot_height <- max(4.0, 1.7 + 0.245 * (n_pm + n_sm))
stub <- file.path(figure_dir, "Fig4C_PM_SM_RNA_KEGG_FDR_faceted_barplot")
ggsave(paste0(stub, ".pdf"), p, device = cairo_pdf,
       width = 7.2, height = plot_height, units = "in", family = "Arial")
ggsave(paste0(stub, ".png"), p, width = 7.2, height = plot_height,
       units = "in", dpi = 600, bg = "white")
svg(paste0(stub, ".svg"), width = 7.2, height = plot_height,
    family = "Arial", bg = "white", onefile = TRUE)
print(p); dev.off()

message("Significant KEGG pathways: PM ", n_pm, "; SM ", n_sm)
message("Figure height: ", signif(plot_height, 3), " in")
