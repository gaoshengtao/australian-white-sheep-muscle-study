#!/usr/bin/env Rscript

# Figure 4: PM-SM targeted fatty-acid PCoA and paired PERMANOVA.
# Bray-Curtis distances are calculated directly from absolute fatty-acid
# contents (ug/mg). No normalization, relative-abundance conversion or
# transformation is applied.

rm(list = ls())

suppressPackageStartupMessages({
  library(ggplot2)
  library(openxlsx)
  library(vegan)
})

project_dir <- "__PROJECT_ROOT__"
work_dir <- file.path(project_dir, "10_Figure4_PM_SM_water_holding_capacity")
input_file <- file.path(project_dir, "02_fatty_acids", "fatty acids.xlsx")
input_sheet <- "measurement.xls"
figure_dir <- file.path(work_dir, "Figures")
table_dir <- file.path(work_dir, "Tables")
dir.create(figure_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(table_dir, recursive = TRUE, showWarnings = FALSE)

figure_stub <- file.path(
  figure_dir,
  "Fig4_PM_SM_targeted_fatty_acids_absolute_BrayCurtis_PCoA_95CI"
)
site_order <- c("PM", "SM")
site_colors <- c(PM = "#C28B48", SM = "#5B837B")
pm_samples <- paste0("PM_", 1:6)
sm_samples <- paste0("SM_", 1:6)
sample_order <- as.vector(rbind(pm_samples, sm_samples))
plot_width_in <- 5.2
plot_height_in <- 4.5

write_tsv <- function(x, filename) {
  write.table(
    x, file.path(table_dir, filename), sep = "\t", quote = FALSE,
    row.names = FALSE, na = "NA"
  )
}

adonis_to_table <- function(x) {
  data.frame(
    Term = rownames(x), as.data.frame(x, check.names = FALSE),
    row.names = NULL, check.names = FALSE
  )
}

format_p <- function(p) {
  if (!is.finite(p)) return("NA")
  if (p < 0.001) return(format(p, scientific = TRUE, digits = 1))
  formatC(p, format = "f", digits = 3)
}

# All 2^6 paired PM/SM label swaps, excluding the identity permutation.
make_exact_paired_permutations <- function(n_animals = 6L) {
  n_samples <- 2L * n_animals
  permutations <- t(vapply(
    seq_len(2^n_animals - 1L),
    function(mask) {
      index <- seq_len(n_samples)
      bits <- as.integer(intToBits(mask))[seq_len(n_animals)]
      for (animal_i in seq_len(n_animals)) {
        if (bits[animal_i] == 1L) {
          pair_index <- c(2L * animal_i - 1L, 2L * animal_i)
          index[pair_index] <- rev(index[pair_index])
        }
      }
      index
    },
    integer(n_samples)
  ))
  if (nrow(unique(permutations)) != 2^n_animals - 1L) {
    stop("Paired permutation matrix is not unique.")
  }
  permutations
}

centroid_confidence_ellipse <- function(data, level = 0.95, n_points = 200L) {
  coordinates <- as.matrix(data[, c("PCoA1", "PCoA2"), drop = FALSE])
  n <- nrow(coordinates)
  p <- ncol(coordinates)
  if (n <= p) stop("Too few samples for a two-dimensional confidence ellipse.")
  covariance_matrix <- stats::cov(coordinates)
  eigen_decomposition <- eigen(covariance_matrix, symmetric = TRUE)
  if (any(eigen_decomposition$values <= 0)) {
    stop("Non-positive covariance eigenvalue in confidence ellipse.")
  }
  hotelling_factor <-
    p * (n - 1) / (n * (n - p)) * stats::qf(level, p, n - p)
  transform_matrix <- eigen_decomposition$vectors %*%
    diag(sqrt(eigen_decomposition$values * hotelling_factor), nrow = p)
  angles <- seq(0, 2 * pi, length.out = n_points)
  ellipse_coordinates <- sweep(
    cbind(cos(angles), sin(angles)) %*% t(transform_matrix),
    2, colMeans(coordinates), "+"
  )
  data.frame(
    PCoA1 = ellipse_coordinates[, 1],
    PCoA2 = ellipse_coordinates[, 2]
  )
}

if (!file.exists(input_file)) stop("Input file not found: ", input_file)
fatty_acids <- read.xlsx(
  input_file, sheet = input_sheet, check.names = FALSE,
  detectDates = FALSE, skipEmptyRows = FALSE
)

required_columns <- c(
  "Metabolite", "CAS.id", "Formula", "KEGG.Compound.ID", "unit",
  "Retention.time", sample_order
)
missing_columns <- setdiff(required_columns, names(fatty_acids))
if (length(missing_columns)) {
  stop("Missing columns: ", paste(missing_columns, collapse = ", "))
}
if (anyDuplicated(fatty_acids$Metabolite)) stop("Metabolite names are not unique.")
if (length(unique(fatty_acids$unit)) != 1L || unique(fatty_acids$unit) != "ug/mg") {
  stop("Expected a single absolute-content unit: ug/mg.")
}

absolute_matrix_all <- as.matrix(fatty_acids[, sample_order, drop = FALSE])
suppressWarnings(storage.mode(absolute_matrix_all) <- "double")
rownames(absolute_matrix_all) <- fatty_acids$Metabolite
if (any(!is.finite(absolute_matrix_all))) {
  stop("Absolute fatty-acid matrix contains missing or non-finite values.")
}
if (any(absolute_matrix_all < 0)) {
  stop("Absolute fatty-acid matrix contains negative values.")
}

detected_rows <- rowSums(absolute_matrix_all > 0) > 0
absolute_matrix <- absolute_matrix_all[detected_rows, , drop = FALSE]
if (nrow(absolute_matrix) < 2L) stop("Too few detected fatty acids.")

metadata <- data.frame(
  Sample = sample_order,
  Site = factor(rep(site_order, times = 6L), levels = site_order),
  Animal = factor(rep(1:6, each = 2L), levels = as.character(1:6)),
  Fatty_acids_detected = colSums(absolute_matrix > 0),
  Total_fatty_acid_content_ug_mg = colSums(absolute_matrix),
  row.names = sample_order,
  stringsAsFactors = FALSE
)
pairing_table <- table(metadata$Animal, metadata$Site)
if (!all(dim(pairing_table) == c(6L, 2L)) || !all(pairing_table == 1L)) {
  stop("Expected one PM and one SM sample from each of six animals.")
}

bray_distance <- vegan::vegdist(t(absolute_matrix), method = "bray")
distance_matrix <- as.matrix(bray_distance)
uncorrected_pcoa <- vegan::wcmdscale(
  bray_distance, k = 2, eig = TRUE, add = FALSE
)
pcoa_fit <- vegan::wcmdscale(
  bray_distance, k = 2, eig = TRUE, add = "lingoes", x.ret = TRUE
)
positive_eigenvalues <- as.numeric(pcoa_fit$eig[pcoa_fit$eig > 0])
if (length(positive_eigenvalues) < 2L) stop("Fewer than two positive PCoA axes.")
pcoa_variance <- 100 * positive_eigenvalues / sum(positive_eigenvalues)

pcoa_coordinates <- data.frame(
  Sample = rownames(pcoa_fit$points),
  PCoA1 = pcoa_fit$points[, 1],
  PCoA2 = pcoa_fit$points[, 2],
  Site = metadata[rownames(pcoa_fit$points), "Site"],
  Animal = metadata[rownames(pcoa_fit$points), "Animal"],
  stringsAsFactors = FALSE
)
pcoa_coordinates$Site <- factor(pcoa_coordinates$Site, levels = site_order)
pcoa_coordinates$Animal <- factor(
  pcoa_coordinates$Animal, levels = as.character(1:6)
)

pcoa_variance_table <- data.frame(
  Axis = paste0("PCoA", seq_along(positive_eigenvalues)),
  Positive_eigenvalue = positive_eigenvalues,
  Variance_explained_percent = pcoa_variance,
  Cumulative_variance_percent = cumsum(pcoa_variance)
)

confidence_ellipses <- do.call(rbind, lapply(site_order, function(site_name) {
  z <- pcoa_coordinates[pcoa_coordinates$Site == site_name, , drop = FALSE]
  ellipse <- centroid_confidence_ellipse(z)
  ellipse$Site <- factor(site_name, levels = site_order)
  ellipse$Point_order <- seq_len(nrow(ellipse))
  ellipse
}))

site_centroids <- do.call(rbind, lapply(site_order, function(site_name) {
  z <- pcoa_coordinates[pcoa_coordinates$Site == site_name, , drop = FALSE]
  data.frame(
    Site = site_name,
    n = nrow(z),
    PCoA1_centroid = mean(z$PCoA1),
    PCoA2_centroid = mean(z$PCoA2),
    Mean_total_fatty_acid_ug_mg = mean(
      metadata[metadata$Site == site_name, "Total_fatty_acid_content_ug_mg"]
    )
  )
}))

permutation_matrix <- make_exact_paired_permutations(6L)
adonis_fit <- vegan::adonis2(
  bray_distance ~ Animal + Site,
  data = metadata,
  permutations = permutation_matrix,
  by = "margin",
  parallel = 1
)
adonis_full <- adonis_to_table(adonis_fit)
site_row <- adonis_full[adonis_full$Term == "Site", , drop = FALSE]
residual_row <- adonis_full[adonis_full$Term == "Residual", , drop = FALSE]
if (nrow(site_row) != 1L || nrow(residual_row) != 1L) {
  stop("Could not extract Site and Residual rows from adonis2.")
}
adonis_summary <- data.frame(
  Test = "PM vs SM paired Site effect",
  Model = "absolute-content Bray-Curtis distance ~ Animal + Site",
  Site_Df = site_row$Df,
  Site_SumOfSqs = site_row$SumOfSqs,
  Site_R2_total = site_row$R2,
  Site_partial_R2 = site_row$SumOfSqs /
    (site_row$SumOfSqs + residual_row$SumOfSqs),
  Pseudo_F = site_row$F,
  P_value = site_row[["Pr(>F)"]],
  Exact_nonidentity_permutations = nrow(permutation_matrix),
  Total_label_configurations_including_observed = nrow(permutation_matrix) + 1L,
  Minimum_attainable_P = 1 / (nrow(permutation_matrix) + 1L),
  Permutation_restriction = "PM/SM label swaps within Animal"
)

dispersion_fit <- vegan::betadisper(
  bray_distance, group = metadata$Site,
  type = "median", bias.adjust = TRUE
)
dispersion_test <- vegan::permutest(
  dispersion_fit, permutations = permutation_matrix, pairwise = FALSE
)
dispersion_overall <- data.frame(
  Term = rownames(dispersion_test$tab),
  as.data.frame(dispersion_test$tab, check.names = FALSE),
  row.names = NULL, check.names = FALSE
)
dispersion_distances <- data.frame(
  Sample = rownames(metadata),
  Site = metadata$Site,
  Animal = metadata$Animal,
  Distance_to_site_spatial_median = dispersion_fit$distances
)

pcoa_correction <- data.frame(
  Method = "Lingoes",
  Additive_constant = pcoa_fit$ac,
  Negative_eigenvalues_before_correction = sum(uncorrected_pcoa$eig < -1e-10),
  Sum_positive_eigenvalues = sum(positive_eigenvalues)
)

annotation_label <- sprintf(
  "R²: %.2f\nP-value: %s",
  adonis_summary$Site_R2_total,
  format_p(adonis_summary$P_value)
)

p <- ggplot(pcoa_coordinates, aes(PCoA1, PCoA2, color = Site, fill = Site)) +
  geom_path(
    data = confidence_ellipses,
    aes(group = Site), linewidth = 0.68, alpha = 0.85,
    show.legend = FALSE
  ) +
  geom_point(shape = 21, size = 2.8, stroke = 0.55) +
  annotate(
    "text", x = -Inf, y = Inf, label = annotation_label,
    hjust = -0.08, vjust = 1.15, family = "Arial", size = 3.15,
    color = "#30363D", lineheight = 1.05
  ) +
  scale_color_manual(values = site_colors, breaks = site_order, drop = FALSE) +
  scale_fill_manual(
    values = scales::alpha(site_colors, 0.20),
    breaks = site_order, drop = FALSE
  ) +
  scale_x_continuous(expand = expansion(mult = 0.12)) +
  scale_y_continuous(expand = expansion(mult = 0.12)) +
  labs(
    title = "Targeted fatty acids",
    x = sprintf("PCoA1 (%.1f%%)", pcoa_variance[1]),
    y = sprintf("PCoA2 (%.1f%%)", pcoa_variance[2]),
    color = NULL, fill = NULL
  ) +
  theme_bw(base_size = 10.5, base_family = "Arial") +
  theme(
    aspect.ratio = 1,
    plot.title = element_text(hjust = 0.5),
    panel.grid = element_line(color = "#E6E8EA", linewidth = 0.28),
    panel.border = element_rect(color = "#303337", linewidth = 0.48),
    legend.position = "right",
    plot.background = element_rect(fill = "white", color = NA)
  )

ggsave(
  paste0(figure_stub, ".pdf"), p, device = cairo_pdf,
  width = plot_width_in, height = plot_height_in, units = "in",
  family = "Arial"
)
ggsave(
  paste0(figure_stub, ".png"), p,
  width = plot_width_in, height = plot_height_in, units = "in",
  dpi = 600, bg = "white"
)
svg(
  paste0(figure_stub, ".svg"), width = plot_width_in,
  height = plot_height_in, family = "Arial", bg = "white", onefile = TRUE
)
print(p)
dev.off()

write_tsv(metadata, "Fig4_PM_SM_targeted_fatty_acids_sample_metadata.tsv")
write_tsv(
  pcoa_coordinates,
  "Fig4_PM_SM_targeted_fatty_acids_absolute_BrayCurtis_PCoA_coordinates.tsv"
)
write_tsv(
  pcoa_variance_table,
  "Fig4_PM_SM_targeted_fatty_acids_absolute_BrayCurtis_PCoA_variance.tsv"
)
write_tsv(
  confidence_ellipses,
  "Fig4_PM_SM_targeted_fatty_acids_PCoA_centroid_95CI_coordinates.tsv"
)
write_tsv(site_centroids, "Fig4_PM_SM_targeted_fatty_acids_PCoA_site_centroids.tsv")
write_tsv(adonis_full, "Fig4_PM_SM_targeted_fatty_acids_paired_Adonis_full.tsv")
write_tsv(adonis_summary, "Fig4_PM_SM_targeted_fatty_acids_paired_Adonis_summary.tsv")
write_tsv(dispersion_overall, "Fig4_PM_SM_targeted_fatty_acids_PERMDISP_overall.tsv")
write_tsv(
  dispersion_distances,
  "Fig4_PM_SM_targeted_fatty_acids_PERMDISP_sample_distances.tsv"
)
write_tsv(pcoa_correction, "Fig4_PM_SM_targeted_fatty_acids_PCoA_correction.tsv")

distance_export <- data.frame(
  Sample = rownames(distance_matrix), distance_matrix,
  check.names = FALSE, row.names = NULL
)
write_tsv(
  distance_export,
  "Fig4_PM_SM_targeted_fatty_acids_absolute_BrayCurtis_distance_matrix.tsv"
)

input_matrix_export <- data.frame(
  Metabolite = rownames(absolute_matrix),
  Unit = "ug/mg",
  absolute_matrix,
  check.names = FALSE, row.names = NULL
)
write_tsv(
  input_matrix_export,
  "Fig4_PM_SM_targeted_fatty_acids_absolute_PCoA_input.tsv"
)

feature_qa <- data.frame(
  Metabolite = fatty_acids$Metabolite,
  CAS_ID = fatty_acids$CAS.id,
  Formula = fatty_acids$Formula,
  KEGG_Compound_ID = fatty_acids$KEGG.Compound.ID,
  Unit = fatty_acids$unit,
  Retention_time = fatty_acids$Retention.time,
  Detected_in_PM_SM = detected_rows,
  Number_nonzero_samples = rowSums(absolute_matrix_all > 0),
  stringsAsFactors = FALSE
)
write_tsv(feature_qa, "Fig4_PM_SM_targeted_fatty_acids_feature_QA.tsv")

permdisp_p <- dispersion_overall[
  dispersion_overall$Term == "Groups", "Pr(>F)"
]
qa_manifest <- data.frame(
  Item = c(
    "Input", "Input sheet", "Samples", "Animals", "Sites", "Input unit",
    "Fatty acids input", "Fatty acids retained", "All-zero fatty acids removed",
    "Normalization", "Transformation", "Distance input", "Distance",
    "PCoA correction", "Adonis model", "Permutation scheme",
    "Nonidentity permutations", "Minimum P", "Site R2 total",
    "Site partial R2", "Adonis P", "PERMDISP P", "Panel aspect", "Font"
  ),
  Value = c(
    input_file, input_sheet, nrow(metadata), nlevels(metadata$Animal),
    paste(site_order, collapse = ", "), "ug/mg", nrow(absolute_matrix_all),
    nrow(absolute_matrix), sum(!detected_rows), "None", "None",
    "absolute fatty-acid content", "Bray-Curtis", "Lingoes",
    "distance ~ Animal + Site",
    "all paired PM/SM swaps within Animal, excluding identity",
    nrow(permutation_matrix), 1 / (nrow(permutation_matrix) + 1L),
    adonis_summary$Site_R2_total, adonis_summary$Site_partial_R2,
    adonis_summary$P_value, permdisp_p, "1:1", "Arial"
  ),
  stringsAsFactors = FALSE
)
write_tsv(qa_manifest, "Fig4_PM_SM_targeted_fatty_acids_PCoA_Adonis_QA.tsv")

write.xlsx(
  list(
    Adonis_summary = adonis_summary,
    Adonis_full = adonis_full,
    PCoA_coordinates = pcoa_coordinates,
    PCoA_variance = pcoa_variance_table,
    Site_centroids = site_centroids,
    Sample_metadata = metadata,
    Feature_QA = feature_qa,
    PERMDISP = dispersion_overall,
    QA = qa_manifest
  ),
  file.path(
    table_dir,
    "Fig4_PM_SM_targeted_fatty_acids_absolute_PCoA_Adonis_results.xlsx"
  ),
  overwrite = TRUE, asTable = TRUE
)

message("Figure written to: ", figure_dir)
message("Tables written to: ", table_dir)
message(sprintf(
  "Paired Adonis Site effect: R2 = %.4f; partial R2 = %.4f; P = %.6f",
  adonis_summary$Site_R2_total,
  adonis_summary$Site_partial_R2,
  adonis_summary$P_value
))
message(sprintf(
  "Mean total fatty-acid content: PM = %.3f ug/mg; SM = %.3f ug/mg",
  site_centroids$Mean_total_fatty_acid_ug_mg[site_centroids$Site == "PM"],
  site_centroids$Mean_total_fatty_acid_ug_mg[site_centroids$Site == "SM"]
))
