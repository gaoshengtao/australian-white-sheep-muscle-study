#!/usr/bin/env Rscript

# Figure 4B: paired PM-SM transcriptome/proteome differential overview.
# Source models are the project-wide paired DESeq2 and limma analyses.
# SM_vs_PM log2FC > 0 denotes SM enrichment; no fold-change cutoff is used.
# Only BH FDR < 0.05 is highlighted, matching final Figure 3B.

suppressPackageStartupMessages({
  library(ggplot2)
  library(openxlsx)
})

project_dir <- "__PROJECT_ROOT__"
work_dir <- file.path(project_dir, "10_Figure4_PM_SM_water_holding_capacity")
source_dir <- file.path(project_dir, "07_Figure2_muscle_functional_states",
                        "03_One_vs_rest_specificity", "Tables")
figure_dir <- file.path(work_dir, "Figures")
table_dir <- file.path(work_dir, "Tables")
dir.create(figure_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(table_dir, recursive = TRUE, showWarnings = FALSE)

rna_file <- file.path(source_dir,
  "Fig2_muscle_fiber_pairwise_transcriptome_DESeq2_all_gene_results.tsv.gz")
protein_file <- file.path(source_dir,
  "Fig2_muscle_fiber_pairwise_proteome_limma_all_gene_results.tsv.gz")
for (f in c(rna_file, protein_file)) if (!file.exists(f)) stop("Missing: ", f)

read_contrast <- function(path, omics) {
  d <- read.delim(gzfile(path), check.names = FALSE)
  required <- c("Gene_symbol", "Comparison", "log2FoldChange",
                "P_value", "P_FDR_BH")
  if (length(setdiff(required, names(d)))) stop("Unexpected input: ", path)
  d <- d[d$Comparison == "SM_vs_PM" & is.finite(d$log2FoldChange) &
           !is.na(d$P_value) & d$P_value > 0 & !is.na(d$P_FDR_BH), ]
  feature_id <- if (omics == "Transcriptome" && "gene_id" %in% names(d)) {
    d$gene_id
  } else if (omics == "Proteome" && "Human_Entrez_ID" %in% names(d)) {
    d$Human_Entrez_ID
  } else seq_len(nrow(d))
  data.frame(
    Omics = omics,
    Feature_ID = as.character(feature_id),
    Gene_symbol = as.character(d$Gene_symbol),
    Comparison = d$Comparison,
    log2FoldChange_SM_vs_PM = d$log2FoldChange,
    P_value = d$P_value,
    P_FDR_BH = d$P_FDR_BH,
    stringsAsFactors = FALSE
  )
}

plot_df <- rbind(read_contrast(rna_file, "Transcriptome"),
                 read_contrast(protein_file, "Proteome"))
plot_df$Enriched_site <- ifelse(plot_df$log2FoldChange_SM_vs_PM > 0, "SM", "PM")
plot_df$Evidence <- ifelse(plot_df$P_FDR_BH < 0.05, "FDR < 0.05", "FDR >= 0.05")
plot_df$Minus_log10_FDR <- -log10(pmax(plot_df$P_FDR_BH,
                                       .Machine$double.xmin))
plot_df$Omics <- factor(plot_df$Omics,
                        levels = c("Transcriptome", "Proteome"))
plot_df$Enriched_site <- factor(plot_df$Enriched_site,
                                levels = c("PM", "SM"))

count_summary <- do.call(rbind, lapply(levels(plot_df$Omics), function(o) {
  z <- plot_df[plot_df$Omics == o, ]
  data.frame(
    Omics = o,
    Tested_features = nrow(z),
    FDR_lt_0.05_total = sum(z$P_FDR_BH < 0.05),
    FDR_lt_0.05_PM = sum(z$P_FDR_BH < 0.05 & z$Enriched_site == "PM"),
    FDR_lt_0.05_SM = sum(z$P_FDR_BH < 0.05 & z$Enriched_site == "SM"),
    stringsAsFactors = FALSE
  )
}))

write.table(count_summary,
  file.path(table_dir, "Fig4B_PM_SM_RNA_protein_differential_counts.tsv"),
  sep = "\t", quote = FALSE, row.names = FALSE)
con <- gzfile(file.path(table_dir,
  "Fig4B_PM_SM_RNA_protein_differential_all_results.tsv.gz"), "wt")
write.table(plot_df, con, sep = "\t", quote = FALSE, row.names = FALSE,
            na = "NA")
close(con)
sig_df <- plot_df[plot_df$P_FDR_BH < 0.05, ]

methods <- data.frame(
  Item = c("RNA model", "Protein model", "Contrast", "Direction",
           "Significance", "Fold-change cutoff", "Volcano y-axis",
           "Transcriptome mark", "Proteome mark", "Panel aspect", "Font"),
  Value = c("DESeq2: ~ Animal + Site", "limma: ~ Animal + Site", "SM_vs_PM",
            "Positive log2FC = SM; negative log2FC = PM",
            "BH FDR < 0.05", "None", "-log10(BH FDR)", "Circle", "Square",
            "1:1", "Arial"),
  stringsAsFactors = FALSE
)
write.xlsx(list(Counts = count_summary, Significant_features = sig_df,
                Methods_and_QA = methods),
  file.path(table_dir, "Fig4B_PM_SM_RNA_protein_differential_results.xlsx"),
  overwrite = TRUE, asTable = TRUE)

site_colors <- c(PM = "#C28B48", SM = "#5B837B")
omics_shapes <- c(Transcriptome = 21, Proteome = 22)
background <- plot_df[plot_df$P_FDR_BH >= 0.05, ]
x_abs <- ceiling(max(abs(plot_df$log2FoldChange_SM_vs_PM)) * 2) / 2
y_max <- ceiling(max(plot_df$Minus_log10_FDR) * 2) / 2

label_for <- function(o) {
  z <- count_summary[count_summary$Omics == o, ]
  sprintf("%s\nFDR < 0.05: %d\nPM: %d | SM: %d", o,
          z$FDR_lt_0.05_total, z$FDR_lt_0.05_PM, z$FDR_lt_0.05_SM)
}

p_volcano <- ggplot() +
  geom_hline(yintercept = -log10(0.05), color = "#A8ACB0",
             linewidth = 0.34, linetype = "22") +
  geom_vline(xintercept = 0, color = "#8D9297",
             linewidth = 0.42, linetype = "22") +
  geom_point(data = background,
    aes(log2FoldChange_SM_vs_PM, Minus_log10_FDR, shape = Omics),
    color = "#B7BABD", fill = "#B7BABD", alpha = 0.25,
    size = 0.38, stroke = 0, show.legend = FALSE) +
  geom_point(data = sig_df,
    aes(log2FoldChange_SM_vs_PM, Minus_log10_FDR, shape = Omics,
        color = Enriched_site, fill = Enriched_site),
    size = 0.88, stroke = 0.30, alpha = 0.72) +
  annotate("label", x = -x_abs + 0.26, y = y_max - 0.20,
    label = label_for("Transcriptome"), hjust = 0, vjust = 1,
    family = "Arial", fontface = "bold", size = 3.05,
    lineheight = 1.04, linewidth = 0, fill = scales::alpha("white", 0.86),
    label.padding = unit(0.18, "lines")) +
  annotate("label", x = x_abs - 0.26, y = y_max - 0.20,
    label = label_for("Proteome"), hjust = 1, vjust = 1,
    family = "Arial", fontface = "bold", size = 3.05,
    lineheight = 1.04, linewidth = 0, fill = scales::alpha("white", 0.86),
    label.padding = unit(0.18, "lines")) +
  scale_x_continuous(limits = c(-x_abs, x_abs),
                     expand = expansion(mult = 0)) +
  scale_y_continuous(limits = c(0, y_max), expand = expansion(mult = 0)) +
  scale_shape_manual(values = omics_shapes, breaks = names(omics_shapes),
                     labels = c("RNA", "Protein"), name = "Omics") +
  scale_color_manual(values = site_colors, breaks = c("PM", "SM"),
                     name = "Enriched site") +
  scale_fill_manual(values = site_colors, guide = "none") +
  labs(x = expression(log[2] * " fold change (SM / PM)"),
       y = expression(-log[10] * "(FDR)")) +
  theme_bw(base_size = 10.5, base_family = "Arial") +
  theme(
    aspect.ratio = 1,
    plot.background = element_rect(fill = "white", color = NA),
    panel.background = element_rect(fill = "white", color = NA),
    panel.grid.major = element_line(color = "#E6E8EA", linewidth = 0.30),
    panel.grid.minor = element_blank(),
    panel.border = element_rect(color = "#303337", linewidth = 0.48),
    axis.title = element_text(size = 10.2, color = "#25282C"),
    axis.text = element_text(size = 9.0, color = "#25282C"),
    axis.ticks = element_line(color = "#303337", linewidth = 0.35),
    legend.position = "right", legend.box = "vertical",
    legend.title = element_text(face = "bold", size = 9.0),
    legend.text = element_text(size = 8.5),
    plot.margin = margin(5, 4, 4.5, 5)
  ) +
  guides(
    shape = guide_legend(order = 1,
      override.aes = list(size = 2.8, stroke = 0.65,
                          color = "#303337", fill = "white", alpha = 1)),
    color = guide_legend(order = 2,
      override.aes = list(shape = 16, size = 2.8, fill = NA, alpha = 1))
  )

count_df <- rbind(
  data.frame(Omics = count_summary$Omics, Enriched_site = "PM",
             Count = count_summary$FDR_lt_0.05_PM),
  data.frame(Omics = count_summary$Omics, Enriched_site = "SM",
             Count = count_summary$FDR_lt_0.05_SM)
)
count_df$Omics <- factor(count_df$Omics,
                         levels = c("Transcriptome", "Proteome"))
count_df$Enriched_site <- factor(count_df$Enriched_site,
                                 levels = c("PM", "SM"))
p_counts <- ggplot(count_df, aes(Enriched_site, Count, fill = Enriched_site)) +
  geom_col(width = 0.62, color = "#303337", linewidth = 0.38,
           show.legend = FALSE) +
  geom_text(aes(label = Count, color = Enriched_site), vjust = -0.45,
            size = 3.25, fontface = "bold", show.legend = FALSE) +
  facet_wrap(~Omics, nrow = 1, scales = "free_y") +
  scale_fill_manual(values = site_colors) +
  scale_color_manual(values = site_colors) +
  scale_y_continuous(expand = expansion(mult = c(0, 0.15))) +
  labs(x = NULL, y = "FDR-significant features") +
  theme_bw(base_size = 10.5, base_family = "Arial") +
  theme(panel.grid.major.x = element_blank(), panel.grid.minor = element_blank(),
        panel.grid.major.y = element_line(color = "#E6E8EA", linewidth = 0.30),
        panel.border = element_rect(color = "#303337", linewidth = 0.45),
        strip.background = element_rect(fill = "#F1F1F1", color = "#B8BABD"),
        strip.text = element_text(face = "bold"),
        plot.background = element_rect(fill = "white", color = NA))

ggsave(file.path(figure_dir, "Fig4B_PM_SM_combined_RNA_protein_volcano.pdf"),
       p_volcano, device = cairo_pdf, width = 6.20, height = 4.65,
       units = "in", family = "Arial")
ggsave(file.path(figure_dir, "Fig4B_PM_SM_combined_RNA_protein_volcano.png"),
       p_volcano, width = 6.20, height = 4.65, units = "in", dpi = 600,
       bg = "white")
ggsave(file.path(figure_dir, "Fig4B_PM_SM_RNA_protein_FDR_counts.pdf"),
       p_counts, device = cairo_pdf, width = 4.20, height = 2.75,
       units = "in", family = "Arial")
ggsave(file.path(figure_dir, "Fig4B_PM_SM_RNA_protein_FDR_counts.png"),
       p_counts, width = 4.20, height = 2.75, units = "in", dpi = 600,
       bg = "white")

message("Transcriptome/proteome differential outputs written to Figure 4.")
