#!/usr/bin/env Rscript

# ============================================================================
# Australian White sheep meat-quality visualization by anatomical site
#
# Chart contract
# - Question: How do 12 meat-quality traits differ among four anatomical sites?
# - Form: jittered observations + mean +/- SEM + all six pairwise comparisons.
# - Figure size: 3.0 x 4.2 inches per panel for a narrower publication layout.
# - Panel box: fixed height/width ratio; all exports share aligned gtable dimensions.
# - X-axis site labels: four independent text layers for Illustrator editing.
# - Paired design: LT_i, SM_i, PM_i, and AM_i are four sites from Animal i.
# - Inference displayed: random-intercept mixed-model site contrasts with BH
#   adjustment across the six comparisons within each trait.
# - Sensitivity analysis: Friedman omnibus tests and paired Wilcoxon tests.
# - Supporting tables: pairing QA, descriptive statistics, model diagnostics,
#   primary/sensitivity inference, plot annotations, IQR flags, and clean data.
# ============================================================================

rm(list = ls())

suppressPackageStartupMessages({
  library(ggplot2)
  library(openxlsx)
  library(colorspace)
  library(grid)
  library(nlme)
})

# ----------------------------------------------------------------------------
# 1. Paths and reproducibility
# ----------------------------------------------------------------------------
base_dir <- "__PROJECT_ROOT__/01_meat_quality"
input_file <- file.path(base_dir, "meat quality.xlsx")
figure_dir <- file.path(base_dir, "Figures", "Figure1_meat_quality_by_site")
table_dir <- file.path(base_dir, "Tables")

dir.create(figure_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(table_dir, recursive = TRUE, showWarnings = FALSE)

set.seed(20260822)

# ----------------------------------------------------------------------------
# 2. Group definitions and a new print-friendly palette
# ----------------------------------------------------------------------------
group_order <- c("LTL", "SM", "PM", "EAO")

group_full_label <- c(
  LTL = "Longissimus thoracis et lumborum",
  SM  = "Semimembranosus",
  PM  = "Psoas major",
  EAO = "External abdominal oblique"
)

# Muted sapphire, eucalyptus, ochre, and mulberry.
site_colors <- c(
  LTL = "#365B8C",
  SM  = "#4F7C71",
  PM  = "#C28B48",
  EAO = "#A65D68"
)

site_colors_dark <- vapply(
  site_colors,
  function(x) colorspace::darken(x, amount = 0.34),
  character(1)
)

pair_list <- combn(group_order, 2, simplify = FALSE)

# Lock both the outer canvas and black panel box. ggplot2 defines
# aspect.ratio as panel height / panel width.
single_plot_width_in <- 3.0
single_plot_height_in <- 4.2
panel_aspect_ratio <- 1.35

sig_label <- function(p) {
  ifelse(
    is.na(p), NA_character_,
    ifelse(p < 0.001, "***",
      ifelse(p < 0.01, "**",
        ifelse(p < 0.05, "*", "n.s.")
      )
    )
  )
}

safe_shapiro <- function(x) {
  x <- x[is.finite(x)]
  if (length(x) < 3L || length(x) > 5000L || length(unique(x)) < 3L) {
    return(c(W = NA_real_, P = NA_real_))
  }
  ans <- tryCatch(shapiro.test(x), error = function(e) NULL)
  if (is.null(ans)) c(W = NA_real_, P = NA_real_) else c(W = unname(ans$statistic), P = ans$p.value)
}

paired_cohen_dz <- function(difference) {
  difference <- difference[is.finite(difference)]
  if (length(difference) < 2L) return(NA_real_)
  difference_sd <- sd(difference)
  if (!is.finite(difference_sd) || difference_sd == 0) return(NA_real_)
  mean(difference) / difference_sd
}

paired_rank_biserial <- function(difference) {
  difference <- difference[is.finite(difference) & difference != 0]
  if (length(difference) == 0L) return(NA_real_)
  signed_ranks <- rank(abs(difference), ties.method = "average")
  positive_sum <- sum(signed_ranks[difference > 0])
  negative_sum <- sum(signed_ranks[difference < 0])
  (positive_sum - negative_sum) / (positive_sum + negative_sum)
}

# ----------------------------------------------------------------------------
# 3. Read and standardize the analysis sheet
# ----------------------------------------------------------------------------
if (!file.exists(input_file)) stop("Input workbook not found: ", input_file)

raw_df <- openxlsx::read.xlsx(input_file, sheet = "Sheet2", check.names = FALSE)

required_meta <- c("Group_full", "Group", "SampleID")
missing_meta <- setdiff(required_meta, names(raw_df))
if (length(missing_meta) > 0L) {
  stop("Missing metadata columns: ", paste(missing_meta, collapse = ", "))
}

trait_map <- data.frame(
  Original = c(
    "L*.(Lightness)45min",
    "L*.(Lightness)24h",
    "a*.(Redness)45min",
    "a*.(Redness)24h",
    "b*.(Yellowness)45min",
    "b*.(Yellowness)24h",
    "pH.45min",
    "pH.24h",
    "Drip.loss,.%",
    "Cooking.loss,.%",
    "Shear.force,.N",
    "IMF,%"
  ),
  Trait = c(
    "L_45min", "L_24h",
    "a_45min", "a_24h",
    "b_45min", "b_24h",
    "pH_45min", "pH_24h",
    "Drip_loss", "Cooking_loss",
    "Shear_force", "IMF"
  ),
  Trait_label = c(
    "45 min L*", "24 h L*",
    "45 min a*", "24 h a*",
    "45 min b*", "24 h b*",
    "45 min pH", "24 h pH",
    "Drip loss (%)", "Cooking loss (%)",
    "Shear force (N)", "IMF (%)"
  ),
  Figure = paste0("Fig1", LETTERS[1:12]),
  File_stub = c(
    "45min_L", "24h_L",
    "45min_a", "24h_a",
    "45min_b", "24h_b",
    "45min_pH", "24h_pH",
    "Drip_loss", "Cooking_loss",
    "Shear_force", "IMF"
  ),
  stringsAsFactors = FALSE
)

missing_traits <- setdiff(trait_map$Original, names(raw_df))
if (length(missing_traits) > 0L) {
  stop("Missing meat-quality columns: ", paste(missing_traits, collapse = ", "))
}

unexpected_groups <- setdiff(unique(as.character(raw_df$Group)), group_order)
if (length(unexpected_groups) > 0L) {
  stop("Unexpected group labels: ", paste(unexpected_groups, collapse = ", "))
}

sample_ids <- as.character(raw_df$SampleID)
valid_sample_id <- grepl("^[^_]+_[0-9]+$", sample_ids)
if (!all(valid_sample_id)) {
  stop("SampleID must have the form siteprefix_animalnumber. Invalid IDs: ",
       paste(sample_ids[!valid_sample_id], collapse = ", "))
}

sample_prefix <- sub("_.*$", "", sample_ids)
animal_number <- as.integer(sub("^.*_", "", sample_ids))
expected_prefix <- c(LTL = "LT", SM = "SM", PM = "PM", EAO = "AM")
prefix_matches_site <- sample_prefix == unname(expected_prefix[as.character(raw_df$Group)])
if (!all(prefix_matches_site)) {
  stop("SampleID prefixes do not agree with the anatomical-site labels: ",
       paste(sample_ids[!prefix_matches_site], collapse = ", "))
}

meat_df <- data.frame(
  Animal = factor(animal_number, levels = sort(unique(animal_number))),
  Group_full = as.character(raw_df$Group_full),
  Group = factor(as.character(raw_df$Group), levels = group_order),
  SampleID = sample_ids,
  stringsAsFactors = FALSE
)

for (i in seq_len(nrow(trait_map))) {
  meat_df[[trait_map$Trait[i]]] <- suppressWarnings(as.numeric(raw_df[[trait_map$Original[i]]]))
}

meat_long_list <- lapply(seq_len(nrow(trait_map)), function(i) {
  data.frame(
    Animal = meat_df$Animal,
    SampleID = meat_df$SampleID,
    Group = meat_df$Group,
    Group_full = meat_df$Group_full,
    Trait = trait_map$Trait[i],
    Trait_label = trait_map$Trait_label[i],
    Value = meat_df[[trait_map$Trait[i]]],
    stringsAsFactors = FALSE
  )
})
meat_long <- do.call(rbind, meat_long_list)
meat_long$Animal <- factor(meat_long$Animal, levels = levels(meat_df$Animal))
meat_long$Group <- factor(meat_long$Group, levels = group_order)
meat_long$Trait <- factor(meat_long$Trait, levels = trait_map$Trait)

# ----------------------------------------------------------------------------
# 4. Data quality checks and IQR flags (flags are not excluded)
# ----------------------------------------------------------------------------
numeric_matrix <- as.matrix(meat_df[, trait_map$Trait, drop = FALSE])
storage.mode(numeric_matrix) <- "numeric"

group_counts <- as.data.frame(table(meat_df$Group), stringsAsFactors = FALSE)
names(group_counts) <- c("Group", "n")
group_counts$Group <- as.character(group_counts$Group)

animal_site_table <- table(meat_df$Animal, meat_df$Group)
animal_site_key <- paste(meat_df$Animal, meat_df$Group, sep = "::")
n_animals <- nlevels(meat_df$Animal)
complete_pairing <- n_animals == 15L &&
  all(dim(animal_site_table) == c(15L, 4L)) &&
  all(animal_site_table == 1L)

if (!complete_pairing) {
  stop("The paired design is incomplete: expected exactly one row for each of 15 animals x 4 sites.")
}

outlier_rows <- list()
outlier_index <- 0L

for (trait in trait_map$Trait) {
  for (grp in group_order) {
    rows <- meat_long$Trait == trait & meat_long$Group == grp & is.finite(meat_long$Value)
    z <- meat_long$Value[rows]
    q1 <- unname(quantile(z, 0.25, na.rm = TRUE, type = 7))
    q3 <- unname(quantile(z, 0.75, na.rm = TRUE, type = 7))
    iqr <- q3 - q1
    lower <- q1 - 1.5 * iqr
    upper <- q3 + 1.5 * iqr
    flagged <- which(rows & (meat_long$Value < lower | meat_long$Value > upper))
    if (length(flagged) > 0L) {
      for (idx in flagged) {
        outlier_index <- outlier_index + 1L
        outlier_rows[[outlier_index]] <- data.frame(
          SampleID = meat_long$SampleID[idx],
          Group = as.character(meat_long$Group[idx]),
          Trait = as.character(meat_long$Trait[idx]),
          Trait_label = meat_long$Trait_label[idx],
          Value = meat_long$Value[idx],
          Q1 = q1,
          Q3 = q3,
          IQR_lower = lower,
          IQR_upper = upper,
          stringsAsFactors = FALSE
        )
      }
    }
  }
}

if (length(outlier_rows) == 0L) {
  iqr_outliers <- data.frame(
    SampleID = character(), Group = character(), Trait = character(),
    Trait_label = character(), Value = numeric(), Q1 = numeric(), Q3 = numeric(),
    IQR_lower = numeric(), IQR_upper = numeric(), stringsAsFactors = FALSE
  )
} else {
  iqr_outliers <- do.call(rbind, outlier_rows)
}

dq_checks <- data.frame(
  Check = c(
    "Analysis sheet", "Rows", "Animals", "Anatomical sites", "Samples per site",
    "Complete Animal x Site pairing", "Duplicate Animal x Site", "Traits",
    "Duplicate SampleID", "Missing metadata values",
    "Missing trait values", "Non-finite trait values", "IQR outlier flags"
  ),
  Result = c(
    "Sheet2",
    nrow(meat_df),
    n_animals,
    length(unique(meat_df$Group)),
    paste(paste(group_counts$Group, group_counts$n, sep = "="), collapse = "; "),
    ifelse(complete_pairing, "15 animals x 4 sites", "Incomplete"),
    sum(duplicated(animal_site_key)),
    length(trait_map$Trait),
    sum(duplicated(meat_df$SampleID)),
    sum(is.na(meat_df[, required_meta, drop = FALSE])),
    sum(is.na(numeric_matrix)),
    sum(!is.finite(numeric_matrix) & !is.na(numeric_matrix)),
    nrow(iqr_outliers)
  ),
  Status = c(
    "PASS", "PASS", ifelse(n_animals == 15L, "PASS", "CHECK"), "PASS", "PASS",
    ifelse(complete_pairing, "PASS", "CHECK"),
    ifelse(sum(duplicated(animal_site_key)) == 0L, "PASS", "CHECK"), "PASS",
    ifelse(sum(duplicated(meat_df$SampleID)) == 0L, "PASS", "CHECK"),
    ifelse(sum(is.na(meat_df[, required_meta, drop = FALSE])) == 0L, "PASS", "CHECK"),
    ifelse(sum(is.na(numeric_matrix)) == 0L, "PASS", "CHECK"),
    ifelse(sum(!is.finite(numeric_matrix) & !is.na(numeric_matrix)) == 0L, "PASS", "CHECK"),
    "REVIEW_ONLY"
  ),
  Details = c(
    "Sheet2 is the tidy sample-level analysis table.",
    "Expected 60 sample rows.",
    "Animal identity was extracted from the numeric SampleID suffix.",
    "Expected LTL, SM, PM, and EAO.",
    "Balanced design expected: n=15 per site.",
    "Each animal must contribute one LTL, SM, PM, and EAO observation.",
    "Duplicate animal-site rows would invalidate the repeated-measures structure.",
    "Twelve meat-quality traits were analyzed.",
    "Sample IDs must be unique.",
    "Group, full group label, and SampleID checked.",
    "All 12 quantitative traits checked.",
    "Inf and -Inf checked separately from missing values.",
    "Within-site 1.5xIQR flags are reported but retained in all analyses."
  ),
  stringsAsFactors = FALSE
)

# ----------------------------------------------------------------------------
# 5. Descriptive statistics
# ----------------------------------------------------------------------------
summary_rows <- list()
row_index <- 0L

for (i in seq_len(nrow(trait_map))) {
  trait <- trait_map$Trait[i]
  label <- trait_map$Trait_label[i]
  for (grp in group_order) {
    z <- meat_df[meat_df$Group == grp, trait]
    z <- z[is.finite(z)]
    row_index <- row_index + 1L
    summary_rows[[row_index]] <- data.frame(
      Trait = trait,
      Trait_label = label,
      Group = grp,
      Anatomical_site = unname(group_full_label[grp]),
      n = length(z),
      Mean = mean(z),
      SD = sd(z),
      SEM = sd(z) / sqrt(length(z)),
      Median = median(z),
      Q1 = unname(quantile(z, 0.25)),
      Q3 = unname(quantile(z, 0.75)),
      Min = min(z),
      Max = max(z),
      CV_percent = ifelse(mean(z) == 0, NA_real_, 100 * sd(z) / abs(mean(z))),
      Mean_SEM = sprintf("%.3f ± %.3f", mean(z), sd(z) / sqrt(length(z))),
      stringsAsFactors = FALSE
    )
  }
}

descriptive_stats <- do.call(rbind, summary_rows)
descriptive_stats$Group <- factor(descriptive_stats$Group, levels = group_order)
descriptive_stats <- descriptive_stats[order(match(descriptive_stats$Trait, trait_map$Trait), descriptive_stats$Group), ]
descriptive_stats$Group <- as.character(descriptive_stats$Group)
rownames(descriptive_stats) <- NULL

# ----------------------------------------------------------------------------
# 6. Paired inference: mixed model plus non-parametric sensitivity analysis
# ----------------------------------------------------------------------------
normality_rows <- list()
residual_normality_rows <- list()
mixed_model_rows <- list()
friedman_rows <- list()
lmm_pairwise_rows <- list()
wilcox_rows <- list()

site_design <- model.matrix(
  ~ Site,
  data = data.frame(Site = factor(group_order, levels = group_order))
)
rownames(site_design) <- group_order

for (i in seq_len(nrow(trait_map))) {
  trait <- trait_map$Trait[i]
  label <- trait_map$Trait_label[i]
  trait_df <- data.frame(
    Animal = meat_df$Animal,
    Site = factor(meat_df$Group, levels = group_order),
    Value = meat_df[[trait]],
    stringsAsFactors = FALSE
  )
  trait_df <- trait_df[is.finite(trait_df$Value) & !is.na(trait_df$Site), , drop = FALSE]

  trait_pairing <- table(trait_df$Animal, trait_df$Site)
  if (!all(dim(trait_pairing) == c(15L, 4L)) || !all(trait_pairing == 1L)) {
    stop("Incomplete paired observations for trait: ", trait)
  }

  for (grp in group_order) {
    z <- trait_df$Value[trait_df$Site == grp]
    sh <- safe_shapiro(z)
    normality_rows[[length(normality_rows) + 1L]] <- data.frame(
      Trait = trait,
      Trait_label = label,
      Site = grp,
      Anatomical_site = unname(group_full_label[grp]),
      n = length(z),
      Shapiro_W = sh["W"],
      P_value = sh["P"],
      Interpretation = ifelse(
        is.na(sh["P"]), "Not tested",
        ifelse(sh["P"] > 0.05, "No evidence against normality", "Evidence against normality")
      ),
      stringsAsFactors = FALSE
    )
  }

  lmm <- tryCatch(
    nlme::lme(
      fixed = Value ~ Site,
      random = ~ 1 | Animal,
      data = trait_df,
      method = "REML",
      na.action = na.fail,
      control = nlme::lmeControl(msMaxIter = 200L, niterEM = 50L)
    ),
    error = function(e) {
      stop("Mixed model failed for ", trait, ": ", conditionMessage(e))
    }
  )

  model_anova <- anova(lmm)
  site_anova <- model_anova["Site", , drop = FALSE]
  variance_components <- nlme::VarCorr(lmm)
  random_variance <- as.numeric(as.character(variance_components[1, "Variance"]))
  residual_variance <- as.numeric(as.character(variance_components[nrow(variance_components), "Variance"]))
  normalized_residuals <- residuals(lmm, type = "normalized")
  residual_shapiro <- safe_shapiro(normalized_residuals)

  mixed_model_rows[[length(mixed_model_rows) + 1L]] <- data.frame(
    Trait = trait,
    Trait_label = label,
    Model = "Value ~ Site + (1|Animal)",
    Estimation = "REML",
    n_animals = nlevels(droplevels(trait_df$Animal)),
    n_observations = nrow(trait_df),
    Site_numDF = unname(site_anova$numDF),
    Site_denDF = unname(site_anova$denDF),
    Site_F = unname(site_anova$`F-value`),
    Site_P = unname(site_anova$`p-value`),
    Site_Sig = sig_label(unname(site_anova$`p-value`)),
    Random_intercept_variance = random_variance,
    Residual_variance = residual_variance,
    ICC = random_variance / (random_variance + residual_variance),
    stringsAsFactors = FALSE
  )

  residual_normality_rows[[length(residual_normality_rows) + 1L]] <- data.frame(
    Trait = trait,
    Trait_label = label,
    n = length(normalized_residuals),
    Shapiro_W = residual_shapiro["W"],
    P_value = residual_shapiro["P"],
    Interpretation = ifelse(
      is.na(residual_shapiro["P"]), "Not tested",
      ifelse(residual_shapiro["P"] > 0.05, "No evidence against normality", "Evidence against normality")
    ),
    stringsAsFactors = FALSE
  )

  friedman_result <- friedman.test(Value ~ Site | Animal, data = trait_df)
  friedman_rows[[length(friedman_rows) + 1L]] <- data.frame(
    Trait = trait,
    Trait_label = label,
    n_animals = nlevels(droplevels(trait_df$Animal)),
    Friedman_chisq = unname(friedman_result$statistic),
    Friedman_df = unname(friedman_result$parameter),
    P_value = friedman_result$p.value,
    Sig = sig_label(friedman_result$p.value),
    stringsAsFactors = FALSE
  )

  fixed_effects <- nlme::fixef(lmm)
  fixed_vcov <- vcov(lmm)
  current_site_design <- site_design[, names(fixed_effects), drop = FALSE]
  estimated_site_means <- as.numeric(current_site_design %*% fixed_effects)
  names(estimated_site_means) <- rownames(current_site_design)
  contrast_df <- unname(site_anova$denDF)

  trait_lmm_pairs <- vector("list", length(pair_list))
  trait_wilcox_pairs <- vector("list", length(pair_list))

  for (j in seq_along(pair_list)) {
    g1 <- pair_list[[j]][1]
    g2 <- pair_list[[j]][2]

    g1_data <- trait_df[trait_df$Site == g1, c("Animal", "Value"), drop = FALSE]
    g2_data <- trait_df[trait_df$Site == g2, c("Animal", "Value"), drop = FALSE]
    names(g1_data)[2] <- "Value1"
    names(g2_data)[2] <- "Value2"
    paired_data <- merge(g1_data, g2_data, by = "Animal", all = FALSE, sort = TRUE)
    paired_data <- paired_data[is.finite(paired_data$Value1) & is.finite(paired_data$Value2), , drop = FALSE]
    if (nrow(paired_data) != 15L) {
      stop("Expected 15 matched pairs for ", trait, ", ", g1, " vs ", g2)
    }
    paired_difference <- paired_data$Value1 - paired_data$Value2

    contrast_vector <- current_site_design[g1, ] - current_site_design[g2, ]
    estimated_difference <- unname(sum(contrast_vector * fixed_effects))
    contrast_se <- sqrt(as.numeric(t(contrast_vector) %*% fixed_vcov %*% contrast_vector))
    contrast_t <- estimated_difference / contrast_se
    contrast_p <- 2 * pt(abs(contrast_t), df = contrast_df, lower.tail = FALSE)
    critical_t <- qt(0.975, df = contrast_df)

    trait_lmm_pairs[[j]] <- data.frame(
      Trait = trait,
      Trait_label = label,
      Group1 = g1,
      Group2 = g2,
      Comparison = paste(g1, "vs", g2),
      n_pairs = nrow(paired_data),
      Estimated_mean1 = unname(estimated_site_means[g1]),
      Estimated_mean2 = unname(estimated_site_means[g2]),
      Model_estimated_difference = estimated_difference,
      Observed_paired_mean_difference = mean(paired_difference),
      SE = contrast_se,
      df = contrast_df,
      t = contrast_t,
      CI95_lower = estimated_difference - critical_t * contrast_se,
      CI95_upper = estimated_difference + critical_t * contrast_se,
      Cohen_dz = paired_cohen_dz(paired_difference),
      P_raw = contrast_p,
      stringsAsFactors = FALSE
    )

    wilcox_result <- wilcox.test(
      paired_data$Value1,
      paired_data$Value2,
      paired = TRUE,
      exact = FALSE,
      correct = TRUE
    )
    trait_wilcox_pairs[[j]] <- data.frame(
      Trait = trait,
      Trait_label = label,
      Group1 = g1,
      Group2 = g2,
      Comparison = paste(g1, "vs", g2),
      n_pairs = nrow(paired_data),
      n_nonzero_differences = sum(paired_difference != 0),
      Median1 = median(paired_data$Value1),
      Median2 = median(paired_data$Value2),
      Median_paired_difference = median(paired_difference),
      Wilcoxon_V = unname(wilcox_result$statistic),
      Rank_biserial_paired = paired_rank_biserial(paired_difference),
      P_raw = wilcox_result$p.value,
      stringsAsFactors = FALSE
    )
  }

  trait_lmm_pairs <- do.call(rbind, trait_lmm_pairs)
  trait_lmm_pairs$P_adj_BH <- p.adjust(trait_lmm_pairs$P_raw, method = "BH")
  trait_lmm_pairs$P_adj_Holm <- p.adjust(trait_lmm_pairs$P_raw, method = "holm")
  trait_lmm_pairs$Sig_BH <- sig_label(trait_lmm_pairs$P_adj_BH)
  trait_lmm_pairs$Sig_Holm <- sig_label(trait_lmm_pairs$P_adj_Holm)

  trait_wilcox_pairs <- do.call(rbind, trait_wilcox_pairs)
  trait_wilcox_pairs$P_adj_BH <- p.adjust(trait_wilcox_pairs$P_raw, method = "BH")
  trait_wilcox_pairs$P_adj_Holm <- p.adjust(trait_wilcox_pairs$P_raw, method = "holm")
  trait_wilcox_pairs$Sig_BH <- sig_label(trait_wilcox_pairs$P_adj_BH)
  trait_wilcox_pairs$Sig_Holm <- sig_label(trait_wilcox_pairs$P_adj_Holm)

  lmm_pairwise_rows[[length(lmm_pairwise_rows) + 1L]] <- trait_lmm_pairs
  wilcox_rows[[length(wilcox_rows) + 1L]] <- trait_wilcox_pairs
}

normality_by_group <- do.call(rbind, normality_rows)
normality_model_residuals <- do.call(rbind, residual_normality_rows)
mixed_model_omnibus <- do.call(rbind, mixed_model_rows)
friedman_tests <- do.call(rbind, friedman_rows)
pairwise_lmm <- do.call(rbind, lmm_pairwise_rows)
pairwise_wilcox_paired <- do.call(rbind, wilcox_rows)

mixed_model_omnibus$Site_P_adj_BH_across_traits <- p.adjust(mixed_model_omnibus$Site_P, method = "BH")
mixed_model_omnibus$Site_Sig_BH_across_traits <- sig_label(mixed_model_omnibus$Site_P_adj_BH_across_traits)
friedman_tests$P_adj_BH_across_traits <- p.adjust(friedman_tests$P_value, method = "BH")
friedman_tests$Sig_BH_across_traits <- sig_label(friedman_tests$P_adj_BH_across_traits)

significant_pairs_bh <- pairwise_lmm[pairwise_lmm$P_adj_BH < 0.05, , drop = FALSE]

comparison_keys_match <-
  pairwise_lmm$Trait == pairwise_wilcox_paired$Trait &
  pairwise_lmm$Comparison == pairwise_wilcox_paired$Comparison
stopifnot(all(comparison_keys_match))

paired_sensitivity_concordance <- data.frame(
  Trait = pairwise_lmm$Trait,
  Trait_label = pairwise_lmm$Trait_label,
  Comparison = pairwise_lmm$Comparison,
  n_pairs = pairwise_lmm$n_pairs,
  LMM_difference = pairwise_lmm$Model_estimated_difference,
  LMM_P_adj_BH = pairwise_lmm$P_adj_BH,
  LMM_Sig_BH = pairwise_lmm$Sig_BH,
  Paired_Wilcoxon_median_difference = pairwise_wilcox_paired$Median_paired_difference,
  Paired_Wilcoxon_P_adj_BH = pairwise_wilcox_paired$P_adj_BH,
  Paired_Wilcoxon_Sig_BH = pairwise_wilcox_paired$Sig_BH,
  Same_significance_decision =
    (pairwise_lmm$P_adj_BH < 0.05) == (pairwise_wilcox_paired$P_adj_BH < 0.05),
  Same_direction =
    sign(pairwise_lmm$Model_estimated_difference) ==
    sign(pairwise_wilcox_paired$Median_paired_difference),
  stringsAsFactors = FALSE
)

normality_by_group <- `rownames<-`(normality_by_group, NULL)
normality_model_residuals <- `rownames<-`(normality_model_residuals, NULL)
mixed_model_omnibus <- `rownames<-`(mixed_model_omnibus, NULL)
friedman_tests <- `rownames<-`(friedman_tests, NULL)
pairwise_lmm <- `rownames<-`(pairwise_lmm, NULL)
pairwise_wilcox_paired <- `rownames<-`(pairwise_wilcox_paired, NULL)
significant_pairs_bh <- `rownames<-`(significant_pairs_bh, NULL)
paired_sensitivity_concordance <- `rownames<-`(paired_sensitivity_concordance, NULL)

# ----------------------------------------------------------------------------
# 7. Figure annotation data using BH-adjusted mixed-model paired contrasts
# ----------------------------------------------------------------------------
plot_significance <- pairwise_lmm
plot_significance$xmin <- match(plot_significance$Group1, group_order)
plot_significance$xmax <- match(plot_significance$Group2, group_order)
plot_significance$xmid <- (plot_significance$xmin + plot_significance$xmax) / 2
plot_significance$annotation <- plot_significance$Sig_BH
plot_significance$y_position <- NA_real_

for (trait in trait_map$Trait) {
  z <- meat_long$Value[meat_long$Trait == trait]
  z <- z[is.finite(z)]
  z_range <- diff(range(z))
  if (!is.finite(z_range) || z_range == 0) z_range <- max(abs(z), 1) * 0.1
  rows <- which(plot_significance$Trait == trait)
  plot_significance$y_position[rows] <- max(z) + z_range * (0.12 + 0.10 * (seq_along(rows) - 1))
}

# ----------------------------------------------------------------------------
# 8. Plot function: narrow reference style with independently editable X labels
# ----------------------------------------------------------------------------
make_trait_plot <- function(trait, label, seed_value) {
  d <- meat_long[meat_long$Trait == trait & is.finite(meat_long$Value), , drop = FALSE]
  d$Group <- factor(d$Group, levels = group_order)
  s <- descriptive_stats[descriptive_stats$Trait == trait, , drop = FALSE]
  s$Group <- factor(s$Group, levels = group_order)
  a <- plot_significance[plot_significance$Trait == trait, , drop = FALSE]

  z_range <- diff(range(d$Value))
  if (!is.finite(z_range) || z_range == 0) z_range <- max(abs(d$Value), 1) * 0.1
  lower_limit <- min(d$Value) - 0.07 * z_range
  upper_limit <- max(a$y_position) + 0.10 * z_range

  # The default ggplot2 discrete axis stores all tick labels in one vectorized
  # text grob. Four one-label layers keep LTL/SM/PM/EAO separate in vector files.
  independent_x_label_layers <- lapply(seq_along(group_order), function(i) {
    annotate(
      "text",
      x = i,
      y = -Inf,
      label = group_order[i],
      family = "Arial",
      fontface = "bold",
      size = 3.23,
      color = "#1F2328",
      vjust = 1.70
    )
  })

  ggplot(d, aes(x = Group, y = Value)) +
    geom_point(
      aes(fill = Group),
      position = position_jitter(width = 0.16, height = 0, seed = seed_value),
      shape = 21,
      size = 3.2,
      stroke = 0.45,
      alpha = 0.92,
      color = "#1F2328"
    ) +
    geom_errorbar(
      data = s,
      aes(x = Group, ymin = Mean - SEM, ymax = Mean + SEM, color = Group),
      inherit.aes = FALSE,
      width = 0.12,
      linewidth = 0.75
    ) +
    geom_point(
      data = s,
      aes(x = Group, y = Mean, color = Group),
      inherit.aes = FALSE,
      size = 3.0,
      stroke = 0.45
    ) +
    geom_segment(
      data = a,
      aes(x = xmin, xend = xmax, y = y_position, yend = y_position),
      inherit.aes = FALSE,
      linewidth = 0.38,
      color = "#2B2B2B"
    ) +
    geom_text(
      data = a,
      aes(x = xmid, y = y_position + 0.018 * z_range, label = annotation),
      inherit.aes = FALSE,
      size = 3.05,
      vjust = 0,
      color = "#252525"
    ) +
    independent_x_label_layers +
    scale_fill_manual(values = site_colors, drop = FALSE) +
    scale_color_manual(values = site_colors_dark, drop = FALSE) +
    scale_x_discrete(drop = FALSE, labels = NULL) +
    scale_y_continuous(
      limits = c(lower_limit, upper_limit),
      expand = expansion(mult = c(0, 0))
    ) +
    coord_cartesian(clip = "off") +
    labs(
      x = NULL,
      y = label
    ) +
    theme_bw(base_size = 10.5, base_family = "Arial") +
    theme(
      aspect.ratio = panel_aspect_ratio,
      legend.position = "none",
      panel.grid = element_blank(),
      panel.border = element_rect(color = "#1F1F1F", linewidth = 0.5),
      axis.text.x = element_blank(),
      axis.text.y = element_text(color = "#30363D", size = 8.5),
      axis.title.y = element_text(color = "#1F2328", size = 10.5, margin = margin(r = 7)),
      axis.ticks = element_line(color = "#1F1F1F", linewidth = 0.4),
      axis.ticks.length = unit(2, "mm"),
      plot.margin = margin(t = 4, r = 7, b = 16, l = 7)
    )
}

plot_list <- vector("list", nrow(trait_map))
names(plot_list) <- trait_map$Trait

for (i in seq_len(nrow(trait_map))) {
  p <- make_trait_plot(trait_map$Trait[i], trait_map$Trait_label[i], 20260822 + i)
  plot_list[[i]] <- p
}

# Use a common set of gtable widths and heights for every individual export.
# This prevents long or short Y-axis tick labels from changing the panel-box size.
align_plot_grobs <- function(plot_objects) {
  grobs <- lapply(plot_objects, ggplotGrob)
  common_widths <- Reduce(unit.pmax, lapply(grobs, function(g) g$widths))
  common_heights <- Reduce(unit.pmax, lapply(grobs, function(g) g$heights))

  lapply(grobs, function(g) {
    g$widths <- common_widths
    g$heights <- common_heights
    g
  })
}

# Build text metrics on a Cairo device so the installed TrueType Arial files
# are used during gtable alignment as well as during final PDF/PNG rendering.
font_metric_device <- tempfile(fileext = ".pdf")
cairo_pdf(font_metric_device, width = single_plot_width_in, height = single_plot_height_in, bg = "white")
aligned_grobs <- tryCatch(
  align_plot_grobs(plot_list),
  finally = {
    dev.off()
    unlink(font_metric_device)
  }
)

same_widths <- vapply(
  aligned_grobs,
  function(g) identical(g$widths, aligned_grobs[[1]]$widths),
  logical(1)
)
same_heights <- vapply(
  aligned_grobs,
  function(g) identical(g$heights, aligned_grobs[[1]]$heights),
  logical(1)
)
stopifnot(all(same_widths), all(same_heights))

panel_layout_qa <- data.frame(
  Figure = trait_map$Figure,
  Trait = trait_map$Trait,
  Panel_height_to_width = panel_aspect_ratio,
  Shared_gtable_widths = same_widths,
  Shared_gtable_heights = same_heights,
  Canvas_width_in = single_plot_width_in,
  Canvas_height_in = single_plot_height_in,
  stringsAsFactors = FALSE
)

for (i in seq_len(nrow(trait_map))) {

  output_base <- paste0(trait_map$Figure[i], "_", trait_map$File_stub[i], "_by_site")
  ggsave(
    filename = file.path(figure_dir, paste0(output_base, ".pdf")),
    plot = aligned_grobs[[i]],
    width = single_plot_width_in,
    height = single_plot_height_in,
    units = "in",
    device = cairo_pdf,
    bg = "white"
  )
  ggsave(
    filename = file.path(figure_dir, paste0(output_base, ".png")),
    plot = aligned_grobs[[i]],
    width = single_plot_width_in,
    height = single_plot_height_in,
    units = "in",
    dpi = 600,
    bg = "white"
  )
}

draw_plot_grid <- function(plot_grobs, nrow = 3L, ncol = 4L) {
  grid.newpage()
  layout <- grid.layout(nrow = nrow, ncol = ncol)
  pushViewport(viewport(layout = layout))
  for (i in seq_along(plot_grobs)) {
    row_id <- ((i - 1L) %/% ncol) + 1L
    col_id <- ((i - 1L) %% ncol) + 1L
    pushViewport(viewport(layout.pos.row = row_id, layout.pos.col = col_id))
    grid.draw(plot_grobs[[i]])
    popViewport()
  }
  popViewport()
}

combined_pdf <- file.path(figure_dir, "Figure1_all_meat_quality_traits_4x3.pdf")
cairo_pdf(combined_pdf, width = 4 * single_plot_width_in, height = 3 * single_plot_height_in, bg = "white")
draw_plot_grid(aligned_grobs, nrow = 3L, ncol = 4L)
dev.off()

combined_png <- file.path(figure_dir, "Figure1_all_meat_quality_traits_4x3.png")
png(
  combined_png,
  width = 4 * single_plot_width_in,
  height = 3 * single_plot_height_in,
  units = "in",
  res = 300,
  bg = "white",
  type = "cairo"
)
draw_plot_grid(aligned_grobs, nrow = 3L, ncol = 4L)
dev.off()

# ----------------------------------------------------------------------------
# 9. Export reproducible tables
# ----------------------------------------------------------------------------
group_dictionary <- data.frame(
  Group = group_order,
  Anatomical_site = unname(group_full_label[group_order]),
  n = as.integer(group_counts$n[match(group_order, group_counts$Group)]),
  Fill_color = unname(site_colors[group_order]),
  Outline_color = unname(site_colors_dark[group_order]),
  stringsAsFactors = FALSE
)

clean_data_export <- meat_df
clean_data_export$Animal <- as.character(clean_data_export$Animal)
clean_data_export$Group <- as.character(clean_data_export$Group)

clean_long_export <- meat_long
clean_long_export$Animal <- as.character(clean_long_export$Animal)
clean_long_export$Group <- as.character(clean_long_export$Group)
clean_long_export$Trait <- as.character(clean_long_export$Trait)

pairing_manifest <- meat_df[, c("Animal", "Group", "SampleID"), drop = FALSE]
pairing_manifest$Animal <- as.character(pairing_manifest$Animal)
pairing_manifest$Group <- as.character(pairing_manifest$Group)
pairing_manifest <- pairing_manifest[
  order(as.integer(pairing_manifest$Animal), match(pairing_manifest$Group, group_order)),
  ,
  drop = FALSE
]
rownames(pairing_manifest) <- NULL

analysis_methods <- data.frame(
  Component = c(
    "Study design",
    "Primary omnibus test",
    "Primary pairwise comparisons",
    "Pairwise multiplicity control",
    "Figure annotations",
    "Non-parametric omnibus sensitivity",
    "Non-parametric pairwise sensitivity",
    "Sensitivity multiplicity control",
    "Outlier handling"
  ),
  Method = c(
    "Repeated measures: four anatomical sites from each of 15 animals",
    "REML random-intercept mixed model: Trait ~ Site + (1|Animal)",
    "Six Site contrasts derived from the fitted mixed model",
    "Benjamini-Hochberg adjustment across six contrasts within each trait",
    "Significance symbols use primary mixed-model BH-adjusted P values",
    "Friedman test blocked by Animal",
    "Paired Wilcoxon signed-rank test after matching on Animal",
    "Benjamini-Hochberg adjustment across six contrasts within each trait",
    "Within-site 1.5xIQR flags reported; no observations removed"
  ),
  stringsAsFactors = FALSE
)

workbook_file <- file.path(table_dir, "meat_quality_statistics_by_site.xlsx")
wb <- createWorkbook()
header_style <- createStyle(
  fontColour = "#FFFFFF",
  fgFill = "#365B8C",
  textDecoration = "bold",
  halign = "center",
  valign = "center"
)

table_list <- list(
  Data_quality = dq_checks,
  Analysis_methods = analysis_methods,
  Pairing_manifest = pairing_manifest,
  Group_dictionary = group_dictionary,
  Clean_data = clean_data_export,
  Clean_long = clean_long_export,
  Descriptive_stats = descriptive_stats,
  Normality_by_group = normality_by_group,
  LMM_residual_normality = normality_model_residuals,
  Mixed_model_omnibus = mixed_model_omnibus,
  Friedman_tests = friedman_tests,
  Pairwise_LMM_BH = pairwise_lmm,
  Significant_pairs_BH = significant_pairs_bh,
  Pairwise_Wilcox_paired_BH = pairwise_wilcox_paired,
  Sensitivity_concordance = paired_sensitivity_concordance,
  Plot_significance = plot_significance,
  Panel_layout_QA = panel_layout_qa,
  IQR_outlier_flags = iqr_outliers
)

for (sheet_name in names(table_list)) {
  dat <- table_list[[sheet_name]]
  addWorksheet(wb, sheet_name, gridLines = FALSE)
  writeData(wb, sheet_name, dat, headerStyle = header_style, withFilter = nrow(dat) > 0L)
  freezePane(wb, sheet_name, firstRow = TRUE)
  setColWidths(wb, sheet_name, cols = seq_len(max(1L, ncol(dat))), widths = "auto")
}

saveWorkbook(wb, workbook_file, overwrite = TRUE)

write.table(descriptive_stats, file.path(table_dir, "meat_quality_descriptive_statistics.tsv"), sep = "\t", row.names = FALSE, quote = FALSE, na = "NA")
write.table(mixed_model_omnibus, file.path(table_dir, "meat_quality_mixed_model_omnibus.tsv"), sep = "\t", row.names = FALSE, quote = FALSE, na = "NA")
write.table(friedman_tests, file.path(table_dir, "meat_quality_friedman_tests.tsv"), sep = "\t", row.names = FALSE, quote = FALSE, na = "NA")
write.table(pairwise_lmm, file.path(table_dir, "meat_quality_pairwise_LMM_BH.tsv"), sep = "\t", row.names = FALSE, quote = FALSE, na = "NA")
write.table(significant_pairs_bh, file.path(table_dir, "meat_quality_significant_pairs_BH.tsv"), sep = "\t", row.names = FALSE, quote = FALSE, na = "NA")
write.table(pairwise_wilcox_paired, file.path(table_dir, "meat_quality_pairwise_paired_Wilcoxon_BH.tsv"), sep = "\t", row.names = FALSE, quote = FALSE, na = "NA")
write.table(paired_sensitivity_concordance, file.path(table_dir, "meat_quality_paired_sensitivity_concordance.tsv"), sep = "\t", row.names = FALSE, quote = FALSE, na = "NA")
write.table(plot_significance, file.path(table_dir, "meat_quality_plot_significance.tsv"), sep = "\t", row.names = FALSE, quote = FALSE, na = "NA")
write.table(panel_layout_qa, file.path(table_dir, "meat_quality_panel_layout_QA.tsv"), sep = "\t", row.names = FALSE, quote = FALSE, na = "NA")

obsolete_unpaired_tables <- file.path(
  table_dir,
  c(
    "meat_quality_omnibus_tests.tsv",
    "meat_quality_pairwise_Welch_BH.tsv",
    "meat_quality_pairwise_Wilcoxon_BH.tsv"
  )
)
unlink(obsolete_unpaired_tables[file.exists(obsolete_unpaired_tables)])

cat("Completed meat-quality visualization.\n")
cat("Figures:", figure_dir, "\n")
cat("Tables:", table_dir, "\n")
cat("Individual traits:", length(plot_list), "\n")
cat("Panel height/width ratio:", panel_aspect_ratio, "\n")
cat("Shared gtable widths/heights: PASS\n")
cat("Samples:", nrow(meat_df), "\n")
cat("Paired animals/sites:", n_animals, "x", length(group_order), "(PASS)\n")
cat("Primary pairwise contrasts:", nrow(pairwise_lmm), "\n")
cat("Paired Wilcoxon contrasts:", nrow(pairwise_wilcox_paired), "\n")
cat("IQR flags retained:", nrow(iqr_outliers), "\n")
