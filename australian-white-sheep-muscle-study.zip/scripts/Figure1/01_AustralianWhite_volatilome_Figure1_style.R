#!/usr/bin/env Rscript

# Australian White sheep volatilome: beef-jerky Figure 1 style panels
# Input: 03_HS_SPME/HS-SPME-metab_abund.xlsx and metab_desc.txt
# Design: 4 paired anatomical sites from 6 animals
# One-vs-rest definition: each site is compared with the within-animal mean of
# the other three sites. Marker threshold follows the reference figure:
# paired Wilcoxon raw P < 0.05, PLS-DA VIP > 1, and target/rest log2FC > 0.
# BH-FDR is additionally calculated and exported for transparent reporting.

suppressPackageStartupMessages({
  library(openxlsx)
  library(data.table)
  library(dplyr)
  library(tidyr)
  library(stringr)
  library(ggplot2)
  library(vegan)
  library(permute)
  library(ropls)
  library(ComplexHeatmap)
  library(circlize)
  library(grid)
})

options(stringsAsFactors = FALSE)
set.seed(20260909)

root_dir <- "__PROJECT_ROOT__"
work_dir <- file.path(root_dir, "02_Figure1_volatilome")
fig_dir <- file.path(work_dir, "Figures")
tab_dir <- file.path(work_dir, "Tables")
dir.create(fig_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(tab_dir, recursive = TRUE, showWarnings = FALSE)

abund_file <- file.path(root_dir, "03_HS_SPME", "HS-SPME-metab_abund.xlsx")
desc_file <- file.path(root_dir, "03_HS_SPME", "metab_desc.txt")

site_order <- c("LTL", "SM", "PM", "EAO")
site_cols <- c(
  LTL = "#355C8A",
  SM  = "#4F7D73",
  PM  = "#C28B48",
  EAO = "#A65D68"
)

class_palette <- c(
  "#E64B35", "#4DBBD5", "#00A087", "#3C5488",
  "#F39B7F", "#8491B4", "#91D1C2", "#DC0000",
  "#7E6148", "#B09C85", "#56B4E9", "#D55E00",
  "#009E73", "#CC79A7", "#0072B2", "#F0E442",
  "#999999", "#8DD3C7", "#FB8072", "#80B1D3"
)

base_theme <- function(base_size = 10.5) {
  theme_bw(base_size = base_size, base_family = "Arial") +
    theme(
      panel.grid.minor = element_blank(),
      axis.text = element_text(color = "black"),
      axis.title = element_text(color = "black"),
      legend.title = element_text(color = "black"),
      legend.text = element_text(color = "black")
    )
}

save_pdf <- function(plot, filename, width, height) {
  ggsave(
    filename = file.path(fig_dir, filename),
    plot = plot,
    width = width,
    height = height,
    units = "in",
    device = grDevices::cairo_pdf
  )
}

format_p <- function(p) {
  if (is.na(p)) return("NA")
  if (p < 0.001) return(format(p, scientific = TRUE, digits = 2))
  sprintf("%.3f", p)
}

fill_half_min <- function(mat) {
  positive <- mat[is.finite(mat) & !is.na(mat) & mat > 0]
  fill_value <- if (length(positive)) min(positive) / 2 else 1e-6
  mat[!is.finite(mat) | is.na(mat) | mat <= 0] <- fill_value
  list(mat = mat, fill_value = fill_value)
}

tic_normalize <- function(mat) {
  tic <- colSums(mat, na.rm = TRUE)
  tic[!is.finite(tic) | tic <= 0] <- 1
  sweep(mat, 2, tic / max(tic), "/")
}

safe_paired_wilcox <- function(x, y) {
  keep <- is.finite(x) & is.finite(y)
  if (sum(keep) < 3 || all(abs(x[keep] - y[keep]) < .Machine$double.eps^0.5)) {
    return(1)
  }
  tryCatch(
    wilcox.test(x[keep], y[keep], paired = TRUE, exact = FALSE)$p.value,
    error = function(e) NA_real_
  )
}

read_inputs <- function() {
  abund <- openxlsx::read.xlsx(abund_file, sheet = "metab_abund", check.names = FALSE)
  annot <- data.table::fread(desc_file, data.table = FALSE, check.names = FALSE)
  abund[["metab_id"]] <- as.character(abund[["metab_id"]])
  annot[["metab_id"]] <- as.character(annot[["metab_id"]])
  annot <- annot[!duplicated(annot[["metab_id"]]), , drop = FALSE]

  sample_ids <- grep("^(LTHF|SMHF|PMHF|AMHF)_[1-6]$", names(abund), value = TRUE)
  meta <- data.frame(
    SampleID = sample_ids,
    Site = sub("HF_.*$", "", sample_ids),
    Animal = sub("^.*_", "", sample_ids),
    stringsAsFactors = FALSE
  )
  meta[["Site"]] <- recode(meta[["Site"]], LT = "LTL", SM = "SM", PM = "PM", AM = "EAO")
  meta[["Site"]] <- factor(meta[["Site"]], levels = site_order)
  meta[["Animal"]] <- factor(meta[["Animal"]], levels = as.character(1:6))
  meta <- meta[order(meta[["Site"]], meta[["Animal"]]), , drop = FALSE]

  mat <- as.matrix(abund[, meta[["SampleID"]], drop = FALSE])
  storage.mode(mat) <- "numeric"
  rownames(mat) <- abund[["metab_id"]]
  imp <- fill_half_min(mat)
  mat_tic <- tic_normalize(imp$mat)
  mat_log <- log10(mat_tic + 1)

  common <- intersect(rownames(mat_log), annot[["metab_id"]])
  mat_tic <- mat_tic[common, meta[["SampleID"]], drop = FALSE]
  mat_log <- mat_log[common, meta[["SampleID"]], drop = FALSE]
  annot <- annot[match(common, annot[["metab_id"]]), , drop = FALSE]

  list(
    annot = annot,
    meta = meta,
    mat_tic = mat_tic,
    mat_log = mat_log,
    fill_value = imp$fill_value
  )
}

dat <- read_inputs()
annot <- dat$annot
meta <- dat$meta
mat_tic <- dat$mat_tic
mat_log <- dat$mat_log

annot[["Metabolite"]] <- as.character(annot[["Metabolite"]])
annot[["Metabolite"]][is.na(annot[["Metabolite"]]) | annot[["Metabolite"]] == ""] <- annot[["metab_id"]][is.na(annot[["Metabolite"]]) | annot[["Metabolite"]] == ""]
annot[["Volatile_Class1"]] <- as.character(annot[["Volatile_Class1"]])
annot[["Volatile_Class1"]][is.na(annot[["Volatile_Class1"]]) | annot[["Volatile_Class1"]] %in% c("", "-")] <- "Unknown"

# -----------------------------------------------------------------------------
# Panel A: mean abundance of each volatile class
# -----------------------------------------------------------------------------
class_map <- annot[, c("metab_id", "Volatile_Class1"), drop = FALSE]
class_long <- data.frame(metab_id = rownames(mat_log), mat_log, check.names = FALSE) |>
  pivot_longer(-metab_id, names_to = "SampleID", values_to = "Abundance") |>
  left_join(class_map, by = "metab_id")

class_mean <- class_long |>
  group_by(Volatile_Class1) |>
  summarise(
    n_metabolites = n_distinct(metab_id),
    Mean_abundance = sum(Abundance, na.rm = TRUE) / n_distinct(SampleID),
    .groups = "drop"
  ) |>
  arrange(Mean_abundance)

class_mean[["Volatile_Class1"]] <- factor(class_mean[["Volatile_Class1"]], levels = class_mean[["Volatile_Class1"]])
polar_cols <- rep(c("#111111", "#BDBDBD"), length.out = nrow(class_mean))
names(polar_cols) <- levels(class_mean[["Volatile_Class1"]])

p_a <- ggplot(class_mean, aes(x = Volatile_Class1, y = Mean_abundance, fill = Volatile_Class1)) +
  geom_col(width = 0.55, color = "white", linewidth = 0.25) +
  coord_polar(start = pi / 2, clip = "off") +
  scale_x_discrete(labels = function(x) stringr::str_wrap(x, width = 17)) +
  scale_fill_manual(values = polar_cols) +
  base_theme(10.5) +
  labs(x = NULL, y = "Mean abundance of each volatile class") +
  theme(
    panel.grid.major.x = element_blank(),
    panel.grid.minor = element_blank(),
    axis.text.x = element_text(size = 7.8, lineheight = 0.9),
    axis.text.y = element_text(size = 8.5),
    legend.position = "none",
    plot.margin = margin(18, 32, 18, 32)
  )
save_pdf(p_a, "Fig1V_A_volatile_class_mean_abundance_polar.pdf", 6.2, 5.5)

# -----------------------------------------------------------------------------
# Panel B: top 30 odour descriptors and volatile-class composition
# -----------------------------------------------------------------------------
odour_long <- annot |>
  select(metab_id, Metabolite, Odour, Volatile_Class1) |>
  mutate(Odour = as.character(Odour)) |>
  filter(!is.na(Odour), !Odour %in% c("", "-")) |>
  separate_rows(Odour, sep = ";") |>
  mutate(Odour = str_to_lower(str_squish(Odour))) |>
  filter(!is.na(Odour), !Odour %in% c("", "-")) |>
  distinct(metab_id, Odour, .keep_all = TRUE)

odour_total <- odour_long |>
  count(Odour, name = "TotalCount") |>
  arrange(desc(TotalCount), Odour)
top_odours <- head(odour_total[["Odour"]], 30)
odour_plot <- odour_long |>
  filter(Odour %in% top_odours) |>
  count(Odour, Volatile_Class1, name = "Count") |>
  group_by(Odour) |>
  mutate(TotalCount = sum(Count)) |>
  ungroup()
odour_order <- odour_plot |>
  distinct(Odour, TotalCount) |>
  arrange(desc(TotalCount), Odour) |>
  pull(Odour)
class_order <- odour_plot |>
  group_by(Volatile_Class1) |>
  summarise(ClassTotal = sum(Count), .groups = "drop") |>
  arrange(desc(ClassTotal)) |>
  pull(Volatile_Class1)
class_order <- c(setdiff(class_order, "Unknown"), intersect(class_order, "Unknown"))
odour_plot[["Odour"]] <- factor(odour_plot[["Odour"]], levels = rev(odour_order))
odour_plot[["Volatile_Class1"]] <- factor(odour_plot[["Volatile_Class1"]], levels = class_order)
class_cols <- rep(class_palette, length.out = length(class_order))
names(class_cols) <- class_order
if ("Unknown" %in% names(class_cols)) class_cols[["Unknown"]] <- "#BDBDBD"
odour_labels <- distinct(odour_plot, Odour, TotalCount)

p_b <- ggplot(odour_plot, aes(x = Count, y = Odour, fill = Volatile_Class1)) +
  geom_col(width = 0.72, color = "white", linewidth = 0.2) +
  geom_text(
    data = odour_labels,
    aes(x = TotalCount, y = Odour, label = TotalCount),
    inherit.aes = FALSE,
    hjust = -0.18,
    size = 3.0,
    family = "Arial"
  ) +
  scale_fill_manual(values = class_cols) +
  scale_x_continuous(expand = expansion(mult = c(0, 0.13))) +
  base_theme(10.5) +
  labs(x = "Occurrence frequency", y = NULL, fill = "Volatile class") +
  theme(
    panel.grid.major.y = element_blank(),
    legend.position = "right",
    legend.title = element_text(size = 9.5),
    legend.text = element_text(size = 7.8),
    axis.text.y = element_text(size = 8.8)
  )
save_pdf(p_b, "Fig1V_B_top30_odour_descriptor_composition.pdf", 6.0, 8.5)

# -----------------------------------------------------------------------------
# Panel C: Bray-Curtis PCoA and paired-design PERMANOVA
# -----------------------------------------------------------------------------
x <- t(mat_log)
x <- x[, apply(x, 2, sd, na.rm = TRUE) > 0, drop = FALSE]
bc <- vegan::vegdist(x, method = "bray")
pcoa <- vegan::wcmdscale(bc, k = 2, eig = TRUE, add = "lingoes")
positive_eig <- pcoa$eig[pcoa$eig > 0]
axis_pct <- 100 * pcoa$eig[1:2] / sum(positive_eig)
pcoa_df <- data.frame(
  SampleID = rownames(pcoa$points),
  PCoA1 = pcoa$points[, 1],
  PCoA2 = pcoa$points[, 2],
  stringsAsFactors = FALSE
) |>
  left_join(meta, by = "SampleID")

perm_design <- permute::how(nperm = 999)
permute::setBlocks(perm_design) <- meta[["Animal"]]
adonis_fit <- vegan::adonis2(bc ~ Animal + Site, data = meta, permutations = perm_design, by = "terms")
adonis_df <- data.frame(Term = rownames(adonis_fit), adonis_fit, check.names = FALSE)
site_row <- adonis_df[adonis_df[["Term"]] == "Site", , drop = FALSE]
site_r2 <- site_row[["R2"]][1]
site_p <- site_row[["Pr(>F)"]][1]

p_c <- ggplot(pcoa_df, aes(PCoA1, PCoA2, color = Site)) +
  stat_ellipse(aes(fill = Site), geom = "polygon", type = "norm", level = 0.95,
               alpha = 0.08, color = NA, show.legend = FALSE) +
  stat_ellipse(type = "norm", level = 0.95, linewidth = 0.65, show.legend = FALSE) +
  geom_point(size = 2.7, alpha = 0.95, stroke = 0.2) +
  annotate(
    "text", x = -Inf, y = Inf,
    label = paste0("Paired PERMANOVA\nR² = ", sprintf("%.2f", site_r2),
                   "\nP = ", format_p(site_p)),
    hjust = -0.05, vjust = 1.08, size = 3.1, family = "Arial"
  ) +
  scale_color_manual(values = site_cols) +
  scale_fill_manual(values = site_cols) +
  base_theme(10.5) +
  labs(
    x = paste0("PCoA1 (", sprintf("%.1f", axis_pct[1]), "%)"),
    y = paste0("PCoA2 (", sprintf("%.1f", axis_pct[2]), "%)"),
    color = NULL
  ) +
  theme(
    panel.grid = element_blank(),
    legend.position = c(0.80, 0.78),
    legend.background = element_blank(),
    legend.key = element_blank(),
    aspect.ratio = 1
  )
save_pdf(p_c, "Fig1V_C_BrayCurtis_PCoA_paired_PERMANOVA.pdf", 4.4, 4.4)

# -----------------------------------------------------------------------------
# Paired one-vs-rest statistics and VIP
# -----------------------------------------------------------------------------
run_one_vs_rest <- function(target_site) {
  animals <- levels(meta[["Animal"]])
  target_tic <- matrix(NA_real_, nrow(mat_tic), length(animals),
                       dimnames = list(rownames(mat_tic), animals))
  rest_tic <- target_tic
  for (animal in animals) {
    target_id <- meta[["SampleID"]][meta[["Animal"]] == animal & meta[["Site"]] == target_site]
    rest_ids <- meta[["SampleID"]][meta[["Animal"]] == animal & meta[["Site"]] != target_site]
    target_tic[, animal] <- mat_tic[, target_id]
    rest_tic[, animal] <- rowMeans(mat_tic[, rest_ids, drop = FALSE], na.rm = TRUE)
  }
  target_log <- log10(target_tic + 1)
  rest_log <- log10(rest_tic + 1)
  delta <- target_log - rest_log

  pvalue <- vapply(seq_len(nrow(delta)), function(i) {
    safe_paired_wilcox(target_log[i, ], rest_log[i, ])
  }, numeric(1))

  x_centered <- rbind(t(delta / 2), t(-delta / 2))
  rownames(x_centered) <- c(paste0(target_site, "_", animals), paste0("Rest_", animals))
  keep <- apply(x_centered, 2, sd, na.rm = TRUE) > 0
  x_fit <- x_centered[, keep, drop = FALSE]
  y_fit <- factor(rep(c(target_site, "Rest"), each = length(animals)),
                  levels = c(target_site, "Rest"))
  vip <- rep(NA_real_, nrow(mat_log))
  names(vip) <- rownames(mat_log)
  if (ncol(x_fit) >= 2) {
    fit <- tryCatch(
      ropls::opls(
        x_fit, y_fit,
        predI = 1, orthoI = 0, permI = 0,
        scaleC = "standard", fig.pdfC = "none", info.txtC = "none"
      ),
      error = function(e) NULL
    )
    if (!is.null(fit)) {
      fit_vip <- ropls::getVipVn(fit)
      vip[names(fit_vip)] <- fit_vip
    }
  }

  out <- data.frame(
    metab_id = rownames(mat_log),
    TargetSite = target_site,
    Mean_target = rowMeans(target_tic),
    Mean_rest = rowMeans(rest_tic),
    log2FC_target_vs_rest = log2((rowMeans(target_tic) + 1e-12) /
                                  (rowMeans(rest_tic) + 1e-12)),
    Paired_Wilcoxon_P = pvalue,
    FDR = p.adjust(pvalue, method = "BH"),
    VIP = as.numeric(vip[rownames(mat_log)]),
    stringsAsFactors = FALSE
  ) |>
    left_join(annot, by = "metab_id") |>
    arrange(Paired_Wilcoxon_P)
  out[["Marker"]] <- with(out,
    !is.na(VIP) & VIP > 1 & Paired_Wilcoxon_P < 0.05 & log2FC_target_vs_rest > 0)
  out
}

ovr_list <- setNames(lapply(site_order, run_one_vs_rest), site_order)
ovr_all <- bind_rows(ovr_list)
markers_all <- ovr_all |>
  filter(Marker) |>
  arrange(factor(TargetSite, levels = site_order), Paired_Wilcoxon_P)

marker_summary <- ovr_all |>
  group_by(TargetSite) |>
  summarise(
    Features_tested = n(),
    VIP_gt_1 = sum(VIP > 1, na.rm = TRUE),
    RawP_lt_0.05 = sum(Paired_Wilcoxon_P < 0.05, na.rm = TRUE),
    FDR_lt_0.05 = sum(FDR < 0.05, na.rm = TRUE),
    Target_up_VIP1_rawP005 = sum(Marker, na.rm = TRUE),
    .groups = "drop"
  ) |>
  arrange(match(TargetSite, site_order))

# -----------------------------------------------------------------------------
# Panel D: one-vs-rest marker heatmap
# -----------------------------------------------------------------------------
marker_unique <- markers_all |>
  group_by(metab_id) |>
  slice_min(Paired_Wilcoxon_P, n = 1, with_ties = FALSE) |>
  ungroup() |>
  mutate(TargetSite = factor(TargetSite, levels = site_order)) |>
  arrange(TargetSite, Paired_Wilcoxon_P)

if (nrow(marker_unique) > 0) {
  sample_order <- meta |>
    arrange(Site, Animal) |>
    pull(SampleID)
  heat <- mat_log[marker_unique[["metab_id"]], sample_order, drop = FALSE]
  heat_z <- t(scale(t(heat)))
  heat_z[!is.finite(heat_z)] <- 0
  heat_z[heat_z > 2] <- 2
  heat_z[heat_z < -2] <- -2
  label <- marker_unique[["Metabolite"]][match(rownames(heat_z), marker_unique[["metab_id"]])]
  label[is.na(label) | label == ""] <- rownames(heat_z)[is.na(label) | label == ""]
  rownames(heat_z) <- make.unique(label)
  col_split <- factor(meta[["Site"]][match(sample_order, meta[["SampleID"]])], levels = site_order)
  row_split <- factor(marker_unique[["TargetSite"]], levels = site_order)
  show_rows <- nrow(heat_z) <= 100
  heat_height <- max(6.5, min(15, 3.3 + nrow(heat_z) * 0.045))

  ht <- ComplexHeatmap::Heatmap(
    heat_z,
    name = "Z-score",
    col = circlize::colorRamp2(c(-2, 0, 2), c("#111111", "#837516", "#FFD92F")),
    top_annotation = ComplexHeatmap::HeatmapAnnotation(
      Site = col_split,
      col = list(Site = site_cols),
      show_annotation_name = FALSE,
      simple_anno_size = unit(0.35, "cm")
    ),
    left_annotation = ComplexHeatmap::rowAnnotation(
      Enriched_site = row_split,
      col = list(Enriched_site = site_cols),
      show_annotation_name = FALSE,
      simple_anno_size = unit(0.3, "cm")
    ),
    row_split = row_split,
    column_split = col_split,
    cluster_rows = TRUE,
    cluster_columns = FALSE,
    show_row_names = show_rows,
    show_column_names = FALSE,
    row_names_gp = gpar(fontsize = 6.5, fontfamily = "Arial"),
    row_title_gp = gpar(fontsize = 10, fontface = "bold", fontfamily = "Arial"),
    column_title_gp = gpar(fontsize = 10, fontface = "bold", fontfamily = "Arial"),
    border = TRUE,
    use_raster = TRUE,
    raster_quality = 2
  )
  grDevices::cairo_pdf(
    filename = file.path(fig_dir, "Fig1V_D_one_vs_rest_specific_metabolite_heatmap.pdf"),
    width = 8.8, height = heat_height, family = "Arial"
  )
  ComplexHeatmap::draw(ht, heatmap_legend_side = "right", annotation_legend_side = "right")
  dev.off()
}

# -----------------------------------------------------------------------------
# Panels E-H: site-specific differential metabolite counts by volatile class
# -----------------------------------------------------------------------------
panel_letters <- c(LTL = "E", SM = "F", PM = "G", EAO = "H")
class_count_list <- list()
for (site in site_order) {
  dd <- markers_all |>
    filter(TargetSite == site) |>
    mutate(
      Volatile_Class1 = ifelse(
        is.na(Volatile_Class1) | Volatile_Class1 %in% c("", "-"),
        "Unknown", Volatile_Class1
      )
    ) |>
    count(TargetSite, Volatile_Class1, name = "Count") |>
    arrange(Count)
  class_count_list[[site]] <- dd
  if (nrow(dd) == 0) next
  dd[["Volatile_Class1"]] <- factor(dd[["Volatile_Class1"]], levels = dd[["Volatile_Class1"]])
  p_site <- ggplot(dd, aes(x = Count, y = Volatile_Class1)) +
    geom_col(width = 0.72, fill = site_cols[[site]], color = "black", linewidth = 0.25) +
    geom_text(aes(label = Count), hjust = -0.18, size = 3.0, family = "Arial") +
    scale_x_continuous(expand = expansion(mult = c(0, 0.16))) +
    base_theme(10.5) +
    labs(x = "Number of differential metabolites", y = NULL) +
    theme(
      panel.grid.major.y = element_blank(),
      axis.text.y = element_text(size = 9),
      aspect.ratio = 1
    )
  save_pdf(
    p_site,
    paste0("Fig1V_", panel_letters[[site]], "_", site, "_specific_volatile_class_counts.pdf"),
    4.4, 4.4
  )
}
class_counts <- bind_rows(class_count_list)

# -----------------------------------------------------------------------------
# Reference panel H adapted to four sites: odour word clouds (additional panel I)
# -----------------------------------------------------------------------------
word_freq_list <- list()
for (site in site_order) {
  ids <- markers_all[["metab_id"]][markers_all[["TargetSite"]] == site]
  freq <- annot |>
    filter(metab_id %in% ids, !is.na(Odour), !Odour %in% c("", "-")) |>
    select(metab_id, Odour) |>
    separate_rows(Odour, sep = ";") |>
    mutate(Odour = str_to_lower(str_squish(Odour))) |>
    filter(!is.na(Odour), !Odour %in% c("", "-")) |>
    distinct(metab_id, Odour) |>
    count(Odour, name = "Frequency") |>
    arrange(desc(Frequency), Odour)
  freq[["Site"]] <- site
  word_freq_list[[site]] <- freq
}
word_freq <- bind_rows(word_freq_list)

if (requireNamespace("wordcloud", quietly = TRUE)) {
  grDevices::cairo_pdf(
    filename = file.path(fig_dir, "Fig1V_I_four_site_odour_wordclouds.pdf"),
    width = 10, height = 8, family = "Arial"
  )
  par(mfrow = c(2, 2), mar = c(0.5, 0.5, 2.1, 0.5), family = "Arial")
  for (site in site_order) {
    freq <- word_freq_list[[site]]
    if (!nrow(freq)) {
      plot.new()
      title(main = paste0(site, "\nNo annotated odour"))
      next
    }
    wordcloud::wordcloud(
      words = freq[["Odour"]],
      freq = freq[["Frequency"]],
      min.freq = 1,
      max.words = 80,
      random.order = FALSE,
      rot.per = 0.10,
      scale = c(3.8, 0.65),
      colors = site_cols[[site]],
      family = "Arial"
    )
    title(main = site, font.main = 2, cex.main = 1.25)
  }
  dev.off()
} else {
  message("R package 'wordcloud' is unavailable; run companion Python script 02 for panel I.")
}

# -----------------------------------------------------------------------------
# Export analysis tables and a clear panel map
# -----------------------------------------------------------------------------
preprocess_summary <- data.frame(
  Item = c(
    "Input abundance file", "Input annotation file", "Biological samples",
    "Features", "Missing/non-positive replacement", "Normalization",
    "Transformation", "PCoA distance", "PERMANOVA design",
    "One-vs-rest comparison", "Marker threshold"
  ),
  Value = c(
    abund_file, desc_file, nrow(meta), nrow(mat_log),
    paste0("global positive minimum / 2 = ", signif(dat$fill_value, 6)),
    "TIC normalization", "log10(TIC-normalized abundance + 1)",
    "Bray-Curtis", "Site adjusted for Animal; permutations restricted within Animal",
    "target site vs within-animal mean of the other three sites",
    "PLS-DA VIP > 1, paired Wilcoxon raw P < 0.05, target/rest log2FC > 0"
  ),
  stringsAsFactors = FALSE
)

panel_map <- data.frame(
  Panel = c("A", "B", "C", "D", "E", "F", "G", "H", "I (added)"),
  Content = c(
    "Mean abundance of each volatile class",
    "Top 30 odour descriptors and volatile-class composition",
    "Bray-Curtis PCoA and paired-design PERMANOVA",
    "One-vs-rest site-specific volatile metabolite heatmap",
    "LTL-specific differential metabolites by volatile class",
    "SM-specific differential metabolites by volatile class",
    "PM-specific differential metabolites by volatile class",
    "EAO-specific differential metabolites by volatile class",
    "Four-site odour word clouds; added because the sheep design has four sites"
  ),
  stringsAsFactors = FALSE
)

openxlsx::write.xlsx(
  list(
    Sample_metadata = meta,
    Preprocessing = preprocess_summary,
    Panel_map = panel_map,
    PCoA_coordinates = pcoa_df,
    PERMANOVA = adonis_df,
    Volatile_class_abundance = class_mean,
    Top30_odour_composition = odour_plot,
    One_vs_rest_summary = marker_summary,
    One_vs_rest_all = ovr_all,
    Markers_for_heatmap = marker_unique,
    Marker_class_counts = class_counts,
    Marker_odour_frequency = word_freq
  ),
  file = file.path(tab_dir, "Fig1_volatilome_AustralianWhite_all_results.xlsx"),
  overwrite = TRUE
)

write.table(
  marker_summary,
  file = file.path(tab_dir, "Fig1_volatilome_one_vs_rest_marker_summary.tsv"),
  sep = "\t", row.names = FALSE, quote = FALSE
)
write.table(
  panel_map,
  file = file.path(tab_dir, "Fig1_volatilome_panel_map.tsv"),
  sep = "\t", row.names = FALSE, quote = FALSE
)
write.table(
  word_freq,
  file = file.path(tab_dir, "Fig1_volatilome_site_marker_odour_frequency.tsv"),
  sep = "\t", row.names = FALSE, quote = FALSE
)

message("Completed. Figures: ", fig_dir)
message("Tables: ", tab_dir)
print(marker_summary)
