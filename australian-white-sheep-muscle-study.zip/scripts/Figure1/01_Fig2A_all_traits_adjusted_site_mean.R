#!/usr/bin/env Rscript

# =============================================================================
# Figure 2A: all 12 meat-quality traits as adjusted anatomical-site means
#
# Question
#   What complete phenotype structure across LTL, SM, PM, and EAO motivates
#   the downstream biological questions, without preselecting anchor traits?
#
# Chart contract
#   - All 12 Figure 1 traits are retained.
#   - Each trait is standardized across all 60 observations before fitting.
#   - Paired model: standardized trait ~ Site + (1 | Animal).
#   - Heatmap colors and printed values are adjusted site means in SD units.
#   - Both traits and anatomical sites are clustered by Euclidean distance and
#     Ward.D2 linkage.
#   - Row suffixes show BH-adjusted omnibus Site significance.
#   - Positive values mean higher trait values, not better meat quality.
# =============================================================================

rm(list = ls())

suppressPackageStartupMessages({
  library(openxlsx)
  library(nlme)
  library(cluster)
  library(grid)
  library(pheatmap)
})

# -----------------------------------------------------------------------------
# 1. Paths and definitions
# -----------------------------------------------------------------------------
project_dir <- "__PROJECT_ROOT__"
input_file <- file.path(project_dir, "01_meat_quality", "meat quality.xlsx")
work_dir <- file.path(project_dir, "07_Figure2_muscle_functional_states")
figure_dir <- file.path(work_dir, "Figures")
table_dir <- file.path(work_dir, "Tables")
figure1_dir <- file.path(
  project_dir,
  "01_meat_quality",
  "Figures",
  "Figure1_meat_quality_by_site"
)

dir.create(figure_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(table_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(figure1_dir, recursive = TRUE, showWarnings = FALSE)

group_order <- c("LTL", "SM", "PM", "EAO")
site_colors <- c(
  LTL = "#365B8C",
  SM  = "#4F7C71",
  PM  = "#C28B48",
  EAO = "#A65D68"
)

trait_map <- data.frame(
  Original = c(
    "L*.(Lightness)45min",
    "L*.(Lightness)24h",
    "a*.(Redness)45min",
    "a*.(Redness)24h",
    "b*.(Yellowness)45min",
    "b*.(Yellowness)24h",
    "pH.45min",
    "pH.24h",
    "Drip.loss,.%",
    "Cooking.loss,.%",
    "Shear.force,.N",
    "IMF,%"
  ),
  Trait = c(
    "L_45min", "L_24h",
    "a_45min", "a_24h",
    "b_45min", "b_24h",
    "pH_45min", "pH_24h",
    "Drip_loss", "Cooking_loss",
    "Shear_force", "IMF"
  ),
  Trait_label = c(
    "45 min L*", "24 h L*",
    "45 min a*", "24 h a*",
    "45 min b*", "24 h b*",
    "45 min pH", "24 h pH",
    "Drip loss (%)", "Cooking loss (%)",
    "Shear force (N)", "IMF (%)"
  ),
  Measurement_family = c(
    rep("Color phenotype", 6),
    rep("Postmortem pH", 2),
    rep("Tenderness / water-holding", 3),
    "Lipid deposition"
  ),
  stringsAsFactors = FALSE
)

sig_label <- function(p) {
  ifelse(
    is.na(p), "NA",
    ifelse(p < 0.001, "***",
      ifelse(p < 0.01, "**",
        ifelse(p < 0.05, "*", "n.s.")
      )
    )
  )
}

# -----------------------------------------------------------------------------
# 2. Read and validate the paired data
# -----------------------------------------------------------------------------
if (!file.exists(input_file)) stop("Input workbook not found: ", input_file)
raw_df <- openxlsx::read.xlsx(input_file, sheet = "Sheet2", check.names = FALSE)

required_columns <- c("Group", "SampleID", trait_map$Original)
missing_columns <- setdiff(required_columns, names(raw_df))
if (length(missing_columns) > 0L) {
  stop("Missing required columns: ", paste(missing_columns, collapse = ", "))
}

unexpected_sites <- setdiff(unique(as.character(raw_df$Group)), group_order)
if (length(unexpected_sites) > 0L) {
  stop("Unexpected site labels: ", paste(unexpected_sites, collapse = ", "))
}

sample_ids <- as.character(raw_df$SampleID)
if (!all(grepl("^[^_]+_[0-9]+$", sample_ids))) {
  stop("Sample IDs must use the site_animal format.")
}

animal_number <- as.integer(sub("^.*_", "", sample_ids))
meat_df <- data.frame(
  Animal = factor(animal_number, levels = sort(unique(animal_number))),
  Site = factor(as.character(raw_df$Group), levels = group_order),
  SampleID = sample_ids,
  stringsAsFactors = FALSE
)

for (i in seq_len(nrow(trait_map))) {
  meat_df[[trait_map$Trait[i]]] <- suppressWarnings(
    as.numeric(raw_df[[trait_map$Original[i]]])
  )
}

pairing_table <- table(meat_df$Animal, meat_df$Site)
if (!all(dim(pairing_table) == c(15L, 4L)) || !all(pairing_table == 1L)) {
  stop("Expected one complete four-site observation for each of 15 animals.")
}

trait_matrix_raw <- as.matrix(meat_df[, trait_map$Trait, drop = FALSE])
storage.mode(trait_matrix_raw) <- "numeric"
if (any(!is.finite(trait_matrix_raw))) {
  stop("The 12 meat-quality traits contain missing or non-finite values.")
}

# -----------------------------------------------------------------------------
# 3. Paired mixed models on globally standardized values
# -----------------------------------------------------------------------------
site_rows <- data.frame(Site = factor(group_order, levels = group_order))
profile_rows <- list()
omnibus_rows <- list()
raw_summary_rows <- list()

for (i in seq_len(nrow(trait_map))) {
  trait <- trait_map$Trait[i]
  trait_label <- trait_map$Trait_label[i]
  family_label <- trait_map$Measurement_family[i]
  values <- meat_df[[trait]]
  center_value <- mean(values)
  scale_value <- sd(values)

  if (!is.finite(scale_value) || scale_value <= 0) {
    stop("Cannot standardize trait: ", trait)
  }

  model_df <- data.frame(
    Animal = meat_df$Animal,
    Site = meat_df$Site,
    Value = values,
    Z = (values - center_value) / scale_value
  )

  fit_z <- nlme::lme(
    fixed = Z ~ Site,
    random = ~1 | Animal,
    data = model_df,
    method = "REML",
    na.action = na.fail,
    control = nlme::lmeControl(opt = "optim", returnObject = TRUE)
  )

  design_matrix <- model.matrix(~ Site, data = site_rows)
  beta <- nlme::fixef(fit_z)
  beta_vcov <- vcov(fit_z)
  z_mean <- as.numeric(design_matrix %*% beta)
  z_se <- sqrt(diag(design_matrix %*% beta_vcov %*% t(design_matrix)))
  model_anova <- anova(fit_z)
  site_p <- model_anova["Site", "p-value"]

  profile_rows[[i]] <- data.frame(
    Trait = trait,
    Trait_label = trait_label,
    Measurement_family = family_label,
    Site = group_order,
    Adjusted_mean_SD = z_mean,
    SE_SD = z_se,
    CI95_lower_SD = z_mean - 1.96 * z_se,
    CI95_upper_SD = z_mean + 1.96 * z_se,
    Backtransformed_mean = center_value + z_mean * scale_value,
    Global_mean = center_value,
    Global_SD = scale_value,
    Site_omnibus_P = site_p,
    stringsAsFactors = FALSE
  )

  omnibus_rows[[i]] <- data.frame(
    Trait = trait,
    Trait_label = trait_label,
    Measurement_family = family_label,
    Model = "Standardized_trait ~ Site + (1 | Animal)",
    n_animals = nlevels(model_df$Animal),
    n_observations = nrow(model_df),
    Site_numDF = model_anova["Site", "numDF"],
    Site_denDF = model_anova["Site", "denDF"],
    Site_F = model_anova["Site", "F-value"],
    Site_P = site_p,
    Random_intercept_variance = as.numeric(VarCorr(fit_z)[1, "Variance"]),
    Residual_variance = as.numeric(VarCorr(fit_z)[2, "Variance"]),
    stringsAsFactors = FALSE
  )

  for (site in group_order) {
    x <- values[meat_df$Site == site]
    raw_summary_rows[[length(raw_summary_rows) + 1L]] <- data.frame(
      Trait = trait,
      Trait_label = trait_label,
      Measurement_family = family_label,
      Site = site,
      n = length(x),
      Mean = mean(x),
      SD = sd(x),
      SEM = sd(x) / sqrt(length(x)),
      Median = median(x),
      Min = min(x),
      Max = max(x),
      stringsAsFactors = FALSE
    )
  }
}

site_profile <- do.call(rbind, profile_rows)
model_omnibus <- do.call(rbind, omnibus_rows)
raw_summary <- do.call(rbind, raw_summary_rows)

model_omnibus$Site_P_FDR_BH <- p.adjust(model_omnibus$Site_P, method = "BH")
model_omnibus$Site_significance_FDR <- sig_label(model_omnibus$Site_P_FDR_BH)

site_profile$Site_P_FDR_BH <- model_omnibus$Site_P_FDR_BH[
  match(site_profile$Trait, model_omnibus$Trait)
]
site_profile$Site_significance_FDR <- model_omnibus$Site_significance_FDR[
  match(site_profile$Trait, model_omnibus$Trait)
]

profile_center_qa <- aggregate(
  Adjusted_mean_SD ~ Trait,
  data = site_profile,
  FUN = mean
)
names(profile_center_qa)[2] <- "Mean_of_four_adjusted_site_effects_SD"

# -----------------------------------------------------------------------------
# 4. Data-driven profile clustering as a sensitivity analysis
#
# Clustering is saved to the tables but does not determine the primary figure's
# biological interpretation. With only four site coordinates, it is a compact
# description of phenotype patterns rather than proof of biological mechanisms.
# -----------------------------------------------------------------------------
profile_matrix <- matrix(
  NA_real_,
  nrow = nrow(trait_map),
  ncol = length(group_order),
  dimnames = list(trait_map$Trait, group_order)
)

for (trait in trait_map$Trait) {
  profile_matrix[trait, ] <- site_profile$Adjusted_mean_SD[
    match(
      paste(trait, group_order),
      paste(site_profile$Trait, site_profile$Site)
    )
  ]
}

profile_distance <- dist(profile_matrix, method = "euclidean")
profile_hclust <- hclust(profile_distance, method = "ward.D2")
site_distance <- dist(t(profile_matrix), method = "euclidean")
site_hclust <- hclust(site_distance, method = "ward.D2")

silhouette_rows <- list()
cluster_membership_rows <- list()
for (k in 2:6) {
  cluster_id <- cutree(profile_hclust, k = k)
  sil <- cluster::silhouette(cluster_id, profile_distance)
  silhouette_rows[[length(silhouette_rows) + 1L]] <- data.frame(
    k = k,
    Average_silhouette_width = mean(sil[, "sil_width"]),
    stringsAsFactors = FALSE
  )
  cluster_membership_rows[[length(cluster_membership_rows) + 1L]] <- data.frame(
    k = k,
    Trait = names(cluster_id),
    Cluster = as.integer(cluster_id),
    stringsAsFactors = FALSE
  )
}

silhouette_summary <- do.call(rbind, silhouette_rows)
cluster_membership <- do.call(rbind, cluster_membership_rows)
optimal_k <- silhouette_summary$k[
  which.max(silhouette_summary$Average_silhouette_width)
]

cluster_order <- data.frame(
  Ward_order = seq_along(profile_hclust$order),
  Trait = rownames(profile_matrix)[profile_hclust$order],
  Trait_label = trait_map$Trait_label[
    match(rownames(profile_matrix)[profile_hclust$order], trait_map$Trait)
  ],
  Optimal_k_by_silhouette = optimal_k,
  Cluster_at_optimal_k = unname(
    cutree(profile_hclust, k = optimal_k)[
      rownames(profile_matrix)[profile_hclust$order]
    ]
  ),
  stringsAsFactors = FALSE
)

site_cluster_order <- data.frame(
  Ward_order = seq_along(site_hclust$order),
  Site = colnames(profile_matrix)[site_hclust$order],
  stringsAsFactors = FALSE
)

# -----------------------------------------------------------------------------
# 5. Primary two-way clustered all-trait heatmap
# -----------------------------------------------------------------------------
plot_label_map <- data.frame(
  Trait = model_omnibus$Trait,
  Trait_display = paste0(
    model_omnibus$Trait_label,
    "   [",
    model_omnibus$Site_significance_FDR,
    "]"
  ),
  stringsAsFactors = FALSE
)

heat_limit <- ceiling(max(abs(site_profile$Adjusted_mean_SD)) * 10) / 10

plot_matrix <- t(profile_matrix)
colnames(plot_matrix) <- plot_label_map$Trait_display[
  match(colnames(plot_matrix), plot_label_map$Trait)
]

number_matrix <- matrix(
  sprintf("%+.2f", as.vector(plot_matrix)),
  nrow = nrow(plot_matrix),
  ncol = ncol(plot_matrix),
  dimnames = dimnames(plot_matrix)
)

site_annotation <- data.frame(
  Site = factor(rownames(plot_matrix), levels = group_order),
  row.names = rownames(plot_matrix)
)

heatmap_colors <- colorRampPalette(
  c("#365B8C", "#F4F1EA", "#A65D68")
)(101)
heatmap_breaks <- seq(-heat_limit, heat_limit, length.out = 102)

main_plot <- pheatmap::pheatmap(
  mat = plot_matrix,
  color = heatmap_colors,
  breaks = heatmap_breaks,
  cluster_rows = site_hclust,
  cluster_cols = profile_hclust,
  clustering_distance_rows = "euclidean",
  clustering_distance_cols = "euclidean",
  clustering_method = "ward.D2",
  annotation_row = site_annotation,
  annotation_colors = list(Site = site_colors),
  annotation_names_row = FALSE,
  annotation_legend = FALSE,
  display_numbers = number_matrix,
  number_color = "#20242A",
  fontsize_number = 8.2,
  fontsize = 10.5,
  fontsize_row = 10,
  fontsize_col = 8.5,
  angle_col = 45,
  border_color = "white",
  treeheight_row = 30,
  treeheight_col = 36,
  legend_breaks = c(-heat_limit, 0, heat_limit),
  legend_labels = sprintf("%+.1f", c(-heat_limit, 0, heat_limit)),
  silent = TRUE
)

# -----------------------------------------------------------------------------
# 6. Export
# -----------------------------------------------------------------------------
output_stub <- file.path(
  figure_dir,
  "Fig2A_All_12_traits_adjusted_site_mean"
)
figure1_output_stub <- file.path(
  figure1_dir,
  "Fig1M_All_12_traits_adjusted_site_mean_clustered"
)

plot_width_in <- 9.2
plot_height_in <- 4.2

grDevices::cairo_pdf(
  filename = paste0(output_stub, ".pdf"),
  width = plot_width_in,
  height = plot_height_in,
  family = "Arial"
)
grid::grid.newpage()
grid::grid.draw(main_plot$gtable)
dev.off()

png(
  filename = paste0(output_stub, ".png"),
  width = plot_width_in,
  height = plot_height_in,
  units = "in",
  res = 600,
  type = "cairo",
  family = "Arial",
  bg = "white"
)
grid::grid.newpage()
grid::grid.draw(main_plot$gtable)
dev.off()

svg(
  filename = paste0(output_stub, ".svg"),
  width = plot_width_in,
  height = plot_height_in,
  family = "Arial",
  pointsize = 10.5,
  onefile = TRUE,
  bg = "white"
)
grid::grid.newpage()
grid::grid.draw(main_plot$gtable)
dev.off()

for (extension in c("pdf", "png", "svg")) {
  copied <- file.copy(
    from = paste0(output_stub, ".", extension),
    to = paste0(figure1_output_stub, ".", extension),
    overwrite = TRUE
  )
  if (!copied) stop("Failed to copy Figure 1 ", extension, " output.")
}

# -----------------------------------------------------------------------------
# 7. Tables and QA
# -----------------------------------------------------------------------------
write.table(
  site_profile,
  file = file.path(table_dir, "Fig2A_all_traits_adjusted_site_effects.tsv"),
  sep = "\t",
  quote = FALSE,
  row.names = FALSE,
  na = "NA"
)
write.table(
  model_omnibus,
  file = file.path(table_dir, "Fig2A_all_traits_mixed_model_omnibus.tsv"),
  sep = "\t",
  quote = FALSE,
  row.names = FALSE,
  na = "NA"
)
write.table(
  silhouette_summary,
  file = file.path(table_dir, "Fig2A_trait_profile_cluster_silhouette.tsv"),
  sep = "\t",
  quote = FALSE,
  row.names = FALSE
)
write.table(
  cluster_membership,
  file = file.path(table_dir, "Fig2A_trait_profile_cluster_membership.tsv"),
  sep = "\t",
  quote = FALSE,
  row.names = FALSE
)
write.table(
  cluster_order,
  file = file.path(table_dir, "Fig2A_trait_profile_Ward_order.tsv"),
  sep = "\t",
  quote = FALSE,
  row.names = FALSE
)
write.table(
  site_cluster_order,
  file = file.path(table_dir, "Fig2A_site_profile_Ward_order.tsv"),
  sep = "\t",
  quote = FALSE,
  row.names = FALSE
)

qa_manifest <- data.frame(
  Check = c(
    "Animals",
    "Sites per animal",
    "Traits retained",
    "Missing trait values",
    "Maximum absolute centering deviation",
    "Optimal cluster k by average silhouette",
    "Row clustering",
    "Column clustering",
    "Figure width (in)",
    "Figure height (in)",
    "Typeface",
    "Direction note"
  ),
  Value = c(
    nlevels(meat_df$Animal),
    paste(sort(unique(as.numeric(rowSums(pairing_table > 0)))), collapse = ","),
    nrow(trait_map),
    sum(!is.finite(trait_matrix_raw)),
    max(abs(profile_center_qa$Mean_of_four_adjusted_site_effects_SD)),
    optimal_k,
    "Euclidean distance; Ward.D2 linkage",
    "Euclidean distance; Ward.D2 linkage",
    plot_width_in,
    plot_height_in,
    "Arial",
    "Positive values indicate higher trait values, not better quality"
  ),
  stringsAsFactors = FALSE
)

method_notes <- data.frame(
  Item = c(
    "Analytical question",
    "Trait inclusion",
    "Primary model",
    "Standardization",
    "Heatmap interpretation",
    "Row suffix",
    "Clustering sensitivity analysis",
    "Primary row order",
    "Primary column order",
    "Input source"
  ),
  Description = c(
    "What complete phenotype structure motivates downstream biological questions?",
    "All 12 Figure 1 meat-quality traits; no anchor preselection",
    "Standardized trait ~ Site + (1 | Animal), fitted by REML",
    "Each trait centered and divided by its SD across all 60 observations before model fitting",
    "Cell values are adjusted site means in global SD units; higher does not imply better quality",
    "Bracketed symbols are BH-adjusted omnibus Site significance across the 12 traits",
    "Ward.D2 clustering on the 12 x 4 adjusted-site profile matrix; k=2 to 6 compared by average silhouette",
    "Ward.D2 dendrogram order based on Euclidean distances among the four site profiles",
    "Ward.D2 dendrogram order based on Euclidean distances among the 12 trait profiles",
    input_file
  ),
  stringsAsFactors = FALSE
)

workbook <- openxlsx::createWorkbook()
table_list <- list(
  Adjusted_site_effects = site_profile,
  Mixed_model_omnibus = model_omnibus,
  Raw_summary = raw_summary,
  Profile_matrix = data.frame(Trait = rownames(profile_matrix), profile_matrix, check.names = FALSE),
  Cluster_silhouette = silhouette_summary,
  Cluster_membership = cluster_membership,
  Ward_order = cluster_order,
  Site_Ward_order = site_cluster_order,
  Centering_QA = profile_center_qa,
  Figure_QA = qa_manifest,
  Method_notes = method_notes,
  Clean_meat_quality_data = meat_df
)

for (sheet_name in names(table_list)) {
  openxlsx::addWorksheet(workbook, sheet_name)
  openxlsx::writeData(workbook, sheet_name, table_list[[sheet_name]])
  openxlsx::freezePane(workbook, sheet_name, firstRow = TRUE)
  openxlsx::addFilter(
    workbook,
    sheet_name,
    rows = 1,
    cols = seq_len(ncol(table_list[[sheet_name]]))
  )
  openxlsx::setColWidths(
    workbook,
    sheet_name,
    cols = seq_len(ncol(table_list[[sheet_name]])),
    widths = "auto"
  )
}

openxlsx::saveWorkbook(
  workbook,
  file.path(table_dir, "Fig2A_all_12_traits_adjusted_site_mean.xlsx"),
  overwrite = TRUE
)

figure1_workbook <- file.path(
  project_dir,
  "01_meat_quality",
  "Tables",
  "Fig1M_all_12_traits_adjusted_site_mean_clustered.xlsx"
)
if (!file.copy(
  from = file.path(table_dir, "Fig2A_all_12_traits_adjusted_site_mean.xlsx"),
  to = figure1_workbook,
  overwrite = TRUE
)) {
  stop("Failed to copy the Figure 1 result workbook.")
}

write.table(
  qa_manifest,
  file = file.path(table_dir, "Fig2A_all_traits_QA_manifest.tsv"),
  sep = "\t",
  quote = FALSE,
  row.names = FALSE
)

cat("All-trait Figure 2A completed.\n")
cat("Optimal k by silhouette:", optimal_k, "\n")
cat("PDF:", paste0(output_stub, ".pdf"), "\n")
cat("PNG:", paste0(output_stub, ".png"), "\n")
cat("SVG:", paste0(output_stub, ".svg"), "\n")
cat("Figure 1 PDF:", paste0(figure1_output_stub, ".pdf"), "\n")
cat("Workbook:", file.path(table_dir, "Fig2A_all_12_traits_adjusted_site_mean.xlsx"), "\n")
