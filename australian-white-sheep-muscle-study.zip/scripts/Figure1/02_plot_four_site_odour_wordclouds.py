#!/usr/bin/env python3
"""Create a four-site vector-text word-cloud PDF from the R analysis table."""

from pathlib import Path
import csv

import matplotlib.pyplot as plt
from matplotlib.font_manager import FontProperties
from matplotlib.patches import Rectangle
from PIL import Image, ImageDraw, ImageFont
from wordcloud import WordCloud


WORK = Path("__PROJECT_ROOT__/02_Figure1_volatilome")
INPUT = WORK / "Tables" / "Fig1_volatilome_site_marker_odour_frequency.tsv"
OUTPUT = WORK / "Figures" / "Fig1V_I_four_site_odour_wordclouds.pdf"
FONT = Path("/home/gao/.local/share/fonts/msttcorefonts/Arial.TTF")
if not FONT.exists():
    FONT = Path("/usr/share/fonts/truetype/msttcorefonts/Arial.ttf")

SITES = ["LTL", "SM", "PM", "EAO"]
COLORS = {
    "LTL": "#355C8A",
    "SM": "#4F7D73",
    "PM": "#C28B48",
    "EAO": "#A65D68",
}


def constant_color(color):
    def color_func(*args, **kwargs):
        return color

    return color_func


def layout_centrality_score(cloud, width, height):
    """Weighted distance of frequent words from the canvas centre (lower is better)."""
    draw = ImageDraw.Draw(Image.new("L", (width, height)))
    score = 0.0
    for rank, ((word, relative_freq), font_size, (row, col), orientation, _) in enumerate(cloud.layout_):
        font = ImageFont.truetype(str(FONT), font_size)
        left, top, right, bottom = draw.textbbox((0, 0), word, font=font, anchor="lt")
        word_width = right - left
        word_height = bottom - top
        cx = col + word_width / 2
        cy = row + word_height / 2
        distance = ((cx - width / 2) ** 2 + (cy - height / 2) ** 2) ** 0.5
        distance /= (width**2 + height**2) ** 0.5
        # WordCloud reports frequency relative to the most frequent word.
        weight = max(float(relative_freq), 0.02) ** 1.7
        # Force the most frequent words to dominate layout selection.
        if rank == 0:
            weight *= 15
        elif rank < 3:
            weight *= 6
        elif rank < 8:
            weight *= 2
        score += weight * distance
    return score


def build_centered_cloud(frequencies, site, width, height):
    """Select, from many collision-free layouts, the one with central high-frequency words."""
    best_cloud = None
    best_score = float("inf")
    # Candidate layouts retain reproducibility while avoiding a single unlucky seed.
    for seed in range(16):
        cloud = WordCloud(
            width=width,
            height=height,
            background_color="white",
            max_words=80,
            prefer_horizontal=1.0,
            relative_scaling=0.48,
            min_font_size=7,
            max_font_size=92,
            margin=5,
            random_state=20260909 + seed,
            font_path=str(FONT),
            collocations=False,
            color_func=constant_color(COLORS[site]),
        ).generate_from_frequencies(frequencies)
        score = layout_centrality_score(cloud, width, height)
        if score < best_score:
            best_cloud = cloud
            best_score = score
    return best_cloud


def add_vector_cloud(ax, frequencies, site, canvas_width=1000, canvas_height=650):
    """Use WordCloud for collision-free layout, then redraw every word as PDF text."""
    ax.set_xlim(0, canvas_width)
    ax.set_ylim(0, canvas_height)
    ax.axis("off")
    ax.add_patch(
        Rectangle(
            (0, 1.01),
            1,
            0.075,
            facecolor=COLORS[site],
            edgecolor="none",
            transform=ax.transAxes,
            clip_on=False,
            zorder=10,
        )
    )
    ax.text(
        0.5,
        1.047,
        site,
        ha="center",
        va="center",
        color="black",
        fontsize=14,
        fontproperties=FontProperties(fname=str(FONT)),
        transform=ax.transAxes,
        clip_on=False,
        zorder=11,
    )

    if not frequencies:
        ax.text(
            canvas_width / 2,
            canvas_height / 2,
            "No annotated odour",
            ha="center",
            va="center",
            fontsize=12,
            fontproperties=FontProperties(fname=str(FONT)),
        )
        return

    cloud = build_centered_cloud(frequencies, site, canvas_width, canvas_height)

    # WordCloud positions are (row, column), counted from the upper-left corner.
    # Redrawing with Matplotlib keeps text editable/vector-based in the PDF.
    fp = FontProperties(fname=str(FONT))
    for (word, _), size_px, (row, col), orientation, color in cloud.layout_:
        rotation = 90 if orientation is not None else 0
        ax.text(
            col,
            canvas_height - row,
            word,
            ha="left",
            va="top",
            rotation=rotation,
            rotation_mode="anchor",
            color=color,
            # Convert layout pixels to points for a ~5-inch-wide subplot.
            # A 0.36 factor preserves the collision-free WordCloud geometry.
            fontsize=size_px * 0.36,
            fontproperties=fp,
        )


def main():
    by_site = {site: {} for site in SITES}
    with INPUT.open("r", encoding="utf-8", newline="") as handle:
        for row in csv.DictReader(handle, delimiter="\t"):
            site = row["Site"]
            if site in by_site:
                by_site[site][row["Odour"]] = float(row["Frequency"])
    fig, axes = plt.subplots(2, 2, figsize=(11.0, 7.8))
    for ax, site in zip(axes.flat, SITES):
        add_vector_cloud(ax, by_site[site], site)
    fig.subplots_adjust(left=0.025, right=0.985, bottom=0.025, top=0.94, wspace=0.08, hspace=0.20)
    fig.savefig(OUTPUT, format="pdf", transparent=False)
    plt.close(fig)
    print(f"Saved: {OUTPUT}")


if __name__ == "__main__":
    main()
