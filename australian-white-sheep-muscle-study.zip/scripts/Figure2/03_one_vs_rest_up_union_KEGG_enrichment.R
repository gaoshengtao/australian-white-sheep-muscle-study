#!/usr/bin/env Rscript

# KEGG ORA for each site's union of significantly upregulated transcript and
# protein genes. Sheep genes are mapped through Ensembl 115 human orthologs
# because direct oas KEGG/NCBI mapping is too sparse for LTL and SM.

rm(list = ls())
suppressPackageStartupMessages({
  library(biomaRt)
  library(clusterProfiler)
  library(KEGGREST)
  library(AnnotationDbi)
  library(org.Hs.eg.db)
  library(openxlsx)
})
options(stringsAsFactors = FALSE, timeout = 600)

project_dir <- "__PROJECT_ROOT__"
work_dir <- file.path(project_dir, "07_Figure2_muscle_functional_states",
                      "03_One_vs_rest_specificity")
table_dir <- file.path(work_dir, "Tables")
cache_dir <- file.path(work_dir, "cache", "Ensembl115_human_ortholog")
dir.create(table_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(cache_dir, recursive = TRUE, showWarnings = FALSE)

transcript_file <- file.path(
  table_dir, "Transcriptome_DESeq2_one_vs_rest_all_results.tsv.gz"
)
protein_file <- file.path(
  table_dir, "Proteome_limma_one_vs_rest_all_results.tsv.gz"
)
cross_mapping_file <- file.path(
  project_dir, "04_transcriptome", "04_ID_mapping",
  "transcriptome_proteome_Gene_symbol_matches.tsv"
)
required_files <- c(transcript_file, protein_file, cross_mapping_file)
missing_files <- required_files[!file.exists(required_files)]
if (length(missing_files)) {
  stop("Missing input files: ", paste(missing_files, collapse = ", "))
}

site_order <- c("LTL", "SM", "PM", "EAO")
fdr_threshold <- 0.05
min_gene_set_size <- 10L
max_gene_set_size <- 500L
archive_host <- "https://sep2025.archive.ensembl.org"
ensembl_dataset <- "oaries_gene_ensembl"

clean_id <- function(x) {
  x <- trimws(as.character(x))
  x[is.na(x)] <- ""
  x
}
write_tsv <- function(x, filename) {
  write.table(
    x, file.path(table_dir, filename), sep = "\t", quote = FALSE,
    row.names = FALSE, na = "NA"
  )
}
parse_ratio <- function(x) {
  pieces <- strsplit(as.character(x), "/", fixed = TRUE)
  vapply(pieces, function(z) as.numeric(z[1]) / as.numeric(z[2]), numeric(1))
}

transcript <- read.delim(
  gzfile(transcript_file), check.names = FALSE, quote = "", comment.char = ""
)
protein <- read.delim(
  gzfile(protein_file), check.names = FALSE, quote = "", comment.char = ""
)
cross_mapping <- read.delim(
  cross_mapping_file, check.names = FALSE, quote = "", comment.char = ""
)
stopifnot(all(c("gene_id", "Target_site", "log2FoldChange", "P_FDR_BH")
              %in% names(transcript)))
stopifnot(all(c("Protein_row", "Target_site", "log2FoldChange", "P_FDR_BH")
              %in% names(protein)))
stopifnot(all(c("Protein_row", "gene_id") %in% names(cross_mapping)))

cross_mapping$gene_id <- clean_id(cross_mapping$gene_id)
cross_mapping <- unique(cross_mapping[
  cross_mapping$Protein_row %in% unique(protein$Protein_row) &
    nzchar(cross_mapping$gene_id), c("Protein_row", "gene_id")
])
transcript_universe <- unique(clean_id(transcript$gene_id))
transcript_universe <- transcript_universe[nzchar(transcript_universe)]
protein_universe <- unique(cross_mapping$gene_id)
universe_sheep_ensembl <- sort(unique(c(transcript_universe,
                                        protein_universe)))

# Per-site union of significant positive effects in either omics layer.
membership_list <- lapply(site_order, function(site_name) {
  transcript_up <- unique(clean_id(transcript$gene_id[
    transcript$Target_site == site_name &
      !is.na(transcript$P_FDR_BH) & transcript$P_FDR_BH < fdr_threshold &
      is.finite(transcript$log2FoldChange) & transcript$log2FoldChange > 0
  ]))
  transcript_up <- transcript_up[nzchar(transcript_up)]
  protein_up_rows <- unique(protein$Protein_row[
    protein$Target_site == site_name &
      !is.na(protein$P_FDR_BH) & protein$P_FDR_BH < fdr_threshold &
      is.finite(protein$log2FoldChange) & protein$log2FoldChange > 0
  ])
  protein_up <- unique(cross_mapping$gene_id[
    cross_mapping$Protein_row %in% protein_up_rows
  ])
  protein_up <- protein_up[nzchar(protein_up)]
  union_ids <- sort(unique(c(transcript_up, protein_up)))
  data.frame(
    Site = site_name,
    Sheep_Ensembl_gene_id = union_ids,
    Transcript_up = union_ids %in% transcript_up,
    Protein_up = union_ids %in% protein_up,
    Omics_membership = ifelse(
      union_ids %in% transcript_up & union_ids %in% protein_up,
      "Transcriptome + Proteome",
      ifelse(union_ids %in% transcript_up,
             "Transcriptome only", "Proteome only")
    ), stringsAsFactors = FALSE
  )
})
site_gene_membership <- do.call(rbind, membership_list)
rownames(site_gene_membership) <- NULL

# Ensembl 115 sheep-to-human ortholog mapping, cached in 1000-gene chunks.
patched_archive_table <- function(https = TRUE, httr_config = list()) {
  data.frame(
    name = c("Ensembl 116", "Ensembl 115"),
    date = c("Jun 2026", "Sep 2025"),
    url = c("https://www.ensembl.org", archive_host),
    version = c("116", "115"), current_release = c("*", ""),
    stringsAsFactors = FALSE
  )
}
assignInNamespace(".listEnsemblArchives", patched_archive_table, ns = "biomaRt")
mart <- useMart(
  biomart = "ENSEMBL_MART_ENSEMBL",
  dataset = ensembl_dataset, host = archive_host
)

query_human_ortholog_chunks <- function(ids, chunk_size = 1000L,
                                        max_attempts = 4L) {
  ids <- sort(unique(ids[nzchar(ids)]))
  chunks <- split(seq_along(ids), ceiling(seq_along(ids) / chunk_size))
  output <- vector("list", length(chunks))
  attributes <- c(
    "ensembl_gene_id", "hsapiens_homolog_ensembl_gene",
    "hsapiens_homolog_associated_gene_name",
    "hsapiens_homolog_orthology_type",
    "hsapiens_homolog_orthology_confidence",
    "hsapiens_homolog_perc_id"
  )
  for (i in seq_along(chunks)) {
    this_ids <- ids[chunks[[i]]]
    cache_file <- file.path(cache_dir, sprintf("human_ortholog_%03d.rds", i))
    if (file.exists(cache_file)) {
      cached <- readRDS(cache_file)
      if (is.list(cached) &&
          all(c("queried_ids", "result") %in% names(cached)) &&
          identical(cached$queried_ids, this_ids)) {
        output[[i]] <- cached$result
        message("Ortholog chunk ", i, "/", length(chunks), " loaded from cache")
        next
      }
    }
    result <- NULL
    last_error <- NULL
    for (attempt in seq_len(max_attempts)) {
      result <- tryCatch(
        getBM(
          attributes = attributes, filters = "ensembl_gene_id",
          values = this_ids, mart = mart, uniqueRows = TRUE
        ), error = function(e) {
          last_error <<- conditionMessage(e)
          NULL
        }
      )
      if (!is.null(result)) break
      Sys.sleep(min(2^attempt, 12))
    }
    if (is.null(result)) {
      stop("Ortholog chunk ", i, " failed after ", max_attempts,
           " attempts: ", last_error)
    }
    saveRDS(list(queried_ids = this_ids, result = result), cache_file)
    output[[i]] <- result
    message("Ortholog chunk ", i, "/", length(chunks), ": ", nrow(result),
            " rows")
  }
  unique(do.call(rbind, output))
}

ortholog_raw <- query_human_ortholog_chunks(universe_sheep_ensembl)
rename_map <- c(
  ensembl_gene_id = "Sheep_Ensembl_gene_id",
  hsapiens_homolog_ensembl_gene = "Human_Ensembl_gene_id",
  hsapiens_homolog_associated_gene_name = "Human_Gene_symbol_BioMart",
  hsapiens_homolog_orthology_type = "Orthology_type",
  hsapiens_homolog_orthology_confidence = "Orthology_confidence",
  hsapiens_homolog_perc_id = "Sheep_to_human_percent_identity"
)
for (old_name in names(rename_map)) {
  names(ortholog_raw)[names(ortholog_raw) == old_name] <- rename_map[old_name]
}
ortholog_raw$Sheep_Ensembl_gene_id <- clean_id(
  ortholog_raw$Sheep_Ensembl_gene_id
)
ortholog_raw$Human_Ensembl_gene_id <- clean_id(
  ortholog_raw$Human_Ensembl_gene_id
)
ortholog_raw <- ortholog_raw[nzchar(ortholog_raw$Human_Ensembl_gene_id), ]

human_id_map <- AnnotationDbi::select(
  org.Hs.eg.db,
  keys = unique(ortholog_raw$Human_Ensembl_gene_id),
  keytype = "ENSEMBL", columns = c("ENTREZID", "SYMBOL")
)
human_id_map <- unique(human_id_map[
  !is.na(human_id_map$ENTREZID) & nzchar(human_id_map$ENTREZID),
  c("ENSEMBL", "ENTREZID", "SYMBOL")
])
sheep_human_map <- merge(
  ortholog_raw, human_id_map,
  by.x = "Human_Ensembl_gene_id", by.y = "ENSEMBL",
  all = FALSE, sort = FALSE
)
names(sheep_human_map)[names(sheep_human_map) == "ENTREZID"] <-
  "Human_Entrez_ID"
names(sheep_human_map)[names(sheep_human_map) == "SYMBOL"] <-
  "Human_Gene_symbol"
sheep_human_map <- unique(sheep_human_map)
if (!nrow(sheep_human_map)) stop("No sheep genes mapped to human Entrez IDs.")

site_gene_membership_mapped <- merge(
  site_gene_membership, sheep_human_map,
  by = "Sheep_Ensembl_gene_id", all.x = TRUE, sort = FALSE
)
site_gene_membership_mapped <- site_gene_membership_mapped[
  order(match(site_gene_membership_mapped$Site, site_order),
        site_gene_membership_mapped$Sheep_Ensembl_gene_id,
        site_gene_membership_mapped$Human_Entrez_ID), ]

universe_human_entrez <- sort(unique(sheep_human_map$Human_Entrez_ID))
entrez_symbol_lookup <- setNames(human_id_map$SYMBOL, human_id_map$ENTREZID)
make_symbol_list <- function(gene_string) {
  ids <- strsplit(gene_string, "/", fixed = TRUE)[[1]]
  symbols <- unname(entrez_symbol_lookup[ids])
  replace <- is.na(symbols) | !nzchar(symbols)
  symbols[replace] <- ids[replace]
  paste(symbols, collapse = "/")
}

enrichment_list <- setNames(vector("list", length(site_order)), site_order)
for (site_name in site_order) {
  target_entrez <- sort(unique(site_gene_membership_mapped$Human_Entrez_ID[
    site_gene_membership_mapped$Site == site_name &
      !is.na(site_gene_membership_mapped$Human_Entrez_ID) &
      nzchar(site_gene_membership_mapped$Human_Entrez_ID)
  ]))
  if (length(target_entrez) < min_gene_set_size) {
    stop(site_name, " has fewer than ", min_gene_set_size,
         " mapped human ortholog genes.")
  }
  enrichment <- enrichKEGG(
    gene = target_entrez, organism = "hsa", keyType = "ncbi-geneid",
    universe = universe_human_entrez,
    pvalueCutoff = 1, pAdjustMethod = "BH", qvalueCutoff = 1,
    minGSSize = min_gene_set_size, maxGSSize = max_gene_set_size,
    use_internal_data = FALSE
  )
  result <- as.data.frame(enrichment)
  if (nrow(result)) {
    result$Site <- site_name
    result$RichFactor <- result$Count /
      as.numeric(sub("/.*$", "", result$BgRatio))
    result$FoldEnrichment <- parse_ratio(result$GeneRatio) /
      parse_ratio(result$BgRatio)
    result$Significant_FDR_lt_0_05 <-
      !is.na(result$p.adjust) & result$p.adjust < fdr_threshold
    result$Gene_symbols <- vapply(
      result$geneID, make_symbol_list, character(1)
    )
    keep <- c(
      "Site", "ID", "Description", "GeneRatio", "BgRatio",
      "RichFactor", "FoldEnrichment", "pvalue", "p.adjust", "qvalue",
      "Count", "Significant_FDR_lt_0_05", "geneID", "Gene_symbols"
    )
    result <- result[, keep]
    result <- result[order(result$p.adjust, result$pvalue), ]
  }
  enrichment_list[[site_name]] <- result
}

all_enrichment <- do.call(rbind, enrichment_list)
rownames(all_enrichment) <- NULL

# KEGG pathway hierarchy from the official br08901 classification used by
# https://www.genome.jp/kegg/pathway.html. Human Diseases and Drug Development
# are removed before BH correction, as requested.
brite_text <- KEGGREST::keggGet("br:br08901")
brite_lines <- strsplit(brite_text, "\n", fixed = TRUE)[[1]]
top_category <- ""
subcategory <- ""
category_records <- list()
record_index <- 0L
for (line in brite_lines) {
  if (grepl("^A", line)) {
    top_category <- trimws(sub("^A", "", line))
  } else if (grepl("^B +", line)) {
    subcategory <- trimws(sub("^B +", "", line))
  } else if (grepl("^C +[0-9]{5} ", line)) {
    pathway_number <- sub("^C +([0-9]{5}).*$", "\\1", line)
    hierarchy_description <- sub("^C +[0-9]{5} +", "", line)
    hierarchy_description <- sub(" +\\[PATH:hsa[0-9]{5}\\].*$", "",
                                 hierarchy_description)
    record_index <- record_index + 1L
    category_records[[record_index]] <- data.frame(
      ID = paste0("hsa", pathway_number),
      KEGG_top_category = top_category,
      KEGG_subcategory = subcategory,
      KEGG_hierarchy_description = hierarchy_description,
      stringsAsFactors = FALSE
    )
  }
}
kegg_category_map <- unique(do.call(rbind, category_records))
excluded_top_categories <- c("Human Diseases", "Drug Development")
if (!all(excluded_top_categories %in% kegg_category_map$KEGG_top_category)) {
  stop("The official KEGG br08901 hierarchy did not contain both exclusion categories.")
}
if (anyDuplicated(kegg_category_map$ID)) {
  stop("A KEGG pathway was assigned to multiple top-level categories.")
}

all_enrichment <- merge(
  all_enrichment, kegg_category_map, by = "ID", all.x = TRUE, sort = FALSE
)
if (anyNA(all_enrichment$KEGG_top_category)) {
  stop("Some tested KEGG pathways lack an official br08901 category.")
}
all_enrichment$Excluded_before_BH <-
  all_enrichment$KEGG_top_category %in% excluded_top_categories
excluded_pathways <- all_enrichment[
  all_enrichment$Excluded_before_BH, , drop = FALSE
]
names(all_enrichment)[names(all_enrichment) == "p.adjust"] <-
  "p.adjust_before_category_filter"
names(all_enrichment)[names(all_enrichment) == "qvalue"] <-
  "qvalue_before_category_filter"
names(excluded_pathways)[names(excluded_pathways) == "p.adjust"] <-
  "p.adjust_before_category_filter"
names(excluded_pathways)[names(excluded_pathways) == "qvalue"] <-
  "qvalue_before_category_filter"

all_enrichment <- all_enrichment[
  !all_enrichment$Excluded_before_BH, , drop = FALSE
]
all_enrichment$p.adjust <- ave(
  all_enrichment$pvalue, all_enrichment$Site,
  FUN = function(x) p.adjust(x, method = "BH")
)
all_enrichment$Significant_FDR_lt_0_05 <-
  !is.na(all_enrichment$p.adjust) &
  all_enrichment$p.adjust < fdr_threshold
all_enrichment <- all_enrichment[
  order(match(all_enrichment$Site, site_order),
        all_enrichment$p.adjust, all_enrichment$pvalue),
]
rownames(all_enrichment) <- NULL
significant_enrichment <- all_enrichment[
  all_enrichment$Significant_FDR_lt_0_05, , drop = FALSE
]
enrichment_list <- setNames(lapply(site_order, function(site_name) {
  all_enrichment[all_enrichment$Site == site_name, , drop = FALSE]
}), site_order)

input_summary <- do.call(rbind, lapply(site_order, function(site_name) {
  raw <- site_gene_membership[site_gene_membership$Site == site_name, ]
  mapped <- site_gene_membership_mapped[
    site_gene_membership_mapped$Site == site_name &
      !is.na(site_gene_membership_mapped$Human_Entrez_ID) &
      nzchar(site_gene_membership_mapped$Human_Entrez_ID), ]
  tr <- unique(raw$Sheep_Ensembl_gene_id[raw$Transcript_up])
  pr <- unique(raw$Sheep_Ensembl_gene_id[raw$Protein_up])
  er <- enrichment_list[[site_name]]
  data.frame(
    Site = site_name,
    Transcript_up_sheep_genes = length(tr),
    Protein_up_mapped_sheep_genes = length(pr),
    Transcript_protein_overlap_sheep_genes = length(intersect(tr, pr)),
    Union_sheep_genes = nrow(raw),
    Union_sheep_genes_with_human_ortholog_Entrez = length(unique(
      mapped$Sheep_Ensembl_gene_id
    )),
    Union_unique_human_Entrez_genes = length(unique(mapped$Human_Entrez_ID)),
    KEGG_pathways_tested = nrow(er),
    KEGG_pathways_FDR_lt_0_05 = sum(er$Significant_FDR_lt_0_05),
    stringsAsFactors = FALSE
  )
}))

qa <- data.frame(
  Metric = c(
    "Input genes", "Transcript criterion", "Protein criterion",
    "Cross-omics operation", "Background", "Ortholog source",
    "KEGG organism", "KEGG method", "Pathway category source",
    "Excluded before BH", "Pathway multiple testing",
    "Significant pathway criterion", "Pathway size range",
    "Background sheep Ensembl genes", "Background human Entrez genes",
    "Direct sheep KEGG mapping QA", "clusterProfiler version"
  ),
  Value = c(
    "Significantly upregulated one-vs-rest genes only",
    "log2FC > 0 and BH FDR < 0.05; no magnitude cutoff",
    "log2FC > 0 and BH FDR < 0.05; no magnitude cutoff",
    "Transcript-protein union separately within each site",
    "Union of genes testable in transcriptome or mapped from tested proteins, then mapped by the same ortholog procedure",
    "Ensembl release 115 Ovis aries to Homo sapiens homolog mapping; human Ensembl-to-Entrez by org.Hs.eg.db",
    "hsa (human ortholog KEGG pathways)",
    "clusterProfiler::enrichKEGG over-representation analysis",
    "Official KEGG br08901 hierarchy corresponding to https://www.genome.jp/kegg/pathway.html",
    paste(excluded_top_categories, collapse = "; "),
    "After category exclusion, BH separately within each site",
    "BH FDR < 0.05",
    paste0(min_gene_set_size, "-", max_gene_set_size),
    length(universe_sheep_ensembl), length(universe_human_entrez),
    "Rejected as primary route: only 4, 9, 92 and 348 mapped Entrez genes for LTL, SM, PM and EAO",
    as.character(packageVersion("clusterProfiler"))
  ), stringsAsFactors = FALSE
)

write_tsv(sheep_human_map,
          "Fig2_Ensembl115_sheep_to_human_ortholog_Entrez_mapping.tsv")
write_tsv(site_gene_membership_mapped,
          "Fig2_one_vs_rest_up_union_gene_membership_and_human_ortholog.tsv")
write_tsv(input_summary,
          "Fig2_one_vs_rest_up_union_KEGG_enrichment_counts.tsv")
write_tsv(all_enrichment,
          "Fig2_one_vs_rest_up_union_KEGG_all_pathways.tsv")
write_tsv(excluded_pathways,
          "Fig2_one_vs_rest_up_union_KEGG_excluded_before_BH.tsv")
write_tsv(kegg_category_map,
          "Fig2_KEGG_br08901_pathway_category_map.tsv")
write_tsv(significant_enrichment,
          "Fig2_one_vs_rest_up_union_KEGG_significant_pathways_FDR_lt_0.05.tsv")
write_tsv(qa, "Fig2_one_vs_rest_up_union_KEGG_QA.tsv")

workbook <- list(
  Summary = input_summary,
  Significant_KEGG = significant_enrichment,
  All_KEGG = all_enrichment,
  Excluded_before_BH = excluded_pathways,
  KEGG_categories = kegg_category_map,
  Gene_membership = site_gene_membership_mapped,
  Sheep_human_mapping = sheep_human_map,
  QA = qa
)
for (site_name in site_order) {
  workbook[[paste0(site_name, "_KEGG")]] <- enrichment_list[[site_name]]
}
openxlsx::write.xlsx(
  workbook,
  file.path(table_dir, "Fig2_one_vs_rest_up_union_KEGG_enrichment.xlsx"),
  overwrite = TRUE
)

cat("Cross-omics upregulated-gene union KEGG enrichment completed.\n")
print(input_summary)
cat("Significant KEGG pathways (BH FDR < 0.05):\n")
print(setNames(input_summary$KEGG_pathways_FDR_lt_0_05,
               input_summary$Site))
