#!/usr/bin/env Rscript

# Lollipop plot of significant KEGG pathways after category filtering and
# within-site BH correction.

rm(list = ls())
suppressPackageStartupMessages({
  library(ggplot2)
  library(openxlsx)
})
options(stringsAsFactors = FALSE)

work_dir <- paste0(
  "__PROJECT_ROOT__/07_Figure2_muscle_functional_states/",
  "03_One_vs_rest_specificity"
)
table_dir <- file.path(work_dir, "Tables")
figure_dir <- file.path(work_dir, "Figures")
dir.create(figure_dir, recursive = TRUE, showWarnings = FALSE)

input_file <- file.path(
  table_dir,
  "Fig2_one_vs_rest_up_union_KEGG_significant_pathways_FDR_lt_0.05.tsv"
)
if (!file.exists(input_file)) stop("Missing significant KEGG table: ", input_file)

site_order <- c("LTL", "SM", "PM", "EAO")
site_colors <- c(
  LTL = "#365B8C", SM = "#4F7C71", PM = "#C28B48", EAO = "#A65D68"
)
plot_width <- 8.8
plot_height <- 14.5

write_tsv <- function(x, filename) {
  write.table(
    x, file.path(table_dir, filename), sep = "\t", quote = FALSE,
    row.names = FALSE, na = "NA"
  )
}
wrap_label <- function(x, width = 54L) {
  vapply(x, function(z) paste(strwrap(z, width = width), collapse = "\n"),
         character(1), USE.NAMES = FALSE)
}

data <- read.delim(
  input_file, header = TRUE, check.names = FALSE,
  quote = "", comment.char = ""
)
required_columns <- c(
  "ID", "Site", "Description", "pvalue", "p.adjust", "Count",
  "KEGG_top_category"
)
if (!all(required_columns %in% names(data))) {
  stop("Significant KEGG table lacks required columns: ",
       paste(setdiff(required_columns, names(data)), collapse = ", "))
}
if (anyDuplicated(data[, c("Site", "ID")]) ||
    any(!data$Site %in% site_order) ||
    any(!is.finite(data$pvalue) | data$pvalue <= 0 | data$pvalue > 1) ||
    any(!is.finite(data$p.adjust) | data$p.adjust >= 0.05) ||
    any(!is.finite(data$Count) | data$Count <= 0)) {
  stop("Significant KEGG table failed uniqueness or numeric validation.")
}
if (any(data$KEGG_top_category %in% c("Human Diseases", "Drug Development"))) {
  stop("Excluded KEGG categories remain in the significant pathway table.")
}

data$Site <- factor(data$Site, levels = site_order)
data$Minus_log10_P <- -log10(data$pvalue)
data <- do.call(rbind, lapply(site_order, function(site_name) {
  z <- data[as.character(data$Site) == site_name, , drop = FALSE]
  z <- z[order(z$Minus_log10_P, z$Description), , drop = FALSE]
  z$Within_site_rank <- rev(seq_len(nrow(z)))
  z
}))
rownames(data) <- NULL

# Composite key preserves independent pathway ordering inside each facet.
data$Pathway_key <- paste(data$Site, data$Description, sep = "___")
data$Pathway_key <- factor(data$Pathway_key, levels = unique(data$Pathway_key))

pathway_label_lookup <- setNames(
  wrap_label(data$Description), as.character(data$Pathway_key)
)
site_counts <- as.data.frame(table(
  Site = factor(data$Site, levels = site_order)
))
names(site_counts)[2] <- "Significant_pathways"

p <- ggplot(data, aes(y = Pathway_key, color = Site)) +
  geom_segment(
    aes(x = 0, xend = Minus_log10_P, yend = Pathway_key),
    linewidth = 0.72, alpha = 0.72, lineend = "round"
  ) +
  geom_point(
    aes(x = Minus_log10_P, size = Count, fill = Site),
    shape = 21, color = "white", stroke = 0.38, alpha = 0.95
  ) +
  facet_grid(
    rows = vars(Site), scales = "free_y", space = "free_y",
    switch = "y"
  ) +
  scale_color_manual(values = site_colors, guide = "none") +
  scale_fill_manual(values = site_colors, guide = "none") +
  scale_size_continuous(
    name = "Gene count", range = c(2.8, 8.2),
    breaks = scales::breaks_pretty(n = 4)
  ) +
  scale_y_discrete(
    labels = pathway_label_lookup,
    expand = expansion(add = c(0.42, 0.42))
  ) +
  scale_x_continuous(
    name = expression(-log[10](italic(P))),
    breaks = scales::breaks_pretty(n = 6),
    expand = expansion(mult = c(0, 0.035))
  ) +
  labs(y = NULL) +
  theme_bw(base_size = 10.5, base_family = "Arial") +
  theme(
    aspect.ratio = NULL,
    plot.title = element_blank(),
    plot.subtitle = element_blank(),
    plot.caption = element_blank(),
    panel.grid.major.y = element_blank(),
    panel.grid.minor = element_blank(),
    panel.grid.major.x = element_line(color = "#E3E5E7", linewidth = 0.34),
    panel.border = element_rect(color = "#25282C", linewidth = 0.48),
    axis.title.x = element_text(size = 10.5, color = "#25282C",
                                margin = margin(t = 7)),
    axis.text.x = element_text(size = 9, color = "#25282C"),
    axis.text.y = element_text(size = 8.5, color = "#25282C",
                               lineheight = 0.98),
    axis.ticks.y = element_blank(),
    axis.ticks.x = element_line(color = "#25282C", linewidth = 0.35),
    strip.placement = "outside",
    strip.background = element_rect(fill = "white", color = NA),
    strip.text.y.left = element_text(
      angle = 90, face = "bold", size = 11, color = "#25282C",
      margin = margin(r = 5)
    ),
    panel.spacing.y = unit(2.3, "mm"),
    legend.position = "right",
    legend.title = element_text(size = 9.2, color = "#25282C"),
    legend.text = element_text(size = 8.7, color = "#25282C"),
    legend.key.height = unit(5.2, "mm"),
    plot.margin = margin(t = 7, r = 8, b = 7, l = 7)
  ) +
  guides(size = guide_legend(
    title.position = "top", override.aes = list(
      shape = 21, fill = "#777777", color = "white", alpha = 0.95
    )
  ))

output_stub <- file.path(
  figure_dir, "Fig2_one_vs_rest_up_union_significant_KEGG_lollipop"
)
ggsave(
  paste0(output_stub, ".pdf"), p, device = cairo_pdf,
  width = plot_width, height = plot_height, units = "in", family = "Arial"
)
png(
  paste0(output_stub, ".png"), width = plot_width, height = plot_height,
  units = "in", res = 600, type = "cairo", family = "Arial", bg = "white"
)
print(p)
dev.off()
svg(
  paste0(output_stub, ".svg"), width = plot_width, height = plot_height,
  family = "Arial", pointsize = 10.5, onefile = TRUE, bg = "white"
)
print(p)
dev.off()

plot_data_export <- data
plot_data_export$Pathway_key <- as.character(plot_data_export$Pathway_key)
qa <- data.frame(
  Metric = c(
    "Input table", "Pathways plotted", "Facet layout", "Facet order",
    "X axis", "Y axis", "Point size", "Pathway order",
    "Significance prefilter", "Excluded categories", "Figure size inches",
    "Typeface"
  ),
  Value = c(
    input_file, nrow(data), "One column by four rows",
    paste(site_order, collapse = ", "),
    "-log10(raw KEGG enrichment P value)", "KEGG pathway description",
    "Pathway gene Count", "Ascending -log10(P) from bottom to top within site",
    "Retained pathways have post-category-filter BH FDR < 0.05",
    "Human Diseases; Drug Development",
    paste(plot_width, plot_height, sep = " x "), "Arial"
  ), stringsAsFactors = FALSE
)

write_tsv(
  plot_data_export,
  "Fig2_one_vs_rest_up_union_significant_KEGG_lollipop_plot_data.tsv"
)
write_tsv(
  site_counts,
  "Fig2_one_vs_rest_up_union_significant_KEGG_lollipop_counts.tsv"
)
write_tsv(
  qa,
  "Fig2_one_vs_rest_up_union_significant_KEGG_lollipop_QA.tsv"
)
openxlsx::write.xlsx(
  list(Plot_data = plot_data_export, Counts = site_counts, QA = qa),
  file.path(
    table_dir,
    "Fig2_one_vs_rest_up_union_significant_KEGG_lollipop_results.xlsx"
  ), overwrite = TRUE
)

cat("Significant KEGG lollipop plot completed.\n")
print(site_counts)
cat("PDF:", paste0(output_stub, ".pdf"), "\n")
