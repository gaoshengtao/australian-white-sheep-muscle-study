#!/usr/bin/env Rscript

# =============================================================================
# Australian White sheep transcriptome: paired Bray-Curtis PERMANOVA
#
# Primary inference
#   Bray-Curtis distance ~ Animal + Site
#   Site is tested marginally after Animal.
#   Permutations are restricted within Animal to respect the paired four-site
#   sampling design.
#
# Additional outputs
#   - Six paired site contrasts with BH correction.
#   - PERMDISP diagnostic for equality of multivariate dispersion.
# =============================================================================

rm(list = ls())

suppressPackageStartupMessages({
  library(vegan)
  library(permute)
})

# -----------------------------------------------------------------------------
# 1. Paths and constants
# -----------------------------------------------------------------------------
work_dir <- "__PROJECT_ROOT__/04_transcriptome"
analysis_dir <- "__PROJECT_ROOT__/07_Figure2_muscle_functional_states/01_Transcriptome_PCoA_Adonis"
table_dir <- file.path(analysis_dir, "Tables")

distance_file <- file.path(table_dir, "BrayCurtis_distance.rds")
metadata_file <- file.path(
  table_dir,
  "transcriptome_sample_metadata_and_size_factors.tsv"
)

site_order <- c("LTL", "SM", "PM", "EAO")
n_requested_permutations <- 9999L
analysis_seed <- 20260827L

if (!file.exists(distance_file)) stop("Missing distance object: ", distance_file)
if (!file.exists(metadata_file)) stop("Missing sample metadata: ", metadata_file)

# -----------------------------------------------------------------------------
# 2. Read and validate paired metadata and Bray-Curtis distances
# -----------------------------------------------------------------------------
bray_distance <- readRDS(distance_file)
if (!inherits(bray_distance, "dist")) stop("Bray-Curtis RDS is not a dist object.")

sample_metadata <- read.delim(
  metadata_file,
  header = TRUE,
  check.names = FALSE,
  stringsAsFactors = FALSE
)
if (anyDuplicated(sample_metadata$Sample)) stop("Duplicated sample metadata rows.")

distance_samples <- attr(bray_distance, "Labels")
missing_metadata <- setdiff(distance_samples, sample_metadata$Sample)
if (length(missing_metadata) > 0L) {
  stop("Distance samples missing from metadata: ", paste(missing_metadata, collapse = ", "))
}

sample_metadata <- sample_metadata[
  match(distance_samples, sample_metadata$Sample),
  ,
  drop = FALSE
]
rownames(sample_metadata) <- sample_metadata$Sample
sample_metadata$Site <- factor(sample_metadata$Site, levels = site_order)
sample_metadata$Animal <- factor(sample_metadata$Animal)

pairing_table <- table(sample_metadata$Animal, sample_metadata$Site)
if (!all(dim(pairing_table) == c(6L, 4L)) || !all(pairing_table == 1L)) {
  stop("Expected a complete six-animal by four-site paired design.")
}
if (!identical(rownames(sample_metadata), distance_samples)) {
  stop("Metadata and distance ordering do not match.")
}

make_blocked_permutations <- function(metadata, n_requested, seed) {
  set.seed(seed)
  control <- permute::how(
    within = permute::Within(type = "free"),
    blocks = metadata$Animal,
    nperm = n_requested
  )
  permute::shuffleSet(
    n = nrow(metadata),
    nset = n_requested,
    control = control
  )
}

adonis_to_table <- function(result) {
  out <- data.frame(
    Term = rownames(result),
    as.data.frame(result, check.names = FALSE),
    row.names = NULL,
    check.names = FALSE
  )
  out
}

# -----------------------------------------------------------------------------
# 3. Overall paired PERMANOVA
# -----------------------------------------------------------------------------
overall_permutation_matrix <- make_blocked_permutations(
  sample_metadata,
  n_requested_permutations,
  analysis_seed
)

overall_adonis <- vegan::adonis2(
  formula = bray_distance ~ Animal + Site,
  data = sample_metadata,
  permutations = overall_permutation_matrix,
  by = "margin",
  parallel = 1
)
overall_adonis_table <- adonis_to_table(overall_adonis)
overall_adonis_table$Interpretation <- ifelse(
  overall_adonis_table$Term == "Site",
  "Primary paired Site test; marginal after Animal; permutations restricted within Animal",
  ifelse(
    overall_adonis_table$Term == "Animal",
    "Animal term included to remove paired-animal variation; its permutation P value is not interpreted under within-Animal restrictions",
    "Model residual/total"
  )
)

overall_site_row <- overall_adonis_table[
  overall_adonis_table$Term == "Site",
  ,
  drop = FALSE
]
overall_residual_row <- overall_adonis_table[
  overall_adonis_table$Term == "Residual",
  ,
  drop = FALSE
]
if (nrow(overall_site_row) != 1L || nrow(overall_residual_row) != 1L) {
  stop("Could not extract Site and Residual rows from overall adonis2 result.")
}

overall_primary_result <- data.frame(
  Test = "Overall paired Site effect",
  Model = "Bray-Curtis distance ~ Animal + Site",
  Site_Df = overall_site_row$Df,
  Site_SumOfSqs = overall_site_row$SumOfSqs,
  Site_R2_total = overall_site_row$R2,
  Site_partial_R2 = overall_site_row$SumOfSqs /
    (overall_site_row$SumOfSqs + overall_residual_row$SumOfSqs),
  Pseudo_F = overall_site_row$F,
  P_value = overall_site_row[["Pr(>F)"]],
  Requested_permutations = n_requested_permutations,
  Permutations_used = nrow(overall_permutation_matrix),
  Permutation_restriction = "Within Animal",
  stringsAsFactors = FALSE
)

# -----------------------------------------------------------------------------
# 4. Six paired site contrasts with BH correction
# -----------------------------------------------------------------------------
site_pairs <- combn(site_order, 2, simplify = FALSE)
distance_matrix <- as.matrix(bray_distance)
pairwise_rows <- vector("list", length(site_pairs))

for (pair_index in seq_along(site_pairs)) {
  pair <- site_pairs[[pair_index]]
  keep_samples <- sample_metadata$Site %in% pair
  pair_metadata <- droplevels(sample_metadata[keep_samples, , drop = FALSE])
  pair_sample_names <- rownames(pair_metadata)
  pair_distance <- as.dist(
    distance_matrix[pair_sample_names, pair_sample_names, drop = FALSE]
  )

  pair_permutation_matrix <- make_blocked_permutations(
    pair_metadata,
    n_requested_permutations,
    analysis_seed + pair_index
  )

  pair_adonis <- vegan::adonis2(
    formula = pair_distance ~ Animal + Site,
    data = pair_metadata,
    permutations = pair_permutation_matrix,
    by = "margin",
    parallel = 1
  )
  pair_table <- adonis_to_table(pair_adonis)
  site_row <- pair_table[pair_table$Term == "Site", , drop = FALSE]
  residual_row <- pair_table[pair_table$Term == "Residual", , drop = FALSE]

  if (nrow(site_row) != 1L || nrow(residual_row) != 1L) {
    stop("Could not extract pairwise Site/Residual rows for ", paste(pair, collapse = " vs "))
  }

  pairwise_rows[[pair_index]] <- data.frame(
    Contrast = paste(pair, collapse = " vs "),
    Site_1 = pair[1],
    Site_2 = pair[2],
    n_animals = nlevels(pair_metadata$Animal),
    n_samples = nrow(pair_metadata),
    Site_Df = site_row$Df,
    Site_SumOfSqs = site_row$SumOfSqs,
    Site_R2_total = site_row$R2,
    Site_partial_R2 = site_row$SumOfSqs /
      (site_row$SumOfSqs + residual_row$SumOfSqs),
    Pseudo_F = site_row$F,
    P_value = site_row[["Pr(>F)"]],
    Requested_permutations = n_requested_permutations,
    Permutations_used = nrow(pair_permutation_matrix),
    Permutation_restriction = "Within Animal",
    stringsAsFactors = FALSE
  )
}

pairwise_adonis <- do.call(rbind, pairwise_rows)
pairwise_adonis$P_FDR_BH <- p.adjust(pairwise_adonis$P_value, method = "BH")
pairwise_adonis$Significant_FDR_0.05 <- pairwise_adonis$P_FDR_BH < 0.05
pairwise_adonis <- pairwise_adonis[
  order(pairwise_adonis$P_FDR_BH, -pairwise_adonis$Site_partial_R2),
  ,
  drop = FALSE
]
rownames(pairwise_adonis) <- NULL

# -----------------------------------------------------------------------------
# 5. Multivariate dispersion diagnostic (PERMDISP)
# -----------------------------------------------------------------------------
dispersion_fit <- vegan::betadisper(
  d = bray_distance,
  group = sample_metadata$Site,
  type = "median",
  bias.adjust = TRUE
)

set.seed(analysis_seed + 100L)
dispersion_permutation <- vegan::permutest(
  dispersion_fit,
  permutations = overall_permutation_matrix,
  pairwise = TRUE
)

dispersion_overall <- data.frame(
  Term = rownames(dispersion_permutation$tab),
  as.data.frame(dispersion_permutation$tab, check.names = FALSE),
  row.names = NULL,
  check.names = FALSE
)

dispersion_distances <- data.frame(
  Sample = distance_samples,
  Site = sample_metadata$Site,
  Animal = sample_metadata$Animal,
  Distance_to_site_spatial_median = dispersion_fit$distances,
  stringsAsFactors = FALSE
)

dispersion_summary <- do.call(
  rbind,
  lapply(site_order, function(site_name) {
    values <- dispersion_fit$distances[sample_metadata$Site == site_name]
    data.frame(
      Site = site_name,
      n = length(values),
      Mean_distance_to_spatial_median = mean(values),
      SD = sd(values),
      SEM = sd(values) / sqrt(length(values)),
      Median = median(values),
      stringsAsFactors = FALSE
    )
  })
)

dispersion_pairwise <- data.frame()
if (!is.null(dispersion_permutation$pairwise)) {
  parametric_p <- dispersion_permutation$pairwise$observed
  permutation_p <- dispersion_permutation$pairwise$permuted
  contrast_names <- names(permutation_p)
  split_contrasts <- strsplit(contrast_names, "-", fixed = TRUE)
  dispersion_pairwise <- data.frame(
    Contrast = contrast_names,
    Site_1 = vapply(split_contrasts, `[`, character(1), 1),
    Site_2 = vapply(split_contrasts, `[`, character(1), 2),
    Parametric_P_value = as.numeric(parametric_p[contrast_names]),
    Permutation_P_value = as.numeric(permutation_p[contrast_names]),
    stringsAsFactors = FALSE
  )
  dispersion_pairwise$P_FDR_BH <- p.adjust(
    dispersion_pairwise$Permutation_P_value,
    method = "BH"
  )
  rownames(dispersion_pairwise) <- NULL
}

# -----------------------------------------------------------------------------
# 6. Export tables and QA
# -----------------------------------------------------------------------------
write_tsv <- function(object, filename) {
  write.table(
    object,
    file = file.path(table_dir, filename),
    sep = "\t",
    quote = FALSE,
    row.names = FALSE,
    na = "NA"
  )
}

write_tsv(
  overall_primary_result,
  "transcriptome_BrayCurtis_paired_adonis_overall.tsv"
)
write_tsv(
  overall_adonis_table,
  "transcriptome_BrayCurtis_paired_adonis_full_model.tsv"
)
write_tsv(
  pairwise_adonis,
  "transcriptome_BrayCurtis_paired_adonis_pairwise_BH.tsv"
)
write_tsv(
  dispersion_overall,
  "transcriptome_BrayCurtis_PERMDISP_overall.tsv"
)
write_tsv(
  dispersion_summary,
  "transcriptome_BrayCurtis_PERMDISP_site_summary.tsv"
)
write_tsv(
  dispersion_distances,
  "transcriptome_BrayCurtis_PERMDISP_sample_distances.tsv"
)
write_tsv(
  dispersion_pairwise,
  "transcriptome_BrayCurtis_PERMDISP_pairwise_BH.tsv"
)

qa_manifest <- data.frame(
  Check = c(
    "Samples",
    "Animals",
    "Sites",
    "Complete paired design",
    "Distance",
    "Overall model",
    "Site test",
    "Requested overall permutations",
    "Overall permutations used",
    "Pairwise contrasts",
    "Pairwise permutations used per contrast",
    "Pairwise multiplicity correction",
    "Dispersion diagnostic",
    "Random seed",
    "vegan version",
    "permute version"
  ),
  Value = c(
    nrow(sample_metadata),
    nlevels(sample_metadata$Animal),
    nlevels(sample_metadata$Site),
    all(pairing_table == 1L),
    "Bray-Curtis on DESeq2 size-factor normalized counts",
    "Distance ~ Animal + Site",
    "Marginal Site effect after Animal; permutations restricted within Animal",
    n_requested_permutations,
    nrow(overall_permutation_matrix),
    nrow(pairwise_adonis),
    paste(sort(unique(pairwise_adonis$Permutations_used)), collapse = ","),
    "Benjamini-Hochberg FDR across six site contrasts",
    "PERMDISP to site spatial median; permutations restricted within Animal",
    analysis_seed,
    as.character(packageVersion("vegan")),
    as.character(packageVersion("permute"))
  ),
  stringsAsFactors = FALSE
)
write_tsv(
  qa_manifest,
  "transcriptome_BrayCurtis_paired_adonis_QA_manifest.tsv"
)

cat("Paired Bray-Curtis adonis2 analysis completed.\n")
cat("Overall Site P:", overall_primary_result$P_value, "\n")
cat("Overall Site R2:", overall_primary_result$Site_R2_total, "\n")
cat("Overall Site partial R2:", overall_primary_result$Site_partial_R2, "\n")
cat("Significant pairwise contrasts after BH:", sum(pairwise_adonis$Significant_FDR_0.05), "\n")
