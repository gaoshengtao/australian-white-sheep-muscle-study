#!/usr/bin/env Rscript

# Extended marker-set scores for 27 functional subtypes (nested within nine
# major classes), repeated-measures correlations with 12 meat-quality traits,
# and separate transcriptome/proteome corrplot-style heatmaps.

rm(list = ls())
suppressPackageStartupMessages({
  library(DESeq2)
  library(limma)
  library(AnnotationDbi)
  library(org.Hs.eg.db)
  library(rmcorr)
  library(ggplot2)
  library(openxlsx)
})
options(stringsAsFactors = FALSE)

project_dir <- "__PROJECT_ROOT__"
work_dir <- file.path(project_dir, "07_Figure2_muscle_functional_states",
                      "03_One_vs_rest_specificity")
table_dir <- file.path(work_dir, "Tables")
figure_dir <- file.path(work_dir, "Figures",
                        "Fig2_subtype_meat_quality_correlations")
dir.create(table_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(figure_dir, recursive = TRUE, showWarnings = FALSE)

dds_file <- file.path(table_dir, "Transcriptome_one_vs_rest_DESeq2_dds.rds")
ortholog_file <- file.path(
  table_dir, "Fig2_Ensembl115_sheep_to_human_ortholog_Entrez_mapping.tsv"
)
protein_file <- file.path(project_dir, "05_protein", "protein.xlsx")
cross_mapping_file <- file.path(
  project_dir, "04_transcriptome", "04_ID_mapping",
  "transcriptome_proteome_Gene_symbol_matches.tsv"
)
meat_file <- file.path(project_dir, "01_meat_quality", "meat quality.xlsx")
required_files <- c(
  dds_file, ortholog_file, protein_file, cross_mapping_file, meat_file
)
missing_files <- required_files[!file.exists(required_files)]
if (length(missing_files)) {
  stop("Missing required files: ", paste(missing_files, collapse = ", "))
}

site_order <- c("LTL", "SM", "PM", "EAO")
omics_order <- c("Transcriptome", "Proteome")
protein_min_samples <- 5L
minimum_genes_per_score <- 2L
fdr_threshold <- 0.05

# Extended a priori signatures. Unlike the preceding compact gene-level plot,
# scoring is not limited to three markers per subtype.
signature_symbols <- list(
  "Muscle fiber type" = list(
    "Slow / oxidative" = c(
      "MYH7", "MYH7B", "TNNT1", "TNNI1", "TNNC1", "MYL2", "MYL3",
      "ATP2A2", "CASQ2", "MYOZ2", "MB", "PPARGC1A", "PPARD",
      "ESRRA", "TFAM", "COX7A1", "CPT1B", "FABP3", "CKMT2", "CS",
      "SDHA"
    ),
    "Fast / glycolytic" = c(
      "MYH1", "MYH2", "MYH4", "TNNT3", "TNNI2", "TNNC2", "MYL1",
      "ATP2A1", "CASQ1", "MYOZ1", "MYOZ3", "PVALB", "PFKM", "PYGM",
      "LDHA", "ENO3", "FBP2", "CKM"
    )
  ),
  "Contractile apparatus" = list(
    "Thick filament" = c(
      "MYH1", "MYH2", "MYH4", "MYH7", "MYBPC1", "MYBPC2", "MYL1",
      "MYL2", "MYL3", "MYOM1", "MYOM2", "MYOM3", "TTN", "OBSCN"
    ),
    "Thin filament" = c(
      "ACTA1", "ACTC1", "TPM1", "TPM2", "TPM3", "TPM4", "TNNT1",
      "TNNT3", "TNNI1", "TNNI2", "TNNC1", "TNNC2", "NEB", "LMOD2",
      "LMOD3"
    ),
    "Z-disc" = c(
      "ACTN2", "ACTN3", "TCAP", "CSRP3", "LDB3", "DES", "FLNC",
      "MYOT", "MYOZ1", "MYOZ2", "MYOZ3", "ANKRD1", "PDLIM3",
      "SYNPO2L"
    )
  ),
  "Calcium signaling" = list(
    "SR uptake / storage" = c(
      "ATP2A1", "ATP2A2", "CASQ1", "CASQ2", "SLN", "PLN", "HRC",
      "ASPH", "CALU", "SRI"
    ),
    "Release / coupling" = c(
      "RYR1", "CACNA1S", "STAC3", "JPH1", "TRDN", "FKBP1A", "CACNB1",
      "CACNG1", "SCN4A", "KCNJ2"
    ),
    "Regulation / buffering" = c(
      "CAMK2D", "CAMK2G", "CALM1", "CALM2", "CALM3", "S100A1",
      "ORAI1", "STIM1", "PPP3CA", "PPP3CB", "NFATC3"
    )
  ),
  "Cytoskeleton" = list(
    "Dystrophin complex" = c(
      "DMD", "DAG1", "SGCA", "SGCB", "SGCG", "SGCD", "DTNA", "UTRN",
      "CAV3", "SNTA1", "SNTB1"
    ),
    "Costamere / integrin" = c(
      "ITGA7", "ITGB1", "TLN1", "TLN2", "VCL", "PXN", "ILK", "PARVA",
      "FLNA", "FERMT2", "ZYX"
    ),
    "Intermediate scaffold" = c(
      "DES", "PLEC", "FLNC", "SYNM", "VIM", "DST", "NEB", "SPTBN1",
      "ACTN2", "ACTN3", "LMNA"
    )
  ),
  "ECM / collagen" = list(
    "Fibrillar collagen" = c(
      "COL1A1", "COL1A2", "COL3A1", "COL5A1", "COL5A2", "COL6A1",
      "COL6A2", "COL6A3", "COL12A1", "COL14A1", "DCN", "LUM"
    ),
    "Basement membrane" = c(
      "COL4A1", "COL4A2", "COL4A3", "COL4A4", "LAMA2", "LAMB1",
      "LAMC1", "NID1", "NID2", "HSPG2", "AGRN", "FN1"
    ),
    "Remodeling / crosslink" = c(
      "MMP2", "MMP9", "MMP14", "TIMP1", "TIMP2", "TIMP3", "LOX",
      "LOXL1", "LOXL2", "PLOD1", "PLOD2", "TGFB1", "TGFBI", "SPARC",
      "CCN2"
    )
  ),
  "Proteolysis" = list(
    "Calpain system" = c(
      "CAPN1", "CAPN2", "CAPN3", "CAPN5", "CAPN6", "CAST", "CAPNS1",
      "CAPNS2"
    ),
    "Ubiquitin-proteasome" = c(
      "TRIM63", "FBXO32", "UBB", "UBC", "UBE2D3", "UBE2E1", "PSMA1",
      "PSMA2", "PSMA3", "PSMB5", "PSMB6", "PSMC1", "PSMC4"
    ),
    "Autophagy / lysosome" = c(
      "BECN1", "ATG3", "ATG5", "ATG7", "ATG12", "MAP1LC3A",
      "MAP1LC3B", "SQSTM1", "LAMP1", "LAMP2", "CTSB", "CTSD", "CTSL",
      "TFEB", "ULK1"
    )
  ),
  "Lipid metabolism" = list(
    "Uptake / transport" = c(
      "CD36", "LPL", "FABP3", "FABP4", "SLC27A1", "SLC27A4", "ACSL1",
      "ACSL5", "CAV1", "VLDLR", "LRP1"
    ),
    "Synthesis / storage" = c(
      "ACACA", "ACACB", "FASN", "SCD", "ELOVL5", "ELOVL6", "DGAT1",
      "DGAT2", "GPAM", "AGPAT2", "PLIN1", "PLIN2", "PPARG", "CEBPA",
      "SREBF1"
    ),
    "Lipolysis" = c(
      "PNPLA2", "LIPE", "MGLL", "ABHD5", "PLIN1", "PLIN2", "G0S2",
      "PNPLA3", "CES1", "LIPA"
    ),
    "Beta-oxidation" = c(
      "CPT1B", "CPT2", "ACADL", "ACADM", "ACADS", "HADHA", "HADHB",
      "ETFDH", "ACAA2", "ECHS1", "PPARA", "PPARD"
    )
  ),
  "Mitochondrial oxidation" = list(
    "TCA cycle" = c(
      "CS", "ACO2", "IDH2", "IDH3A", "IDH3B", "IDH3G", "OGDH", "DLST",
      "SUCLG1", "SUCLG2", "SUCLA2", "SDHA", "SDHB", "FH", "MDH2", "PC"
    ),
    "ETC / ATP synthesis" = c(
      "NDUFS1", "NDUFS2", "NDUFS3", "NDUFV1", "NDUFV2", "UQCRC1",
      "UQCRC2", "CYC1", "COX4I1", "COX5A", "COX6A2", "ATP5F1A",
      "ATP5F1B", "ATP5MC1", "ATP5PD", "CKMT2"
    ),
    "Biogenesis" = c(
      "PPARGC1A", "PPARGC1B", "TFAM", "NRF1", "GABPA", "ESRRA", "MFN1",
      "MFN2", "OPA1", "DNM1L", "PINK1", "PRKN", "NFE2L2", "SIRT1",
      "SIRT3", "PGAM5"
    )
  ),
  "Glycolysis" = list(
    "Glycogen turnover" = c(
      "GYS1", "GYG1", "PYGM", "PGM1", "PHKA1", "PHKB", "PHKG1",
      "PPP1R3A", "AGL", "UGP2", "GSK3B"
    ),
    "Glycolytic flux" = c(
      "HK1", "HK2", "GPI", "PFKM", "ALDOA", "TPI1", "GAPDH", "PGK1",
      "PGAM2", "ENO3", "PKM", "PFKFB3"
    ),
    "Lactate / pH" = c(
      "LDHA", "LDHB", "SLC16A1", "SLC16A3", "CA3", "CA14", "SLC9A1",
      "PDK1", "PDK4", "PDP1", "MPC1", "MPC2", "HIF1A"
    )
  )
)
class_order <- names(signature_symbols)
subtype_order <- unlist(lapply(signature_symbols, names), use.names = FALSE)

# Expand definitions and map symbols to human Entrez IDs.
definition_rows <- list()
definition_index <- 0L
for (class_name in class_order) {
  subtype_list <- signature_symbols[[class_name]]
  for (subtype_name in names(subtype_list)) {
    for (i in seq_along(subtype_list[[subtype_name]])) {
      definition_index <- definition_index + 1L
      definition_rows[[definition_index]] <- data.frame(
        Function_class = class_name,
        Subtype = subtype_name,
        Gene_symbol = subtype_list[[subtype_name]][i],
        Class_order = match(class_name, class_order),
        Subtype_order = match(subtype_name, subtype_order),
        Gene_order = i,
        stringsAsFactors = FALSE
      )
    }
  }
}
definitions <- unique(do.call(rbind, definition_rows))
symbol_map <- AnnotationDbi::select(
  org.Hs.eg.db, keys = unique(definitions$Gene_symbol), keytype = "SYMBOL",
  columns = c("SYMBOL", "ENTREZID")
)
symbol_map <- symbol_map[!is.na(symbol_map$ENTREZID), ]
symbol_map <- symbol_map[!duplicated(symbol_map$SYMBOL), ]
definitions$Human_Entrez_ID <- as.character(symbol_map$ENTREZID[
  match(definitions$Gene_symbol, symbol_map$SYMBOL)
])
definitions$Mapped_to_Entrez <- !is.na(definitions$Human_Entrez_ID)

subtype_key <- paste(definitions$Function_class, definitions$Subtype,
                     sep = "::")
subtype_sets <- split(definitions$Human_Entrez_ID, subtype_key)
subtype_sets <- lapply(subtype_sets, function(x) unique(x[!is.na(x)]))
class_sets <- setNames(lapply(class_order, function(class_name) {
  unique(definitions$Human_Entrez_ID[
    definitions$Function_class == class_name &
      !is.na(definitions$Human_Entrez_ID)
  ])
}), class_order)

module_rows <- list()
module_sets <- list()
module_index <- 0L
for (class_name in class_order) {
  module_index <- module_index + 1L
  class_id <- paste0("Class::", class_name)
  module_sets[[class_id]] <- class_sets[[class_name]]
  module_rows[[module_index]] <- data.frame(
    Module_ID = class_id, Module_level = "Class",
    Function_class = class_name, Subtype = NA_character_,
    Module_label = class_name,
    Plot_order = module_index, stringsAsFactors = FALSE
  )
  for (subtype_name in names(signature_symbols[[class_name]])) {
    module_index <- module_index + 1L
    subtype_id <- paste0("Subtype::", class_name, "::", subtype_name)
    module_sets[[subtype_id]] <- subtype_sets[[paste(class_name, subtype_name,
                                                     sep = "::")]]
    module_rows[[module_index]] <- data.frame(
      Module_ID = subtype_id, Module_level = "Subtype",
      Function_class = class_name, Subtype = subtype_name,
      Module_label = subtype_name,
      Plot_order = module_index, stringsAsFactors = FALSE
    )
  }
}
module_reference <- do.call(rbind, module_rows)

# Transcriptome: DESeq2 VST and one sheep representative per human ortholog.
dds <- readRDS(dds_file)
rna_vst <- assay(vst(dds, blind = FALSE))
ortholog <- read.delim(ortholog_file, check.names = FALSE)
ortholog$Human_Entrez_ID <- as.character(ortholog$Human_Entrez_ID)
ortholog$Orthology_confidence <- suppressWarnings(
  as.numeric(ortholog$Orthology_confidence)
)
ortholog$Sheep_to_human_percent_identity <- suppressWarnings(
  as.numeric(ortholog$Sheep_to_human_percent_identity)
)
ortholog$Orthology_confidence[
  !is.finite(ortholog$Orthology_confidence)] <- -Inf
ortholog$Sheep_to_human_percent_identity[
  !is.finite(ortholog$Sheep_to_human_percent_identity)] <- -Inf
ortholog_valid <- ortholog[
  ortholog$Sheep_Ensembl_gene_id %in% rownames(rna_vst) &
    !is.na(ortholog$Human_Entrez_ID) & nzchar(ortholog$Human_Entrez_ID), ]
ortholog_valid <- ortholog_valid[order(
  ortholog_valid$Sheep_Ensembl_gene_id,
  -ortholog_valid$Orthology_confidence,
  -ortholog_valid$Sheep_to_human_percent_identity,
  ortholog_valid$Human_Entrez_ID
), ]
ortholog_valid <- ortholog_valid[
  !duplicated(ortholog_valid$Sheep_Ensembl_gene_id), ]
rna_mean <- rowMeans(rna_vst)
ortholog_valid$RNA_mean <- rna_mean[ortholog_valid$Sheep_Ensembl_gene_id]
ortholog_valid <- ortholog_valid[order(
  ortholog_valid$Human_Entrez_ID, -ortholog_valid$RNA_mean,
  ortholog_valid$Sheep_Ensembl_gene_id
), ]
rna_human_map <- ortholog_valid[
  !duplicated(ortholog_valid$Human_Entrez_ID), ]
rna_human_matrix <- rna_vst[
  rna_human_map$Sheep_Ensembl_gene_id, , drop = FALSE
]
rownames(rna_human_matrix) <- rna_human_map$Human_Entrez_ID
rna_metadata <- as.data.frame(colData(dds)[, c("Site", "Animal")])
rna_metadata$Sample <- rownames(rna_metadata)
rna_metadata$Site <- as.character(rna_metadata$Site)
rna_metadata$Animal <- as.character(rna_metadata$Animal)
rna_metadata <- rna_metadata[colnames(rna_human_matrix), ]

# Proteome: same 20% filter, half-minimum imputation, PPM aggregation and
# quantile normalization used by the preceding pairwise limma analysis.
protein <- openxlsx::read.xlsx(protein_file, sheet = "protein",
                               check.names = FALSE)
protein_samples <- as.vector(
  outer(c("LT", "SM", "PM", "AM"), 1:6, paste, sep = "_")
)
protein_character <- as.matrix(protein[, protein_samples, drop = FALSE])
protein_character <- apply(protein_character, 2, as.character)
protein_matrix <- matrix(
  suppressWarnings(as.numeric(protein_character)), nrow = nrow(protein),
  ncol = length(protein_samples),
  dimnames = list(as.character(seq_len(nrow(protein))), protein_samples)
)
protein_keep <- rowSums(!is.na(protein_matrix)) >= protein_min_samples
protein_filtered <- protein_matrix[protein_keep, , drop = FALSE]
protein_half_min <- apply(protein_filtered, 2, function(x) {
  min(x[is.finite(x) & x > 0]) / 2
})
protein_imputed <- protein_filtered
for (j in seq_len(ncol(protein_imputed))) {
  protein_imputed[is.na(protein_imputed[, j]), j] <- protein_half_min[j]
}
protein_ppm <- sweep(protein_imputed, 2, colSums(protein_imputed), "/") * 1e6
cross_mapping <- read.delim(cross_mapping_file, check.names = FALSE)
protein_human_map <- merge(
  unique(cross_mapping[, c("Protein_row", "gene_id")]),
  unique(ortholog[, c("Sheep_Ensembl_gene_id", "Human_Entrez_ID")]),
  by.x = "gene_id", by.y = "Sheep_Ensembl_gene_id", all = FALSE
)
protein_human_map$Human_Entrez_ID <- as.character(
  protein_human_map$Human_Entrez_ID
)
protein_human_map <- unique(protein_human_map[
  protein_human_map$Protein_row %in% as.integer(rownames(protein_ppm)) &
    !is.na(protein_human_map$Human_Entrez_ID) &
    nzchar(protein_human_map$Human_Entrez_ID),
  c("Protein_row", "Human_Entrez_ID")
])
genes_per_group <- aggregate(
  Human_Entrez_ID ~ Protein_row, protein_human_map,
  function(x) length(unique(x))
)
unambiguous_rows <- genes_per_group$Protein_row[
  genes_per_group$Human_Entrez_ID == 1L
]
protein_human_map <- protein_human_map[
  protein_human_map$Protein_row %in% unambiguous_rows, ]
protein_human_map <- protein_human_map[
  !duplicated(protein_human_map$Protein_row), ]
protein_indices <- match(
  protein_human_map$Protein_row, as.integer(rownames(protein_ppm))
)
protein_gene_ppm <- rowsum(
  protein_ppm[protein_indices, , drop = FALSE],
  group = protein_human_map$Human_Entrez_ID, reorder = FALSE
)
protein_human_matrix <- normalizeBetweenArrays(
  log2(protein_gene_ppm), method = "quantile"
)
protein_prefix <- sub("_.*$", "", protein_samples)
protein_site_map <- c(LT = "LTL", SM = "SM", PM = "PM", AM = "EAO")
protein_metadata <- data.frame(
  Sample = protein_samples,
  Site = unname(protein_site_map[protein_prefix]),
  Animal = sub("^.*_", "", protein_samples),
  row.names = protein_samples, stringsAsFactors = FALSE
)

# Mean of gene-wise Z-scores for each extended module.
score_modules <- function(expression_matrix, metadata, omics_name) {
  row_sd <- apply(expression_matrix, 1, sd, na.rm = TRUE)
  keep <- is.finite(row_sd) & row_sd > 0
  expression_matrix <- expression_matrix[keep, , drop = FALSE]
  row_z <- t(scale(t(expression_matrix)))
  score_rows <- list()
  coverage_rows <- list()
  index <- 0L
  for (module_id in module_reference$Module_ID) {
    defined_ids <- module_sets[[module_id]]
    available_ids <- intersect(defined_ids, rownames(row_z))
    score <- if (length(available_ids) >= minimum_genes_per_score) {
      colMeans(row_z[available_ids, , drop = FALSE])
    } else {
      setNames(rep(NA_real_, ncol(row_z)), colnames(row_z))
    }
    ref <- module_reference[module_reference$Module_ID == module_id, ]
    index <- index + 1L
    score_rows[[index]] <- data.frame(
      Sample = names(score),
      Site = metadata[names(score), "Site"],
      Animal = metadata[names(score), "Animal"],
      Omics = omics_name,
      Module_ID = module_id,
      Module_level = ref$Module_level,
      Function_class = ref$Function_class,
      Subtype = ref$Subtype,
      Module_label = ref$Module_label,
      Module_score = as.numeric(score),
      Genes_used = length(available_ids),
      stringsAsFactors = FALSE
    )
    coverage_rows[[index]] <- data.frame(
      Omics = omics_name,
      Module_ID = module_id,
      Module_level = ref$Module_level,
      Function_class = ref$Function_class,
      Subtype = ref$Subtype,
      Genes_defined = length(defined_ids),
      Genes_used = length(available_ids),
      Coverage_percent = 100 * length(available_ids) / length(defined_ids),
      Score_available = length(available_ids) >= minimum_genes_per_score,
      stringsAsFactors = FALSE
    )
  }
  list(scores = do.call(rbind, score_rows),
       coverage = do.call(rbind, coverage_rows))
}

rna_scored <- score_modules(rna_human_matrix, rna_metadata, "Transcriptome")
protein_scored <- score_modules(
  protein_human_matrix, protein_metadata, "Proteome"
)
module_scores <- rbind(rna_scored$scores, protein_scored$scores)
module_coverage <- rbind(rna_scored$coverage, protein_scored$coverage)

# Meat-quality data for the same six animals and four sites.
meat_raw <- openxlsx::read.xlsx(meat_file, sheet = "Sheet2",
                                check.names = FALSE)
meat <- data.frame(
  Animal = sub("^.*_", "", meat_raw$SampleID),
  Site = as.character(meat_raw$Group),
  L_45min = as.numeric(meat_raw$`L*.(Lightness)45min`),
  L_24h = as.numeric(meat_raw$`L*.(Lightness)24h`),
  a_45min = as.numeric(meat_raw$`a*.(Redness)45min`),
  a_24h = as.numeric(meat_raw$`a*.(Redness)24h`),
  b_45min = as.numeric(meat_raw$`b*.(Yellowness)45min`),
  b_24h = as.numeric(meat_raw$`b*.(Yellowness)24h`),
  pH_45min = as.numeric(meat_raw$pH.45min),
  pH_24h = as.numeric(meat_raw$pH.24h),
  Drip_loss = as.numeric(meat_raw$`Drip.loss,.%`),
  Cooking_loss = as.numeric(meat_raw$`Cooking.loss,.%`),
  Shear_force = as.numeric(meat_raw$`Shear.force,.N`),
  IMF = as.numeric(meat_raw$`IMF,%`),
  stringsAsFactors = FALSE
)
meat <- meat[
  meat$Animal %in% as.character(1:6) & meat$Site %in% site_order, ]
if (nrow(meat) != 24L || any(table(meat$Animal, meat$Site) != 1L)) {
  stop("Meat-quality data do not match the complete 6-animal omics design.")
}

trait_columns <- c(
  `45 min L*` = "L_45min", `24 h L*` = "L_24h",
  `45 min a*` = "a_45min", `24 h a*` = "a_24h",
  `45 min b*` = "b_45min", `24 h b*` = "b_24h",
  `45 min pH` = "pH_45min", `24 h pH` = "pH_24h",
  `Drip loss (%)` = "Drip_loss",
  `Cooking loss (%)` = "Cooking_loss",
  `Shear force (N)` = "Shear_force", `IMF (%)` = "IMF"
)
trait_order <- names(trait_columns)

# Repeated-measures correlations retain the four-site variation while
# controlling the six animal-specific intercepts.
correlation_rows <- list()
correlation_index <- 0L
for (omics_name in omics_order) {
  for (module_id in module_reference$Module_ID) {
    score_subset <- module_scores[
      module_scores$Omics == omics_name &
        module_scores$Module_ID == module_id, ]
    merged <- merge(score_subset, meat, by = c("Animal", "Site"),
                    all = FALSE, sort = FALSE)
    for (trait_name in trait_order) {
      trait_column <- trait_columns[[trait_name]]
      z <- data.frame(
        Animal = factor(merged$Animal),
        Module_score = merged$Module_score,
        Trait_value = merged[[trait_column]]
      )
      z <- z[complete.cases(z), ]
      fit_available <- nrow(z) == 24L && nlevels(z$Animal) == 6L &&
        sd(z$Module_score) > 0 && sd(z$Trait_value) > 0
      if (fit_available) {
        fit <- suppressWarnings(rmcorr::rmcorr(
          participant = Animal, measure1 = Module_score,
          measure2 = Trait_value, dataset = z
        ))
        r_value <- unname(fit$r)
        p_value <- unname(fit$p)
        degrees_freedom <- unname(fit$df)
        lower_ci <- unname(fit$CI[1])
        upper_ci <- unname(fit$CI[2])
      } else {
        r_value <- p_value <- degrees_freedom <- lower_ci <- upper_ci <- NA_real_
      }
      ref <- module_reference[module_reference$Module_ID == module_id, ]
      correlation_index <- correlation_index + 1L
      correlation_rows[[correlation_index]] <- data.frame(
        Omics = omics_name,
        Module_ID = module_id,
        Module_level = ref$Module_level,
        Function_class = ref$Function_class,
        Subtype = ref$Subtype,
        Module_label = ref$Module_label,
        Trait = trait_name,
        Animals = if (nrow(z)) nlevels(z$Animal) else 0,
        Observations = nrow(z),
        Repeated_measures_r = r_value,
        Lower_95CI = lower_ci,
        Upper_95CI = upper_ci,
        df = degrees_freedom,
        P_value = p_value,
        stringsAsFactors = FALSE
      )
    }
  }
}
correlations <- do.call(rbind, correlation_rows)
correlations$P_FDR_BH_within_omics_and_level <- NA_real_
for (omics_name in omics_order) {
  for (module_level in c("Class", "Subtype")) {
    use <- correlations$Omics == omics_name &
      correlations$Module_level == module_level &
      is.finite(correlations$P_value)
    correlations$P_FDR_BH_within_omics_and_level[use] <- p.adjust(
      correlations$P_value[use], method = "BH"
    )
  }
}
correlations$Significance_FDR <- ifelse(
  correlations$P_FDR_BH_within_omics_and_level < 0.001, "***",
  ifelse(correlations$P_FDR_BH_within_omics_and_level < 0.01, "**",
         ifelse(correlations$P_FDR_BH_within_omics_and_level < 0.05,
                "*", ""))
)
correlations$Significance_raw_P <- ifelse(
  correlations$P_value < 0.001, "***",
  ifelse(correlations$P_value < 0.01, "**",
         ifelse(correlations$P_value < 0.05, "*", ""))
)
correlations$Significance <- correlations$Significance_raw_P
correlations$Significant_raw_P_0.05 <-
  is.finite(correlations$P_value) & correlations$P_value < 0.05
correlations$Significant_FDR_0.05 <-
  is.finite(correlations$P_FDR_BH_within_omics_and_level) &
  correlations$P_FDR_BH_within_omics_and_level < fdr_threshold

# Corrplot-style subtype heatmaps, one output for each omics.
class_label_map <- c(
  `Muscle fiber type` = "Muscle fiber\ntype",
  `Contractile apparatus` = "Contractile\napparatus",
  `Calcium signaling` = "Calcium\nsignaling",
  Cytoskeleton = "Cytoskeleton",
  `ECM / collagen` = "ECM /\ncollagen",
  Proteolysis = "Proteolysis",
  `Lipid metabolism` = "Lipid\nmetabolism",
  `Mitochondrial oxidation` = "Mitochondrial\noxidation",
  Glycolysis = "Glycolysis"
)
plot_subtype_order <- unlist(lapply(signature_symbols, names), use.names = FALSE)

make_correlation_plot <- function(omics_name) {
  z <- correlations[
    correlations$Omics == omics_name &
      correlations$Module_level == "Subtype", ]
  z$Function_class_label <- factor(
    unname(class_label_map[z$Function_class]),
    levels = unname(class_label_map[class_order])
  )
  z$Subtype <- factor(z$Subtype, levels = plot_subtype_order)
  z$Trait <- factor(z$Trait, levels = rev(trait_order))
  z$Star_color <- ifelse(
    is.finite(z$Repeated_measures_r) & abs(z$Repeated_measures_r) >= 0.62,
    "white", "#202327"
  )
  ggplot(z, aes(x = Subtype, y = Trait)) +
    geom_tile(
      aes(fill = Repeated_measures_r), color = "white", linewidth = 0.45
    ) +
    geom_text(
      aes(label = Significance, color = Star_color),
      family = "Arial", fontface = "bold", size = 3.15
    ) +
    facet_grid(
      cols = vars(Function_class_label), scales = "free_x",
      space = "free_x", drop = TRUE
    ) +
    scale_fill_gradient2(
      name = "Repeated-measures r",
      low = "#365B8C", mid = "white", high = "#A65D68",
      midpoint = 0, limits = c(-1, 1),
      breaks = c(-1, -0.5, 0, 0.5, 1), na.value = "#EEEEEE"
    ) +
    scale_color_identity() +
    scale_x_discrete(drop = TRUE, expand = c(0, 0)) +
    scale_y_discrete(drop = FALSE, expand = c(0, 0)) +
    labs(x = NULL, y = NULL) +
    theme_bw(base_size = 10.5, base_family = "Arial") +
    theme(
      plot.title = element_blank(), plot.subtitle = element_blank(),
      plot.caption = element_blank(),
      panel.grid = element_blank(),
      panel.border = element_rect(color = "#393C40", linewidth = 0.42),
      panel.spacing.x = unit(1.4, "mm"),
      strip.background = element_rect(
        fill = "#F1F1F1", color = "#B7BABE", linewidth = 0.38
      ),
      strip.text.x = element_text(
        face = "bold", size = 8.0, color = "#292C30", lineheight = 0.90,
        margin = margin(3.0, 2.0, 3.0, 2.0)
      ),
      axis.text.x = element_text(
        angle = -45, hjust = 0, vjust = 1, size = 7.7,
        color = "#25282C", margin = margin(t = 3)
      ),
      axis.text.y = element_text(size = 8.5, color = "#25282C"),
      axis.ticks = element_blank(),
      legend.position = "right",
      legend.title = element_text(face = "bold", size = 8.8),
      legend.text = element_text(size = 8.0),
      legend.key.height = unit(5.2, "mm"),
      plot.margin = margin(4, 5, 4, 4)
    )
}

save_three_formats <- function(plot, output_stub) {
  plot_width <- 16.8
  plot_height <- 7.8
  ggsave(
    paste0(output_stub, ".pdf"), plot, device = cairo_pdf,
    width = plot_width, height = plot_height, units = "in", family = "Arial"
  )
  png(
    paste0(output_stub, ".png"), width = plot_width, height = plot_height,
    units = "in", res = 450, type = "cairo", family = "Arial", bg = "white"
  )
  print(plot)
  dev.off()
  svg(
    paste0(output_stub, ".svg"), width = plot_width, height = plot_height,
    family = "Arial", pointsize = 10.5, onefile = TRUE, bg = "white"
  )
  print(plot)
  dev.off()
}

rna_plot <- make_correlation_plot("Transcriptome")
protein_plot <- make_correlation_plot("Proteome")
rna_stub <- file.path(
  figure_dir,
  "Fig2_transcriptome_27_subtype_meat_quality_rmcorr_heatmap"
)
protein_stub <- file.path(
  figure_dir,
  "Fig2_proteome_27_subtype_meat_quality_rmcorr_heatmap"
)
save_three_formats(rna_plot, rna_stub)
save_three_formats(protein_plot, protein_stub)

# Exact tables and audit trail.
write_tsv <- function(x, filename) {
  write.table(
    x, file.path(table_dir, filename), sep = "\t", quote = FALSE,
    row.names = FALSE, na = "NA"
  )
}
write_tsv(
  definitions,
  "Fig2_extended_27_subtype_gene_set_definitions.tsv"
)
write_tsv(
  module_coverage,
  "Fig2_extended_class_subtype_module_gene_coverage.tsv"
)
write_tsv(
  module_scores,
  "Fig2_extended_class_subtype_module_scores.tsv"
)
write_tsv(
  correlations,
  "Fig2_extended_class_subtype_meat_quality_rmcorr_results.tsv"
)

raw_significant_summary <- aggregate(
  Significant_raw_P_0.05 ~ Omics + Module_level, correlations, sum
)
names(raw_significant_summary)[3] <-
  "Significant_correlations_raw_P_lt_0.05"
fdr_significant_summary <- aggregate(
  Significant_FDR_0.05 ~ Omics + Module_level, correlations, sum
)
names(fdr_significant_summary)[3] <-
  "Significant_correlations_FDR_lt_0.05"
significant_summary <- merge(
  raw_significant_summary, fdr_significant_summary,
  by = c("Omics", "Module_level"), all = TRUE
)
qa <- data.frame(
  Metric = c(
    "Animals", "Sites", "Meat-quality traits", "Major classes",
    "Functional subtypes", "Module definition", "Module score",
    "Minimum genes per score", "Correlation method", "Correlation scope",
    "Subtype FDR family", "Class FDR family", "Heatmap X axis",
    "Heatmap Y axis", "Heatmap significance", "Typeface",
    "Figure size inches"
  ),
  Value = c(
    6, paste(site_order, collapse = ", "), length(trait_order),
    length(class_order), length(plot_subtype_order),
    "Extended a priori marker sets; not selected from current correlations",
    "Mean across gene-wise Z-scores within each omics and module",
    minimum_genes_per_score,
    "Repeated-measures correlation (rmcorr), controlling Animal intercepts",
    "Retains four-site variation within each animal",
    "BH across 27 subtypes x 12 traits separately within each omics",
    "BH across 9 classes x 12 traits separately within each omics",
    "27 subtypes grouped by nine functional classes",
    "12 meat-quality traits",
    "Stars use raw P (* <0.05, ** <0.01, *** <0.001); BH-FDR retained in tables",
    "Arial", "16.8 x 7.8"
  ), stringsAsFactors = FALSE
)
write_tsv(
  significant_summary,
  "Fig2_extended_module_meat_quality_rmcorr_significant_counts.tsv"
)
write_tsv(qa, "Fig2_extended_module_meat_quality_rmcorr_QA.tsv")
openxlsx::write.xlsx(
  list(
    Extended_gene_sets = definitions,
    Module_coverage = module_coverage,
    Module_scores = module_scores,
    Correlation_results = correlations,
    Significant_summary = significant_summary,
    QA = qa
  ),
  file.path(
    table_dir,
    "Fig2_extended_class_subtype_meat_quality_rmcorr_results.xlsx"
  ),
  overwrite = TRUE
)

cat("Extended module-score correlation analysis completed.\n")
cat("Mapped signature rows:", sum(definitions$Mapped_to_Entrez), "/",
    nrow(definitions), "\n")
cat("Score rows:", nrow(module_scores), "\n")
cat("Correlation rows:", nrow(correlations), "\n")
cat("\nModule coverage:\n")
print(module_coverage)
cat("\nSignificant correlation counts:\n")
print(significant_summary)
cat("\nTranscriptome PDF:", paste0(rna_stub, ".pdf"), "\n")
cat("Proteome PDF:", paste0(protein_stub, ".pdf"), "\n")
