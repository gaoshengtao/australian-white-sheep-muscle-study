#!/usr/bin/env Rscript

# Transcriptome/proteome detection overlap and cross-gene abundance regression

rm(list = ls())

suppressPackageStartupMessages({
  library(ggplot2)
  library(grid)
  library(openxlsx)
})

options(stringsAsFactors = FALSE)

# Paths and prespecified thresholds ------------------------------------------
project_dir <- "__PROJECT_ROOT__"
work_dir <- file.path(project_dir, "07_Figure2_muscle_functional_states")
figure_dir <- file.path(work_dir, "Figures")
table_dir <- file.path(work_dir, "Tables")
dir.create(figure_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(table_dir, recursive = TRUE, showWarnings = FALSE)

raw_count_file <- file.path(
  project_dir, "04_transcriptome", "02_counts", "gene_read_counts.tsv"
)
normalized_count_file <- file.path(
  work_dir, "01_Transcriptome_PCoA_Adonis", "Tables",
  "DESeq2_size_factor_normalized_counts.tsv.gz"
)
gene_mapping_file <- file.path(
  project_dir, "04_transcriptome", "04_ID_mapping",
  "Ensembl115_gene_symbol_mapping_one_row_per_gene.tsv"
)
protein_file <- file.path(project_dir, "05_protein", "protein.xlsx")
cross_omics_mapping_file <- file.path(
  project_dir, "04_transcriptome", "04_ID_mapping",
  "transcriptome_proteome_Gene_symbol_matches.tsv"
)

required_files <- c(
  raw_count_file, normalized_count_file, gene_mapping_file,
  protein_file, cross_omics_mapping_file
)
missing_files <- required_files[!file.exists(required_files)]
if (length(missing_files)) {
  stop("Missing input files: ", paste(missing_files, collapse = ", "))
}

sample_fraction_threshold <- 0.20
transcript_min_raw_count <- 10
plot_width_in <- 4.4
plot_height_in <- 4.4
transcript_color <- "#365B8C"
protein_color <- "#C28B48"
fit_color <- "#A65D68"

write_tsv <- function(object, filename) {
  write.table(
    object, file.path(table_dir, filename), sep = "\t", quote = FALSE,
    row.names = FALSE, na = "NA"
  )
}

write_tsv_gz <- function(object, filename) {
  con <- gzfile(file.path(table_dir, filename), open = "wt")
  on.exit(close(con), add = TRUE)
  write.table(
    object, con, sep = "\t", quote = FALSE, row.names = FALSE, na = "NA"
  )
}

clean_symbol <- function(x) {
  x <- toupper(trimws(as.character(x)))
  x[is.na(x)] <- ""
  x
}

# Transcript filtering and symbol-level abundance ----------------------------
raw_counts <- read.delim(
  raw_count_file, header = TRUE, check.names = FALSE,
  quote = "", comment.char = ""
)
if (names(raw_counts)[1] != "gene_id" || anyDuplicated(raw_counts$gene_id)) {
  stop("Unexpected raw transcript count matrix structure.")
}
transcript_samples <- setdiff(names(raw_counts), "gene_id")
if (length(transcript_samples) != 24L) stop("Expected 24 transcript samples.")
raw_count_matrix <- as.matrix(raw_counts[, transcript_samples, drop = FALSE])
storage.mode(raw_count_matrix) <- "numeric"
if (any(!is.finite(raw_count_matrix)) || any(raw_count_matrix < 0)) {
  stop("Raw transcript count matrix contains invalid values.")
}
min_samples <- ceiling(sample_fraction_threshold * length(transcript_samples))
transcript_samples_passing <- rowSums(
  raw_count_matrix >= transcript_min_raw_count
)
transcript_keep <- transcript_samples_passing >= min_samples

gene_mapping <- read.delim(
  gene_mapping_file, header = TRUE, check.names = FALSE,
  quote = "", comment.char = ""
)
required_gene_mapping <- c("gene_id", "Gene_symbol", "Gene_symbol_upper")
if (!all(required_gene_mapping %in% names(gene_mapping)) ||
    anyDuplicated(gene_mapping$gene_id)) {
  stop("Gene-symbol mapping table failed validation.")
}
gene_mapping$Gene_symbol_upper <- clean_symbol(gene_mapping$Gene_symbol_upper)
map_index <- match(raw_counts$gene_id, gene_mapping$gene_id)
if (anyNA(map_index)) stop("Raw count genes are missing from mapping table.")

transcript_filter_table <- data.frame(
  gene_id = raw_counts$gene_id,
  Gene_symbol = gene_mapping$Gene_symbol[map_index],
  Gene_symbol_upper = gene_mapping$Gene_symbol_upper[map_index],
  Samples_raw_count_ge_10 = transcript_samples_passing,
  Total_samples = length(transcript_samples),
  Pass_filter = transcript_keep,
  Has_mapped_symbol = nzchar(gene_mapping$Gene_symbol_upper[map_index]),
  stringsAsFactors = FALSE
)

normalized_counts <- read.delim(
  gzfile(normalized_count_file), header = TRUE, check.names = FALSE,
  quote = "", comment.char = ""
)
if (names(normalized_counts)[1] != "gene_id" ||
    anyDuplicated(normalized_counts$gene_id) ||
    !setequal(setdiff(names(normalized_counts), "gene_id"), transcript_samples)) {
  stop("Unexpected DESeq2-normalized count matrix structure.")
}
normalized_index <- match(raw_counts$gene_id, normalized_counts$gene_id)
if (anyNA(normalized_index)) stop("Raw genes missing from normalized matrix.")
normalized_matrix <- as.matrix(
  normalized_counts[normalized_index, transcript_samples, drop = FALSE]
)
storage.mode(normalized_matrix) <- "numeric"

transcript_mapped_keep <- transcript_keep &
  nzchar(transcript_filter_table$Gene_symbol_upper)
transcript_symbol_matrix <- rowsum(
  normalized_matrix[transcript_mapped_keep, , drop = FALSE],
  group = transcript_filter_table$Gene_symbol_upper[transcript_mapped_keep],
  reorder = FALSE
)
transcript_symbol_mean <- rowMeans(transcript_symbol_matrix)
transcript_symbols <- rownames(transcript_symbol_matrix)

# Protein filtering, mapping, half-minimum imputation and normalization -------
protein <- openxlsx::read.xlsx(
  protein_file, sheet = "protein", check.names = FALSE
)
required_protein_columns <- c("PG.ProteinGroups", "PG.Genes")
if (!all(required_protein_columns %in% names(protein))) {
  stop("Protein workbook lacks PG.ProteinGroups or PG.Genes.")
}
protein_samples <- grep("^(LT|SM|PM|AM)_[1-6]$", names(protein), value = TRUE)
expected_protein_samples <- as.vector(
  outer(c("LT", "SM", "PM", "AM"), 1:6, paste, sep = "_")
)
if (length(protein_samples) != 24L ||
    !setequal(protein_samples, expected_protein_samples)) {
  stop("Expected 24 LT/SM/PM/AM protein samples.")
}
protein_samples <- expected_protein_samples
protein_character <- as.matrix(protein[, protein_samples, drop = FALSE])
protein_character <- apply(protein_character, 2, as.character)
protein_abundance <- matrix(
  suppressWarnings(as.numeric(protein_character)),
  nrow = nrow(protein), ncol = length(protein_samples),
  dimnames = list(seq_len(nrow(protein)), protein_samples)
)
unexpected_non_numeric <- is.na(protein_abundance) &
  nzchar(trimws(protein_character)) &
  !toupper(trimws(protein_character)) %in% c("NA", "N/A", "NAN")
if (any(unexpected_non_numeric)) {
  stop("Unexpected non-numeric protein abundance values detected.")
}
if (any(protein_abundance <= 0, na.rm = TRUE)) {
  stop("Protein abundance includes zero or negative values; review detection rule.")
}

protein_detected_samples <- rowSums(!is.na(protein_abundance))
protein_keep <- protein_detected_samples >= min_samples
protein_rows_kept <- which(protein_keep)
protein_filtered <- protein_abundance[protein_keep, , drop = FALSE]
protein_missing_before <- sum(is.na(protein_filtered))
protein_half_min_by_sample <- apply(protein_filtered, 2, function(x) {
  min(x[is.finite(x) & x > 0]) / 2
})
if (any(!is.finite(protein_half_min_by_sample) |
        protein_half_min_by_sample <= 0)) {
  stop("Could not define positive half-minimum imputation values.")
}
protein_imputed <- protein_filtered
for (j in seq_len(ncol(protein_imputed))) {
  protein_imputed[is.na(protein_imputed[, j]), j] <-
    protein_half_min_by_sample[j]
}
if (anyNA(protein_imputed)) stop("Protein half-minimum imputation failed.")
protein_imputed_ppm <- sweep(
  protein_imputed, 2, colSums(protein_imputed), "/"
) * 1e6

cross_mapping <- read.delim(
  cross_omics_mapping_file, header = TRUE, check.names = FALSE,
  quote = "", comment.char = ""
)
required_cross_mapping <- c("Protein_row", "gene_id", "Gene_symbol")
if (!all(required_cross_mapping %in% names(cross_mapping))) {
  stop("Cross-omics mapping table lacks required columns.")
}
cross_mapping$Gene_symbol_upper <- clean_symbol(cross_mapping$Gene_symbol)
filtered_mapping <- unique(cross_mapping[
  cross_mapping$Protein_row %in% protein_rows_kept &
    nzchar(cross_mapping$Gene_symbol_upper),
  c("Protein_row", "Gene_symbol", "Gene_symbol_upper")
])

protein_symbols_all_mapped <- unique(filtered_mapping$Gene_symbol_upper)
symbols_per_protein_row <- aggregate(
  Gene_symbol_upper ~ Protein_row, filtered_mapping,
  function(x) length(unique(x[nzchar(x)]))
)
names(symbols_per_protein_row)[2] <- "Mapped_symbols_in_protein_group"
unambiguous_protein_rows <- symbols_per_protein_row$Protein_row[
  symbols_per_protein_row$Mapped_symbols_in_protein_group == 1L
]
ambiguous_protein_rows <- symbols_per_protein_row$Protein_row[
  symbols_per_protein_row$Mapped_symbols_in_protein_group > 1L
]
unambiguous_mapping <- unique(filtered_mapping[
  filtered_mapping$Protein_row %in% unambiguous_protein_rows,
  c("Protein_row", "Gene_symbol_upper")
])
if (anyDuplicated(unambiguous_mapping$Protein_row)) {
  stop("An allegedly unambiguous protein row maps to multiple symbols.")
}

protein_row_to_filtered_index <- match(
  unambiguous_mapping$Protein_row, protein_rows_kept
)
if (anyNA(protein_row_to_filtered_index)) stop("Protein-row alignment failed.")
protein_unambiguous_ppm <- protein_imputed_ppm[
  protein_row_to_filtered_index, , drop = FALSE
]
protein_symbol_matrix <- rowsum(
  protein_unambiguous_ppm,
  group = unambiguous_mapping$Gene_symbol_upper,
  reorder = FALSE
)
protein_symbol_mean <- rowMeans(protein_symbol_matrix)
protein_symbols_unambiguous <- rownames(protein_symbol_matrix)

protein_filter_table <- data.frame(
  Protein_row = seq_len(nrow(protein)),
  PG.ProteinGroups = as.character(protein$PG.ProteinGroups),
  PG.Genes = as.character(protein$PG.Genes),
  Nonmissing_samples = protein_detected_samples,
  Total_samples = length(protein_samples),
  Pass_filter = protein_keep,
  stringsAsFactors = FALSE,
  check.names = FALSE
)
mapped_symbol_count <- integer(nrow(protein_filter_table))
mapped_symbol_count[match(
  symbols_per_protein_row$Protein_row,
  protein_filter_table$Protein_row
)] <- symbols_per_protein_row$Mapped_symbols_in_protein_group
protein_filter_table$Mapped_standard_symbols <- mapped_symbol_count
protein_filter_table$Mapping_class <- ifelse(
  !protein_filter_table$Pass_filter, "Failed detection filter",
  ifelse(
    protein_filter_table$Mapped_standard_symbols == 0, "No mapped standard symbol",
    ifelse(
      protein_filter_table$Mapped_standard_symbols == 1,
      "One mapped standard symbol", "Multiple mapped standard symbols"
    )
  )
)

# Venn membership: all filtered, mapped primary symbols ----------------------
overlap_symbols <- intersect(transcript_symbols, protein_symbols_all_mapped)
transcript_only_symbols <- setdiff(transcript_symbols, protein_symbols_all_mapped)
protein_only_symbols <- setdiff(protein_symbols_all_mapped, transcript_symbols)
union_symbols <- union(transcript_symbols, protein_symbols_all_mapped)

venn_membership <- data.frame(
  Gene_symbol_upper = union_symbols,
  Transcriptome = union_symbols %in% transcript_symbols,
  Proteome = union_symbols %in% protein_symbols_all_mapped,
  Region = ifelse(
    union_symbols %in% overlap_symbols, "Intersection",
    ifelse(
      union_symbols %in% transcript_only_symbols,
      "Transcriptome only", "Proteome only"
    )
  ),
  stringsAsFactors = FALSE
)
venn_counts <- data.frame(
  Region = c(
    "Transcriptome total", "Proteome total", "Transcriptome only",
    "Intersection", "Proteome only"
  ),
  Gene_symbols = c(
    length(transcript_symbols), length(protein_symbols_all_mapped),
    length(transcript_only_symbols), length(overlap_symbols),
    length(protein_only_symbols)
  ),
  stringsAsFactors = FALSE
)

# Area-proportional two-set Euler-style Venn geometry ------------------------
circle_overlap_area <- function(r1, r2, d) {
  if (d >= r1 + r2) return(0)
  if (d <= abs(r1 - r2)) return(pi * min(r1, r2)^2)
  a1 <- r1^2 * acos((d^2 + r1^2 - r2^2) / (2 * d * r1))
  a2 <- r2^2 * acos((d^2 + r2^2 - r1^2) / (2 * d * r2))
  a3 <- 0.5 * sqrt(
    (-d + r1 + r2) * (d + r1 - r2) *
      (d - r1 + r2) * (d + r1 + r2)
  )
  a1 + a2 - a3
}

r_transcript <- 1.50
r_protein <- r_transcript * sqrt(
  length(protein_symbols_all_mapped) / length(transcript_symbols)
)
target_overlap_fraction <- length(overlap_symbols) /
  length(protein_symbols_all_mapped)
target_overlap_area <- target_overlap_fraction * pi * r_protein^2
distance_solution <- optimize(
  function(d) abs(circle_overlap_area(r_transcript, r_protein, d) -
                         target_overlap_area),
  interval = c(abs(r_transcript - r_protein) + 1e-6,
               r_transcript + r_protein - 1e-6)
)$minimum
protein_center_x <- distance_solution

circle_polygon <- function(cx, cy, radius, set_name, n = 800L) {
  theta <- seq(0, 2 * pi, length.out = n)
  data.frame(
    x = cx + radius * cos(theta),
    y = cy + radius * sin(theta),
    Set = set_name,
    stringsAsFactors = FALSE
  )
}
venn_circles <- rbind(
  circle_polygon(0, 0, r_transcript, "Transcriptome"),
  circle_polygon(protein_center_x, 0, r_protein, "Proteome")
)
venn_circles$Set <- factor(
  venn_circles$Set, levels = c("Transcriptome", "Proteome")
)

right_protein_edge <- protein_center_x + r_protein
right_transcript_edge <- r_transcript
protein_only_anchor_x <- (right_protein_edge + right_transcript_edge) / 2
protein_only_label_x <- right_protein_edge + 0.40

p_venn <- ggplot() +
  geom_polygon(
    data = venn_circles,
    aes(x = x, y = y, group = Set, fill = Set, color = Set),
    alpha = 0.34, linewidth = 0.75
  ) +
  annotate(
    "text", x = -0.72, y = 0,
    label = format(length(transcript_only_symbols), big.mark = ","),
    family = "Arial", fontface = "bold", size = 5.0, color = "#25282C"
  ) +
  annotate(
    "text", x = protein_center_x - 0.12, y = 0,
    label = format(length(overlap_symbols), big.mark = ","),
    family = "Arial", fontface = "bold", size = 5.0, color = "#25282C"
  ) +
  annotate(
    "segment", x = protein_only_anchor_x, y = 0.05,
    xend = protein_only_label_x - 0.08, yend = 0.40,
    color = "#6B7178", linewidth = 0.40
  ) +
  annotate(
    "text", x = protein_only_label_x, y = 0.46,
    label = format(length(protein_only_symbols), big.mark = ","),
    family = "Arial", fontface = "bold", size = 4.3, color = "#25282C"
  ) +
  annotate(
    "text", x = -0.55, y = 1.73,
    label = paste0(
      "Transcriptome\n(n = ",
      format(length(transcript_symbols), big.mark = ","), ")"
    ),
    family = "Arial", fontface = "bold", size = 3.9,
    color = transcript_color
  ) +
  annotate(
    "text", x = protein_center_x + 0.45, y = 1.08,
    label = paste0(
      "Proteome\n(n = ",
      format(length(protein_symbols_all_mapped), big.mark = ","), ")"
    ),
    family = "Arial", fontface = "bold", size = 3.9,
    color = protein_color
  ) +
  scale_fill_manual(
    values = c(Transcriptome = transcript_color, Proteome = protein_color),
    guide = "none"
  ) +
  scale_color_manual(
    values = c(Transcriptome = transcript_color, Proteome = protein_color),
    guide = "none"
  ) +
  coord_fixed(
    ratio = 1,
    xlim = c(-1.70, protein_only_label_x + 0.35),
    ylim = c(-1.68, 1.95),
    clip = "off", expand = FALSE
  ) +
  theme_void(base_size = 10.5, base_family = "Arial") +
  theme(
    aspect.ratio = 1,
    plot.margin = margin(t = 8, r = 8, b = 8, l = 8)
  )

# Cross-gene abundance regression on unambiguous mapped protein groups --------
regression_symbols <- intersect(
  transcript_symbols, protein_symbols_unambiguous
)
regression_data <- data.frame(
  Gene_symbol_upper = regression_symbols,
  Mean_DESeq2_normalized_count = unname(
    transcript_symbol_mean[regression_symbols]
  ),
  Mean_protein_PPM_half_min_imputed = unname(
    protein_symbol_mean[regression_symbols]
  ),
  stringsAsFactors = FALSE
)
regression_data$Log2_mean_transcript_abundance <- log2(
  regression_data$Mean_DESeq2_normalized_count + 1
)
regression_data$Log2_mean_protein_abundance <- log2(
  regression_data$Mean_protein_PPM_half_min_imputed + 1
)
if (nrow(regression_data) < 100L || any(!is.finite(as.matrix(
  regression_data[, c(
    "Log2_mean_transcript_abundance", "Log2_mean_protein_abundance"
  )]
)))) {
  stop("Regression data failed validation.")
}

linear_fit <- lm(
  Log2_mean_protein_abundance ~ Log2_mean_transcript_abundance,
  data = regression_data
)
fit_summary <- summary(linear_fit)
pearson_test <- cor.test(
  regression_data$Log2_mean_transcript_abundance,
  regression_data$Log2_mean_protein_abundance,
  method = "pearson"
)
spearman_test <- cor.test(
  regression_data$Log2_mean_transcript_abundance,
  regression_data$Log2_mean_protein_abundance,
  method = "spearman", exact = FALSE
)

# Zero-fill sensitivity uses the same filter, normalization and unambiguous map.
protein_zero <- protein_filtered
protein_zero[is.na(protein_zero)] <- 0
protein_zero_ppm <- sweep(protein_zero, 2, colSums(protein_zero), "/") * 1e6
protein_zero_symbol_matrix <- rowsum(
  protein_zero_ppm[protein_row_to_filtered_index, , drop = FALSE],
  group = unambiguous_mapping$Gene_symbol_upper,
  reorder = FALSE
)
protein_zero_mean <- rowMeans(protein_zero_symbol_matrix)
zero_y <- log2(protein_zero_mean[regression_symbols] + 1)
zero_pearson <- cor.test(
  regression_data$Log2_mean_transcript_abundance, zero_y,
  method = "pearson"
)
zero_spearman <- cor.test(
  regression_data$Log2_mean_transcript_abundance, zero_y,
  method = "spearman", exact = FALSE
)

regression_statistics <- data.frame(
  Analysis = c("Primary half-minimum imputation", "Sensitivity zero fill"),
  Genes = nrow(regression_data),
  Pearson_r = c(unname(pearson_test$estimate), unname(zero_pearson$estimate)),
  Pearson_P = c(pearson_test$p.value, zero_pearson$p.value),
  Spearman_rho = c(
    unname(spearman_test$estimate), unname(zero_spearman$estimate)
  ),
  Spearman_P = c(spearman_test$p.value, zero_spearman$p.value),
  Linear_model_intercept = c(coef(linear_fit)[1], NA_real_),
  Linear_model_slope = c(coef(linear_fit)[2], NA_real_),
  Linear_model_R_squared = c(fit_summary$r.squared, NA_real_),
  Linear_model_adjusted_R_squared = c(fit_summary$adj.r.squared, NA_real_),
  stringsAsFactors = FALSE
)

p_label <- if (pearson_test$p.value < 2.2e-16) {
  "P < 2.2e-16"
} else {
  paste0("P = ", format.pval(pearson_test$p.value, digits = 2))
}
regression_annotation <- paste0(
  "Pearson r = ", sprintf("%.2f", pearson_test$estimate),
  "\nR2 = ", sprintf("%.2f", fit_summary$r.squared),
  "\n", p_label,
  "\nn = ", format(nrow(regression_data), big.mark = ","), " genes"
)

p_regression <- ggplot(
  regression_data,
  aes(
    x = Log2_mean_transcript_abundance,
    y = Log2_mean_protein_abundance
  )
) +
  geom_point(
    shape = 21, size = 1.55, stroke = 0.18,
    fill = transcript_color, color = "white", alpha = 0.28
  ) +
  geom_smooth(
    method = "lm", formula = y ~ x, se = TRUE, level = 0.95,
    color = fit_color, fill = "#E2BCC0", linewidth = 0.9, alpha = 0.30
  ) +
  annotate(
    "text", x = -Inf, y = Inf, label = regression_annotation,
    hjust = -0.06, vjust = 1.08,
    family = "Arial", size = 3.2, lineheight = 1.08,
    color = "#25282C"
  ) +
  labs(
    x = "Mean transcript abundance\nlog2(normalized count + 1)",
    y = "Mean protein abundance\nlog2(PPM + 1)"
  ) +
  theme_bw(base_size = 10.5, base_family = "Arial") +
  theme(
    aspect.ratio = 1,
    plot.title = element_blank(),
    panel.grid.major = element_line(color = "#E7E8EA", linewidth = 0.35),
    panel.grid.minor = element_blank(),
    panel.border = element_rect(color = "#25282C", linewidth = 0.45),
    axis.title = element_text(size = 10, color = "#25282C"),
    axis.text = element_text(size = 9, color = "#25282C"),
    axis.ticks = element_line(color = "#25282C", linewidth = 0.35),
    plot.margin = margin(t = 8, r = 8, b = 8, l = 8)
  )

# Figure export ---------------------------------------------------------------
save_plot <- function(plot, stub) {
  ggsave(
    paste0(stub, ".pdf"), plot, device = cairo_pdf,
    width = plot_width_in, height = plot_height_in,
    units = "in", family = "Arial"
  )
  png(
    paste0(stub, ".png"), width = plot_width_in, height = plot_height_in,
    units = "in", res = 600, type = "cairo", family = "Arial", bg = "white"
  )
  print(plot)
  dev.off()
  svg(
    paste0(stub, ".svg"), width = plot_width_in, height = plot_height_in,
    family = "Arial", pointsize = 10.5, onefile = TRUE, bg = "white"
  )
  print(plot)
  dev.off()
}

venn_stub <- file.path(
  figure_dir, "Fig2_Transcriptome_Proteome_filtered_gene_overlap_Venn"
)
regression_stub <- file.path(
  figure_dir, "Fig2_Transcriptome_Proteome_mean_abundance_regression"
)
save_plot(p_venn, venn_stub)
save_plot(p_regression, regression_stub)

# Export filtered matrices, plot data, results and QA -------------------------
transcript_symbol_export <- data.frame(
  Gene_symbol_upper = rownames(transcript_symbol_matrix),
  transcript_symbol_matrix,
  check.names = FALSE, row.names = NULL
)
protein_imputed_export <- data.frame(
  Protein_row = protein_rows_kept,
  PG.ProteinGroups = protein$PG.ProteinGroups[protein_rows_kept],
  PG.Genes = protein$PG.Genes[protein_rows_kept],
  protein_imputed_ppm,
  check.names = FALSE, row.names = NULL
)
protein_symbol_export <- data.frame(
  Gene_symbol_upper = rownames(protein_symbol_matrix),
  protein_symbol_matrix,
  check.names = FALSE, row.names = NULL
)
half_min_table <- data.frame(
  Sample = protein_samples,
  Half_minimum_imputation_value = protein_half_min_by_sample,
  Missing_values_imputed = colSums(is.na(protein_filtered)),
  stringsAsFactors = FALSE
)

qa <- data.frame(
  Metric = c(
    "Samples per omics", "Twenty-percent sample threshold",
    "Transcript raw-count threshold",
    "Transcript Ensembl genes before filtering",
    "Transcript Ensembl genes after filtering",
    "Filtered transcript Ensembl genes with mapped symbol",
    "Filtered transcript unique mapped symbols",
    "Protein groups before filtering", "Protein groups after filtering",
    "Missing protein cells before filtering",
    "Missing protein cells after filtering",
    "Missing fraction among filtered protein cells",
    "Filtered protein groups with mapped symbol",
    "Filtered protein groups with one mapped symbol",
    "Filtered protein groups with multiple mapped symbols",
    "Filtered protein unique mapped symbols", "Venn intersection symbols",
    "Venn transcript-only symbols", "Venn protein-only symbols",
    "Regression symbols after ambiguous-group exclusion",
    "Protein missing-value treatment", "Protein normalization",
    "Transcript abundance for regression", "Protein abundance for regression",
    "Primary Pearson r", "Primary linear-model R squared",
    "Primary Spearman rho", "Venn geometry", "Figure dimensions inches",
    "Typeface"
  ),
  Value = as.character(c(
    length(transcript_samples), min_samples,
    paste0("Raw count >= ", transcript_min_raw_count,
           " in at least ", min_samples, " of 24 samples"),
    nrow(raw_counts), sum(transcript_keep), sum(transcript_mapped_keep),
    length(transcript_symbols), nrow(protein), sum(protein_keep),
    sum(is.na(protein_abundance)), protein_missing_before,
    protein_missing_before / length(protein_filtered),
    length(unique(filtered_mapping$Protein_row)),
    length(unambiguous_protein_rows), length(ambiguous_protein_rows),
    length(protein_symbols_all_mapped), length(overlap_symbols),
    length(transcript_only_symbols), length(protein_only_symbols),
    nrow(regression_data),
    "Per-sample half of minimum positive abundance after feature filtering",
    "Sample-total scaling to 1,000,000 after imputation",
    "Mean across 24 samples after summing DESeq2-normalized Ensembl rows by symbol",
    "Mean across 24 samples after summing unambiguous protein-group PPM by symbol",
    unname(pearson_test$estimate), fit_summary$r.squared,
    unname(spearman_test$estimate),
    "Area proportional two-set Euler-style Venn; exact region counts labelled",
    paste(plot_width_in, "x", plot_height_in), "Arial"
  )),
  stringsAsFactors = FALSE
)

write_tsv_gz(
  transcript_filter_table[transcript_filter_table$Pass_filter, ],
  "Fig2_transcript_genes_filtered_raw_count10_in_20percent_samples.tsv.gz"
)
write_tsv_gz(
  protein_filter_table[protein_filter_table$Pass_filter, ],
  "Fig2_protein_groups_filtered_nonmissing_in_20percent_samples.tsv.gz"
)
write_tsv_gz(
  transcript_symbol_export,
  "Fig2_transcript_filtered_symbol_DESeq2_normalized_counts.tsv.gz"
)
write_tsv_gz(
  protein_imputed_export,
  "Fig2_protein_filtered_half_min_imputed_PPM.tsv.gz"
)
write_tsv_gz(
  protein_symbol_export,
  "Fig2_protein_unambiguous_symbol_half_min_imputed_PPM.tsv.gz"
)
write_tsv(venn_counts, "Fig2_filtered_gene_overlap_Venn_counts.tsv")
write_tsv(venn_membership, "Fig2_filtered_gene_overlap_Venn_membership.tsv")
write_tsv(regression_data, "Fig2_transcript_protein_abundance_regression_data.tsv")
write_tsv(
  regression_statistics,
  "Fig2_transcript_protein_abundance_regression_statistics.tsv"
)
write_tsv(half_min_table, "Fig2_protein_half_min_imputation_by_sample.tsv")
write_tsv(qa, "Fig2_transcript_proteome_filter_overlap_regression_QA.tsv")

openxlsx::write.xlsx(
  list(
    Venn_counts = venn_counts,
    Venn_membership = venn_membership,
    Regression_data = regression_data,
    Regression_statistics = regression_statistics,
    Protein_half_min = half_min_table,
    QA = qa
  ),
  file.path(
    table_dir,
    "Fig2_transcriptome_proteome_filter_overlap_abundance_results.xlsx"
  ),
  overwrite = TRUE
)

cat("Transcript/protein overlap and abundance regression completed.\n")
cat("Transcript filtered Ensembl genes:", sum(transcript_keep), "\n")
cat("Transcript unique mapped symbols:", length(transcript_symbols), "\n")
cat("Protein filtered groups:", sum(protein_keep), "\n")
cat("Protein unique mapped symbols:", length(protein_symbols_all_mapped), "\n")
cat("Venn overlap:", length(overlap_symbols), "\n")
cat("Regression genes:", nrow(regression_data), "\n")
cat("Pearson r:", unname(pearson_test$estimate), "\n")
cat("Linear-model R squared:", fit_summary$r.squared, "\n")
cat("Venn PDF:", paste0(venn_stub, ".pdf"), "\n")
cat("Regression PDF:", paste0(regression_stub, ".pdf"), "\n")
