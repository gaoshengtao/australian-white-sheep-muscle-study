#!/usr/bin/env Rscript

# =============================================================================
# Australian White sheep transcriptome: DESeq2 normalization and
# Bray-Curtis principal coordinates analysis (PCoA)
#
# Input
#   02_counts/gene_read_counts.tsv (gene_id + 24 integer-count columns)
#
# Design and transformation
#   - Six animals, each contributing LTL, SM, PM, and EAO.
#   - DESeq2 design: ~ Animal + Site.
#   - Size-factor normalized counts are exported for all genes.
#   - Bray-Curtis distances are calculated from DESeq2 size-factor normalized
#     counts after a low-expression filter (count >= 10 in at least 6 samples).
#   - PCoA uses Lingoes correction for non-Euclidean negative eigenvalues.
#   - Polygons are 95% confidence regions for the two-dimensional site centroid.
# =============================================================================

rm(list = ls())

suppressPackageStartupMessages({
  library(DESeq2)
  library(ggplot2)
  library(grid)
  library(vegan)
})

# -----------------------------------------------------------------------------
# 1. Paths and visual specification
# -----------------------------------------------------------------------------
work_dir <- "__PROJECT_ROOT__/04_transcriptome"
input_file <- file.path(work_dir, "02_counts", "gene_read_counts.tsv")
analysis_dir <- "__PROJECT_ROOT__/07_Figure2_muscle_functional_states/01_Transcriptome_PCoA_Adonis"
figure_dir <- file.path(analysis_dir, "Figures")
table_dir <- file.path(analysis_dir, "Tables")

dir.create(figure_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(table_dir, recursive = TRUE, showWarnings = FALSE)

site_order <- c("LTL", "SM", "PM", "EAO")
site_colors <- c(
  LTL = "#365B8C",
  SM  = "#4F7C71",
  PM  = "#C28B48",
  EAO = "#A65D68"
)

site_prefix_map <- c(
  LTT = "LTL",
  SMT = "SM",
  PMT = "PM",
  AMT = "EAO"
)

plot_width_in <- 5.2
plot_height_in <- 4.5

# -----------------------------------------------------------------------------
# 2. Read and validate the count matrix and paired sample metadata
# -----------------------------------------------------------------------------
if (!file.exists(input_file)) stop("Count matrix not found: ", input_file)

count_df <- read.delim(
  input_file,
  header = TRUE,
  check.names = FALSE,
  stringsAsFactors = FALSE,
  quote = "",
  comment.char = ""
)

if (ncol(count_df) < 2L || names(count_df)[1] != "gene_id") {
  stop("Expected the first column to be gene_id followed by sample columns.")
}
if (anyDuplicated(count_df$gene_id)) stop("Duplicated gene_id values detected.")
if (anyNA(count_df$gene_id) || any(count_df$gene_id == "")) {
  stop("Missing or empty gene_id values detected.")
}

sample_names <- names(count_df)[-1]
if (length(sample_names) != 24L || anyDuplicated(sample_names)) {
  stop("Expected 24 uniquely named samples.")
}
if (!all(grepl("^(LTT|SMT|PMT|AMT)_[1-6]$", sample_names))) {
  stop("Unexpected sample names; expected LTT/SMT/PMT/AMT_1-6.")
}

count_matrix <- as.matrix(count_df[, -1, drop = FALSE])
suppressWarnings(storage.mode(count_matrix) <- "numeric")
rownames(count_matrix) <- count_df$gene_id

if (any(!is.finite(count_matrix))) stop("Counts contain missing/non-finite values.")
if (any(count_matrix < 0)) stop("Counts contain negative values.")
if (any(abs(count_matrix - round(count_matrix)) > 1e-8)) {
  stop("DESeq2 requires integer read counts.")
}
storage.mode(count_matrix) <- "integer"

sample_prefix <- sub("_.*$", "", sample_names)
animal_id <- sub("^.*_", "", sample_names)
site_id <- unname(site_prefix_map[sample_prefix])

sample_metadata <- data.frame(
  Sample = sample_names,
  Site = factor(site_id, levels = site_order),
  Animal = factor(animal_id, levels = as.character(1:6)),
  Library_size_raw = as.numeric(colSums(count_matrix)),
  row.names = sample_names,
  stringsAsFactors = FALSE
)

pairing_table <- table(sample_metadata$Animal, sample_metadata$Site)
if (!all(dim(pairing_table) == c(6L, 4L)) || !all(pairing_table == 1L)) {
  stop("Expected one observation from each of four sites for every animal.")
}

# -----------------------------------------------------------------------------
# 3. DESeq2 size-factor normalization and Bray-Curtis PCoA
# -----------------------------------------------------------------------------
dds <- DESeqDataSetFromMatrix(
  countData = count_matrix,
  colData = sample_metadata,
  design = ~ Animal + Site
)
dds <- estimateSizeFactors(dds)

normalized_counts <- counts(dds, normalized = TRUE)
sample_metadata$DESeq2_size_factor <- sizeFactors(dds)[sample_metadata$Sample]
sample_metadata$Normalized_library_sum <- as.numeric(colSums(normalized_counts))

keep_for_pcoa <- rowSums(count_matrix >= 10L) >= 6L
if (sum(keep_for_pcoa) < 500L) {
  stop("Fewer than 500 genes pass the prespecified PCoA expression filter.")
}

pcoa_input <- t(normalized_counts[keep_for_pcoa, , drop = FALSE])
bray_curtis_distance <- vegan::vegdist(
  pcoa_input,
  method = "bray",
  binary = FALSE
)

uncorrected_pcoa_fit <- vegan::wcmdscale(
  d = bray_curtis_distance,
  k = 2,
  eig = TRUE,
  add = FALSE
)

pcoa_fit <- vegan::wcmdscale(
  d = bray_curtis_distance,
  k = 2,
  eig = TRUE,
  add = "lingoes",
  x.ret = TRUE
)

pcoa_eigenvalues <- as.numeric(pcoa_fit$eig)
positive_eigenvalues <- pcoa_eigenvalues[pcoa_eigenvalues > 0]
if (length(positive_eigenvalues) < 2L) {
  stop("Fewer than two positive PCoA eigenvalues were obtained.")
}
pcoa_variance <- 100 * positive_eigenvalues / sum(positive_eigenvalues)

pcoa_coordinates <- data.frame(
  Sample = rownames(pcoa_fit$points),
  PCoA1 = pcoa_fit$points[, 1],
  PCoA2 = pcoa_fit$points[, 2],
  Site = sample_metadata[rownames(pcoa_fit$points), "Site"],
  Animal = sample_metadata[rownames(pcoa_fit$points), "Animal"],
  stringsAsFactors = FALSE
)
pcoa_coordinates$Site <- factor(pcoa_coordinates$Site, levels = site_order)
pcoa_coordinates$Animal <- factor(
  pcoa_coordinates$Animal,
  levels = levels(sample_metadata$Animal)
)

pcoa_variance_table <- data.frame(
  Axis = paste0("PCoA", seq_along(positive_eigenvalues)),
  Positive_eigenvalue = positive_eigenvalues,
  Variance_explained_percent = pcoa_variance,
  Cumulative_variance_percent = cumsum(pcoa_variance),
  stringsAsFactors = FALSE
)

distance_matrix <- as.matrix(bray_curtis_distance)

centroid_confidence_ellipse <- function(data, level = 0.95, n_points = 200L) {
  coordinates <- as.matrix(data[, c("PCoA1", "PCoA2"), drop = FALSE])
  n <- nrow(coordinates)
  p <- ncol(coordinates)
  if (n <= p) stop("Too few samples to estimate a two-dimensional confidence ellipse.")

  covariance_matrix <- stats::cov(coordinates)
  eigen_decomposition <- eigen(covariance_matrix, symmetric = TRUE)
  if (any(eigen_decomposition$values <= 0)) {
    stop("Non-positive within-site covariance eigenvalue; cannot draw confidence ellipse.")
  }

  hotelling_factor <-
    p * (n - 1) / (n * (n - p)) * stats::qf(level, p, n - p)
  transform_matrix <- eigen_decomposition$vectors %*%
    diag(sqrt(eigen_decomposition$values * hotelling_factor), nrow = p)
  angles <- seq(0, 2 * pi, length.out = n_points)
  unit_circle <- cbind(cos(angles), sin(angles))
  ellipse_coordinates <- sweep(
    unit_circle %*% t(transform_matrix),
    2,
    colMeans(coordinates),
    "+"
  )

  data.frame(
    PCoA1 = ellipse_coordinates[, 1],
    PCoA2 = ellipse_coordinates[, 2],
    stringsAsFactors = FALSE
  )
}

confidence_ellipse_rows <- lapply(site_order, function(site_name) {
  site_data <- pcoa_coordinates[pcoa_coordinates$Site == site_name, , drop = FALSE]
  ellipse <- centroid_confidence_ellipse(site_data, level = 0.95)
  ellipse$Site <- factor(site_name, levels = site_order)
  ellipse$Point_order <- seq_len(nrow(ellipse))
  ellipse
})
confidence_ellipses <- do.call(rbind, confidence_ellipse_rows)

site_centroids <- do.call(
  rbind,
  lapply(site_order, function(site_name) {
    site_data <- pcoa_coordinates[pcoa_coordinates$Site == site_name, , drop = FALSE]
    data.frame(
      Site = site_name,
      n = nrow(site_data),
      PCoA1_centroid = mean(site_data$PCoA1),
      PCoA2_centroid = mean(site_data$PCoA2),
      stringsAsFactors = FALSE
    )
  })
)
site_centroids$Site <- factor(site_centroids$Site, levels = site_order)

pcoa_correction <- data.frame(
  Method = "Lingoes",
  Additive_constant = pcoa_fit$ac,
  Negative_eigenvalues_before_correction = sum(uncorrected_pcoa_fit$eig < -1e-10),
  Sum_positive_eigenvalues = sum(positive_eigenvalues),
  stringsAsFactors = FALSE
)

# -----------------------------------------------------------------------------
# 4. Bray-Curtis PCoA with 95% site-centroid confidence ellipses
# -----------------------------------------------------------------------------
p_pcoa <- ggplot(pcoa_coordinates, aes(x = PCoA1, y = PCoA2)) +
  geom_hline(yintercept = 0, color = "#D8DADD", linewidth = 0.32) +
  geom_vline(xintercept = 0, color = "#D8DADD", linewidth = 0.32) +
  geom_polygon(
    data = confidence_ellipses,
    aes(x = PCoA1, y = PCoA2, group = Site, fill = Site),
    inherit.aes = FALSE,
    alpha = 0.12,
    color = NA,
    show.legend = FALSE
  ) +
  geom_path(
    data = confidence_ellipses,
    aes(x = PCoA1, y = PCoA2, group = Site, color = Site),
    inherit.aes = FALSE,
    linewidth = 0.62,
    alpha = 0.88,
    show.legend = FALSE
  ) +
  geom_point(
    aes(fill = Site),
    shape = 21,
    size = 3.2,
    stroke = 0.45,
    alpha = 0.92,
    color = "#1F2328"
  ) +
  scale_fill_manual(values = site_colors, breaks = site_order, drop = FALSE) +
  scale_color_manual(values = site_colors, breaks = site_order, drop = FALSE) +
  scale_x_continuous(expand = expansion(mult = 0.10)) +
  scale_y_continuous(expand = expansion(mult = 0.10)) +
  labs(
    x = sprintf("PCoA1 (%.1f%%)", pcoa_variance[1]),
    y = sprintf("PCoA2 (%.1f%%)", pcoa_variance[2]),
    fill = NULL
  ) +
  theme_bw(base_size = 10.5, base_family = "Arial") +
  theme(
    aspect.ratio = 1,
    plot.title = element_blank(),
    panel.grid = element_blank(),
    panel.border = element_rect(color = "#1F1F1F", linewidth = 0.5),
    axis.text = element_text(color = "#30363D", size = 8.5),
    axis.title = element_text(color = "#1F2328", size = 10.5),
    axis.title.x = element_text(margin = margin(t = 7)),
    axis.title.y = element_text(margin = margin(r = 7)),
    axis.ticks = element_line(color = "#1F1F1F", linewidth = 0.4),
    axis.ticks.length = unit(2, "mm"),
    legend.position = "right",
    legend.text = element_text(size = 9, color = "#1F2328"),
    legend.key = element_blank(),
    plot.margin = margin(t = 5, r = 7, b = 5, l = 7)
  ) +
  guides(
    fill = guide_legend(
      override.aes = list(
        shape = 21,
        size = 3.2,
        stroke = 0.45,
        alpha = 0.92,
        color = "#1F2328"
      )
    )
  )

output_stub <- file.path(
  figure_dir,
  "Transcriptome_DESeq2_BrayCurtis_PCoA_by_site_95CI"
)

ggsave(
  filename = paste0(output_stub, ".pdf"),
  plot = p_pcoa,
  device = cairo_pdf,
  width = plot_width_in,
  height = plot_height_in,
  units = "in",
  family = "Arial"
)

png(
  filename = paste0(output_stub, ".png"),
  width = plot_width_in,
  height = plot_height_in,
  units = "in",
  res = 600,
  type = "cairo",
  family = "Arial",
  bg = "white"
)
print(p_pcoa)
dev.off()

svg(
  filename = paste0(output_stub, ".svg"),
  width = plot_width_in,
  height = plot_height_in,
  family = "Arial",
  pointsize = 10.5,
  onefile = TRUE,
  bg = "white"
)
print(p_pcoa)
dev.off()

# -----------------------------------------------------------------------------
# 5. Export normalization, PCoA, confidence-ellipse, and QA tables
# -----------------------------------------------------------------------------
write_matrix_gz <- function(mat, path, digits = NULL) {
  out <- data.frame(gene_id = rownames(mat), mat, check.names = FALSE)
  connection <- gzfile(path, open = "wt")
  on.exit(close(connection), add = TRUE)
  if (!is.null(digits)) {
    numeric_columns <- vapply(out, is.numeric, logical(1))
    out[numeric_columns] <- lapply(out[numeric_columns], round, digits = digits)
  }
  write.table(
    out,
    file = connection,
    sep = "\t",
    quote = FALSE,
    row.names = FALSE,
    na = "NA"
  )
}

write_matrix_gz(
  normalized_counts,
  file.path(table_dir, "DESeq2_size_factor_normalized_counts.tsv.gz"),
  digits = 4
)

write.table(
  data.frame(sample_metadata, check.names = FALSE),
  file = file.path(table_dir, "transcriptome_sample_metadata_and_size_factors.tsv"),
  sep = "\t",
  quote = FALSE,
  row.names = FALSE
)
write.table(
  pcoa_coordinates,
  file = file.path(table_dir, "transcriptome_BrayCurtis_PCoA_sample_coordinates.tsv"),
  sep = "\t",
  quote = FALSE,
  row.names = FALSE
)
write.table(
  pcoa_variance_table,
  file = file.path(table_dir, "transcriptome_BrayCurtis_PCoA_variance_explained.tsv"),
  sep = "\t",
  quote = FALSE,
  row.names = FALSE
)
write.table(
  data.frame(Sample = rownames(distance_matrix), distance_matrix, check.names = FALSE),
  file = file.path(table_dir, "transcriptome_BrayCurtis_distance_matrix.tsv"),
  sep = "\t",
  quote = FALSE,
  row.names = FALSE
)
write.table(
  confidence_ellipses,
  file = file.path(table_dir, "transcriptome_PCoA_site_centroid_95CI_coordinates.tsv"),
  sep = "\t",
  quote = FALSE,
  row.names = FALSE
)
write.table(
  site_centroids,
  file = file.path(table_dir, "transcriptome_PCoA_site_centroids.tsv"),
  sep = "\t",
  quote = FALSE,
  row.names = FALSE
)
write.table(
  pcoa_correction,
  file = file.path(table_dir, "transcriptome_BrayCurtis_PCoA_correction.tsv"),
  sep = "\t",
  quote = FALSE,
  row.names = FALSE
)
write.table(
  data.frame(gene_id = rownames(normalized_counts)[keep_for_pcoa]),
  file = file.path(table_dir, "transcriptome_BrayCurtis_retained_genes.tsv"),
  sep = "\t",
  quote = FALSE,
  row.names = FALSE
)

qa_manifest <- data.frame(
  Check = c(
    "Input count table",
    "Genes in raw count matrix",
    "Genes with zero counts in all samples",
    "Genes retained for Bray-Curtis PCoA",
    "Samples",
    "Animals",
    "Sites",
    "Complete paired design",
    "DESeq2 design",
    "Distance input",
    "Distance",
    "PCoA correction",
    "Negative eigenvalues before correction",
    "Lingoes additive constant",
    "PCoA1 variance explained among positive corrected axes (%)",
    "PCoA2 variance explained among positive corrected axes (%)",
    "Confidence region",
    "Minimum DESeq2 size factor",
    "Maximum DESeq2 size factor",
    "Figure width (in)",
    "Figure height (in)",
    "Panel aspect ratio",
    "Typeface"
  ),
  Value = c(
    input_file,
    nrow(count_matrix),
    sum(rowSums(count_matrix) == 0L),
    sum(keep_for_pcoa),
    ncol(count_matrix),
    nlevels(sample_metadata$Animal),
    nlevels(sample_metadata$Site),
    all(pairing_table == 1L),
    "~ Animal + Site",
    "DESeq2 size-factor normalized counts after count >=10 in at least 6 samples",
    "Bray-Curtis",
    "Lingoes",
    pcoa_correction$Negative_eigenvalues_before_correction,
    pcoa_correction$Additive_constant,
    pcoa_variance[1],
    pcoa_variance[2],
    "95% Hotelling T-squared confidence ellipse for each two-dimensional site centroid; n=6 per site",
    min(sizeFactors(dds)),
    max(sizeFactors(dds)),
    plot_width_in,
    plot_height_in,
    1,
    "Arial"
  ),
  stringsAsFactors = FALSE
)

write.table(
  qa_manifest,
  file = file.path(table_dir, "transcriptome_DESeq2_BrayCurtis_PCoA_QA_manifest.tsv"),
  sep = "\t",
  quote = FALSE,
  row.names = FALSE
)

saveRDS(dds, file.path(table_dir, "DESeq2_sizefactor_normalized_dds.rds"))
saveRDS(bray_curtis_distance, file.path(table_dir, "BrayCurtis_distance.rds"))
saveRDS(pcoa_fit, file.path(table_dir, "BrayCurtis_PCoA_Lingoes_fit.rds"))

cat("DESeq2 normalization and Bray-Curtis PCoA completed.\n")
cat("Samples:", ncol(count_matrix), "\n")
cat("Genes retained for PCoA:", sum(keep_for_pcoa), "\n")
cat("PCoA1 variance explained:", sprintf("%.2f%%", pcoa_variance[1]), "\n")
cat("PCoA2 variance explained:", sprintf("%.2f%%", pcoa_variance[2]), "\n")
cat("PDF:", paste0(output_stub, ".pdf"), "\n")
cat("Normalized counts:", file.path(table_dir, "DESeq2_size_factor_normalized_counts.tsv.gz"), "\n")
