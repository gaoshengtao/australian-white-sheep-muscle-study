#!/usr/bin/env Rscript

# Paired one-vs-rest transcriptome/proteome differential analysis and heatmaps

rm(list = ls())

suppressPackageStartupMessages({
  library(DESeq2)
  library(limma)
  library(ComplexHeatmap)
  library(circlize)
  library(openxlsx)
  library(matrixStats)
  library(grid)
})

options(stringsAsFactors = FALSE)

# Paths and prespecified analysis settings -----------------------------------
project_dir <- "__PROJECT_ROOT__"
figure2_dir <- file.path(project_dir, "07_Figure2_muscle_functional_states")
work_dir <- file.path(figure2_dir, "03_One_vs_rest_specificity")
figure_dir <- file.path(work_dir, "Figures")
table_dir <- file.path(work_dir, "Tables")
dir.create(figure_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(table_dir, recursive = TRUE, showWarnings = FALSE)

transcript_count_file <- file.path(
  project_dir, "04_transcriptome", "02_counts", "gene_read_counts.tsv"
)
gene_mapping_file <- file.path(
  project_dir, "04_transcriptome", "04_ID_mapping",
  "Ensembl115_gene_symbol_mapping_one_row_per_gene.tsv"
)
protein_file <- file.path(project_dir, "05_protein", "protein.xlsx")

required_files <- c(transcript_count_file, gene_mapping_file, protein_file)
missing_files <- required_files[!file.exists(required_files)]
if (length(missing_files)) {
  stop("Missing input files: ", paste(missing_files, collapse = ", "))
}

site_order <- c("LTL", "SM", "PM", "EAO")
site_colors <- c(
  LTL = "#365B8C", SM = "#4F7C71", PM = "#C28B48", EAO = "#A65D68"
)
transcript_prefix_map <- c(LTT = "LTL", SMT = "SM", PMT = "PM", AMT = "EAO")
protein_prefix_map <- c(LT = "LTL", SM = "SM", PM = "PM", AM = "EAO")

sample_fraction_threshold <- 0.20
transcript_min_raw_count <- 10L
fdr_threshold <- 0.05
max_features_per_site_for_heatmap <- 500L
zscore_limit <- 2.0
transcript_plot_width <- 8.2
transcript_plot_height <- 10.0
protein_plot_width <- 8.2
protein_plot_height <- 8.5

write_tsv <- function(object, filename) {
  write.table(
    object, file.path(table_dir, filename), sep = "\t", quote = FALSE,
    row.names = FALSE, na = "NA"
  )
}

write_tsv_gz <- function(object, filename) {
  con <- gzfile(file.path(table_dir, filename), open = "wt")
  on.exit(close(con), add = TRUE)
  write.table(
    object, con, sep = "\t", quote = FALSE, row.names = FALSE, na = "NA"
  )
}

parse_metadata <- function(sample_names, prefix_map, expected_pattern,
                           omics_name) {
  if (length(sample_names) != 24L || anyDuplicated(sample_names) ||
      !all(grepl(expected_pattern, sample_names))) {
    stop(omics_name, " does not contain the expected 24 sample names.")
  }
  prefix <- sub("_.*$", "", sample_names)
  animal <- sub("^.*_", "", sample_names)
  site <- unname(prefix_map[prefix])
  metadata <- data.frame(
    Sample = sample_names,
    Site = factor(site, levels = site_order),
    Animal = factor(animal, levels = as.character(1:6)),
    row.names = sample_names,
    stringsAsFactors = FALSE
  )
  pairing <- table(metadata$Animal, metadata$Site)
  if (anyNA(metadata$Site) || anyNA(metadata$Animal) ||
      !all(dim(pairing) == c(6L, 4L)) || !all(pairing == 1L)) {
    stop(omics_name, " metadata is not a complete 6-animal x 4-site design.")
  }
  metadata
}

make_one_vs_rest_weights <- function(target_site) {
  if (!target_site %in% site_order) stop("Unexpected target site.")
  weights <- setNames(rep(-1 / 3, length(site_order)), site_order)
  weights[target_site] <- 1
  weights
}

make_zscore_matrix <- function(expression_matrix) {
  row_sd <- rowSds(expression_matrix)
  if (any(!is.finite(row_sd)) || any(row_sd <= 0)) {
    stop("A selected heatmap feature has zero or invalid row SD.")
  }
  z <- sweep(expression_matrix, 1, rowMeans(expression_matrix), "-")
  z <- sweep(z, 1, row_sd, "/")
  pmax(pmin(z, zscore_limit), -zscore_limit)
}

select_heatmap_features <- function(specific_table, feature_column) {
  selected <- do.call(rbind, lapply(site_order, function(site_name) {
    z <- specific_table[specific_table$Specific_site == site_name, , drop = FALSE]
    z <- z[order(z$P_FDR_BH, -z$log2FoldChange), , drop = FALSE]
    z$Specific_total_for_site <- rep(nrow(z), nrow(z))
    z$Shown_in_heatmap <- seq_len(nrow(z)) <= max_features_per_site_for_heatmap
    z[z$Shown_in_heatmap, , drop = FALSE]
  }))
  if (is.null(selected) || !nrow(selected)) {
    stop("No site-specific features are available for the heatmap.")
  }
  selected[[feature_column]] <- as.character(selected[[feature_column]])
  selected
}

format_p <- function(p) {
  ifelse(is.na(p), "NA", format.pval(p, digits = 4, eps = 1e-300))
}

# Transcriptome: paired DESeq2 one-vs-rest -----------------------------------
count_df <- read.delim(
  transcript_count_file, header = TRUE, check.names = FALSE,
  quote = "", comment.char = ""
)
if (names(count_df)[1] != "gene_id" || anyDuplicated(count_df$gene_id)) {
  stop("Unexpected transcript count table structure.")
}
transcript_samples <- setdiff(names(count_df), "gene_id")
transcript_metadata <- parse_metadata(
  transcript_samples, transcript_prefix_map,
  "^(LTT|SMT|PMT|AMT)_[1-6]$", "Transcriptome"
)
transcript_counts <- as.matrix(count_df[, transcript_samples, drop = FALSE])
storage.mode(transcript_counts) <- "numeric"
if (any(!is.finite(transcript_counts)) || any(transcript_counts < 0) ||
    any(abs(transcript_counts - round(transcript_counts)) > 1e-8)) {
  stop("Transcript counts are not valid nonnegative integers.")
}
storage.mode(transcript_counts) <- "integer"
rownames(transcript_counts) <- count_df$gene_id

transcript_min_samples <- ceiling(
  sample_fraction_threshold * ncol(transcript_counts)
)
transcript_detected_samples <- rowSums(
  transcript_counts >= transcript_min_raw_count
)
transcript_keep <- transcript_detected_samples >= transcript_min_samples
transcript_counts_filtered <- transcript_counts[transcript_keep, , drop = FALSE]
if (nrow(transcript_counts_filtered) < 500L) {
  stop("Too few transcript genes pass filtering.")
}

dds <- DESeqDataSetFromMatrix(
  countData = transcript_counts_filtered,
  colData = transcript_metadata,
  design = ~ Animal + Site
)
dds <- DESeq(dds, quiet = FALSE, parallel = FALSE)
transcript_normalized <- counts(dds, normalized = TRUE)
transcript_vst <- assay(vst(dds, blind = FALSE))
transcript_results_names <- resultsNames(dds)
expected_site_coefficients <- c(
  SM = "Site_SM_vs_LTL", PM = "Site_PM_vs_LTL", EAO = "Site_EAO_vs_LTL"
)
if (!all(expected_site_coefficients %in% transcript_results_names)) {
  stop("Could not identify DESeq2 Site coefficients: ",
       paste(transcript_results_names, collapse = ", "))
}

gene_mapping <- read.delim(
  gene_mapping_file, header = TRUE, check.names = FALSE,
  quote = "", comment.char = ""
)
if (!all(c("gene_id", "Gene_symbol", "gene_biotype", "description") %in%
         names(gene_mapping)) || anyDuplicated(gene_mapping$gene_id)) {
  stop("Gene mapping table failed validation.")
}
gene_map_index <- match(rownames(dds), gene_mapping$gene_id)
if (anyNA(gene_map_index)) stop("Filtered transcript genes lack mapping rows.")

transcript_site_means <- sapply(site_order, function(site_name) {
  rowMeans(
    transcript_normalized[, transcript_metadata$Site == site_name, drop = FALSE]
  )
})
colnames(transcript_site_means) <- site_order

transcript_result_list <- vector("list", length(site_order))
names(transcript_result_list) <- site_order
for (site_name in site_order) {
  site_weights <- make_one_vs_rest_weights(site_name)
  contrast_vector <- setNames(rep(0, length(transcript_results_names)),
                              transcript_results_names)
  contrast_vector[expected_site_coefficients] <- site_weights[names(
    expected_site_coefficients
  )]
  result <- results(
    dds, contrast = contrast_vector, alpha = fdr_threshold,
    independentFiltering = FALSE, cooksCutoff = FALSE
  )
  result_df <- data.frame(
    gene_id = rownames(result),
    baseMean = result$baseMean,
    log2FoldChange = result$log2FoldChange,
    lfcSE = result$lfcSE,
    statistic = result$stat,
    P_value = result$pvalue,
    P_FDR_BH = result$padj,
    stringsAsFactors = FALSE
  )
  mi <- match(result_df$gene_id, gene_mapping$gene_id)
  result_df$Gene_symbol <- gene_mapping$Gene_symbol[mi]
  result_df$gene_biotype <- gene_mapping$gene_biotype[mi]
  result_df$description <- gene_mapping$description[mi]
  result_df$Target_site <- site_name
  result_df$Target_site_mean_normalized_count <-
    transcript_site_means[result_df$gene_id, site_name]
  result_df$Maximum_other_site_mean_normalized_count <- rowMaxs(
    transcript_site_means[
      result_df$gene_id, setdiff(site_order, site_name), drop = FALSE
    ]
  )
  result_df$Pass_site_specific_enrichment <-
    !is.na(result_df$P_FDR_BH) &
    result_df$P_FDR_BH < fdr_threshold &
    result_df$log2FoldChange > 0
  transcript_result_list[[site_name]] <- result_df
}
transcript_results_all <- do.call(rbind, transcript_result_list)
rownames(transcript_results_all) <- NULL
transcript_specific <- transcript_results_all[
  transcript_results_all$Pass_site_specific_enrichment, , drop = FALSE
]
transcript_specific$Specific_site <- factor(
  transcript_specific$Target_site, levels = site_order
)
transcript_heatmap_features <- select_heatmap_features(
  transcript_specific, "gene_id"
)

# Proteome: paired limma one-vs-rest -----------------------------------------
protein <- openxlsx::read.xlsx(
  protein_file, sheet = "protein", check.names = FALSE
)
if (!all(c("PG.ProteinGroups", "PG.Genes") %in% names(protein))) {
  stop("Protein workbook lacks required identifier columns.")
}
protein_samples <- grep("^(LT|SM|PM|AM)_[1-6]$", names(protein), value = TRUE)
expected_protein_samples <- as.vector(
  outer(c("LT", "SM", "PM", "AM"), 1:6, paste, sep = "_")
)
if (!setequal(protein_samples, expected_protein_samples)) {
  stop("Unexpected protein sample columns.")
}
protein_samples <- expected_protein_samples
protein_metadata <- parse_metadata(
  protein_samples, protein_prefix_map,
  "^(LT|SM|PM|AM)_[1-6]$", "Proteome"
)
protein_character <- as.matrix(protein[, protein_samples, drop = FALSE])
protein_character <- apply(protein_character, 2, as.character)
protein_abundance <- matrix(
  suppressWarnings(as.numeric(protein_character)),
  nrow = nrow(protein), ncol = length(protein_samples),
  dimnames = list(seq_len(nrow(protein)), protein_samples)
)
unexpected_non_numeric <- is.na(protein_abundance) &
  nzchar(trimws(protein_character)) &
  !toupper(trimws(protein_character)) %in% c("NA", "N/A", "NAN")
if (any(unexpected_non_numeric) || any(protein_abundance <= 0, na.rm = TRUE)) {
  stop("Protein abundance contains unexpected nonnumeric/nonpositive values.")
}
protein_min_samples <- ceiling(
  sample_fraction_threshold * ncol(protein_abundance)
)
protein_detected_samples <- rowSums(!is.na(protein_abundance))
protein_keep <- protein_detected_samples >= protein_min_samples
protein_rows_filtered <- which(protein_keep)
protein_filtered <- protein_abundance[protein_keep, , drop = FALSE]
if (nrow(protein_filtered) < 500L) stop("Too few protein groups pass filtering.")

protein_half_min <- apply(protein_filtered, 2, function(x) {
  min(x[is.finite(x) & x > 0]) / 2
})
protein_imputed <- protein_filtered
for (j in seq_len(ncol(protein_imputed))) {
  protein_imputed[is.na(protein_imputed[, j]), j] <- protein_half_min[j]
}
protein_log2 <- log2(protein_imputed)
protein_log2_normalized <- normalizeBetweenArrays(
  protein_log2, method = "quantile"
)
rownames(protein_log2_normalized) <- as.character(protein_rows_filtered)

protein_design <- model.matrix(
  ~ 0 + Site + Animal, data = protein_metadata
)
colnames(protein_design) <- sub("^Site", "", colnames(protein_design))
if (!all(site_order %in% colnames(protein_design)) ||
    qr(protein_design)$rank != ncol(protein_design)) {
  stop("Protein limma design is not full-rank or lacks site columns.")
}
protein_contrasts <- makeContrasts(
  LTL_vs_rest = LTL - (SM + PM + EAO) / 3,
  SM_vs_rest = SM - (LTL + PM + EAO) / 3,
  PM_vs_rest = PM - (LTL + SM + EAO) / 3,
  EAO_vs_rest = EAO - (LTL + SM + PM) / 3,
  levels = protein_design
)
protein_fit <- lmFit(protein_log2_normalized, protein_design)
protein_fit_contrasts <- contrasts.fit(protein_fit, protein_contrasts)
protein_fit_ebayes <- eBayes(
  protein_fit_contrasts, trend = TRUE, robust = TRUE
)

protein_site_means <- sapply(site_order, function(site_name) {
  rowMeans(
    protein_log2_normalized[, protein_metadata$Site == site_name, drop = FALSE]
  )
})
colnames(protein_site_means) <- site_order

protein_result_list <- vector("list", length(site_order))
names(protein_result_list) <- site_order
for (i in seq_along(site_order)) {
  site_name <- site_order[i]
  result_df <- topTable(
    protein_fit_ebayes, coef = i, number = Inf,
    adjust.method = "BH", sort.by = "none"
  )
  result_df$Protein_row <- as.integer(rownames(result_df))
  result_df <- result_df[, c(
    "Protein_row", "logFC", "AveExpr", "t", "P.Value", "adj.P.Val", "B"
  )]
  names(result_df)[names(result_df) == "logFC"] <- "log2FoldChange"
  names(result_df)[names(result_df) == "P.Value"] <- "P_value"
  names(result_df)[names(result_df) == "adj.P.Val"] <- "P_FDR_BH"
  result_df$PG.ProteinGroups <- protein$PG.ProteinGroups[result_df$Protein_row]
  result_df$PG.Genes <- protein$PG.Genes[result_df$Protein_row]
  result_df$PG.ProteinDescriptions <-
    protein$PG.ProteinDescriptions[result_df$Protein_row]
  result_df$Target_site <- site_name
  row_keys <- as.character(result_df$Protein_row)
  result_df$Target_site_mean_log2_normalized_abundance <-
    protein_site_means[row_keys, site_name]
  result_df$Maximum_other_site_mean_log2_normalized_abundance <- rowMaxs(
    protein_site_means[row_keys, setdiff(site_order, site_name), drop = FALSE]
  )
  result_df$Pass_site_specific_enrichment <-
    !is.na(result_df$P_FDR_BH) &
    result_df$P_FDR_BH < fdr_threshold &
    result_df$log2FoldChange > 0
  protein_result_list[[site_name]] <- result_df
}
protein_results_all <- do.call(rbind, protein_result_list)
rownames(protein_results_all) <- NULL
protein_specific <- protein_results_all[
  protein_results_all$Pass_site_specific_enrichment, , drop = FALSE
]
protein_specific$Specific_site <- factor(
  protein_specific$Target_site, levels = site_order
)
protein_heatmap_features <- select_heatmap_features(
  protein_specific, "Protein_row"
)

# Heatmap preparation ---------------------------------------------------------
ordered_transcript_samples <- rownames(transcript_metadata)[order(
  transcript_metadata$Site, transcript_metadata$Animal
)]
ordered_protein_samples <- rownames(protein_metadata)[order(
  protein_metadata$Site, protein_metadata$Animal
)]

transcript_heatmap_matrix <- transcript_vst[
  transcript_heatmap_features$gene_id,
  ordered_transcript_samples,
  drop = FALSE
]
transcript_heatmap_z <- make_zscore_matrix(transcript_heatmap_matrix)
transcript_row_split <- factor(
  transcript_heatmap_features$Specific_site,
  levels = site_order[site_order %in%
                        as.character(transcript_heatmap_features$Specific_site)]
)

protein_heatmap_matrix <- protein_log2_normalized[
  as.character(protein_heatmap_features$Protein_row),
  ordered_protein_samples,
  drop = FALSE
]
protein_heatmap_z <- make_zscore_matrix(protein_heatmap_matrix)
protein_row_split <- factor(
  protein_heatmap_features$Specific_site,
  levels = site_order[site_order %in%
                        as.character(protein_heatmap_features$Specific_site)]
)

make_block_labels <- function(specific_table, heatmap_table, unit_name) {
  displayed_sites <- site_order[site_order %in%
                                  as.character(heatmap_table$Specific_site)]
  vapply(displayed_sites, function(site_name) {
    total <- sum(as.character(specific_table$Specific_site) == site_name)
    shown <- sum(as.character(heatmap_table$Specific_site) == site_name)
    if (total == shown) {
      paste0("n = ", total)
    } else {
      paste0("n = ", total, "\n(top ", shown, ")")
    }
  }, character(1))
}

transcript_block_labels <- make_block_labels(
  transcript_specific, transcript_heatmap_features, "genes"
)
protein_block_labels <- make_block_labels(
  protein_specific, protein_heatmap_features, "proteins"
)

heatmap_color_function <- colorRamp2(
  c(-zscore_limit, 0, zscore_limit),
  c("#171717", "#81751F", "#F2D20A")
)

make_site_specific_heatmap <- function(
    z_matrix, row_split, sample_metadata, ordered_samples,
    block_labels, heatmap_name) {
  column_split <- factor(
    sample_metadata[ordered_samples, "Site"], levels = site_order
  )
  top_annotation <- HeatmapAnnotation(
    Site = column_split,
    col = list(Site = site_colors),
    show_annotation_name = FALSE,
    show_legend = FALSE,
    simple_anno_size = unit(3.2, "mm")
  )
  left_annotation <- rowAnnotation(
    Specific_site = row_split,
    col = list(Specific_site = site_colors),
    show_annotation_name = FALSE,
    show_legend = FALSE,
    simple_anno_size = unit(2.8, "mm")
  )
  right_annotation <- rowAnnotation(
    Counts = anno_block(
      labels = block_labels,
      labels_rot = 0,
      gp = gpar(fill = "white", col = NA),
      labels_gp = gpar(
        fontfamily = "Arial", fontsize = 8, col = "#25282C"
      ),
      width = unit(16, "mm")
    ),
    show_annotation_name = TRUE,
    annotation_name_side = "top",
    annotation_name_rot = 0,
    annotation_name_gp = gpar(
      fontfamily = "Arial", fontsize = 8.5, col = "#25282C"
    )
  )
  Heatmap(
    z_matrix,
    name = "Z-score",
    col = heatmap_color_function,
    na_col = "#D9DDE1",
    row_split = row_split,
    column_split = column_split,
    cluster_rows = TRUE,
    cluster_row_slices = FALSE,
    clustering_distance_rows = "euclidean",
    clustering_method_rows = "ward.D2",
    cluster_columns = FALSE,
    cluster_column_slices = FALSE,
    show_row_names = FALSE,
    show_column_names = FALSE,
    row_gap = unit(1.2, "mm"),
    column_gap = unit(1.2, "mm"),
    border = TRUE,
    rect_gp = gpar(col = NA),
    top_annotation = top_annotation,
    left_annotation = left_annotation,
    right_annotation = right_annotation,
    column_title = site_order,
    column_title_gp = gpar(
      fontfamily = "Arial", fontface = "bold", fontsize = 11,
      col = "#25282C"
    ),
    column_title_rot = 0,
    heatmap_legend_param = list(
      title = "Z-score",
      at = c(-2, -1, 0, 1, 2),
      title_gp = gpar(fontfamily = "Arial", fontsize = 9),
      labels_gp = gpar(fontfamily = "Arial", fontsize = 8.5),
      legend_height = unit(35, "mm")
    ),
    use_raster = nrow(z_matrix) > 1000L,
    raster_quality = 3,
    raster_device = "png"
  )
}

transcript_heatmap <- make_site_specific_heatmap(
  transcript_heatmap_z, transcript_row_split,
  transcript_metadata, ordered_transcript_samples,
  transcript_block_labels, "Transcriptome"
)
protein_heatmap <- make_site_specific_heatmap(
  protein_heatmap_z, protein_row_split,
  protein_metadata, ordered_protein_samples,
  protein_block_labels, "Proteome"
)

draw_heatmap <- function(heatmap_object, output_stub, width, height) {
  cairo_pdf(paste0(output_stub, ".pdf"), width = width, height = height,
            family = "Arial")
  draw(
    heatmap_object,
    heatmap_legend_side = "right",
    annotation_legend_side = "right",
    padding = unit(c(7, 7, 7, 7), "mm")
  )
  dev.off()

  png(
    paste0(output_stub, ".png"), width = width, height = height,
    units = "in", res = 600, type = "cairo", family = "Arial", bg = "white"
  )
  draw(
    heatmap_object,
    heatmap_legend_side = "right",
    annotation_legend_side = "right",
    padding = unit(c(7, 7, 7, 7), "mm")
  )
  dev.off()

  svg(
    paste0(output_stub, ".svg"), width = width, height = height,
    family = "Arial", pointsize = 10.5, onefile = TRUE, bg = "white"
  )
  draw(
    heatmap_object,
    heatmap_legend_side = "right",
    annotation_legend_side = "right",
    padding = unit(c(7, 7, 7, 7), "mm")
  )
  dev.off()
}

transcript_output_stub <- file.path(
  figure_dir, "Fig2_Transcriptome_one_vs_rest_site_specific_genes_heatmap"
)
protein_output_stub <- file.path(
  figure_dir, "Fig2_Proteome_one_vs_rest_site_specific_proteins_heatmap"
)
draw_heatmap(
  transcript_heatmap, transcript_output_stub,
  transcript_plot_width, transcript_plot_height
)
draw_heatmap(
  protein_heatmap, protein_output_stub,
  protein_plot_width, protein_plot_height
)

# Export detailed results -----------------------------------------------------
transcript_counts_summary <- data.frame(
  Omics = "Transcriptome",
  Site = site_order,
  Tested_features = nrow(dds),
  FDR_significant_all_directions = vapply(site_order, function(site_name) {
    z <- transcript_results_all[transcript_results_all$Target_site == site_name, ]
    sum(!is.na(z$P_FDR_BH) & z$P_FDR_BH < fdr_threshold)
  }, integer(1)),
  Target_enriched_FDR_lt_0_05 = vapply(site_order, function(site_name) {
    sum(as.character(transcript_specific$Specific_site) == site_name)
  }, integer(1)),
  Displayed_in_heatmap = vapply(site_order, function(site_name) {
    sum(as.character(transcript_heatmap_features$Specific_site) == site_name)
  }, integer(1)),
  stringsAsFactors = FALSE
)
protein_counts_summary <- data.frame(
  Omics = "Proteome",
  Site = site_order,
  Tested_features = nrow(protein_filtered),
  FDR_significant_all_directions = vapply(site_order, function(site_name) {
    z <- protein_results_all[protein_results_all$Target_site == site_name, ]
    sum(!is.na(z$P_FDR_BH) & z$P_FDR_BH < fdr_threshold)
  }, integer(1)),
  Target_enriched_FDR_lt_0_05 = vapply(site_order, function(site_name) {
    sum(as.character(protein_specific$Specific_site) == site_name)
  }, integer(1)),
  Displayed_in_heatmap = vapply(site_order, function(site_name) {
    sum(as.character(protein_heatmap_features$Specific_site) == site_name)
  }, integer(1)),
  stringsAsFactors = FALSE
)
specific_counts_summary <- rbind(
  transcript_counts_summary, protein_counts_summary
)

transcript_heatmap_export <- data.frame(
  gene_id = rownames(transcript_heatmap_z),
  Gene_symbol = gene_mapping$Gene_symbol[
    match(rownames(transcript_heatmap_z), gene_mapping$gene_id)
  ],
  Specific_site = as.character(transcript_row_split),
  transcript_heatmap_z,
  check.names = FALSE, row.names = NULL
)
protein_heatmap_export <- data.frame(
  Protein_row = as.integer(rownames(protein_heatmap_z)),
  PG.ProteinGroups = protein$PG.ProteinGroups[
    as.integer(rownames(protein_heatmap_z))
  ],
  PG.Genes = protein$PG.Genes[as.integer(rownames(protein_heatmap_z))],
  Specific_site = as.character(protein_row_split),
  protein_heatmap_z,
  check.names = FALSE, row.names = NULL
)
protein_imputation_table <- data.frame(
  Sample = protein_samples,
  Site = as.character(protein_metadata$Site[protein_samples]),
  Animal = as.character(protein_metadata$Animal[protein_samples]),
  Half_minimum_value = protein_half_min,
  Missing_values_imputed = colSums(is.na(protein_filtered)),
  stringsAsFactors = FALSE
)

qa <- data.frame(
  Check = c(
    "Paired animals", "Sites", "One-vs-rest definition",
    "Transcript filter", "Transcript genes before filter",
    "Transcript genes after filter", "Transcript DESeq2 design",
    "Transcript coefficient test", "Protein filter",
    "Protein groups before filter", "Protein groups after filter",
    "Protein missing values after filter", "Protein imputation",
    "Protein transformation", "Protein normalization", "Protein limma design",
    "Protein empirical Bayes", "Selection rule", "Effect direction",
    "Cross-contrast overlap", "BH family", "Heatmap expression",
    "Heatmap row scaling", "Heatmap clipping", "Heatmap clustering",
    "Maximum displayed per site", "Transcript displayed rows",
    "Protein displayed rows", "Typeface", "DESeq2 version", "limma version",
    "ComplexHeatmap version"
  ),
  Value = as.character(c(
    6, paste(site_order, collapse = ", "),
    "Target site minus arithmetic mean of the other three sites",
    paste0("Raw count >=10 in at least ", transcript_min_samples,
           " of 24 samples"),
    nrow(transcript_counts), nrow(dds), "~ Animal + Site",
    "Wald test of numeric one-vs-rest contrast; independentFiltering=FALSE; cooksCutoff=FALSE",
    paste0("Nonmissing abundance in at least ", protein_min_samples,
           " of 24 samples"),
    nrow(protein), nrow(protein_filtered), sum(is.na(protein_filtered)),
    "Half the minimum positive abundance separately within each sample after filtering",
    "log2 abundance", "Quantile normalization across samples",
    "~ 0 + Site + Animal", "eBayes(trend=TRUE, robust=TRUE)",
    "FDR < 0.05; no log2FC magnitude cutoff",
    "Positive coefficient: target site enriched relative to pooled mean of the other three sites",
    "Allowed: each one-vs-rest contrast is interpreted independently",
    "BH correction separately across all tested features within each of four contrasts",
    "DESeq2 VST for transcriptome; quantile-normalized log2 abundance for proteome",
    "Per-feature Z-score across 24 samples", paste0("[-", zscore_limit,
    ", ", zscore_limit, "]"),
    "Euclidean distance and Ward.D2 within each site-specific row block; columns fixed by Site and Animal",
    max_features_per_site_for_heatmap,
    nrow(transcript_heatmap_z), nrow(protein_heatmap_z), "Arial",
    as.character(packageVersion("DESeq2")),
    as.character(packageVersion("limma")),
    as.character(packageVersion("ComplexHeatmap"))
  )),
  stringsAsFactors = FALSE
)

write_tsv_gz(
  transcript_results_all,
  "Transcriptome_DESeq2_one_vs_rest_all_results.tsv.gz"
)
write_tsv(
  transcript_specific,
  "Transcriptome_DESeq2_site_specific_enriched_genes.tsv"
)
write_tsv_gz(
  protein_results_all,
  "Proteome_limma_one_vs_rest_all_results.tsv.gz"
)
write_tsv(
  protein_specific,
  "Proteome_limma_site_specific_enriched_proteins.tsv"
)
write_tsv(
  specific_counts_summary,
  "One_vs_rest_site_specific_feature_counts.tsv"
)
write_tsv_gz(
  transcript_heatmap_export,
  "Transcriptome_one_vs_rest_heatmap_Zscore_matrix.tsv.gz"
)
write_tsv_gz(
  protein_heatmap_export,
  "Proteome_one_vs_rest_heatmap_Zscore_matrix.tsv.gz"
)
write_tsv(
  protein_imputation_table,
  "Proteome_half_minimum_imputation_by_sample.tsv"
)
write_tsv(qa, "One_vs_rest_analysis_QA_manifest.tsv")

saveRDS(dds, file.path(table_dir, "Transcriptome_one_vs_rest_DESeq2_dds.rds"))
saveRDS(
  protein_fit_ebayes,
  file.path(table_dir, "Proteome_one_vs_rest_limma_fit.rds")
)

openxlsx::write.xlsx(
  list(
    Counts = specific_counts_summary,
    Transcript_specific = transcript_specific,
    Protein_specific = protein_specific,
    Protein_imputation = protein_imputation_table,
    QA = qa
  ),
  file.path(table_dir, "One_vs_rest_DESeq2_limma_results.xlsx"),
  overwrite = TRUE
)

cat("Paired one-vs-rest DESeq2/limma analysis completed.\n")
cat("Transcript tested genes:", nrow(dds), "\n")
cat("Transcript site-specific genes:", nrow(transcript_specific), "\n")
cat("Transcript heatmap rows:", nrow(transcript_heatmap_z), "\n")
cat("Protein tested groups:", nrow(protein_filtered), "\n")
cat("Protein site-specific groups:", nrow(protein_specific), "\n")
cat("Protein heatmap rows:", nrow(protein_heatmap_z), "\n")
cat("Counts by site:\n")
print(specific_counts_summary)
cat("Transcript PDF:", paste0(transcript_output_stub, ".pdf"), "\n")
cat("Protein PDF:", paste0(protein_output_stub, ".pdf"), "\n")
