#!/usr/bin/env Rscript

# Australian White sheep proteome: Bray-Curtis PCoA and paired PERMANOVA

rm(list = ls())

suppressPackageStartupMessages({
  library(openxlsx)
  library(ggplot2)
  library(grid)
  library(vegan)
  library(permute)
})

options(stringsAsFactors = FALSE)

# Paths and constants ---------------------------------------------------------
work_dir <- "__PROJECT_ROOT__/05_protein"
input_file <- file.path(work_dir, "protein.xlsx")
analysis_dir <- "__PROJECT_ROOT__/07_Figure2_muscle_functional_states/02_Proteome_PCoA_Adonis"
figure_dir <- file.path(analysis_dir, "Figures")
table_dir <- file.path(analysis_dir, "Tables")
dir.create(figure_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(table_dir, recursive = TRUE, showWarnings = FALSE)

site_order <- c("LTL", "SM", "PM", "EAO")
site_colors <- c(
  LTL = "#365B8C",
  SM  = "#4F7C71",
  PM  = "#C28B48",
  EAO = "#A65D68"
)
site_prefix_map <- c(LT = "LTL", SM = "SM", PM = "PM", AM = "EAO")
expected_samples <- as.vector(outer(c("LT", "SM", "PM", "AM"), 1:6, paste, sep = "_"))

min_detected_per_site <- 3L
n_requested_permutations <- 9999L
analysis_seed <- 20260827L
plot_width_in <- 5.2
plot_height_in <- 4.5

write_tsv <- function(object, filename) {
  write.table(
    object,
    file = file.path(table_dir, filename),
    sep = "\t", quote = FALSE, row.names = FALSE, na = "NA"
  )
}

write_matrix_gz <- function(mat, identifiers, filename, digits = 6L) {
  out <- cbind(identifiers, as.data.frame(mat, check.names = FALSE))
  numeric_cols <- vapply(out, is.numeric, logical(1))
  out[numeric_cols] <- lapply(out[numeric_cols], round, digits = digits)
  con <- gzfile(file.path(table_dir, filename), open = "wt")
  on.exit(close(con), add = TRUE)
  write.table(out, con, sep = "\t", quote = FALSE, row.names = FALSE, na = "NA")
}

adonis_to_table <- function(result) {
  data.frame(
    Term = rownames(result),
    as.data.frame(result, check.names = FALSE),
    row.names = NULL,
    check.names = FALSE
  )
}

make_blocked_permutations <- function(metadata, n_requested, seed) {
  set.seed(seed)
  control <- permute::how(
    within = permute::Within(type = "free"),
    blocks = metadata$Animal,
    nperm = n_requested
  )
  permute::shuffleSet(
    n = nrow(metadata),
    nset = n_requested,
    control = control
  )
}

run_primary_adonis <- function(distance_object, metadata, permutation_matrix) {
  fit <- vegan::adonis2(
    distance_object ~ Animal + Site,
    data = metadata,
    permutations = permutation_matrix,
    by = "margin",
    parallel = 1
  )
  full <- adonis_to_table(fit)
  site_row <- full[full$Term == "Site", , drop = FALSE]
  residual_row <- full[full$Term == "Residual", , drop = FALSE]
  if (nrow(site_row) != 1L || nrow(residual_row) != 1L) {
    stop("Could not extract Site and Residual rows from adonis2 result.")
  }
  primary <- data.frame(
    Test = "Overall paired Site effect",
    Model = "Bray-Curtis distance ~ Animal + Site",
    Site_Df = site_row$Df,
    Site_SumOfSqs = site_row$SumOfSqs,
    Site_R2_total = site_row$R2,
    Site_partial_R2 = site_row$SumOfSqs /
      (site_row$SumOfSqs + residual_row$SumOfSqs),
    Pseudo_F = site_row$F,
    P_value = site_row[["Pr(>F)"]],
    Requested_permutations = n_requested_permutations,
    Permutations_used = nrow(permutation_matrix),
    Permutation_restriction = "Within Animal",
    stringsAsFactors = FALSE
  )
  list(full = full, primary = primary)
}

make_bray_input <- function(abundance_matrix) {
  sample_sums <- colSums(abundance_matrix)
  if (any(!is.finite(sample_sums)) || any(sample_sums <= 0)) {
    stop("A sample has a zero or invalid retained-protein abundance sum.")
  }
  abundance_ppm <- sweep(abundance_matrix, 2, sample_sums, "/") * 1e6
  sqrt_abundance_ppm <- sqrt(abundance_ppm)
  list(
    abundance_ppm = abundance_ppm,
    sqrt_abundance_ppm = sqrt_abundance_ppm,
    distance = vegan::vegdist(t(sqrt_abundance_ppm), method = "bray")
  )
}

# Read and validate protein abundance table -----------------------------------
if (!file.exists(input_file)) stop("Protein workbook not found: ", input_file)
protein <- openxlsx::read.xlsx(input_file, sheet = "protein", check.names = FALSE)
if (!all(c("PG.ProteinGroups", "PG.Genes") %in% names(protein))) {
  stop("Expected PG.ProteinGroups and PG.Genes columns in sheet 'protein'.")
}

sample_names <- grep("^(LT|SM|PM|AM)_[1-6]$", names(protein), value = TRUE)
if (!setequal(sample_names, expected_samples) || length(sample_names) != 24L) {
  stop("Expected exactly LT/SM/PM/AM_1-6 abundance columns.")
}
sample_names <- expected_samples

raw_character <- as.matrix(protein[, sample_names, drop = FALSE])
raw_character <- apply(raw_character, 2, as.character)
abundance <- matrix(
  suppressWarnings(as.numeric(raw_character)),
  nrow = nrow(protein), ncol = length(sample_names),
  dimnames = list(NULL, sample_names)
)
non_numeric <- is.na(abundance) &
  nzchar(trimws(raw_character)) &
  !toupper(trimws(raw_character)) %in% c("NA", "N/A", "NAN")
if (any(non_numeric)) {
  stop("Unexpected non-numeric protein abundance values: ",
       paste(head(unique(raw_character[non_numeric]), 10), collapse = ", "))
}
if (any(abundance < 0, na.rm = TRUE)) stop("Negative protein abundance detected.")

protein_ids <- data.frame(
  Protein_row = seq_len(nrow(protein)),
  PG.ProteinGroups = as.character(protein$PG.ProteinGroups),
  PG.Genes = as.character(protein$PG.Genes),
  stringsAsFactors = FALSE,
  check.names = FALSE
)
if (anyDuplicated(protein_ids$PG.ProteinGroups)) {
  warning("Duplicated PG.ProteinGroups found; Protein_row remains the unique identifier.")
}

detected <- is.finite(abundance) & abundance > 0
site_prefix <- sub("_.*$", "", sample_names)
animal_id <- sub("^.*_", "", sample_names)
site_id <- unname(site_prefix_map[site_prefix])
sample_metadata <- data.frame(
  Sample = sample_names,
  Site = factor(site_id, levels = site_order),
  Animal = factor(animal_id, levels = as.character(1:6)),
  Proteins_detected = colSums(detected),
  Missing_percent = 100 * colMeans(!detected),
  Raw_abundance_sum = colSums(abundance, na.rm = TRUE),
  Raw_detected_median = apply(abundance, 2, median, na.rm = TRUE),
  row.names = sample_names,
  stringsAsFactors = FALSE
)
pairing_table <- table(sample_metadata$Animal, sample_metadata$Site)
if (!all(dim(pairing_table) == c(6L, 4L)) || !all(pairing_table == 1L)) {
  stop("Expected one sample from each of four sites for every animal.")
}

detection_by_site <- sapply(site_order, function(site_name) {
  rowSums(detected[, sample_metadata$Site == site_name, drop = FALSE])
})
colnames(detection_by_site) <- site_order
keep_main <- apply(detection_by_site >= min_detected_per_site, 1, any)
keep_complete <- rowSums(detected) == ncol(abundance)
if (sum(keep_main) < 500L) stop("Too few proteins pass the prespecified filter.")
if (sum(keep_complete) < 500L) stop("Too few complete-case proteins for sensitivity analysis.")

abundance_zero <- abundance
abundance_zero[!detected] <- 0
main_abundance <- abundance_zero[keep_main, , drop = FALSE]
main_transform <- make_bray_input(main_abundance)

sample_metadata$Retained_proteins_detected <- colSums(
  detected[keep_main, , drop = FALSE]
)
sample_metadata$Retained_abundance_sum <- colSums(main_abundance)

# PCoA with Lingoes correction ------------------------------------------------
bray_distance <- main_transform$distance
uncorrected_pcoa <- vegan::wcmdscale(bray_distance, k = 2, eig = TRUE, add = FALSE)
pcoa_fit <- vegan::wcmdscale(
  bray_distance, k = 2, eig = TRUE, add = "lingoes", x.ret = TRUE
)
positive_eigenvalues <- as.numeric(pcoa_fit$eig[pcoa_fit$eig > 0])
if (length(positive_eigenvalues) < 2L) stop("Fewer than two positive PCoA axes.")
pcoa_variance <- 100 * positive_eigenvalues / sum(positive_eigenvalues)

pcoa_coordinates <- data.frame(
  Sample = rownames(pcoa_fit$points),
  PCoA1 = pcoa_fit$points[, 1],
  PCoA2 = pcoa_fit$points[, 2],
  Site = sample_metadata[rownames(pcoa_fit$points), "Site"],
  Animal = sample_metadata[rownames(pcoa_fit$points), "Animal"],
  stringsAsFactors = FALSE
)
pcoa_coordinates$Site <- factor(pcoa_coordinates$Site, levels = site_order)
pcoa_coordinates$Animal <- factor(pcoa_coordinates$Animal, levels = as.character(1:6))

pcoa_variance_table <- data.frame(
  Axis = paste0("PCoA", seq_along(positive_eigenvalues)),
  Positive_eigenvalue = positive_eigenvalues,
  Variance_explained_percent = pcoa_variance,
  Cumulative_variance_percent = cumsum(pcoa_variance),
  stringsAsFactors = FALSE
)

centroid_confidence_ellipse <- function(data, level = 0.95, n_points = 200L) {
  xy <- as.matrix(data[, c("PCoA1", "PCoA2"), drop = FALSE])
  n <- nrow(xy)
  p <- ncol(xy)
  if (n <= p) stop("Too few samples for a two-dimensional confidence ellipse.")
  covariance_matrix <- stats::cov(xy)
  eig <- eigen(covariance_matrix, symmetric = TRUE)
  if (any(eig$values <= 0)) stop("Non-positive within-site covariance eigenvalue.")
  factor <- p * (n - 1) / (n * (n - p)) * stats::qf(level, p, n - p)
  transform <- eig$vectors %*% diag(sqrt(eig$values * factor), nrow = p)
  angles <- seq(0, 2 * pi, length.out = n_points)
  unit_circle <- cbind(cos(angles), sin(angles))
  ellipse <- sweep(unit_circle %*% t(transform), 2, colMeans(xy), "+")
  data.frame(PCoA1 = ellipse[, 1], PCoA2 = ellipse[, 2])
}

confidence_ellipses <- do.call(rbind, lapply(site_order, function(site_name) {
  out <- centroid_confidence_ellipse(
    pcoa_coordinates[pcoa_coordinates$Site == site_name, , drop = FALSE]
  )
  out$Site <- factor(site_name, levels = site_order)
  out$Point_order <- seq_len(nrow(out))
  out
}))

site_centroids <- do.call(rbind, lapply(site_order, function(site_name) {
  z <- pcoa_coordinates[pcoa_coordinates$Site == site_name, , drop = FALSE]
  data.frame(
    Site = site_name, n = nrow(z),
    PCoA1_centroid = mean(z$PCoA1), PCoA2_centroid = mean(z$PCoA2)
  )
}))

# Paired PERMANOVA and pairwise contrasts ------------------------------------
overall_permutations <- make_blocked_permutations(
  sample_metadata, n_requested_permutations, analysis_seed
)
overall_result <- run_primary_adonis(
  bray_distance, sample_metadata, overall_permutations
)
overall_result$full$Interpretation <- ifelse(
  overall_result$full$Term == "Site",
  "Primary paired Site test; marginal after Animal; permutations restricted within Animal",
  ifelse(
    overall_result$full$Term == "Animal",
    "Animal included to remove paired-animal variation; its restricted-permutation P value is not interpreted",
    "Model residual/total"
  )
)

distance_matrix <- as.matrix(bray_distance)
site_pairs <- combn(site_order, 2, simplify = FALSE)
pairwise_rows <- vector("list", length(site_pairs))
for (i in seq_along(site_pairs)) {
  pair <- site_pairs[[i]]
  keep_samples <- sample_metadata$Site %in% pair
  pair_metadata <- droplevels(sample_metadata[keep_samples, , drop = FALSE])
  pair_names <- rownames(pair_metadata)
  pair_distance <- as.dist(distance_matrix[pair_names, pair_names, drop = FALSE])
  pair_permutations <- make_blocked_permutations(
    pair_metadata, n_requested_permutations, analysis_seed + i
  )
  pair_fit <- run_primary_adonis(pair_distance, pair_metadata, pair_permutations)
  z <- pair_fit$primary
  pairwise_rows[[i]] <- data.frame(
    Contrast = paste(pair, collapse = " vs "),
    Site_1 = pair[1], Site_2 = pair[2],
    n_animals = nlevels(pair_metadata$Animal),
    n_samples = nrow(pair_metadata),
    Site_Df = z$Site_Df,
    Site_SumOfSqs = z$Site_SumOfSqs,
    Site_R2_total = z$Site_R2_total,
    Site_partial_R2 = z$Site_partial_R2,
    Pseudo_F = z$Pseudo_F,
    P_value = z$P_value,
    Requested_permutations = z$Requested_permutations,
    Permutations_used = z$Permutations_used,
    Permutation_restriction = z$Permutation_restriction,
    stringsAsFactors = FALSE
  )
}
pairwise_adonis <- do.call(rbind, pairwise_rows)
pairwise_adonis$P_FDR_BH <- p.adjust(pairwise_adonis$P_value, method = "BH")
pairwise_adonis$Significant_FDR_0.05 <- pairwise_adonis$P_FDR_BH < 0.05
pairwise_adonis <- pairwise_adonis[order(pairwise_adonis$P_FDR_BH), ]
rownames(pairwise_adonis) <- NULL

# PERMDISP diagnostic ---------------------------------------------------------
dispersion_fit <- vegan::betadisper(
  bray_distance, group = sample_metadata$Site,
  type = "median", bias.adjust = TRUE
)
set.seed(analysis_seed + 100L)
dispersion_permutation <- vegan::permutest(
  dispersion_fit, permutations = overall_permutations, pairwise = TRUE
)
dispersion_overall <- data.frame(
  Term = rownames(dispersion_permutation$tab),
  as.data.frame(dispersion_permutation$tab, check.names = FALSE),
  row.names = NULL, check.names = FALSE
)
dispersion_distances <- data.frame(
  Sample = rownames(sample_metadata),
  Site = sample_metadata$Site,
  Animal = sample_metadata$Animal,
  Distance_to_site_spatial_median = dispersion_fit$distances,
  stringsAsFactors = FALSE
)
dispersion_summary <- do.call(rbind, lapply(site_order, function(site_name) {
  z <- dispersion_fit$distances[sample_metadata$Site == site_name]
  data.frame(
    Site = site_name, n = length(z), Mean = mean(z), SD = sd(z),
    SEM = sd(z) / sqrt(length(z)), Median = median(z)
  )
}))

dispersion_pairwise <- data.frame()
if (!is.null(dispersion_permutation$pairwise)) {
  observed_p <- dispersion_permutation$pairwise$observed
  permuted_p <- dispersion_permutation$pairwise$permuted
  contrast_names <- names(permuted_p)
  split_names <- strsplit(contrast_names, "-", fixed = TRUE)
  dispersion_pairwise <- data.frame(
    Contrast = contrast_names,
    Site_1 = vapply(split_names, `[`, character(1), 1),
    Site_2 = vapply(split_names, `[`, character(1), 2),
    Parametric_P_value = as.numeric(observed_p[contrast_names]),
    Permutation_P_value = as.numeric(permuted_p[contrast_names]),
    stringsAsFactors = FALSE
  )
  dispersion_pairwise$P_FDR_BH <- p.adjust(
    dispersion_pairwise$Permutation_P_value, method = "BH"
  )
}

# Complete-case sensitivity analysis -----------------------------------------
complete_transform <- make_bray_input(abundance_zero[keep_complete, , drop = FALSE])
complete_adonis <- run_primary_adonis(
  complete_transform$distance, sample_metadata, overall_permutations
)

# Plot ------------------------------------------------------------------------
p_pcoa <- ggplot(pcoa_coordinates, aes(PCoA1, PCoA2)) +
  geom_hline(yintercept = 0, color = "#D8DADD", linewidth = 0.32) +
  geom_vline(xintercept = 0, color = "#D8DADD", linewidth = 0.32) +
  geom_polygon(
    data = confidence_ellipses,
    aes(PCoA1, PCoA2, group = Site, fill = Site),
    inherit.aes = FALSE, alpha = 0.12, color = NA, show.legend = FALSE
  ) +
  geom_path(
    data = confidence_ellipses,
    aes(PCoA1, PCoA2, group = Site, color = Site),
    inherit.aes = FALSE, linewidth = 0.62, alpha = 0.88,
    show.legend = FALSE
  ) +
  geom_point(
    aes(fill = Site), shape = 21, size = 3.2, stroke = 0.45,
    alpha = 0.92, color = "#1F2328"
  ) +
  scale_fill_manual(values = site_colors, breaks = site_order, drop = FALSE) +
  scale_color_manual(values = site_colors, breaks = site_order, drop = FALSE) +
  scale_x_continuous(expand = expansion(mult = 0.10)) +
  scale_y_continuous(expand = expansion(mult = 0.10)) +
  labs(
    x = sprintf("PCoA1 (%.1f%%)", pcoa_variance[1]),
    y = sprintf("PCoA2 (%.1f%%)", pcoa_variance[2]), fill = NULL
  ) +
  theme_bw(base_size = 10.5, base_family = "Arial") +
  theme(
    aspect.ratio = 1,
    plot.title = element_blank(),
    panel.grid = element_blank(),
    panel.border = element_rect(color = "#1F1F1F", linewidth = 0.5),
    axis.text = element_text(color = "#30363D", size = 8.5),
    axis.title = element_text(color = "#1F2328", size = 10.5),
    axis.title.x = element_text(margin = margin(t = 7)),
    axis.title.y = element_text(margin = margin(r = 7)),
    axis.ticks = element_line(color = "#1F1F1F", linewidth = 0.4),
    axis.ticks.length = unit(2, "mm"),
    legend.position = "right",
    legend.text = element_text(size = 9, color = "#1F2328"),
    legend.key = element_blank(),
    plot.margin = margin(t = 5, r = 7, b = 5, l = 7)
  ) +
  guides(fill = guide_legend(override.aes = list(
    shape = 21, size = 3.2, stroke = 0.45,
    alpha = 0.92, color = "#1F2328"
  )))

output_stub <- file.path(figure_dir, "Protein_BrayCurtis_PCoA_by_site_95CI")
ggsave(
  paste0(output_stub, ".pdf"), p_pcoa, device = cairo_pdf,
  width = plot_width_in, height = plot_height_in, units = "in", family = "Arial"
)
png(
  paste0(output_stub, ".png"), width = plot_width_in, height = plot_height_in,
  units = "in", res = 600, type = "cairo", family = "Arial", bg = "white"
)
print(p_pcoa)
dev.off()
svg(
  paste0(output_stub, ".svg"), width = plot_width_in, height = plot_height_in,
  family = "Arial", pointsize = 10.5, onefile = TRUE, bg = "white"
)
print(p_pcoa)
dev.off()

# Exports ---------------------------------------------------------------------
retained_ids <- cbind(
  protein_ids[keep_main, , drop = FALSE],
  as.data.frame(detection_by_site[keep_main, , drop = FALSE], check.names = FALSE),
  Total_samples_detected = rowSums(detected[keep_main, , drop = FALSE])
)
complete_ids <- protein_ids[keep_complete, , drop = FALSE]

write_matrix_gz(
  main_transform$abundance_ppm, protein_ids[keep_main, , drop = FALSE],
  "protein_retained_abundance_PPM.tsv.gz"
)
write_matrix_gz(
  main_transform$sqrt_abundance_ppm, protein_ids[keep_main, , drop = FALSE],
  "protein_retained_sqrt_abundance_PPM_PCoA_input.tsv.gz"
)
write_tsv(data.frame(sample_metadata, check.names = FALSE), "protein_sample_metadata_QC.tsv")
write_tsv(retained_ids, "protein_retained_for_main_PCoA.tsv")
write_tsv(complete_ids, "protein_completecase_for_sensitivity.tsv")
write_tsv(pcoa_coordinates, "protein_BrayCurtis_PCoA_sample_coordinates.tsv")
write_tsv(pcoa_variance_table, "protein_BrayCurtis_PCoA_variance_explained.tsv")
write_tsv(confidence_ellipses, "protein_PCoA_site_centroid_95CI_coordinates.tsv")
write_tsv(site_centroids, "protein_PCoA_site_centroids.tsv")
write_tsv(
  data.frame(Sample = rownames(distance_matrix), distance_matrix, check.names = FALSE),
  "protein_BrayCurtis_distance_matrix.tsv"
)
write_tsv(overall_result$primary, "protein_BrayCurtis_paired_adonis_overall.tsv")
write_tsv(overall_result$full, "protein_BrayCurtis_paired_adonis_full_model.tsv")
write_tsv(pairwise_adonis, "protein_BrayCurtis_paired_adonis_pairwise_BH.tsv")
write_tsv(dispersion_overall, "protein_BrayCurtis_PERMDISP_overall.tsv")
write_tsv(dispersion_summary, "protein_BrayCurtis_PERMDISP_site_summary.tsv")
write_tsv(dispersion_distances, "protein_BrayCurtis_PERMDISP_sample_distances.tsv")
write_tsv(dispersion_pairwise, "protein_BrayCurtis_PERMDISP_pairwise_BH.tsv")
write_tsv(
  complete_adonis$primary,
  "protein_BrayCurtis_completecase_sensitivity_adonis_overall.tsv"
)
write_tsv(
  complete_adonis$full,
  "protein_BrayCurtis_completecase_sensitivity_adonis_full_model.tsv"
)

pcoa_correction <- data.frame(
  Method = "Lingoes",
  Additive_constant = pcoa_fit$ac,
  Negative_eigenvalues_before_correction = sum(uncorrected_pcoa$eig < -1e-10),
  Sum_positive_eigenvalues = sum(positive_eigenvalues),
  stringsAsFactors = FALSE
)
write_tsv(pcoa_correction, "protein_BrayCurtis_PCoA_correction.tsv")

dispersion_p <- dispersion_overall[dispersion_overall$Term == "Groups", "Pr(>F)"]
if (!length(dispersion_p)) dispersion_p <- NA_real_
qa_manifest <- data.frame(
  Check = c(
    "Input workbook", "Input sheet", "Protein groups", "Samples", "Animals", "Sites",
    "Complete paired design", "Missing value encoding", "Minimum sample missing percent",
    "Maximum sample missing percent", "Main protein filter", "Proteins retained for main PCoA",
    "Missing-value handling", "Sample normalization", "Transformation", "Distance",
    "PCoA correction", "PCoA1 variance percent", "PCoA2 variance percent",
    "Overall paired model", "Permutation restriction", "Permutations used",
    "Overall Site R2", "Overall Site partial R2", "Overall Site P value",
    "PERMDISP Site P value", "Complete-case proteins", "Complete-case Site R2",
    "Complete-case Site P value", "Pairwise correction", "Confidence region",
    "Figure width inches", "Figure height inches", "Panel aspect ratio", "Typeface",
    "openxlsx version", "vegan version", "permute version", "ggplot2 version"
  ),
  Value = c(
    input_file, "protein", nrow(protein), ncol(abundance),
    nlevels(sample_metadata$Animal), nlevels(sample_metadata$Site), all(pairing_table == 1L),
    "NaN interpreted as not detected", min(sample_metadata$Missing_percent),
    max(sample_metadata$Missing_percent),
    "Detected in >=3 of 6 animals in at least one site", sum(keep_main),
    "Not detected set to zero after filtering", "Total retained abundance scaled to 1,000,000 per sample",
    "Square root of abundance PPM", "Bray-Curtis", "Lingoes",
    pcoa_variance[1], pcoa_variance[2], "Distance ~ Animal + Site",
    "Within Animal", nrow(overall_permutations),
    overall_result$primary$Site_R2_total, overall_result$primary$Site_partial_R2,
    overall_result$primary$P_value, dispersion_p, sum(keep_complete),
    complete_adonis$primary$Site_R2_total, complete_adonis$primary$P_value,
    "Benjamini-Hochberg FDR across six paired site contrasts",
    "95% Hotelling T-squared confidence ellipse for each site centroid; n=6 per site",
    plot_width_in, plot_height_in, 1, "Arial",
    as.character(packageVersion("openxlsx")), as.character(packageVersion("vegan")),
    as.character(packageVersion("permute")), as.character(packageVersion("ggplot2"))
  ),
  stringsAsFactors = FALSE
)
write_tsv(qa_manifest, "protein_BrayCurtis_PCoA_Adonis_QA_manifest.tsv")

saveRDS(bray_distance, file.path(table_dir, "protein_BrayCurtis_distance.rds"))
saveRDS(pcoa_fit, file.path(table_dir, "protein_BrayCurtis_PCoA_Lingoes_fit.rds"))

cat("Protein Bray-Curtis PCoA and paired Adonis completed.\n")
cat("Proteins retained:", sum(keep_main), "of", nrow(protein), "\n")
cat("Complete-case proteins:", sum(keep_complete), "\n")
cat("PCoA1:", sprintf("%.2f%%", pcoa_variance[1]), "\n")
cat("PCoA2:", sprintf("%.2f%%", pcoa_variance[2]), "\n")
cat("Overall Site R2:", overall_result$primary$Site_R2_total, "\n")
cat("Overall Site partial R2:", overall_result$primary$Site_partial_R2, "\n")
cat("Overall Site P:", overall_result$primary$P_value, "\n")
cat("PERMDISP P:", dispersion_p, "\n")
cat("Significant pairwise contrasts after BH:",
    sum(pairwise_adonis$Significant_FDR_0.05), "of", nrow(pairwise_adonis), "\n")
cat("PDF:", paste0(output_stub, ".pdf"), "\n")
