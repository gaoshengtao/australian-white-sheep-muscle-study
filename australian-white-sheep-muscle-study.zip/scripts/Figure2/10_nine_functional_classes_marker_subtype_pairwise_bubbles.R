#!/usr/bin/env Rscript

# Compact marker-level atlas for nine muscle functional classes.
# Pairwise effects are extracted from previously fitted all-feature paired
# DESeq2/limma models, so marker selection does not define the FDR universe.

rm(list = ls())
suppressPackageStartupMessages({
  library(AnnotationDbi)
  library(org.Hs.eg.db)
  library(ggplot2)
  library(openxlsx)
})
options(stringsAsFactors = FALSE)

project_dir <- "__PROJECT_ROOT__"
work_dir <- file.path(project_dir, "07_Figure2_muscle_functional_states",
                      "03_One_vs_rest_specificity")
table_dir <- file.path(work_dir, "Tables")
figure_dir <- file.path(work_dir, "Figures", "Fig2_marker_subtype_pairwise")
dir.create(table_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(figure_dir, recursive = TRUE, showWarnings = FALSE)

transcript_result_file <- file.path(
  table_dir,
  "Fig2_muscle_fiber_pairwise_transcriptome_DESeq2_all_gene_results.tsv.gz"
)
protein_result_file <- file.path(
  table_dir,
  "Fig2_muscle_fiber_pairwise_proteome_limma_all_gene_results.tsv.gz"
)
ortholog_file <- file.path(
  table_dir, "Fig2_Ensembl115_sheep_to_human_ortholog_Entrez_mapping.tsv"
)
required_files <- c(transcript_result_file, protein_result_file, ortholog_file)
missing_files <- required_files[!file.exists(required_files)]
if (length(missing_files)) {
  stop("Missing required files: ", paste(missing_files, collapse = ", "))
}

site_order <- c("LTL", "SM", "PM", "EAO")
site_colors <- c(
  LTL = "#365B8C", SM = "#4F7C71", PM = "#C28B48", EAO = "#A65D68"
)
comparison_ids <- c(
  "LTL_vs_SM", "LTL_vs_PM", "LTL_vs_EAO",
  "SM_vs_PM", "SM_vs_EAO", "PM_vs_EAO"
)
comparison_labels <- c(
  LTL_vs_SM = "LTL\nvs\nSM", LTL_vs_PM = "LTL\nvs\nPM",
  LTL_vs_EAO = "LTL\nvs\nEAO", SM_vs_PM = "SM\nvs\nPM",
  SM_vs_EAO = "SM\nvs\nEAO", PM_vs_EAO = "PM\nvs\nEAO"
)
comparison_positions <- setNames(seq_along(comparison_ids), comparison_ids)
omics_order <- c("Transcriptome", "Proteome")
fdr_threshold <- 0.05

# Deliberately compact, literature-established marker sets. These markers are
# biological representatives, not genes selected by the current P values.
marker_list <- list(
  "Muscle fiber type" = list(
    "Slow / oxidative" = c(
      "MYH7", "TNNT1", "TNNI1"
    ),
    "Fast / glycolytic" = c(
      "MYH1", "MYH2", "TNNT3"
    )
  ),
  "Contractile apparatus" = list(
    "Thick filament" = c("MYBPC1", "MYBPC2", "MYOM1"),
    "Thin filament" = c("ACTA1", "TPM1", "TPM2"),
    "Z-disc" = c("ACTN2", "ACTN3", "TCAP")
  ),
  "Calcium signaling" = list(
    "SR uptake / storage" = c("ATP2A1", "ATP2A2", "CASQ1"),
    "Release / coupling" = c("RYR1", "CACNA1S", "STAC3"),
    "Regulation / buffering" = c("PLN", "SLN", "CAMK2D")
  ),
  "Cytoskeleton" = list(
    "Dystrophin complex" = c("DMD", "DAG1", "SGCA"),
    "Costamere / integrin" = c("ITGA7", "ITGB1", "VCL"),
    "Intermediate scaffold" = c("DES", "PLEC", "FLNC")
  ),
  "ECM / collagen" = list(
    "Fibrillar collagen" = c("COL1A1", "COL1A2", "COL3A1"),
    "Basement membrane" = c("COL4A1", "LAMA2", "NID1"),
    "Remodeling / crosslink" = c("MMP2", "MMP14", "LOX")
  ),
  "Proteolysis" = list(
    "Calpain system" = c("CAPN1", "CAPN3", "CAST"),
    "Ubiquitin-proteasome" = c("TRIM63", "FBXO32", "PSMB5"),
    "Autophagy / lysosome" = c("BECN1", "SQSTM1", "CTSL")
  ),
  "Lipid metabolism" = list(
    "Uptake / transport" = c("CD36", "LPL", "FABP3"),
    "Synthesis / storage" = c("ACACA", "FASN", "SCD"),
    "Lipolysis" = c("PNPLA2", "LIPE", "MGLL"),
    "Beta-oxidation" = c("CPT1B", "ACADL", "HADHA")
  ),
  "Mitochondrial oxidation" = list(
    "TCA cycle" = c("CS", "ACO2", "OGDH"),
    "ETC / ATP synthesis" = c("NDUFS1", "COX4I1", "ATP5F1A"),
    "Biogenesis" = c("PPARGC1A", "TFAM", "ESRRA")
  ),
  "Glycolysis" = list(
    "Glycogen turnover" = c("GYS1", "PYGM", "PGM1"),
    "Glycolytic flux" = c("HK2", "PFKM", "PKM"),
    "Lactate / pH" = c("LDHA", "SLC16A1", "SLC16A3")
  )
)
class_order <- names(marker_list)

marker_rows <- list()
marker_index <- 0L
for (class_name in names(marker_list)) {
  subtype_list <- marker_list[[class_name]]
  for (subtype_name in names(subtype_list)) {
    symbols <- subtype_list[[subtype_name]]
    for (i in seq_along(symbols)) {
      marker_index <- marker_index + 1L
      marker_rows[[marker_index]] <- data.frame(
        Function_class = class_name,
        Subtype = subtype_name,
        Gene_symbol = symbols[i],
        Class_order = match(class_name, class_order),
        Subtype_order = match(subtype_name, names(subtype_list)),
        Gene_order_within_subtype = i,
        stringsAsFactors = FALSE
      )
    }
  }
}
markers <- do.call(rbind, marker_rows)

# Human symbol to Entrez mapping.
symbol_to_entrez <- AnnotationDbi::select(
  org.Hs.eg.db, keys = unique(markers$Gene_symbol), keytype = "SYMBOL",
  columns = c("SYMBOL", "ENTREZID")
)
symbol_to_entrez <- symbol_to_entrez[!is.na(symbol_to_entrez$ENTREZID), ]
symbol_to_entrez <- symbol_to_entrez[!duplicated(symbol_to_entrez$SYMBOL), ]
markers$Human_Entrez_ID <- as.character(symbol_to_entrez$ENTREZID[
  match(markers$Gene_symbol, symbol_to_entrez$SYMBOL)
])
if (anyNA(markers$Human_Entrez_ID)) {
  warning("No human Entrez mapping for: ", paste(
    markers$Gene_symbol[is.na(markers$Human_Entrez_ID)], collapse = ", "
  ))
}

# Load all-feature differential results fitted previously with paired designs.
transcript_all <- read.delim(gzfile(transcript_result_file), check.names = FALSE)
protein_all <- read.delim(gzfile(protein_result_file), check.names = FALSE)
ortholog <- read.delim(ortholog_file, check.names = FALSE)
ortholog$Human_Entrez_ID <- as.character(ortholog$Human_Entrez_ID)

# Choose one sheep transcript per human marker. Preference is high-confidence
# one-to-one orthology, then identity and abundance; the choice is independent
# of pairwise P values and therefore cannot select for significance.
transcript_reference <- unique(transcript_all[, c(
  "gene_id", "Gene_symbol", "baseMean"
)])
ortholog_candidates <- merge(
  ortholog[, c(
    "Sheep_Ensembl_gene_id", "Human_Entrez_ID", "Orthology_type",
    "Orthology_confidence", "Sheep_to_human_percent_identity"
  )],
  transcript_reference[, c("gene_id", "baseMean")],
  by.x = "Sheep_Ensembl_gene_id", by.y = "gene_id", all = FALSE
)
ortholog_candidates <- ortholog_candidates[
  ortholog_candidates$Human_Entrez_ID %in% markers$Human_Entrez_ID, ]
ortholog_candidates$One_to_one <-
  ortholog_candidates$Orthology_type == "ortholog_one2one"
ortholog_candidates$Orthology_confidence[
  is.na(ortholog_candidates$Orthology_confidence)] <- -Inf
ortholog_candidates$Sheep_to_human_percent_identity[
  is.na(ortholog_candidates$Sheep_to_human_percent_identity)] <- -Inf
ortholog_candidates$baseMean[is.na(ortholog_candidates$baseMean)] <- -Inf
ortholog_candidates <- ortholog_candidates[order(
  ortholog_candidates$Human_Entrez_ID,
  -ortholog_candidates$One_to_one,
  -ortholog_candidates$Orthology_confidence,
  -ortholog_candidates$Sheep_to_human_percent_identity,
  -ortholog_candidates$baseMean,
  ortholog_candidates$Sheep_Ensembl_gene_id
), ]
transcript_representatives <- ortholog_candidates[
  !duplicated(ortholog_candidates$Human_Entrez_ID), ]
markers$Transcript_representative_sheep_gene <-
  transcript_representatives$Sheep_Ensembl_gene_id[
    match(markers$Human_Entrez_ID,
          transcript_representatives$Human_Entrez_ID)
  ]

# Extract marker rows after full-universe BH correction.
plot_rows <- list()
row_index <- 0L
for (i in seq_len(nrow(markers))) {
  marker <- markers[i, ]
  for (comparison_id in comparison_ids) {
    pair <- strsplit(comparison_id, "_vs_", fixed = TRUE)[[1]]
    transcript_row <- transcript_all[
      transcript_all$Comparison == comparison_id &
        transcript_all$gene_id == marker$Transcript_representative_sheep_gene,
    ]
    protein_row <- protein_all[
      protein_all$Comparison == comparison_id &
        protein_all$Human_Entrez_ID == marker$Human_Entrez_ID,
    ]
    for (omics_name in omics_order) {
      z <- if (omics_name == "Transcriptome") transcript_row else protein_row
      row_index <- row_index + 1L
      plot_rows[[row_index]] <- data.frame(
        Function_class = marker$Function_class,
        Subtype = marker$Subtype,
        Gene_symbol = marker$Gene_symbol,
        Human_Entrez_ID = marker$Human_Entrez_ID,
        Transcript_representative_sheep_gene =
          marker$Transcript_representative_sheep_gene,
        Class_order = marker$Class_order,
        Subtype_order = marker$Subtype_order,
        Gene_order_within_subtype = marker$Gene_order_within_subtype,
        Site_1 = pair[1], Site_2 = pair[2], Comparison = comparison_id,
        Omics = omics_name,
        log2FoldChange = if (nrow(z)) z$log2FoldChange[1] else NA_real_,
        P_value = if (nrow(z)) z$P_value[1] else NA_real_,
        P_FDR_BH = if (nrow(z)) z$P_FDR_BH[1] else NA_real_,
        Feature_available = nrow(z) == 1L,
        stringsAsFactors = FALSE
      )
    }
  }
}
plot_data <- do.call(rbind, plot_rows)
plot_data$Significant_FDR_0.05 <- with(
  plot_data,
  Feature_available & is.finite(P_FDR_BH) & P_FDR_BH < fdr_threshold
)
plot_data$Enriched_site <- ifelse(
  !plot_data$Feature_available | !is.finite(plot_data$log2FoldChange),
  NA_character_,
  ifelse(plot_data$log2FoldChange >= 0,
         plot_data$Site_1, plot_data$Site_2)
)
plot_data$Fill_state <- ifelse(
  !plot_data$Feature_available, "Not detected",
  ifelse(plot_data$Significant_FDR_0.05,
         plot_data$Enriched_site, "Not significant")
)
plot_data$Absolute_log2FC <- ifelse(
  plot_data$Feature_available & is.finite(plot_data$log2FoldChange),
  abs(plot_data$log2FoldChange), 0
)
plot_data$X <- unname(comparison_positions[plot_data$Comparison]) +
  ifelse(plot_data$Omics == "Transcriptome", -0.105, 0.105)

fill_colors <- c(
  site_colors, `Not significant` = "#D9D9D9", `Not detected` = "white"
)

gene_order_top_to_bottom <- markers$Gene_symbol[order(
  markers$Class_order, markers$Subtype_order,
  markers$Gene_order_within_subtype
)]
subtype_order <- unique(markers$Subtype[order(
  markers$Class_order, markers$Subtype_order
)])
plot_data$Gene_axis_label <- ifelse(
  plot_data$Gene_order_within_subtype == 1L,
  paste0(plot_data$Gene_symbol, "  [", plot_data$Subtype, "]"),
  plot_data$Gene_symbol
)
gene_axis_reference <- unique(plot_data[, c(
  "Function_class", "Gene_symbol", "Gene_axis_label", "Class_order",
  "Subtype_order", "Gene_order_within_subtype"
)])
gene_axis_reference <- gene_axis_reference[order(
  gene_axis_reference$Class_order, gene_axis_reference$Subtype_order,
  gene_axis_reference$Gene_order_within_subtype
), ]
gene_axis_reference$Y_position <- rev(seq_len(nrow(gene_axis_reference)))
plot_data$Y_position <- gene_axis_reference$Y_position[match(
  paste(plot_data$Function_class, plot_data$Gene_symbol),
  paste(gene_axis_reference$Function_class, gene_axis_reference$Gene_symbol)
)]
plot_data$Function_class <- factor(
  plot_data$Function_class, levels = class_order
)
plot_data$Subtype <- factor(plot_data$Subtype, levels = subtype_order)
plot_data$Comparison <- factor(plot_data$Comparison, levels = comparison_ids)
plot_data$Omics <- factor(plot_data$Omics, levels = omics_order)
available_plot <- plot_data[plot_data$Feature_available, ]
missing_plot <- plot_data[!plot_data$Feature_available, ]
maximum_effect <- max(available_plot$Absolute_log2FC, na.rm = TRUE)
if (!is.finite(maximum_effect) || maximum_effect <= 0) maximum_effect <- 1
size_breaks <- pretty(c(0, maximum_effect), n = 4)
size_breaks <- size_breaks[size_breaks >= 0 & size_breaks <= maximum_effect]
size_breaks <- sort(unique(c(0, size_breaks)))

# One integrated figure. Each major class forms one continuous row block; the
# first marker in each subtype carries the subtype label on the gene axis.
p <- ggplot() +
  geom_vline(
    xintercept = seq_along(comparison_ids), color = "#E3E4E6",
    linewidth = 0.28
  ) +
  geom_point(
    data = available_plot,
    aes(x = X, y = Y_position, size = Absolute_log2FC,
        fill = Fill_state, shape = Omics),
    color = "#3E4145", stroke = 0.40, alpha = 0.96
  ) +
  geom_point(
    data = missing_plot,
    aes(x = X, y = Y_position, shape = Omics, fill = Fill_state),
    size = 1.25, color = "#777B80", stroke = 0.44
  ) +
  facet_grid(
    rows = vars(Function_class), scales = "free_y",
    space = "free_y", switch = "y", drop = TRUE
  ) +
  scale_fill_manual(
    name = "FDR < 0.05:\nenriched site", values = fill_colors,
    limits = names(fill_colors),
    breaks = c(site_order, "Not significant", "Not detected"),
    drop = FALSE,
    guide = guide_legend(
      order = 1,
      override.aes = list(shape = 21, size = 2.8,
                          color = "#3E4145", stroke = 0.40)
    )
  ) +
  scale_shape_manual(
    name = "Omics", values = c(Transcriptome = 21, Proteome = 22),
    drop = FALSE, guide = guide_legend(order = 2)
  ) +
  scale_size_area(
    name = "|log2FC|", max_size = 5.1,
    limits = c(0, maximum_effect), breaks = size_breaks,
    guide = guide_legend(order = 3)
  ) +
  scale_x_continuous(
    breaks = seq_along(comparison_ids),
    labels = unname(comparison_labels[comparison_ids]),
    limits = c(0.62, length(comparison_ids) + 0.38),
    position = "top", expand = c(0, 0)
  ) +
  scale_y_continuous(
    breaks = gene_axis_reference$Y_position,
    labels = gene_axis_reference$Gene_axis_label,
    expand = expansion(add = c(0.38, 0.38))
  ) +
  labs(x = NULL, y = NULL) +
  theme_bw(base_size = 10.5, base_family = "Arial") +
  theme(
    plot.title = element_blank(), plot.subtitle = element_blank(),
    plot.caption = element_blank(), panel.grid = element_blank(),
    panel.border = element_rect(color = "#25282C", linewidth = 0.38),
    panel.spacing.y = unit(1.1, "mm"),
    strip.placement = "outside",
    strip.background.y = element_rect(
      fill = "#F1F1F1", color = "#B8BABD", linewidth = 0.32
    ),
    strip.text.y.left = element_text(
      angle = 90, face = "bold", size = 7.4, color = "#303338",
      margin = margin(2.0, 2.0, 2.0, 2.0)
    ),
    axis.text.x.top = element_text(
      face = "bold", size = 8.8, color = "#25282C", lineheight = 0.84,
      margin = margin(b = 4)
    ),
    axis.text.y = element_text(size = 7.5, color = "#25282C"),
    axis.ticks = element_blank(),
    legend.position = "right", legend.box = "vertical",
    legend.title = element_text(size = 8.1, face = "bold"),
    legend.text = element_text(size = 7.4),
    legend.key.height = unit(3.4, "mm"),
    legend.key.width = unit(3.7, "mm"),
    plot.margin = margin(4, 5, 4, 4)
  )

plot_width <- 10.2
plot_height <- 19.0
output_stub <- file.path(
  figure_dir,
  "Fig2_all9_marker_subtype_pairwise_RNA_protein_combined"
)
ggsave(
  paste0(output_stub, ".pdf"), p, device = cairo_pdf,
  width = plot_width, height = plot_height, units = "in", family = "Arial"
)
png(
  paste0(output_stub, ".png"), width = plot_width, height = plot_height,
  units = "in", res = 450, type = "cairo", family = "Arial", bg = "white"
)
print(p)
dev.off()
svg(
  paste0(output_stub, ".svg"), width = plot_width, height = plot_height,
  family = "Arial", pointsize = 10.5, onefile = TRUE, bg = "white"
)
print(p)
dev.off()

figure_qa <- data.frame(
  Function_classes = length(class_order),
  Subtypes = length(subtype_order),
  Marker_rows = nrow(markers),
  Unique_marker_symbols = length(unique(markers$Gene_symbol)),
  Maximum_absolute_log2FC = maximum_effect,
  Figure_width_inches = plot_width,
  Figure_height_inches = plot_height,
  PDF = paste0(output_stub, ".pdf"),
  stringsAsFactors = FALSE
)

# Export exact statistics, mappings, detection and design documentation.
marker_availability <- unique(plot_data[, c(
  "Function_class", "Subtype", "Gene_symbol", "Human_Entrez_ID",
  "Transcript_representative_sheep_gene", "Omics", "Feature_available"
)])
availability_summary <- aggregate(
  Feature_available ~ Function_class + Subtype + Omics,
  marker_availability, sum
)
names(availability_summary)[4] <- "Markers_available"
availability_total <- aggregate(
  Gene_symbol ~ Function_class + Subtype, markers, length
)
names(availability_total)[3] <- "Markers_defined"
availability_summary <- merge(
  availability_summary, availability_total,
  by = c("Function_class", "Subtype"), all.x = TRUE
)
significance_counts <- aggregate(
  Significant_FDR_0.05 ~ Function_class + Subtype + Comparison + Omics,
  plot_data, sum
)
names(significance_counts)[5] <- "Significant_markers_FDR_lt_0.05"

qa <- data.frame(
  Metric = c(
    "Functional classes", "Marker subtypes", "Unique marker symbols",
    "Pairwise comparisons", "Paired design", "Transcript model",
    "Protein model", "FDR family", "log2FC orientation", "Bubble size",
    "Significant fill", "Nonsignificant fill", "Missing modality",
    "Marker selection", "Typeface"
  ),
  Value = c(
    length(class_order), length(unique(paste(markers$Function_class,
                                             markers$Subtype))),
    length(unique(markers$Gene_symbol)), length(comparison_ids),
    "Animal + Site",
    "DESeq2 Wald contrasts from the all-filtered-gene paired model",
    "limma eBayes contrasts from the all-filtered-protein paired model",
    "BH across all tested features within each omics and comparison; markers extracted afterward",
    "Site_1 minus Site_2; positive means higher in Site_1",
    "Absolute log2 fold change on one shared RNA/protein scale per functional class",
    "Color of the higher-abundance site when FDR < 0.05",
    "Light gray", "Small hollow symbol",
    "A priori canonical markers, not selected from current differential P values",
    "Arial"
  ), stringsAsFactors = FALSE
)

markers_export <- markers[, c(
  "Function_class", "Subtype", "Gene_symbol", "Human_Entrez_ID",
  "Transcript_representative_sheep_gene", "Class_order", "Subtype_order",
  "Gene_order_within_subtype"
)]
plot_export <- plot_data[order(
  plot_data$Class_order, plot_data$Subtype_order,
  plot_data$Gene_order_within_subtype,
  match(plot_data$Comparison, comparison_ids),
  match(plot_data$Omics, omics_order)
), ]

write.table(
  markers_export,
  file.path(table_dir, "Fig2_all9_marker_subtype_definitions.tsv"),
  sep = "\t", quote = FALSE, row.names = FALSE, na = "NA"
)
write.table(
  plot_export,
  file.path(table_dir,
            "Fig2_all9_marker_subtype_pairwise_RNA_protein_results.tsv"),
  sep = "\t", quote = FALSE, row.names = FALSE, na = "NA"
)
write.table(
  availability_summary,
  file.path(table_dir, "Fig2_all9_marker_subtype_availability.tsv"),
  sep = "\t", quote = FALSE, row.names = FALSE, na = "NA"
)
write.table(
  significance_counts,
  file.path(table_dir, "Fig2_all9_marker_subtype_significance_counts.tsv"),
  sep = "\t", quote = FALSE, row.names = FALSE, na = "NA"
)
write.table(
  figure_qa,
  file.path(table_dir, "Fig2_all9_marker_subtype_figure_QA.tsv"),
  sep = "\t", quote = FALSE, row.names = FALSE, na = "NA"
)
openxlsx::write.xlsx(
  list(
    Marker_definitions = markers_export,
    Pairwise_results = plot_export,
    Marker_availability = marker_availability,
    Availability_summary = availability_summary,
    Significant_counts = significance_counts,
    Figure_QA = figure_qa,
    Methods_QA = qa
  ),
  file.path(table_dir,
            "Fig2_all9_marker_subtype_pairwise_RNA_protein_results.xlsx"),
  overwrite = TRUE
)

cat("Nine-class marker subtype analysis completed.\n")
cat("Classes:", length(class_order), "\n")
cat("Subtypes:", nrow(unique(markers[, c("Function_class", "Subtype")])),
    "\n")
cat("Marker rows:", nrow(markers), "\n")
cat("Unique marker symbols:", length(unique(markers$Gene_symbol)), "\n")
cat("Pairwise result rows:", nrow(plot_export), "\n")
cat("\nAvailability summary:\n")
print(availability_summary)
cat("\nFigure QA:\n")
print(figure_qa)
cat("\nCombined PDF:", paste0(output_stub, ".pdf"), "\n")
